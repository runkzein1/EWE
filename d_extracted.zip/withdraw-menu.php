<?php
// Aktifkan error reporting dan logging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data user
$user_query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "User tidak ditemukan.";
    header("Location: login.php");
    exit;
}

$user = $result->fetch_assoc();
$balance = $user['balance'] ?? 0;

// Proses permintaan penarikan saldo
$withdrawal_message = '';
$withdrawal_success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['withdraw_amount'])) {
    $amount = (float)$_POST['withdraw_amount'];
    $bank_name = $_POST['bank_name'] ?? '';
    $account_number = $_POST['account_number'] ?? '';
    $account_name = $_POST['account_name'] ?? '';
    $notes = $_POST['notes'] ?? '';
    
    // Validasi
    if ($amount <= 0) {
        $withdrawal_message = '<div class="alert alert-danger">Jumlah penarikan harus lebih dari 0.</div>';
    } elseif ($amount > $balance) {
        $withdrawal_message = '<div class="alert alert-danger">Saldo tidak mencukupi untuk melakukan penarikan.</div>';
    } elseif (empty($bank_name) || empty($account_number) || empty($account_name)) {
        $withdrawal_message = '<div class="alert alert-danger">Mohon lengkapi data bank untuk penarikan.</div>';
    } else {
        // Buat transaksi penarikan
        $withdrawal_sql = "INSERT INTO transactions (user_id, type, amount, status, bank_name, account_number, account_name, notes) 
                           VALUES (?, 'withdrawal', ?, 'pending', ?, ?, ?, ?)";
        $stmt = $conn->prepare($withdrawal_sql);
        $stmt->bind_param("idssss", $user_id, $amount, $bank_name, $account_number, $account_name, $notes);
        
        if ($stmt->execute()) {
            // Kurangi balance
            $update_balance_sql = "UPDATE users SET balance = balance - ? WHERE user_id = ?";
            $stmt = $conn->prepare($update_balance_sql);
            $stmt->bind_param("di", $amount, $user_id);
            
            if ($stmt->execute()) {
                $withdrawal_success = true;
                $withdrawal_message = '<div class="alert alert-success">
                    <i class="fa fa-check-circle me-2"></i>Permintaan penarikan berhasil diajukan. Admin akan memproses dalam 1-2 hari kerja.
                </div>';
                // Update balance variable
                $balance -= $amount;
            } else {
                $withdrawal_message = '<div class="alert alert-danger">Gagal memperbarui saldo. Silakan coba lagi.</div>';
            }
        } else {
            $withdrawal_message = '<div class="alert alert-danger">Gagal membuat transaksi penarikan. Silakan coba lagi.</div>';
        }
    }
}

// Ambil riwayat penarikan
$withdrawals_sql = "SELECT * FROM transactions WHERE user_id = ? AND type = 'withdrawal' ORDER BY created_at DESC LIMIT 5";
$stmt = $conn->prepare($withdrawals_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$withdrawals_result = $stmt->get_result();

// Aktifkan flag untuk halaman dashboard dan tema ultra-modern
$page_title = "Penarikan Saldo";
$is_dashboard_page = true;
$use_ultra_modern = true;
$use_premium_effects = true;
$modern_js_files = true;

// CSS tambahan untuk halaman ini
$page_specific_css = '<link href="css/withdraw-premium.css" rel="stylesheet" type="text/css">';

// JS tambahan untuk halaman ini
$page_specific_js = '<script src="js/withdraw-modern.js"></script>';

// Include header
include('includes/header.php');
?>

<div class="dashboard-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="page-title">Penarikan Saldo</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                        <li class="breadcrumb-item"><a href="account.php">Akun Saya</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Penarikan Saldo</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container py-5">
    <div class="row">
        <!-- Menu Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="account-menu-card">
                <div class="user-profile mb-4">
                    <div class="user-avatar">
                        <div class="avatar-text">
                            <?php echo strtoupper(substr($user['username'] ?? 'U', 0, 1)); ?>
                        </div>
                    </div>
                    <div class="user-info mt-2">
                        <h5 class="mb-1"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h5>
                        <p class="text-muted mb-0">ID: <?php echo $user['user_id']; ?></p>
                    </div>
                </div>
                
                <div class="menu-items">
                    <a href="account.php" class="menu-item">
                        <i class="fa fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="topup-menu.php" class="menu-item">
                        <i class="fa fa-wallet"></i> Top-up Saldo
                    </a>
                    <a href="withdraw-menu.php" class="menu-item active">
                        <i class="fa fa-money-bill-wave"></i> Tarik Saldo
                    </a>
                    <a href="transactions-menu.php" class="menu-item">
                        <i class="fa fa-history"></i> Riwayat Transaksi
                    </a>
                    <a href="bids-menu.php" class="menu-item">
                        <i class="fa fa-gavel"></i> Bid Saya
                    </a>
                    <a href="profile-menu.php" class="menu-item">
                        <i class="fa fa-user"></i> Profil
                    </a>
                    <a href="?logout=true" class="menu-item">
                        <i class="fa fa-sign-out-alt"></i> Keluar
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-lg-9">
            <div class="row">
                <div class="col-md-8">
                    <!-- Withdrawal Form -->
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><i class="fa fa-money-bill-wave me-2"></i>Penarikan Saldo</h5>
                        </div>
                        <div class="card-body">
                            <?php echo $withdrawal_message; ?>
                            
                            <?php if ($withdrawal_success): ?>
                                <div class="success-animation">
                                    <div class="checkmark-circle">
                                        <div class="checkmark draw"></div>
                                    </div>
                                    <h4 class="text-center mt-4">Penarikan Berhasil Diajukan!</h4>
                                    <p class="text-center text-muted">Permintaan penarikan Anda sedang diproses. Admin akan mengirim dana ke rekening bank Anda dalam 1-2 hari kerja.</p>
                                    <div class="text-center mt-4">
                                        <a href="transactions-menu.php" class="btn btn-outline-primary">Lihat Riwayat Transaksi</a>
                                    </div>
                                </div>
                            <?php else: ?>
                                <form id="withdrawalForm" method="POST" action="">
                                    <div class="mb-4">
                                        <label for="current_balance" class="form-label">Saldo Saat Ini</label>
                                        <div class="balance-display">
                                            <span class="currency">Rp</span>
                                            <span class="amount"><?php echo number_format($balance, 0, ',', '.'); ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="withdraw_amount" class="form-label">Jumlah Penarikan</label>
                                        <div class="input-group">
                                            <span class="input-group-text">Rp</span>
                                            <input type="number" class="form-control" id="withdraw_amount" name="withdraw_amount" placeholder="Masukkan jumlah" required>
                                        </div>
                                        <div class="form-text">Minimal penarikan Rp 50.000</div>
                                    </div>
                                    
                                    <div class="withdraw-presets mb-4">
                                        <button type="button" class="preset-btn" data-amount="100000">Rp 100.000</button>
                                        <button type="button" class="preset-btn" data-amount="500000">Rp 500.000</button>
                                        <button type="button" class="preset-btn" data-amount="1000000">Rp 1.000.000</button>
                                        <button type="button" class="preset-btn" data-amount="5000000">Rp 5.000.000</button>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="bank_name" class="form-label">Bank Tujuan</label>
                                        <select class="form-select" id="bank_name" name="bank_name" required>
                                            <option value="">Pilih Bank</option>
                                            <option value="BCA">BCA</option>
                                            <option value="Mandiri">Mandiri</option>
                                            <option value="BNI">BNI</option>
                                            <option value="BRI">BRI</option>
                                            <option value="CIMB Niaga">CIMB Niaga</option>
                                            <option value="BTN">BTN</option>
                                            <option value="Permata">Permata</option>
                                            <option value="Danamon">Danamon</option>
                                            <option value="Other">Bank Lainnya</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="account_number" class="form-label">Nomor Rekening</label>
                                        <input type="text" class="form-control" id="account_number" name="account_number" placeholder="Contoh: 1234567890" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="account_name" class="form-label">Nama Pemilik Rekening</label>
                                        <input type="text" class="form-control" id="account_name" name="account_name" placeholder="Contoh: John Doe" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="notes" class="form-label">Catatan (Opsional)</label>
                                        <textarea class="form-control" id="notes" name="notes" rows="2" placeholder="Tambahkan catatan jika diperlukan"></textarea>
                                    </div>
                                    
                                    <div class="withdrawal-info alert alert-info">
                                        <h6><i class="fa fa-info-circle me-2"></i>Informasi Penarikan</h6>
                                        <ul class="mb-0">
                                            <li>Minimal penarikan adalah Rp 50.000</li>
                                            <li>Penarikan akan diproses dalam 1-2 hari kerja</li>
                                            <li>Pastikan data bank yang diisi sudah benar</li>
                                            <li>Biaya admin akan dibebankan sesuai kebijakan bank tujuan</li>
                                        </ul>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary btn-lg w-100" id="withdrawSubmitBtn">
                                        <i class="fa fa-paper-plane me-2"></i>Ajukan Penarikan
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <!-- Saldo Card -->
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="saldo-card">
                                <div class="saldo-icon">
                                    <i class="fa fa-wallet"></i>
                                </div>
                                <div class="saldo-label">Saldo Tersedia</div>
                                <div class="saldo-amount">Rp <?php echo number_format($balance, 0, ',', '.'); ?></div>
                                <a href="topup-menu.php" class="btn btn-sm btn-outline-primary mt-2">
                                    <i class="fa fa-plus-circle me-1"></i>Top Up
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Recent Withdrawals -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="fa fa-history me-2"></i>Penarikan Terakhir</h5>
                        </div>
                        <div class="card-body p-0">
                            <?php if (!$withdrawals_result || $withdrawals_result->num_rows == 0): ?>
                                <div class="empty-state p-4 text-center">
                                    <div class="empty-state-icon mb-3">
                                        <i class="fa fa-money-bill-wave fa-2x text-muted"></i>
                                    </div>
                                    <p class="text-muted">Belum ada riwayat penarikan.</p>
                                </div>
                            <?php else: ?>
                                <div class="list-group list-group-flush">
                                    <?php while ($withdrawal = $withdrawals_result->fetch_assoc()): ?>
                                        <div class="list-group-item">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <span class="d-block">Rp <?php echo number_format($withdrawal['amount'], 0, ',', '.'); ?></span>
                                                    <small class="text-muted"><?php echo date('d M Y', strtotime($withdrawal['created_at'])); ?></small>
                                                </div>
                                                <?php
                                                switch ($withdrawal['status']) {
                                                    case 'completed':
                                                        echo '<span class="badge bg-success">Selesai</span>';
                                                        break;
                                                    case 'pending':
                                                        echo '<span class="badge bg-warning">Proses</span>';
                                                        break;
                                                    case 'rejected':
                                                        echo '<span class="badge bg-danger">Ditolak</span>';
                                                        break;
                                                    default:
                                                        echo '<span class="badge bg-secondary">' . ucfirst($withdrawal['status']) . '</span>';
                                                }
                                                ?>
                                            </div>
                                            <?php if (!empty($withdrawal['bank_name']) && !empty($withdrawal['account_number'])): ?>
                                                <small class="text-muted d-block mt-1">
                                                    <?php echo $withdrawal['bank_name']; ?> - <?php echo substr($withdrawal['account_number'], 0, 4) . '****' . substr($withdrawal['account_number'], -4); ?>
                                                </small>
                                            <?php endif; ?>
                                        </div>
                                    <?php endwhile; ?>
                                </div>
                                <div class="card-footer text-center">
                                    <a href="transactions-menu.php" class="text-primary">Lihat Semua Penarikan</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
