<?php
/**
 * Modern Account Dashboard
 * LelangMobil Web App - Versi 2025
 */

// Aktifkan error reporting dan logging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 90);

// --- CONFIGURATION & INITIALIZATION ---
// Detect the environment and set appropriate paths
$doc_root = $_SERVER['DOCUMENT_ROOT'];
$script_dir = dirname(__FILE__);

// If we're in the /lelang/public_html/ environment (production server)
if (strpos($script_dir, '/lelang/public_html') !== false) {
    define('ROOT_PATH', '/lelang/public_html/');
    define('CONFIG_PATH', ROOT_PATH . 'config/');
    define('INCLUDES_PATH', ROOT_PATH . 'includes/');
}
// If we're in local development environment
else if (strpos($script_dir, 'MUDDING UNDERGROUND') !== false || strpos($script_dir, 'd_extracted') !== false) {
    define('ROOT_PATH', dirname(__FILE__) . '/');
    define('CONFIG_PATH', ROOT_PATH . 'config/');
    define('INCLUDES_PATH', ROOT_PATH . 'includes/');
}
// Default fallback
else {
    define('ROOT_PATH', dirname(__FILE__) . '/');
    define('CONFIG_PATH', ROOT_PATH . 'config/');
    define('INCLUDES_PATH', ROOT_PATH . 'includes/');
}

// Create directories if they don't exist (for first setup)
$can_create_dirs = (strpos($script_dir, '/lelang/public_html') === false);

// Only attempt to create directories if we're likely to have permission
if ($can_create_dirs) {
    if (!is_dir(INCLUDES_PATH)) {
        @mkdir(INCLUDES_PATH, 0755, true);
    }
    if (!is_dir(CONFIG_PATH)) {
        @mkdir(CONFIG_PATH, 0755, true);
    }
    if (!is_dir(INCLUDES_PATH . 'account_tabs')) {
        @mkdir(INCLUDES_PATH . 'account_tabs', 0755, true);
    }
}

// Load essential helpers, configuration, and database connection
$required_files = [
    'config.php',
    'database.php',
    'functions.php',
    'session_handler.php'
];

// First, check if any of the required files are missing
$missing_files = [];
foreach ($required_files as $file) {
    if (!file_exists(CONFIG_PATH . $file)) {
        $missing_files[] = $file;
    }
}

// If files are missing, show an informative error message instead of crashing
if (!empty($missing_files)) {
    echo "<h2>Website Setup Required</h2>";
    echo "<p>The following required files are missing:</p><ul>";
    foreach ($missing_files as $file) {
        echo "<li>" . htmlspecialchars(CONFIG_PATH . $file) . "</li>";
    }
    echo "</ul>";
    echo "<p>Please create these files or contact your system administrator.</p>";

    // Create minimal placeholder files to prevent future errors (only in development mode)
    if (isset($_GET['setup']) && $_GET['setup'] == 'init' && $can_create_dirs) {
        echo "<h3>Creating minimal placeholder files...</h3>";

        // Create minimal config.php
        if (in_array('config.php', $missing_files)) {
            $config_content = "<?php\n// Auto-generated minimal config file\ndefine('BASE_URL', '//');\n\n// Database configuration\ndefine('DB_HOST', 'localhost');\ndefine('DB_USER', 'lelang_rz');\ndefine('DB_PASS', 'Arunk@123');\ndefine('DB_NAME', 'lelang_rz');\n?>";
            if (@file_put_contents(CONFIG_PATH . 'config.php', $config_content)) {
                echo "<p>Created minimal config.php</p>";
            } else {
                echo "<p class='text-danger'>Failed to create config.php due to permission issues</p>";
            }
        }

        // Create minimal database.php
        if (in_array('database.php', $missing_files)) {
            $db_content = "<?php\n// Auto-generated minimal database file\n\n// Database connection constants\nif (!defined('DB_SERVER')) define('DB_SERVER', 'localhost');\nif (!defined('DB_USERNAME')) define('DB_USERNAME', 'lelang_rz');\nif (!defined('DB_PASSWORD')) define('DB_PASSWORD', 'Arunk@123');\nif (!defined('DB_NAME')) define('DB_NAME', 'lelang_rz');\n\n// Create connection\n\$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);\n\n// Check connection\nif (\$conn->connect_error) {\n    die('Database connection failed: ' . \$conn->connect_error);\n}\n?>";
            if (@file_put_contents(CONFIG_PATH . 'database.php', $db_content)) {
                echo "<p>Created minimal database.php</p>";
            } else {
                echo "<p class='text-danger'>Failed to create database.php due to permission issues</p>";
            }
        }

        // Create minimal functions.php
        if (in_array('functions.php', $missing_files)) {
            $functions_content = "<?php\n// Auto-generated minimal functions file\nfunction sanitize_input(\$input) {\n    return htmlspecialchars(trim(\$input), ENT_QUOTES, 'UTF-8');\n}\n\nfunction redirect_to(\$url) {\n    header('Location: ' . \$url);\n    exit;\n}\n\nfunction log_error(\$message) {\n    error_log(\$message);\n}\n\nfunction get_user_data(\$db, \$user_id) {\n    // Minimal implementation\n    return ['username' => 'user'.\$user_id, 'full_name' => 'Demo User', 'email' => 'user'.\$user_id.'@example.com'];\n}\n\nfunction get_user_wallet(\$db, \$user_id) {\n    // Minimal implementation\n    return ['balance' => 1000000];\n}\n\nfunction get_user_active_bids(\$db, \$user_id) {\n    // Minimal implementation\n    return [];\n}\n\nfunction get_user_transactions(\$db, \$user_id, \$limit = 10) {\n    // Minimal implementation\n    return [];\n}\n?>";
            if (@file_put_contents(CONFIG_PATH . 'functions.php', $functions_content)) {
                echo "<p>Created minimal functions.php</p>";
            } else {
                echo "<p class='text-danger'>Failed to create functions.php due to permission issues</p>";
            }
        }

        // Create minimal session_handler.php
        if (in_array('session_handler.php', $missing_files)) {
            $session_content = "<?php\n// Auto-generated minimal session handler file\nif (session_status() === PHP_SESSION_NONE) {\n    session_start();\n}\n\nfunction is_user_logged_in() {\n    // For demonstration only - always consider logged in in dev mode\n    if (!isset(\$_SESSION['user_id'])) {\n        \$_SESSION['user_id'] = 1; // Demo user ID\n    }\n    return true;\n}\n?>";
            if (@file_put_contents(CONFIG_PATH . 'session_handler.php', $session_content)) {
                echo "<p>Created minimal session_handler.php</p>";
            } else {
                echo "<p class='text-danger'>Failed to create session_handler.php due to permission issues</p>";
            }
        }

        echo "<p>Refresh the page to continue setup. If you are on production, please manually create config files.</p>";
        exit;
    }

    echo "<p><a href='?setup=init' class='btn btn-primary'>Initialize Basic Files</a> (Development mode only)</p>";
    echo "<p><strong>Administrator Note:</strong> If you're on a production server, please manually create the config files.</p>";
    exit;
}

// Now safely require the files
try {
    require_once CONFIG_PATH . 'config.php';
    require_once CONFIG_PATH . 'database.php';
    require_once CONFIG_PATH . 'functions.php';
    require_once CONFIG_PATH . 'session_handler.php';
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<h4>Error Loading Configuration</h4>";
    echo "<p>An error occurred while loading configuration files: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Please contact your system administrator.</p>";
    echo "</div>";
    exit;
}

// Start session and check authentication
if (!is_user_logged_in()) {
    redirect_to(BASE_URL . 'login.php');
    exit;
}

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// --- DATA RETRIEVAL ---
$user_id = $_SESSION['user_id'];
$user_data = get_user_data($conn, $user_id);
$user_wallet = get_user_wallet($conn, $user_id);
$user_bids = get_user_active_bids($conn, $user_id);

// Determine active tab early for conditional data fetching
$current_active_tab_for_data = sanitize_input($_GET['tab'] ?? 'profile');

// Fetch transactions based on active tab
if ($current_active_tab_for_data === 'transactions') {
    $user_transactions = get_user_transactions($conn, $user_id, 100);
} else {
    $user_transactions = get_user_transactions($conn, $user_id, 10);
}

if (!$user_data) {
    log_error("User data not found for user_id: {$user_id} in account.php");
    redirect_to(BASE_URL . 'error.php?code=user_not_found');
    exit;
}

// --- POST REQUEST HANDLING ---
$feedback_message = '';
$feedback_type = ''; // 'success' or 'error'

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $feedback_message = 'Invalid request (CSRF token mismatch). Please try again.';
        $feedback_type = 'error';
        log_error("CSRF token mismatch for user_id: {$user_id}");
    } else {
        $action = $_POST['action'] ?? '';

        switch ($action) {
            case 'update_profile':
                // Profile update logic
                $feedback_message = 'Profile updated successfully.';
                $feedback_type = 'success';
                break;

            case 'change_password':
                // Password change logic
                $feedback_message = 'Password changed successfully.';
                $feedback_type = 'success';
                break;

            case 'update_preferences':
                // Preferences update logic
                $feedback_message = 'Preferences updated successfully.';
                $feedback_type = 'success';
                break;

            default:
                $feedback_message = 'Unknown action requested.';
                $feedback_type = 'error';
                log_error("Unknown POST action '{$action}' requested by user_id: {$user_id}");
                break;
        }
    }
}

// --- UI DATA PREPARATION ---
$page_title = "My Account - " . htmlspecialchars($user_data['full_name'] ?? 'User');
// Determine active tab from GET parameter, default to 'profile'
$active_tab = $current_active_tab_for_data;
$allowed_tabs = ['profile', 'security', 'wallet', 'bids', 'transactions', 'preferences'];
if (!in_array($active_tab, $allowed_tabs)) {
    $active_tab = 'profile'; // Default to profile if tab is invalid
}

// Aktifkan flag untuk halaman dashboard dan tema modern
$is_dashboard_page = true;
$use_ultra_modern = true;
$use_premium_effects = true;
$use_modern_2025 = true;

// Include header
include_once ROOT_PATH . 'includes/header.php';
?>

<div class="container mt-4 account-container modern-2025-theme">
    <header class="account-header mb-4 p-3 bg-light rounded shadow-sm">
        <h1><?php echo $page_title; ?></h1>
        <p class="lead">Welcome back, <?php echo htmlspecialchars($user_data['username'] ?? 'User'); ?>!</p>
    </header>

    <?php if ($feedback_message): ?>
    <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($feedback_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <div class="row">
        <aside class="col-md-3 account-sidebar">
            <div class="list-group">
                <a class="list-group-item list-group-item-action <?php echo $active_tab === 'profile' ? 'active' : ''; ?>" href="?tab=profile">Profile Settings</a>
                <a class="list-group-item list-group-item-action <?php echo $active_tab === 'security' ? 'active' : ''; ?>" href="?tab=security">Security & Password</a>
                <a class="list-group-item list-group-item-action <?php echo $active_tab === 'wallet' ? 'active' : ''; ?>" href="?tab=wallet">My Wallet</a>
                <a class="list-group-item list-group-item-action <?php echo $active_tab === 'bids' ? 'active' : ''; ?>" href="?tab=bids">My Bids</a>
                <a class="list-group-item list-group-item-action <?php echo $active_tab === 'transactions' ? 'active' : ''; ?>" href="?tab=transactions">Transaction History</a>
                <a class="list-group-item list-group-item-action <?php echo $active_tab === 'preferences' ? 'active' : ''; ?>" href="?tab=preferences">Site Preferences</a>
                <a class="list-group-item list-group-item-action text-danger" href="<?php echo htmlspecialchars(BASE_URL); ?>logout.php">Logout</a>
            </div>
        </aside>

        <main class="col-md-9 account-content">
            <div class="card">
                <div class="card-body">
                    <?php
                    // Tab-based content loading
                    $tab_file = ROOT_PATH . 'includes/account_tabs/' . $active_tab . '.php';
                    if (file_exists($tab_file)) {
                        include $tab_file;
                    } else {
                        // Fallback if the specific tab file doesn't exist
                        log_error("Account tab file not found: {$tab_file}");
                        echo "<div class='alert alert-warning'>The selected section ('" . htmlspecialchars($active_tab) . "') is currently unavailable.</div>";
                    }
                    ?>
                </div>
            </div>
        </main>
    </div>
</div>

<?php
// Include footer
include_once ROOT_PATH . 'includes/footer.php';
?>
