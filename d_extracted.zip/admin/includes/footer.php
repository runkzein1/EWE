                </div>
            </div>
        </div>
    </div>
    
    <!-- Javascript Files -->
    <script src="../js/plugins.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/designesia.js"></script>
    <script src="../js/custom.js"></script>
    
    <?php if (isset($page_specific_js)): ?>
        <?php echo $page_specific_js; ?>
    <?php endif; ?>
</body>
</html>
