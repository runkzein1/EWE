<?php
// Aktifkan error reporting dan logging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$error_messages = [];
$success_message = '';

// Ambil data user
$user_query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "User tidak ditemukan.";
    header("Location: login.php");
    exit;
}

$user = $result->fetch_assoc();
$balance = $user['balance'] ?? 0;

// Proses request top-up
if (isset($_POST['request_topup'])) {
    try {
        // Get post data
        $amount = preg_replace('/[^0-9]/', '', $_POST['amount']); // Remove non-numeric characters
        $bank_account = isset($_POST['bank_account']) ? clean_input($_POST['bank_account']) : '';
        $notes = isset($_POST['notes']) ? clean_input($_POST['notes']) : '';
        
        // Validasi jumlah top-up
        if (!$amount || $amount < 50000) {
            $error_messages[] = "Jumlah top-up minimal Rp 50.000";
        } else {
            // Generate reference number
            $reference_number = 'TU' . time() . rand(1000, 9999);
            
            // Insert into database
            $query = "INSERT INTO transactions (user_id, type, amount, status, reference_number, notes, created_at) 
                     VALUES (?, 'deposit', ?, 'pending', ?, ?, NOW())";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("idss", $user_id, $amount, $reference_number, $notes);
            
            if ($stmt->execute()) {
                $transaction_id = $conn->insert_id;
                $success_message = "Permintaan top-up berhasil dibuat. Silahkan transfer ke rekening yang tertera dan upload bukti pembayaran.";
                
                // Redirect to upload payment page
                header("Location: upload-payment.php?id=" . $transaction_id);
                exit;
            } else {
                $error_messages[] = "Gagal membuat permintaan top-up: " . $conn->error;
            }
        }
    } catch (Exception $e) {
        $error_messages[] = "Error: " . $e->getMessage();
    }
}

// Aktifkan flag untuk halaman dashboard dan tema ultra-modern
$page_title = "Top-up Saldo";
$is_dashboard_page = true;
$use_ultra_modern = true;
$use_premium_effects = true;
$modern_js_files = true;

// CSS tambahan untuk halaman ini
$page_specific_css = '<link href="css/topup-premium.css" rel="stylesheet" type="text/css">';

// JS tambahan untuk halaman ini
$page_specific_js = '<script src="js/topup-modern.js"></script>';

// Include header
include('includes/header.php');
?>

<div class="dashboard-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="page-title">Top-up Saldo</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                        <li class="breadcrumb-item"><a href="account.php">Akun Saya</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Top-up Saldo</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container py-5">
    <div class="row">
        <!-- Menu Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="account-menu-card">
                <div class="user-profile mb-4">
                    <div class="user-avatar">
                        <div class="avatar-text">
                            <?php echo strtoupper(substr($user['username'] ?? 'U', 0, 1)); ?>
                        </div>
                    </div>
                    <div class="user-info mt-2">
                        <h5 class="mb-1"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h5>
                        <p class="text-muted mb-0">ID: <?php echo $user['user_id']; ?></p>
                    </div>
                </div>
                
                <div class="menu-items">
                    <a href="account.php" class="menu-item">
                        <i class="fa fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="topup-menu.php" class="menu-item active">
                        <i class="fa fa-wallet"></i> Top-up Saldo
                    </a>
                    <a href="withdraw-menu.php" class="menu-item">
                        <i class="fa fa-money-bill-wave"></i> Tarik Saldo
                    </a>
                    <a href="transactions-menu.php" class="menu-item">
                        <i class="fa fa-history"></i> Riwayat Transaksi
                    </a>
                    <a href="bids-menu.php" class="menu-item">
                        <i class="fa fa-gavel"></i> Bid Saya
                    </a>
                    <a href="profile-menu.php" class="menu-item">
                        <i class="fa fa-user"></i> Profil
                    </a>
                    <a href="?logout=true" class="menu-item">
                        <i class="fa fa-sign-out-alt"></i> Keluar
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-lg-9">
            <!-- Saldo & Top-up -->
            <div class="row">
                <div class="col-12 mb-4">
                    <div class="saldo-card mb-4">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h5 class="saldo-label mb-1">Saldo Tersedia</h5>
                                <h2 class="saldo-amount mb-2">Rp <?php echo number_format($balance, 0, ',', '.'); ?></h2>
                                <p class="saldo-update mb-0">Update terakhir: <?php echo date('d M Y H:i'); ?> WIB</p>
                            </div>
                            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                                <a href="transactions-menu.php" class="btn btn-light btn-sm">
                                    <i class="fa fa-history me-1"></i> Riwayat Transaksi
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Alert Messages -->
                    <?php if (!empty($error_messages)): ?>
                        <div class="alert alert-danger mb-4">
                            <i class="fa fa-exclamation-circle me-2"></i>
                            <?php foreach ($error_messages as $error): ?>
                                <div><?php echo htmlspecialchars($error); ?></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success_message)): ?>
                        <div class="alert alert-success mb-4">
                            <i class="fa fa-check-circle me-2"></i>
                            <?php echo htmlspecialchars($success_message); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="row">
                <div class="col-12">
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><i class="fa fa-plus-circle me-2"></i>Tambah Saldo</h5>
                        </div>
                        <div class="card-body">
                            <form method="post" action="" id="topup-form" enctype="multipart/form-data">
                                <div class="mb-4">
                                    <label for="amount" class="form-label">Pilih Jumlah Top-up</label>
                                    <div class="row preset-grid mb-3">
                                        <div class="col-md-3 col-6 mb-3">
                                            <div class="preset-button" data-amount="100000">
                                                Rp 100.000
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-6 mb-3">
                                            <div class="preset-button" data-amount="250000">
                                                Rp 250.000
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-6 mb-3">
                                            <div class="preset-button" data-amount="500000">
                                                Rp 500.000
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-6 mb-3">
                                            <div class="preset-button premium" data-amount="1000000">
                                                Rp 1.000.000
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="input-group">
                                        <span class="input-group-text">Rp</span>
                                        <input type="text" class="form-control" id="amount" name="amount" placeholder="Masukkan Jumlah Custom" required>
                                    </div>
                                    <small class="text-muted">Minimum top-up Rp 50.000</small>
                                </div>
                                
                                <div class="mb-4">
                                    <label for="bank_account" class="form-label">Pilih Rekening Tujuan</label>
                                    <div class="row bank-selection mb-3">
                                        <div class="col-md-4 mb-3">
                                            <div class="bank-option" data-bank="BCA">
                                                <input type="radio" name="bank_account" id="bank_bca" value="BCA - 12345678910" checked>
                                                <div class="bank-logo">BCA</div>
                                                <div class="bank-name">LelangMobil</div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <div class="bank-option" data-bank="Mandiri">
                                                <input type="radio" name="bank_account" id="bank_mandiri" value="Mandiri - 12345678910">
                                                <div class="bank-logo">Mandiri</div>
                                                <div class="bank-name">LelangMobil</div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <div class="bank-option" data-bank="BNI">
                                                <input type="radio" name="bank_account" id="bank_bni" value="BNI - 12345678910">
                                                <div class="bank-logo">BNI</div>
                                                <div class="bank-name">LelangMobil</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="account-number-display p-3 bg-light rounded">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h6 class="mb-1">Nomor Rekening</h6>
                                                <div class="account-number">12345678910</div>
                                            </div>
                                            <div class="col-auto">
                                                <button type="button" class="btn btn-sm btn-outline-primary copy-button" data-copy="12345678910">
                                                    <i class="fa fa-copy me-1"></i> Salin
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-4">
                                    <label for="notes" class="form-label">Catatan (Opsional)</label>
                                    <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="Tambahkan catatan jika diperlukan"></textarea>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" name="request_topup" class="btn btn-primary">
                                        <i class="fa fa-arrow-right me-2"></i> Lakukan Top-up
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Ringkasan Keuangan -->
            <div class="row">
                <div class="col-12">
                    <div class="card mb-4">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0"><i class="fa fa-chart-pie me-2"></i>Ringkasan Keuangan</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <div class="statistic-item p-3 bg-light rounded text-center">
                                        <div class="stat-icon mb-2 text-primary">
                                            <i class="fa fa-wallet fa-2x"></i>
                                        </div>
                                        <h4 class="mb-1">Rp <?php echo number_format($balance, 0, ',', '.'); ?></h4>
                                        <p class="mb-0 text-muted">Total Saldo</p>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="statistic-item p-3 bg-light rounded text-center">
                                        <div class="stat-icon mb-2 text-success">
                                            <i class="fa fa-arrow-alt-circle-up fa-2x"></i>
                                        </div>
                                        <h4 class="mb-1">Rp <?php echo number_format($balance, 0, ',', '.'); ?></h4>
                                        <p class="mb-0 text-muted">Dana Tersedia</p>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="statistic-item p-3 bg-light rounded text-center">
                                        <div class="stat-icon mb-2 text-warning">
                                            <i class="fa fa-dollar-sign fa-2x"></i>
                                        </div>
                                        <h4 class="mb-1">Rp 0</h4>
                                        <p class="mb-0 text-muted">Dana Ditahan</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
