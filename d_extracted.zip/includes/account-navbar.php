<?php
/**
 * Modern Account Navigation
 * LelangMobil Web App - Versi 2025
 */
?>

<div class="modern-sidebar">
    <div class="modern-card modern-profile-sidebar fade-in">
        <div class="text-center p-4">
            <img src="<?php echo !empty($user['profile_photo']) ? 'uploads/profile/'.$user['profile_photo'] : 'images/avatar-placeholder.jpg'; ?>" 
                 alt="<?php echo htmlspecialchars($user['username']); ?>" 
                 class="modern-profile-avatar"
                 onerror="this.src='images/avatar-placeholder.jpg';">
            
            <h4 class="mt-3 mb-1"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h4>
            
            <div class="balance-display mt-2">
                <div class="balance-label mb-1">Saldo Anda</div>
                <h5 class="balance-amount">Rp<?php echo number_format($user['balance'], 0, ',', '.'); ?></h5>
            </div>
            
            <div class="mt-3 d-flex justify-content-center gap-2">
                <a href="topup-modern.php" class="modern-button modern-button-primary btn-sm">
                    <i class="fa fa-plus-circle"></i> Top Up
                </a>
                <a href="withdraw-modern.php" class="modern-button modern-button-outline btn-sm">
                    <i class="fa fa-arrow-right"></i> Tarik
                </a>
            </div>
        </div>
        
        <hr class="my-0">
        
        <div class="account-nav">
            <ul class="modern-tabs vertical-tabs mb-0">
                <li class="modern-tab-item">
                    <a href="account-modern.php" class="modern-tab-link <?php echo (basename($_SERVER['PHP_SELF']) == 'account-modern.php' || basename($_SERVER['PHP_SELF']) == 'account.php') ? 'active' : ''; ?>">
                        <i class="fa fa-chart-line"></i> Dashboard
                    </a>
                </li>
                <li class="modern-tab-item">
                    <a href="profile-modern.php" class="modern-tab-link <?php echo basename($_SERVER['PHP_SELF']) == 'profile-modern.php' ? 'active' : ''; ?>">
                        <i class="fa fa-user"></i> Profil Saya
                    </a>
                </li>
                <li class="modern-tab-item">
                    <a href="bids-modern.php" class="modern-tab-link <?php echo basename($_SERVER['PHP_SELF']) == 'bids-modern.php' ? 'active' : ''; ?>">
                        <i class="fa fa-gavel"></i> Bid Saya
                    </a>
                </li>
                <li class="modern-tab-item">
                    <a href="transactions-modern.php" class="modern-tab-link <?php echo basename($_SERVER['PHP_SELF']) == 'transactions-modern.php' ? 'active' : ''; ?>">
                        <i class="fa fa-history"></i> Transaksi
                    </a>
                </li>
                <li class="modern-tab-item">
                    <a href="topup-modern.php" class="modern-tab-link <?php echo basename($_SERVER['PHP_SELF']) == 'topup-modern.php' ? 'active' : ''; ?>">
                        <i class="fa fa-wallet"></i> Top Up
                    </a>
                </li>
                <li class="modern-tab-item">
                    <a href="withdraw-modern.php" class="modern-tab-link <?php echo basename($_SERVER['PHP_SELF']) == 'withdraw-modern.php' ? 'active' : ''; ?>">
                        <i class="fa fa-money-bill-wave"></i> Penarikan
                    </a>
                </li>
                <?php if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                <li class="modern-tab-item">
                    <a href="admin/index.php" class="modern-tab-link">
                        <i class="fa fa-cog"></i> Admin Panel
                    </a>
                </li>
                <?php endif; ?>
                <li class="modern-tab-item">
                    <a href="logout.php" class="modern-tab-link text-danger">
                        <i class="fa fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
    
    <div class="modern-card mt-4 fade-in">
        <div class="modern-card-header">
            <h3 class="modern-card-title"><i class="fa fa-info-circle"></i> Info</h3>
        </div>
        <div class="modern-card-body">
            <div class="d-flex align-items-center mb-3">
                <div class="me-3">
                    <i class="fa fa-question-circle fa-2x text-info"></i>
                </div>
                <div>
                    <h5 class="mb-1">Butuh bantuan?</h5>
                    <p class="mb-0 small">Hubungi tim dukungan kami</p>
                </div>
            </div>
            
            <a href="contact.php" class="modern-button modern-button-info w-100">
                <i class="fa fa-headset me-2"></i> Hubungi Kami
            </a>
        </div>
    </div>
</div>

<style>
/* Additional styles for vertical tabs */
.vertical-tabs {
    flex-direction: column;
    border-bottom: none;
}

.vertical-tabs .modern-tab-item {
    margin-right: 0;
    margin-bottom: 0;
}

.vertical-tabs .modern-tab-link {
    border-radius: 0;
    border-left: 3px solid transparent;
    padding: 0.75rem 1.25rem;
    transition: all 0.3s ease;
}

.vertical-tabs .modern-tab-link.active {
    border-color: transparent transparent transparent var(--primary-color);
    background-color: rgba(52, 152, 219, 0.1);
}

.vertical-tabs .modern-tab-link.active::after {
    display: none;
}

.vertical-tabs .modern-tab-link:hover {
    background-color: rgba(52, 152, 219, 0.05);
}

.balance-display {
    background: linear-gradient(45deg, var(--primary-color), var(--info-color));
    border-radius: var(--border-radius);
    padding: 10px;
    color: white;
}

.balance-label {
    opacity: 0.8;
    font-size: 0.8rem;
}

.balance-amount {
    font-weight: 700;
    margin: 0;
}
</style>
