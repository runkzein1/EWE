<?php
// Set page title
$page_title = "Dashboard";

// Include header
include 'includes/header.php';

// Get statistics for dashboard
// Total users
$users_sql = "SELECT COUNT(*) as total FROM users";
$users_result = $conn->query($users_sql);
$users_count = $users_result->fetch_assoc()['total'];

// Total vehicles
$vehicles_sql = "SELECT COUNT(*) as total FROM vehicles";
$vehicles_result = $conn->query($vehicles_sql);
$vehicles_count = $vehicles_result->fetch_assoc()['total'];

// Active auctions
$active_sql = "SELECT COUNT(*) as total FROM vehicles WHERE status = 'active'";
$active_result = $conn->query($active_sql);
$active_count = $active_result->fetch_assoc()['total'];

// Total bids
$bids_sql = "SELECT COUNT(*) as total FROM bids";
$bids_result = $conn->query($bids_sql);
$bids_count = $bids_result->fetch_assoc()['total'];

// Total transactions
$transactions_sql = "SELECT COUNT(*) as total FROM transactions";
$transactions_result = $conn->query($transactions_sql);
$transactions_count = $transactions_result->fetch_assoc()['total'];

// Pending transactions
$pending_sql = "SELECT COUNT(*) as total FROM transactions WHERE status = 'pending'";
$pending_result = $conn->query($pending_sql);
$pending_count = $pending_result->fetch_assoc()['total'];

// Recent users
$recent_users_sql = "SELECT * FROM users ORDER BY created_at DESC LIMIT 5";
$recent_users_result = $conn->query($recent_users_sql);

// Recent auctions
$recent_auctions_sql = "SELECT v.*, u.username as seller_username 
                        FROM vehicles v 
                        LEFT JOIN users u ON v.seller_id = u.user_id 
                        ORDER BY v.created_at DESC 
                        LIMIT 5";
$recent_auctions_result = $conn->query($recent_auctions_sql);

// Recent transactions
$recent_transactions_sql = "SELECT t.*, u.username 
                           FROM transactions t 
                           JOIN users u ON t.user_id = u.user_id 
                           ORDER BY t.created_at DESC 
                           LIMIT 5";
$recent_transactions_result = $conn->query($recent_transactions_sql);
?>

<h1 class="mb-4">Dashboard</h1>

<!-- Statistics Cards -->
<div class="row">
    <div class="col-xl-3 col-md-6">
        <div class="stats-card text-center">
            <i class="fa fa-users id-color"></i>
            <h3><?php echo $users_count; ?></h3>
            <p>Total Pengguna</p>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stats-card text-center">
            <i class="fa fa-car id-color"></i>
            <h3><?php echo $vehicles_count; ?></h3>
            <p>Total Kendaraan</p>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stats-card text-center">
            <i class="fa fa-gavel id-color"></i>
            <h3><?php echo $active_count; ?></h3>
            <p>Lelang Aktif</p>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stats-card text-center">
            <i class="fa fa-money id-color"></i>
            <h3><?php echo $pending_count; ?></h3>
            <p>Transaksi Pending</p>
        </div>
    </div>
</div>

<div class="row mt-4">
    <!-- Recent Users -->
    <div class="col-md-6">
        <div class="de-box">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="m-0">Pengguna Terbaru</h4>
                <a href="users.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Tanggal Daftar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recent_users_result->num_rows > 0): ?>
                            <?php while ($user = $recent_users_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $user['username']; ?></td>
                                    <td><?php echo $user['email']; ?></td>
                                    <td>
                                        <?php if ($user['is_verified']): ?>
                                            <span class="badge bg-success">Terverifikasi</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Belum Verifikasi</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('d M Y', strtotime($user['created_at'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">Belum ada pengguna</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Recent Transactions -->
    <div class="col-md-6">
        <div class="de-box">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="m-0">Transaksi Terbaru</h4>
                <a href="transactions.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Jumlah</th>
                            <th>Tipe</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recent_transactions_result->num_rows > 0): ?>
                            <?php while ($transaction = $recent_transactions_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $transaction['username']; ?></td>
                                    <td><?php echo format_currency($transaction['amount']); ?></td>
                                    <td>
                                        <?php
                                        switch ($transaction['type']) {
                                            case 'deposit':
                                                echo 'Top-up';
                                                break;
                                            case 'withdrawal':
                                                echo 'Penarikan';
                                                break;
                                            case 'bid_hold':
                                                echo 'Hold Bid';
                                                break;
                                            case 'bid_release':
                                                echo 'Release Bid';
                                                break;
                                            case 'winning_payment':
                                                echo 'Pembayaran Menang';
                                                break;
                                            default:
                                                echo $transaction['type'];
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        switch ($transaction['status']) {
                                            case 'pending':
                                                echo '<span class="badge bg-warning">Pending</span>';
                                                break;
                                            case 'completed':
                                                echo '<span class="badge bg-success">Selesai</span>';
                                                break;
                                            case 'rejected':
                                                echo '<span class="badge bg-danger">Ditolak</span>';
                                                break;
                                            default:
                                                echo $transaction['status'];
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">Belum ada transaksi</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Recent Auctions -->
<div class="row mt-4">
    <div class="col-md-12">
        <div class="de-box">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="m-0">Kendaraan Terbaru</h4>
                <a href="vehicles.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>Kendaraan</th>
                            <th>Penjual</th>
                            <th>Harga Awal</th>
                            <th>Current Bid</th>
                            <th>Status</th>
                            <th>Tanggal Berakhir</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recent_auctions_result->num_rows > 0): ?>
                            <?php while ($vehicle = $recent_auctions_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $vehicle['title']; ?></td>
                                    <td><?php echo $vehicle['seller_username']; ?></td>
                                    <td><?php echo format_currency($vehicle['starting_price']); ?></td>
                                    <td>
                                        <?php echo $vehicle['current_bid'] ? format_currency($vehicle['current_bid']) : '-'; ?>
                                    </td>
                                    <td>
                                        <?php
                                        switch ($vehicle['status']) {
                                            case 'upcoming':
                                                echo '<span class="badge bg-info">Akan Datang</span>';
                                                break;
                                            case 'active':
                                                echo '<span class="badge bg-success">Aktif</span>';
                                                break;
                                            case 'ended':
                                                echo '<span class="badge bg-secondary">Selesai</span>';
                                                break;
                                            case 'sold':
                                                echo '<span class="badge bg-primary">Terjual</span>';
                                                break;
                                            case 'not_sold':
                                                echo '<span class="badge bg-danger">Tidak Terjual</span>';
                                                break;
                                            default:
                                                echo $vehicle['status'];
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo date('d M Y H:i', strtotime($vehicle['auction_end'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">Belum ada kendaraan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
