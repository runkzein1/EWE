<?php
// Aktifkan error reporting dan logging untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Set ke 0 di production

// Atur timeout eksekusi agar tidak loading berulang
set_time_limit(10); // 10 detik maksimum
ini_set('max_execution_time', 10);

// Auto redirect jika loading terlalu lama
header("Refresh: 15;url=error.php?reason=timeout&page=withdraw");

// Set error handler untuk menangkap error fatal
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("Error in withdraw.php: [$errno] $errstr in $errfile:$errline");
    if (in_array($errno, [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        header("Location: error.php?reason=" . urlencode($errstr));
        exit;
    }
    return true;
});

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$error_messages = [];
$success_message = '';

// Get user information
$user_sql = "SELECT * FROM users WHERE user_id = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Data bank yang tersedia
$banks = [
    ["code" => "bca", "name" => "Bank Central Asia (BCA)", "icon" => "fa-university"],
    ["code" => "bni", "name" => "Bank Negara Indonesia (BNI)", "icon" => "fa-university"],
    ["code" => "bri", "name" => "Bank Rakyat Indonesia (BRI)", "icon" => "fa-university"],
    ["code" => "mandiri", "name" => "Bank Mandiri", "icon" => "fa-university"],
    ["code" => "cimb", "name" => "CIMB Niaga", "icon" => "fa-university"],
    ["code" => "permata", "name" => "Bank Permata", "icon" => "fa-university"],
    ["code" => "gopay", "name" => "GoPay", "icon" => "fa-wallet"],
    ["code" => "ovo", "name" => "OVO", "icon" => "fa-wallet"],
    ["code" => "dana", "name" => "DANA", "icon" => "fa-wallet"]
];

// Cek pending bids (saldo yang terpesan untuk bid)
$pending_bids_sql = "SELECT COALESCE(SUM(bid_amount), 0) as total_pending 
                    FROM bids 
                    WHERE bidder_id = ? AND is_winning = 0";
$pending_bids_stmt = $conn->prepare($pending_bids_sql);
$pending_bids_stmt->bind_param("i", $user_id);
$pending_bids_stmt->execute();
$pending_bids_result = $pending_bids_stmt->get_result();
$pending_bids = $pending_bids_result->fetch_assoc();
$pending_amount = $pending_bids['total_pending'];

// Hitung saldo yang tersedia untuk withdraw
$available_balance = $user['balance'] - $pending_amount;

// Proses permintaan withdraw
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_withdrawal'])) {
    try {
        // Validasi data masukan dengan pengecekan lebih ketat
        if (!isset($_POST['withdraw_amount']) || empty($_POST['withdraw_amount'])) {
            throw new Exception('Jumlah penarikan harus diisi');
        }
        
        $amount = preg_replace('/[^0-9]/', '', $_POST['withdraw_amount']); // Remove non-numeric characters
        $bank_code = isset($_POST['withdraw_method']) ? clean_input($_POST['withdraw_method']) : '';
        $account_number = isset($_POST['account_number']) ? clean_input($_POST['account_number']) : '';
        $account_name = isset($_POST['account_name']) ? clean_input($_POST['account_name']) : '';
        $notes = isset($_POST['notes']) ? clean_input($_POST['notes']) : '';
        
        // Validasi jumlah dengan pengecekan lebih ketat
        if (empty($amount) || !is_numeric($amount)) {
            throw new Exception('Jumlah penarikan tidak valid');
        }
        
        if ((int)$amount < 50000) {
            throw new Exception('Jumlah penarikan minimal Rp 50.000');
        }
        
        if ((int)$amount > 50000000) { // Batas maksimum 50 juta per penarikan
            throw new Exception('Jumlah penarikan maksimal Rp 50.000.000 per transaksi');
        }
        
        // Validasi saldo tersedia
        if ((int)$amount > $available_balance) {
            throw new Exception('Saldo Anda tidak mencukupi. Saldo tersedia: Rp ' . number_format($available_balance, 0, ',', '.'));
        }
        
        // Validasi bank dengan pencarian yang lebih efisien
        $valid_bank = false;
        $bank_names = array_column($banks, 'name', 'code');
        
        if (!array_key_exists($bank_code, $bank_names)) {
            throw new Exception('Metode penarikan yang dipilih tidak valid');
        }
        
        // Validasi informasi rekening
        if (empty($account_number)) {
            throw new Exception('Nomor rekening/akun harus diisi');
        }
        
        if (strlen($account_number) < 5 || !preg_match('/^[0-9\s\-]+$/', $account_number)) {
            throw new Exception('Format nomor rekening/akun tidak valid');
        }
        
        if (empty($account_name)) {
            throw new Exception('Nama pemilik rekening/akun harus diisi');
        }
        
        if (strlen($account_name) < 3 || strlen($account_name) > 100) {
            throw new Exception('Nama pemilik rekening/akun tidak valid');
        }
        
        // Set timeout untuk operasi database
        $timeout_start = microtime(true);
        
        // Generate unique reference number
        $reference = 'WD' . date('YmdHis') . substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 6);
        
        // Detailed notes including account info
        $detailed_notes = "Penarikan ke " . strtoupper($bank_code) . " - " . $account_number . " a/n " . $account_name;
        if (!empty($notes)) {
            $detailed_notes .= ". Catatan: " . $notes;
        }
        
        // Mulai transaction database untuk memastikan atomicity
        try {
            // Disable autocommit mode
            $conn->autocommit(FALSE);
            
            // 1. Buat record transaksi
            $sql = "INSERT INTO transactions (user_id, amount, type, status, payment_method, reference_number, notes) VALUES (?, ?, 'withdrawal', 'pending', ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            
            if (!$stmt) {
                throw new Exception("Prepare statement error: " . $conn->error);
            }
            
            $stmt->bind_param("idsss", $user_id, $amount, $bank_code, $reference, $detailed_notes);
            
            // Execute dengan timeout check
            $execute_success = $stmt->execute();
            
            if (!$execute_success) {
                throw new Exception("Execute statement error: " . $stmt->error);
            }
            
            // Cek waktu eksekusi
            if ((microtime(true) - $timeout_start) > 5) { // Lebih dari 5 detik
                throw new Exception("Database operation timeout");
            }
            
            $transaction_id = $stmt->insert_id;
            
            // 2. Update saldo user (deduct immediately)
            $update_balance_sql = "UPDATE users SET balance = balance - ? WHERE user_id = ? AND balance >= ?";
            $update_balance_stmt = $conn->prepare($update_balance_sql);
            
            if (!$update_balance_stmt) {
                throw new Exception("Prepare update balance error: " . $conn->error);
            }
            
            $update_balance_stmt->bind_param("dii", $amount, $user_id, $amount);
            $balance_update_success = $update_balance_stmt->execute();
            
            if (!$balance_update_success) {
                throw new Exception("Update balance error: " . $update_balance_stmt->error);
            }
            
            // Pastikan saldo berhasil diupdate
            if ($update_balance_stmt->affected_rows == 0) {
                throw new Exception("Saldo tidak cukup atau telah berubah, silakan refresh halaman");
            }
            
            // 3. Log history aktivitas (opsional)
            $log_sql = "INSERT INTO activity_logs (user_id, activity_type, reference_id, details, ip_address) VALUES (?, 'withdrawal_request', ?, ?, ?)";
            $log_stmt = $conn->prepare($log_sql);
            
            if ($log_stmt) { // Ini opsional, jadi tidak throw exception jika error
                $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                $log_stmt->bind_param("iiss", $user_id, $transaction_id, $detailed_notes, $ip);
                $log_stmt->execute();
            }
            
            // Commit transaksi jika semua berhasil
            $conn->commit();
            
            // Log transaksi berhasil untuk audit
            error_log("Withdrawal request processed successfully: User ID {$user_id}, Amount {$amount}, Transaction ID {$transaction_id}");
            
            // Set session message dan redirect
            $_SESSION['success_message'] = 'Permintaan penarikan berhasil dibuat. Admin akan memproses permintaan Anda dalam 1x24 jam kerja.';
            header("Location: account.php");
            exit;
            
        } catch (Throwable $db_error) {
            // Rollback jika terjadi error
            $conn->rollback();
            error_log("Database error in withdraw.php: " . $db_error->getMessage());
            throw new Exception('Terjadi kesalahan database saat memproses penarikan: ' . $db_error->getMessage());
        } finally {
            // Reset autocommit mode
            $conn->autocommit(TRUE);
        }
    } catch (Throwable $e) {
        // Tangkap semua exception dan error
        error_log("Error in withdraw.php processing: " . $e->getMessage());
        $error_messages[] = $e->getMessage();
    }
}

// Set page title and include header
$page_title = "Withdraw Saldo";
$use_modern_2025 = true; // Flag untuk menggunakan style modern 2025
include 'includes/header.php';
?>

<!-- Custom CSS for Withdraw page with Modern 2025 style -->
<link rel="stylesheet" href="css/modern-account.css">
<link rel="stylesheet" href="css/transaction-style.css">
<link rel="stylesheet" href="css/modern-2025.css">
<script src="js/modern-2025.js"></script>
<link rel="stylesheet" href="css/topup-withdraw.css">

<div class="container mt-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <!-- Main Card -->
            <div class="card premium-card withdraw-card">
                <div class="card-header">
                    <h3 class="mb-0"><i class="fas fa-money-bill-wave float me-2"></i>Withdraw Saldo</h3>
                    <div class="lightning-effect"></div>
                </div>
                
                <div class="card-body">
                    <?php if (!empty($error_messages)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul class="mb-0">
                                <?php foreach ($error_messages as $error): ?>
                                    <li><?php echo $error; ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success_message)): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo $success_message; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <div class="balance-cards">
                        <div class="balance-card total-balance">
                            <div class="balance-icon"><i class="fas fa-wallet"></i></div>
                            <div class="balance-details">
                                <div class="balance-label">Total Saldo</div>
                                <div class="balance-amount">Rp <?php echo number_format($user['balance'], 0, ',', '.'); ?></div>
                            </div>
                        </div>
                        
                        <div class="balance-card pending-balance">
                            <div class="balance-icon"><i class="fas fa-clock"></i></div>
                            <div class="balance-details">
                                <div class="balance-label">Saldo Terpakai</div>
                                <div class="balance-amount">Rp <?php echo number_format($pending_amount, 0, ',', '.'); ?></div>
                            </div>
                        </div>
                        
                        <div class="balance-card available-balance">
                            <div class="balance-icon"><i class="fas fa-coins"></i></div>
                            <div class="balance-details">
                                <div class="balance-label">Saldo Tersedia</div>
                                <div class="balance-amount">Rp <?php echo number_format($available_balance, 0, ',', '.'); ?></div>
                            </div>
                        </div>
                    </div>
                    
                    <form action="withdraw.php" method="post" id="withdrawForm">
                        <div class="section-title">
                            <span class="section-number">1</span>
                            <h4>Pilih Metode Penarikan</h4>
                        </div>
                        
                        <div class="payment-methods-container">
                            <div class="row">
                                <?php foreach ($banks as $bank): ?>
                                <div class="col-md-4 col-6">
                                    <div class="payment-method" data-bank="<?php echo $bank['code']; ?>">
                                        <input type="radio" name="withdraw_method" value="<?php echo $bank['code']; ?>" class="d-none" <?php echo $bank['code'] === 'bca' ? 'checked' : ''; ?>>
                                        <div class="payment-method-inner">
                                            <div class="payment-icon">
                                                <i class="fas <?php echo $bank['icon']; ?>"></i>
                                            </div>
                                            <div class="payment-name"><?php echo $bank['name']; ?></div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="section-title">
                            <span class="section-number">2</span>
                            <h4>Pilih Jumlah Penarikan</h4>
                        </div>
                        
                        <div class="amount-presets-container">
                            <div class="row">
                                <div class="col-md-4 col-6">
                                    <div class="amount-preset" data-amount="100000">
                                        <div class="amount-preset-inner">
                                            Rp 100.000
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-6">
                                    <div class="amount-preset" data-amount="500000">
                                        <div class="amount-preset-inner">
                                            Rp 500.000
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-6">
                                    <div class="amount-preset" data-amount="1000000">
                                        <div class="amount-preset-inner">
                                            Rp 1.000.000
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-6">
                                    <div class="amount-preset" data-amount="2500000">
                                        <div class="amount-preset-inner">
                                            Rp 2.500.000
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-6">
                                    <div class="amount-preset" data-amount="5000000">
                                        <div class="amount-preset-inner">
                                            Rp 5.000.000
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-6">
                                    <div class="amount-preset" data-amount="10000000">
                                        <div class="amount-preset-inner">
                                            Rp 10.000.000
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group custom-amount-group">
                                <label for="withdraw_amount">Jumlah Custom</label>
                                <div class="input-group">
                                    <span class="input-group-text">Rp</span>
                                    <input type="text" class="form-control amount-input" id="withdraw_amount" name="withdraw_amount" value="100.000" required>
                                </div>
                                <small class="text-muted">Minimal penarikan Rp 50.000</small>
                            </div>
                        </div>
                        
                        <div class="section-title">
                            <span class="section-number">3</span>
                            <h4>Informasi Rekening/Akun</h4>
                        </div>
                        
                        <div class="account-info-container">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="account_number">Nomor Rekening / Akun</label>
                                        <input type="text" class="form-control" id="account_number" name="account_number" placeholder="Masukkan nomor rekening/akun" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="account_name">Nama Pemilik Rekening / Akun</label>
                                        <input type="text" class="form-control" id="account_name" name="account_name" placeholder="Masukkan nama pemilik" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="account-verification">
                                <div class="verification-icon"><i class="fas fa-shield-alt"></i></div>
                                <div class="verification-text">
                                    Pastikan data rekening/akun sudah benar. Sistem akan mentransfer ke rekening/akun yang Anda masukkan.
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="notes">Catatan (opsional)</label>
                            <textarea class="form-control" id="notes" name="notes" rows="2" placeholder="Tambahkan catatan jika diperlukan"></textarea>
                        </div>
                        
                        <div class="withdrawal-disclaimer">
                            <div class="disclaimer-icon"><i class="fas fa-exclamation-triangle"></i></div>
                            <div class="disclaimer-text">
                                Penarikan dana akan diproses dalam waktu 1x24 jam kerja setelah permintaan dibuat.
                                Biaya transfer ditanggung oleh penerima (Anda).
                            </div>
                        </div>
                        
                        <div class="withdraw-actions mt-4">
                            <a href="account.php" class="btn btn-outline-primary">Kembali</a>
                            <button type="submit" name="request_withdrawal" class="btn btn-success btn-lg withdraw-submit-btn">
                                <i class="fas fa-money-bill-wave me-2"></i> Ajukan Penarikan
                                <div class="ripple-effect"></div>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="withdraw-info-card mt-4">
                <div class="info-header">
                    <i class="fas fa-info-circle"></i>
                    <h5>Informasi Penarikan</h5>
                </div>
                <div class="info-content">
                    <ol>
                        <li>Pastikan Anda memiliki saldo yang cukup untuk penarikan.</li>
                        <li>Saldo yang sedang digunakan untuk bid tidak dapat ditarik.</li>
                        <li>Masukkan informasi rekening/akun dengan benar.</li>
                        <li>Dana akan ditransfer ke rekening/akun yang Anda masukkan.</li>
                        <li>Proses penarikan membutuhkan waktu 1x24 jam kerja.</li>
                        <li>Biaya transfer/admin ditanggung oleh penerima.</li>
                        <li>Jika ada pertanyaan, silakan hubungi customer service.</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Format currency input
    const amountInput = document.querySelector('.amount-input');
    const formatCurrency = (value) => {
        value = value.replace(/\D/g, '');
        if (value === '') return '';
        return new Intl.NumberFormat('id-ID').format(value);
    };
    
    amountInput.addEventListener('input', function(e) {
        this.value = formatCurrency(this.value);
    });
    
    // Payment Method Selection
    const paymentMethods = document.querySelectorAll('.payment-method');
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            // Update visual selection
            paymentMethods.forEach(m => m.classList.remove('active'));
            this.classList.add('active');
            
            // Check the radio button
            const radio = this.querySelector('input[type="radio"]');
            radio.checked = true;
        });
    });
    
    // Amount Preset Selection
    const amountPresets = document.querySelectorAll('.amount-preset');
    amountPresets.forEach(preset => {
        preset.addEventListener('click', function() {
            // Update visual selection
            amountPresets.forEach(p => p.classList.remove('active'));
            this.classList.add('active');
            
            // Update amount input
            const amount = parseInt(this.dataset.amount);
            amountInput.value = formatCurrency(amount.toString());
        });
    });
    
    // Initialize defaults
    const defaultBank = document.querySelector('.payment-method[data-bank="bca"]');
    defaultBank.classList.add('active');
    
    const defaultAmountPreset = document.querySelector('.amount-preset[data-amount="100000"]');
    defaultAmountPreset.classList.add('active');
    
    // Form validation
    const withdrawForm = document.getElementById('withdrawForm');
    withdrawForm.addEventListener('submit', function(e) {
        const amountValue = parseInt(amountInput.value.replace(/\D/g, ''));
        const availableBalance = <?php echo $available_balance; ?>;
        
        if (amountValue < 50000) {
            e.preventDefault();
            alert('Jumlah penarikan minimal Rp 50.000');
            return false;
        }
        
        if (amountValue > availableBalance) {
            e.preventDefault();
            alert('Saldo Anda tidak mencukupi untuk melakukan penarikan ini.');
            return false;
        }
        
        return true;
    });
    
    // Ripple effect for buttons
    const buttons = document.querySelectorAll('.withdraw-submit-btn');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            const x = e.clientX - e.target.getBoundingClientRect().left;
            const y = e.clientY - e.target.getBoundingClientRect().top;
            
            const ripple = document.createElement('span');
            ripple.classList.add('ripple');
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>
