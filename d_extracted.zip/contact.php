<?php
// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$error = '';
$success = '';

// Process contact form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = clean_input($_POST['name']);
    $email = clean_input($_POST['email']);
    $phone = clean_input($_POST['phone']);
    $subject = clean_input($_POST['subject']);
    $message = clean_input($_POST['message']);
    
    // Validate inputs
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = "Harap isi semua kolom yang diperlukan.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid.";
    } else {
        // Insert contact message into database (optional)
        // You could create a messages table to store contact submissions
        
        // Send email (this can be enhanced with proper email configuration)
        $to = "info@lelangmobil.com"; // Change to your actual email
        $email_subject = "Pesan Kontak: $subject";
        $email_body = "Anda telah menerima pesan baru dari situs LelangMobil.\n\n"
                    . "Detail:\n\n"
                    . "Nama: $name\n"
                    . "Email: $email\n"
                    . "Telepon: $phone\n\n"
                    . "Pesan:\n$message";
        $headers = "From: $email";
        
        if (mail($to, $email_subject, $email_body, $headers)) {
            $success = "Pesan Anda telah terkirim. Kami akan menghubungi Anda segera.";
        } else {
            $error = "Terjadi kesalahan saat mengirim pesan. Silakan coba lagi nanti.";
        }
    }
}

// Page title
$page_title = "Kontak Kami - LelangMobil";
?>

<?php include 'includes/header.php'; ?>

<div id="top"></div>
<section id="subheader" class="jarallax text-light">
    <img src="images/background/2.jpg" class="jarallax-img" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="subtitle wow fadeInUp mb-3">LelangMobil</div>
            </div>
            <div class="col-lg-6">
                <h2 class="wow fadeInUp mb20" data-wow-delay=".2s">Hubungi Kami</h2>
            </div>
        </div>
    </div>
</section>

<section aria-label="section">
    <div class="container">
        <?php if(!empty($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if(!empty($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-lg-8 mb-sm-30">
                <h3>Kirim Pesan</h3>
                
                <form class="form-border" method="post" action="">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="field-set">
                                <label>Nama:</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="field-set">
                                <label>Email:</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="field-set">
                                <label>Nomor Telepon:</label>
                                <input type="text" name="phone" class="form-control">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="field-set">
                                <label>Subjek:</label>
                                <input type="text" name="subject" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="field-set">
                                <label>Pesan:</label>
                                <textarea name="message" class="form-control" rows="5" required></textarea>
                            </div>
                        </div>
                        
                        <div class="col-lg-12">
                            <div class="spacer-20"></div>
                            <button class="btn-main" type="submit">Kirim Pesan</button>
                        </div>
                    </div>
                </form>
            </div>
            
            <div class="col-lg-4">
                <div class="de-box mb30">
                    <h4>Informasi Kontak</h4>
                    <address class="s1">
                        <span><i class="id-color fa fa-map-marker fa-lg"></i>Jl. Jendral Sudirman No. 123, Jakarta Pusat</span>
                        <span><i class="id-color fa fa-phone fa-lg"></i>+62 21 1234 5678</span>
                        <span><i class="id-color fa fa-mobile fa-lg"></i>+62 812 3456 7890</span>
                        <span><i class="id-color fa fa-envelope-o fa-lg"></i><a href="mailto:info@lelangmobil.com">info@lelangmobil.com</a></span>
                    </address>
                </div>
                
                <div class="de-box">
                    <h4>Jam Operasional</h4>
                    <p>Layanan pelanggan kami tersedia pada jam berikut:</p>
                    
                    <div class="spacer-10"></div>
                    
                    <div class="d-flex justify-content-between">
                        <span>Senin - Jumat:</span>
                        <span>08:00 - 17:00</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Sabtu:</span>
                        <span>09:00 - 15:00</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Minggu & Hari Libur:</span>
                        <span>Tutup</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="spacer-double"></div>
        
        <div class="row">
            <div class="col-lg-12">
                <h3>Lokasi Kami</h3>
                <div class="spacer-single"></div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.6664463317382!2d106.82122707571195!3d-6.1753923937583615!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5d2e764b12d%3A0x3d2ad6e1e0e9bcc8!2sJl.%20Jend.%20Sudirman%2C%20Daerah%20Khusus%20Ibukota%20Jakarta!5e0!3m2!1sid!2sid!4v1682745546055!5m2!1sid!2sid" 
                        width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
