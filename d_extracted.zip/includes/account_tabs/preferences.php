<?php
// Ensure this file is included by account.php and has access to $db, $user_id, $user_data, $csrf_token

if (!defined('ROOT_PATH')) {
    die("Direct access not allowed.");
}

// $user_data should contain current preferences, e.g., $user_data['receive_notifications']

?>

<h4>Site Preferences</h4>
<hr>

<form action="<?php echo htmlspecialchars(BASE_URL . 'account.php?tab=preferences'); ?>" method="POST">
    <input type="hidden" name="action" value="update_preferences">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

    <div class="card mb-4">
        <div class="card-header">
            Notification Settings
        </div>
        <div class="card-body">
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" role="switch" id="receive_notifications" name="receive_notifications" value="1" <?php echo (isset($user_data['receive_notifications']) && $user_data['receive_notifications'] == 1) ? 'checked' : ''; ?>>
                <label class="form-check-label" for="receive_notifications">Receive email notifications for important account activity (e.g., winning bids, outbid alerts).</label>
            </div>
            <!-- Add more notification toggles as needed -->
            <!-- Example:
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" role="switch" id="newsletter_subscribe" name="newsletter_subscribe" value="1" <?php echo (isset($user_data['newsletter_subscribed']) && $user_data['newsletter_subscribed'] == 1) ? 'checked' : ''; ?>>
                <label class="form-check-label" for="newsletter_subscribe">Subscribe to weekly newsletter with new auctions and promotions.</label>
            </div>
            -->
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            Display & Theme (Example)
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label for="items_per_page" class="form-label">Items per Page on Auction Listings</label>
                <select class="form-select" id="items_per_page" name="items_per_page">
                    <?php 
                    $ipp_options = [10, 25, 50, 100];
                    $current_ipp = $user_data['items_per_page'] ?? 25;
                    foreach ($ipp_options as $option) {
                        echo "<option value=\"{$option}\" " . ($current_ipp == $option ? 'selected' : '') . ">{$option} items</option>";
                    }
                    ?>
                </select>
            </div>
            <!-- Example Theme Selector (requires backend logic to save and CSS to apply) -->
            <!--
            <div class="mb-3">
                <label for="site_theme" class="form-label">Site Theme</label>
                <select class="form-select" id="site_theme" name="site_theme">
                    <option value="light" <?php echo (isset($user_data['site_theme']) && $user_data['site_theme'] === 'light') ? 'selected' : ''; ?>>Light Mode</option>
                    <option value="dark" <?php echo (isset($user_data['site_theme']) && $user_data['site_theme'] === 'dark') ? 'selected' : ''; ?>>Dark Mode (Modern 2025)</option>
                </select>
            </div>
            -->
        </div>
    </div>

    <!-- Add more preference sections as needed -->

    <button type="submit" class="btn btn-primary">Save Preferences</button>
</form>
