/**
 * Premium Auction Scripts untuk LelangMobil
 * Mengimplementasikan fitur-fitur seperti JBA Lelang
 */

document.addEventListener('DOMContentLoaded', function() {
    // Premium Countdown Timer
    initPremiumTimer();
    
    // Bid Button Effects
    initBidButton();
    
    // Bid Preset Buttons
    initBidPresets();
});

/**
 * Inisialisasi Premium Timer Countdown
 */
function initPremiumTimer() {
    const timerContainer = document.getElementById('premium-timer');
    
    if (!timerContainer) return;
    
    const daysElement = document.getElementById('days');
    const hoursElement = document.getElementById('hours');
    const minutesElement = document.getElementById('minutes');
    const secondsElement = document.getElementById('seconds');
    
    const endTime = parseInt(timerContainer.getAttribute('data-end')) * 1000; // Convert to milliseconds
    
    // Update timer every second
    function updateTimer() {
        const now = new Date().getTime();
        const distance = endTime - now;
        
        if (distance <= 0) {
            // Timer expired
            daysElement.textContent = '0';
            hoursElement.textContent = '0';
            minutesElement.textContent = '0';
            secondsElement.textContent = '0';
            
            // Add expired class
            timerContainer.classList.add('timer-expired');
            
            // Reload page after 3 seconds to reflect end of auction
            setTimeout(() => {
                location.reload();
            }, 3000);
            
            return;
        }
        
        // Calculate time units
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        // Update display
        daysElement.textContent = days.toString().padStart(2, '0');
        hoursElement.textContent = hours.toString().padStart(2, '0');
        minutesElement.textContent = minutes.toString().padStart(2, '0');
        secondsElement.textContent = seconds.toString().padStart(2, '0');
        
        // Add timer-low class for last 10 minutes
        if (distance < 600000) { // 10 minutes in milliseconds
            timerContainer.classList.add('timer-low');
        }
    }
    
    // Initial update
    updateTimer();
    
    // Update every second
    setInterval(updateTimer, 1000);
}

/**
 * Inisialisasi efek visual untuk tombol bid
 */
function initBidButton() {
    const bidButton = document.getElementById('bidButton');
    
    if (!bidButton) return;
    
    bidButton.addEventListener('click', function(e) {
        // Create ripple effect
        const ripple = document.createElement('div');
        ripple.className = 'bid-ripple';
        this.appendChild(ripple);
        
        // Remove ripple after animation completes
        setTimeout(() => {
            ripple.remove();
        }, 800);
    });
    
    // Auto increment link
    const autoIncrement = document.getElementById('autoIncrement');
    const bidInput = document.getElementById('bid_amount');
    
    if (autoIncrement && bidInput) {
        autoIncrement.addEventListener('click', function(e) {
            e.preventDefault();
            const currentValue = parseInt(bidInput.value) || 0;
            bidInput.value = currentValue + 1000000;
        });
    }
}

/**
 * Inisialisasi tombol preset bid
 */
function initBidPresets() {
    const presetButtons = document.querySelectorAll('.bid-preset');
    const bidInput = document.getElementById('bid_amount');
    
    if (!bidInput) return;
    
    presetButtons.forEach(button => {
        button.addEventListener('click', function() {
            const amount = parseInt(this.getAttribute('data-amount'));
            bidInput.value = amount;
            
            // Add active class
            presetButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });
}
