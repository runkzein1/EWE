/**
 * Dashboard Controls JavaScript
 * Mengelola fungsionalitas dashboard dan tabs di LelangMobil
 * Versi: 1.0 (2 Mei 2025)
 */

document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi tab dashboard
    initDashboardTabs();
    
    // Inisialisasi tooltip
    initTooltips();
    
    // Inisialisasi event modal
    initPaymentModals();
    
    // Checkbox dan form handling
    initFormControls();
});

/**
 * Inisialisasi tab dashboard
 * Mengelola perpindahan antar tab dengan animasi smooth
 */
function initDashboardTabs() {
    const triggerTabList = document.querySelectorAll('#dashboardTab button');
    
    // Tab switching functionality
    triggerTabList.forEach(triggerEl => {
        triggerEl.addEventListener('click', event => {
            event.preventDefault();
            const tabTarget = document.querySelector(triggerEl.getAttribute('data-bs-target'));
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab-pane').forEach(pane => {
                pane.classList.remove('show', 'active');
            });
            document.querySelectorAll('#dashboardTab button').forEach(btn => {
                btn.classList.remove('active');
                btn.setAttribute('aria-selected', 'false');
            });
            
            // Add active class to selected tab with slight animation
            triggerEl.classList.add('active');
            triggerEl.setAttribute('aria-selected', 'true');
            
            // Animate tab content appearance
            tabTarget.style.opacity = 0;
            tabTarget.classList.add('show', 'active');
            
            // Fade in animation
            setTimeout(() => {
                let opacity = 0;
                const fadeIn = setInterval(() => {
                    opacity += 0.1;
                    tabTarget.style.opacity = opacity;
                    if (opacity >= 1) {
                        clearInterval(fadeIn);
                        tabTarget.style.opacity = '';
                    }
                }, 20);
            }, 50);
            
            // Simpan tab aktif di local storage agar tetap aktif saat reload
            const tabId = triggerEl.getAttribute('data-bs-target').replace('#', '');
            localStorage.setItem('activeTab', tabId);
        });
    });
    
    // Restore active tab from local storage if exists
    const activeTab = localStorage.getItem('activeTab');
    if (activeTab) {
        const activeTabTrigger = document.querySelector(`button[data-bs-target="#${activeTab}"]`);
        if (activeTabTrigger) {
            activeTabTrigger.click();
        }
    }
}

/**
 * Inisialisasi tooltip di seluruh dashboard
 */
function initTooltips() {
    const tooltipElements = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltipElements.forEach(element => {
        if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
            new bootstrap.Tooltip(element, {
                boundary: document.body
            });
        }
    });
}

/**
 * Inisialisasi modal pembayaran
 */
function initPaymentModals() {
    // Open payment modal
    const paymentButtons = document.querySelectorAll('.payment-modal-trigger');
    paymentButtons.forEach(button => {
        button.addEventListener('click', function() {
            const target = this.getAttribute('data-target');
            const modal = document.querySelector(target);
            
            if (modal && typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                const modalInstance = new bootstrap.Modal(modal);
                modalInstance.show();
            }
        });
    });
    
    // Handle file uploads in payment modal
    const proofInputs = document.querySelectorAll('.payment-proof-input');
    proofInputs.forEach(input => {
        input.addEventListener('change', function() {
            const previewElement = document.querySelector(this.getAttribute('data-preview'));
            if (previewElement && this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewElement.src = e.target.result;
                    previewElement.classList.remove('d-none');
                };
                reader.readAsDataURL(this.files[0]);
            }
        });
    });
}

/**
 * Inisialisasi form controls
 */
function initFormControls() {
    // Handle form submissions with confirmation
    const confirmForms = document.querySelectorAll('.confirm-form');
    confirmForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const confirmMessage = this.getAttribute('data-confirm') || 'Apakah Anda yakin?';
            if (!confirm(confirmMessage)) {
                e.preventDefault();
                return false;
            }
        });
    });
    
    // Toggle checkboxes
    const checkAllButtons = document.querySelectorAll('.check-all-button');
    checkAllButtons.forEach(button => {
        button.addEventListener('click', function() {
            const target = this.getAttribute('data-target');
            const checkboxes = document.querySelectorAll(target);
            const checkState = this.getAttribute('data-state') === 'checked' ? false : true;
            
            checkboxes.forEach(checkbox => {
                checkbox.checked = checkState;
            });
            
            this.setAttribute('data-state', checkState ? 'checked' : 'unchecked');
            this.innerHTML = checkState ? 'Uncheck All' : 'Check All';
        });
    });
}
