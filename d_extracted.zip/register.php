<?php
// Include configuration, database connection and functions
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';
require_once 'config/mailer.php';

$error = '';
$success = '';

// Process registration form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate input
    $username = clean_input($_POST['username']);
    $email = clean_input($_POST['email']);
    $password = clean_input($_POST['password']);
    $confirm_password = clean_input($_POST['confirm_password']);
    $full_name = clean_input($_POST['full_name']);
    $phone = clean_input($_POST['phone']);

    // Check if passwords match
    if ($password != $confirm_password) {
        $error = "Password tidak cocok.";
    } else {
        // Check if username already exists
        $username_check = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($username_check);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Username sudah digunakan.";
        } else {
            // Check if email already exists
            $email_check = "SELECT * FROM users WHERE email = ?";
            $stmt = $conn->prepare($email_check);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $error = "Email sudah terdaftar.";
            } else {
                // All validations passed, create user
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $verification_token = generate_token();
                $token_expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));

                // Insert user into database
                $insert_sql = "INSERT INTO users (username, email, password, full_name, phone, verification_token, token_expiry)
                               VALUES (?, ?, ?, ?, ?, ?, ?)";
                $insert_stmt = $conn->prepare($insert_sql);
                $insert_stmt->bind_param("sssssss", $username, $email, $hashed_password, $full_name, $phone, $verification_token, $token_expiry);

                if ($insert_stmt->execute()) {
                    // Get the user ID of the new user
                    $user_id = $conn->insert_id;

                    // Send verification email
                    if (send_verification_email($conn, $email, $verification_token, $user_id)) {
                        $success = "Pendaftaran berhasil! Silakan periksa email Anda untuk verifikasi akun. Jika tidak menemukannya, periksa folder spam Anda.";
                    } else {
                        $error = "Pendaftaran berhasil, tetapi gagal mengirim email verifikasi. Silakan hubungi admin.";
                    }
                } else {
                    $error = "Terjadi kesalahan saat mendaftar. Silakan coba lagi.";
                }
            }
        }
    }
}

// Page title for header
$page_title = "Daftar - LelangMobil";
?>

<?php include 'includes/header.php'; ?>

<div id="top"></div>
<section id="subheader" class="jarallax text-light">
    <img src="images/background/2.jpg" class="jarallax-img" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="subtitle wow fadeInUp mb-3">LelangMobil</div>
            </div>
            <div class="col-lg-6">
                <h2 class="wow fadeInUp mb20" data-wow-delay=".2s">Daftar Akun</h2>
            </div>
        </div>
    </div>
</section>

<section aria-label="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="de-box">
                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <?php if(!empty($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                        <p class="text-center">Silahkan periksa email Anda (termasuk folder spam) dan klik link verifikasi yang telah kami kirimkan. Kemudian <a href="login.php">Login</a> setelah email Anda terverifikasi.</p>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <h5>Catatan Penting:</h5>
                            <p>Setelah pendaftaran, Anda harus memverifikasi email untuk dapat mengakses semua fitur LelangMobil. Email verifikasi akan dikirim secara otomatis ke alamat email yang Anda daftarkan.</p>
                        </div>
                        <form class="form-border" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="field-set">
                                        <label>Username:</label>
                                        <input type="text" name="username" class="form-control" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="field-set">
                                        <label>Email:</label>
                                        <input type="email" name="email" class="form-control" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="field-set">
                                        <label>Password:</label>
                                        <input type="password" name="password" class="form-control" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="field-set">
                                        <label>Konfirmasi Password:</label>
                                        <input type="password" name="confirm_password" class="form-control" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="field-set">
                                        <label>Nama Lengkap:</label>
                                        <input type="text" name="full_name" class="form-control" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="field-set">
                                        <label>Nomor Telepon:</label>
                                        <input type="text" name="phone" class="form-control" required>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="spacer-20"></div>
                                    <p>Dengan mendaftar, Anda menyetujui <a href="terms.php">Syarat & Ketentuan</a> kami.</p>
                                    <button class="btn-main" type="submit">Daftar</button>
                                    <div class="spacer-20"></div>
                                    <p>Sudah memiliki akun? <a href="login.php">Masuk di sini</a></p>
                                </div>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
