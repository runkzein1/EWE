<?php
// Set page title
$page_title = "Pengaturan Sistem";

// Include header
include 'includes/header.php';

// Define settings categories and their keys
$settings_categories = [
    'general' => [
        'title' => 'Pengaturan Umum',
        'icon' => 'fa-cog',
        'settings' => [
            'site_title' => [
                'label' => 'Judul Situs',
                'type' => 'text',
                'default' => 'LelangMobil'
            ],
            'site_description' => [
                'label' => 'Deskripsi Situs',
                'type' => 'textarea',
                'default' => 'Platform Lelang Mobil Terpercaya'
            ],
            'admin_email' => [
                'label' => 'Email Admin',
                'type' => 'email',
                'default' => 'admin@lelangmobil.com'
            ],
            'contact_phone' => [
                'label' => 'Nomor Telepon Kontak',
                'type' => 'text',
                'default' => '+62 21 1234567'
            ],
            'contact_address' => [
                'label' => 'Alamat Kontak',
                'type' => 'textarea',
                'default' => 'Jl. Raya Mobil No. 123, Jakarta'
            ]
        ]
    ],
    'payment' => [
        'title' => 'Pengaturan Pembayaran',
        'icon' => 'fa-credit-card',
        'settings' => [
            'min_topup_amount' => [
                'label' => 'Minimal Top-up Saldo (Rp)',
                'type' => 'number',
                'default' => '50000'
            ],
            'notify_admin_new_topup' => [
                'label' => 'Notifikasi Admin untuk Top-up Baru',
                'type' => 'checkbox',
                'default' => '1'
            ],
            'topup_auto_expire_hours' => [
                'label' => 'Waktu Kedaluwarsa Top-up (jam)',
                'type' => 'number',
                'default' => '48'
            ],
            'bank_accounts' => [
                'label' => 'Rekening Bank (Format: Nama Bank: Nomor Rekening)',
                'type' => 'textarea',
                'default' => "BCA: 1234567890\nMandiri: 0987654321\nBNI: 5678901234"
            ],
            'bank_account_name' => [
                'label' => 'Nama Pemilik Rekening',
                'type' => 'text',
                'default' => 'LelangMobil'
            ]
        ]
    ],
    'auction' => [
        'title' => 'Pengaturan Lelang',
        'icon' => 'fa-gavel',
        'settings' => [
            'min_bid_increment' => [
                'label' => 'Kenaikan Minimal Bid (Rp)',
                'type' => 'number',
                'default' => '500000'
            ],
            'auction_duration_days' => [
                'label' => 'Durasi Lelang Default (hari)',
                'type' => 'number',
                'default' => '7'
            ],
            'auction_extension_minutes' => [
                'label' => 'Perpanjangan Waktu Saat Ada Bid Pada Menit-menit Terakhir (menit)',
                'type' => 'number',
                'default' => '10'
            ],
            'bid_last_minutes_threshold' => [
                'label' => 'Batas Waktu Menit Terakhir untuk Perpanjangan (menit)',
                'type' => 'number',
                'default' => '5'
            ]
        ]
    ],
    'payment' => [
        'title' => 'Pengaturan Pembayaran',
        'icon' => 'fa-money-bill',
        'settings' => [
            'admin_bank_name' => [
                'label' => 'Nama Bank Admin',
                'type' => 'text',
                'default' => 'Bank BCA'
            ],
            'admin_bank_account' => [
                'label' => 'Nomor Rekening Admin',
                'type' => 'text',
                'default' => '1234567890'
            ],
            'admin_bank_account_name' => [
                'label' => 'Nama Pemilik Rekening Admin',
                'type' => 'text',
                'default' => 'PT. Lelang Mobil Indonesia'
            ],
            'payment_deadline_hours' => [
                'label' => 'Tenggat Waktu Pembayaran (jam)',
                'type' => 'number',
                'default' => '24'
            ],
            'service_fee_percentage' => [
                'label' => 'Persentase Biaya Layanan (%)',
                'type' => 'number',
                'step' => '0.01',
                'default' => '2.5'
            ]
        ]
    ],
    'email' => [
        'title' => 'Pengaturan Email',
        'icon' => 'fa-envelope',
        'settings' => [
            'smtp_host' => [
                'label' => 'SMTP Host',
                'type' => 'text',
                'default' => 'smtp.gmail.com'
            ],
            'smtp_port' => [
                'label' => 'SMTP Port',
                'type' => 'number',
                'default' => '587'
            ],
            'smtp_username' => [
                'label' => 'SMTP Username',
                'type' => 'text',
                'default' => 'noreply@lelangmobil.com'
            ],
            'smtp_password' => [
                'label' => 'SMTP Password',
                'type' => 'password',
                'default' => ''
            ],
            'smtp_encryption' => [
                'label' => 'SMTP Encryption',
                'type' => 'select',
                'options' => [
                    'tls' => 'TLS',
                    'ssl' => 'SSL',
                    'none' => 'None'
                ],
                'default' => 'tls'
            ]
        ]
    ]
];

// Create settings table if not exists
$create_table_sql = "CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(100) PRIMARY KEY,
    setting_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";
$conn->query($create_table_sql);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_settings'])) {
    $category = clean_input($_POST['category']);
    
    // Validate category exists
    if (array_key_exists($category, $settings_categories)) {
        $conn->begin_transaction();
        
        try {
            foreach ($settings_categories[$category]['settings'] as $key => $setting) {
                $value = isset($_POST[$key]) ? clean_input($_POST[$key]) : '';
                
                // Insert or update setting
                $upsert_sql = "INSERT INTO settings (setting_key, setting_value) 
                              VALUES (?, ?) 
                              ON DUPLICATE KEY UPDATE setting_value = ?";
                $upsert_stmt = $conn->prepare($upsert_sql);
                $upsert_stmt->bind_param("sss", $key, $value, $value);
                $upsert_stmt->execute();
            }
            
            $conn->commit();
            $success = "Pengaturan berhasil disimpan.";
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Gagal menyimpan pengaturan: " . $e->getMessage();
        }
    } else {
        $error = "Kategori pengaturan tidak valid.";
    }
}

// Get current settings from database
$settings_sql = "SELECT * FROM settings";
$settings_result = $conn->query($settings_sql);
$current_settings = [];

if ($settings_result->num_rows > 0) {
    while ($row = $settings_result->fetch_assoc()) {
        $current_settings[$row['setting_key']] = $row['setting_value'];
    }
}

// Helper function to get setting value
function get_setting_value($key, $default = '') {
    global $current_settings;
    return isset($current_settings[$key]) ? $current_settings[$key] : $default;
}

// Determine active category
$active_category = isset($_GET['category']) && array_key_exists($_GET['category'], $settings_categories) 
                   ? $_GET['category'] : 'general';
?>

<div class="container-fluid content-wrapper">
    <h1 class="mb-4">Pengaturan Sistem</h1>
    
    <?php if(isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-3">
            <div class="de-box mb-4">
                <div class="list-group">
                    <?php foreach ($settings_categories as $category_key => $category): ?>
                        <a href="?category=<?php echo $category_key; ?>" class="list-group-item list-group-item-action <?php echo ($active_category == $category_key) ? 'active' : ''; ?>">
                            <i class="fa <?php echo $category['icon']; ?> me-2"></i>
                            <?php echo $category['title']; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">
            <div class="de-box">
                <h5 class="mb-4"><?php echo $settings_categories[$active_category]['title']; ?></h5>
                
                <form method="post" action="">
                    <input type="hidden" name="category" value="<?php echo $active_category; ?>">
                    
                    <?php foreach ($settings_categories[$active_category]['settings'] as $key => $setting): ?>
                        <div class="mb-3">
                            <label for="<?php echo $key; ?>" class="form-label"><?php echo $setting['label']; ?></label>
                            
                            <?php if ($setting['type'] == 'textarea'): ?>
                                <textarea class="form-control" id="<?php echo $key; ?>" name="<?php echo $key; ?>" rows="3"><?php echo get_setting_value($key, $setting['default']); ?></textarea>
                            
                            <?php elseif ($setting['type'] == 'select'): ?>
                                <select class="form-control form-select" id="<?php echo $key; ?>" name="<?php echo $key; ?>">
                                    <?php foreach ($setting['options'] as $option_value => $option_label): ?>
                                        <option value="<?php echo $option_value; ?>" <?php echo (get_setting_value($key, $setting['default']) == $option_value) ? 'selected' : ''; ?>>
                                            <?php echo $option_label; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            
                            <?php elseif ($setting['type'] == 'number'): ?>
                                <input type="number" class="form-control" id="<?php echo $key; ?>" name="<?php echo $key; ?>" 
                                       value="<?php echo get_setting_value($key, $setting['default']); ?>"
                                       <?php echo isset($setting['step']) ? 'step="'.$setting['step'].'"' : ''; ?>>
                            
                            <?php else: ?>
                                <input type="<?php echo $setting['type']; ?>" class="form-control" id="<?php echo $key; ?>" name="<?php echo $key; ?>" 
                                       value="<?php echo $setting['type'] == 'password' ? '' : get_setting_value($key, $setting['default']); ?>"
                                       <?php echo $setting['type'] == 'password' ? 'placeholder="Leave empty to keep current password"' : ''; ?>>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    
                    <button type="submit" name="save_settings" class="btn btn-primary">
                        <i class="fa fa-save"></i> Simpan Pengaturan
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
