/**
 * Modern Theme Activator
 * Mengaktifkan tema modern dark tanpa warna putih secara otomatis
 */

document.addEventListener('DOMContentLoaded', function() {
    // Aktifkan modern-theme di body
    document.body.classList.add('modern-theme');
    
    // Cari semua elemen dengan background putih dan ganti dengan warna modern
    const elementsToModify = document.querySelectorAll('.bg-white, .text-white, .border-white');
    
    elementsToModify.forEach(element => {
        // Hapus kelas warna putih
        element.classList.remove('bg-white');
        element.classList.remove('text-white');
        element.classList.remove('border-white');
        
        // Tambahkan kelas modern
        if (element.classList.contains('card')) {
            element.classList.add('premium-card');
        }
        
        if (element.classList.contains('btn')) {
            element.classList.add('btn-premium');
        }
        
        if (element.classList.contains('table')) {
            element.classList.add('table-premium');
        }
        
        if (element.classList.contains('badge')) {
            element.classList.add('premium-badge');
        }
    });
    
    // Efek hover modern untuk cards
    const cards = document.querySelectorAll('.card, .stat-card, .premium-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = 'var(--modern-shadow-strong)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'var(--modern-shadow-soft)';
        });
    });
    
    // Animasi counter untuk nilai stat
    const statValues = document.querySelectorAll('.stat-value[data-count]');
    statValues.forEach(stat => {
        const targetValue = parseFloat(stat.getAttribute('data-count'));
        const duration = 2000; // Durasi animasi dalam ms
        const startValue = 0;
        const startTime = Date.now();
        
        const updateCounter = () => {
            const currentTime = Date.now();
            const elapsedTime = currentTime - startTime;
            const progress = Math.min(elapsedTime / duration, 1);
            
            // Fungsi easing untuk animasi yang lebih smooth
            const easeOutQuad = t => t * (2 - t);
            const easedProgress = easeOutQuad(progress);
            
            // Hitung nilai saat ini berdasarkan progress
            const currentValue = startValue + (targetValue - startValue) * easedProgress;
            
            // Format nilai dengan format Rupiah
            const formattedValue = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            }).format(currentValue);
            
            // Update teks
            stat.textContent = formattedValue;
            
            // Lanjutkan animasi jika belum selesai
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            }
        };
        
        // Mulai animasi
        updateCounter();
    });
    
    // Efek ripple untuk tombol
    const buttons = document.querySelectorAll('.btn-premium');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const ripple = document.createElement('span');
            ripple.classList.add('ripple-effect');
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
});
