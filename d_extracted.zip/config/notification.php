<?php
/**
 * Notification System for LelangMobil
 * Handles admin notifications and alerts
 */

// Make sure functions.php is included
require_once __DIR__ . '/functions.php';

// Function to save admin notification
function save_admin_notification($type, $title, $message, $link = '') {
    global $conn;
    
    $sql = "INSERT INTO admin_notifications (type, title, message, link, is_read, created_at) 
            VALUES (?, ?, ?, ?, 0, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $type, $title, $message, $link);
    return $stmt->execute();
}

// Function to notify admin about new top-up
function notify_admin_new_topup($transaction_id, $username, $amount) {
    global $conn;
    
    // Check if notifications are enabled in settings
    $notify_enabled = get_setting('notify_admin_new_topup', '1');
    
    if ($notify_enabled == '1') {
        $title = "Top-up Baru";
        $message = "User $username mengajukan top-up sebesar Rp " . number_format($amount, 0, ',', '.');
        $link = "transaction-detail.php?id=$transaction_id";
        
        return save_admin_notification('topup', $title, $message, $link);
    }
    
    return false;
}

// Function to get unread admin notifications count
function get_unread_notifications_count() {
    global $conn;
    
    $sql = "SELECT COUNT(*) as count FROM admin_notifications WHERE is_read = 0";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['count'];
    }
    
    return 0;
}

// Function to get admin notifications
function get_admin_notifications($limit = 10) {
    global $conn;
    
    $sql = "SELECT * FROM admin_notifications 
            ORDER BY created_at DESC 
            LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    
    return $stmt->get_result();
}

// Function to mark notification as read
function mark_notification_read($notification_id) {
    global $conn;
    
    $sql = "UPDATE admin_notifications SET is_read = 1 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $notification_id);
    return $stmt->execute();
}

// Function to mark all notifications as read
function mark_all_notifications_read() {
    global $conn;
    
    $sql = "UPDATE admin_notifications SET is_read = 1 WHERE is_read = 0";
    return $conn->query($sql);
}
