<?php
/**
 * Wallet Widget 2025
 * Widget untuk menampilkan informasi saldo dengan tampilan Modern 2025
 */

// Pastikan user_id tersedia
if (!isset($user_id) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
}

// Pastikan use_modern_2025 tersedia
$use_modern_2025 = isset($use_modern_2025) ? $use_modern_2025 : false;

// Inisialisasi data wallet
$wallet_balance = 0;
$hold_amount = 0;
$available_withdrawal = 0;
$active_bids_count = 0;

try {
    // Query wallet balance
    $wallet_sql = "SELECT balance, last_update FROM wallets WHERE user_id = ? LIMIT 1";
    $wallet_stmt = $conn->prepare($wallet_sql);
    $wallet_stmt->bind_param('i', $user_id);
    
    if ($wallet_stmt->execute()) {
        $wallet_result = $wallet_stmt->get_result();
        
        if ($wallet_result && $wallet_result->num_rows > 0) {
            $wallet_data = $wallet_result->fetch_assoc();
            $wallet_balance = $wallet_data['balance'];
        } else {
            // Jika wallet belum ada, buat wallet baru
            $create_wallet_sql = "INSERT INTO wallets (user_id, balance, last_update) VALUES (?, 0, NOW())";
            $create_wallet_stmt = $conn->prepare($create_wallet_sql);
            $create_wallet_stmt->bind_param('i', $user_id);
            $create_wallet_stmt->execute();
        }
    }
    
    // Periksa struktur tabel untuk menentukan nama kolom (bidder_id vs user_id)
    $column_check_sql = "SHOW COLUMNS FROM bids LIKE 'bidder_id'";
    $column_check_stmt = $conn->prepare($column_check_sql);
    $column_check_stmt->execute();
    
    if ($column_check_stmt->get_result()->num_rows > 0) {
        // Gunakan bidder_id jika kolom ada
        $active_bids_sql = "SELECT COUNT(*) as count 
                          FROM bids b 
                          JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                          WHERE b.bidder_id = ? 
                          AND v.auction_end > NOW() 
                          AND v.status = 'active'";
                          
        $hold_amount_sql = "SELECT COALESCE(SUM(b.bid_amount), 0) as total 
                          FROM bids b 
                          JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                          WHERE b.bidder_id = ? 
                          AND v.auction_end > NOW() 
                          AND v.status = 'active' 
                          AND b.bid_amount = v.current_bid";
    } else {
        // Gunakan user_id sebagai fallback
        $active_bids_sql = "SELECT COUNT(*) as count 
                          FROM bids b 
                          JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                          WHERE b.user_id = ? 
                          AND v.auction_end > NOW() 
                          AND v.status = 'active'";
                          
        $hold_amount_sql = "SELECT COALESCE(SUM(b.bid_amount), 0) as total 
                          FROM bids b 
                          JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                          WHERE b.user_id = ? 
                          AND v.auction_end > NOW() 
                          AND v.status = 'active' 
                          AND b.bid_amount = v.current_bid";
    }
    
    // Query active bids count
    $active_bids_stmt = $conn->prepare($active_bids_sql);
    $active_bids_stmt->bind_param('i', $user_id);
    
    if ($active_bids_stmt->execute()) {
        $active_bids_result = $active_bids_stmt->get_result();
        if ($active_bids_result && $active_bids_result->num_rows > 0) {
            $active_bids_data = $active_bids_result->fetch_assoc();
            $active_bids_count = $active_bids_data['count'];
        }
    }
    
    // Query hold amount
    $hold_amount_stmt = $conn->prepare($hold_amount_sql);
    $hold_amount_stmt->bind_param('i', $user_id);
    
    if ($hold_amount_stmt->execute()) {
        $hold_amount_result = $hold_amount_stmt->get_result();
        if ($hold_amount_result && $hold_amount_result->num_rows > 0) {
            $hold_amount_data = $hold_amount_result->fetch_assoc();
            $hold_amount = $hold_amount_data['total'];
        }
    }
    
    // Hitung available balance for withdrawal
    $available_withdrawal = max(0, $wallet_balance - $hold_amount);
    
} catch (Exception $e) {
    // Log error
    error_log("Error in wallet-widget-2025.php: " . $e->getMessage());
}

// Format amounts
$formatted_wallet_balance = number_format($wallet_balance, 0, ',', '.');
$formatted_hold_amount = number_format($hold_amount, 0, ',', '.');
$formatted_available_withdrawal = number_format($available_withdrawal, 0, ',', '.');
?>

<?php if ($use_modern_2025): ?>
<!-- Modern 2025 Wallet Widget -->
<div class="balance-card-2025 fade-in-up">
    <div class="balance-title-2025">Saldo Anda</div>
    <div class="balance-amount-2025">
        Rp <span class="wallet-balance" data-format="balance"><?php echo $formatted_wallet_balance; ?></span>
    </div>
    
    <div class="balance-info-2025">
        <div class="balance-info-item-2025">
            <div class="balance-info-label-2025">Ditahan</div>
            <div class="balance-info-value-2025">
                Rp <span class="wallet-balance" data-format="hold"><?php echo $formatted_hold_amount; ?></span>
            </div>
        </div>
        
        <div class="balance-info-item-2025">
            <div class="balance-info-label-2025">Tersedia</div>
            <div class="balance-info-value-2025">
                Rp <span class="wallet-balance" data-format="available"><?php echo $formatted_available_withdrawal; ?></span>
            </div>
        </div>
        
        <div class="balance-info-item-2025">
            <div class="balance-info-label-2025">Bid Aktif</div>
            <div class="balance-info-value-2025">
                <span class="active-bids-count"><?php echo $active_bids_count; ?></span>
            </div>
        </div>
    </div>
    
    <div class="balance-actions-2025">
        <a href="topup.php" class="balance-action-btn-2025">
            <i class="fas fa-plus-circle"></i> Top Up
        </a>
        
        <a href="withdraw.php" class="balance-action-btn-2025">
            <i class="fas fa-money-bill-wave"></i> Tarik Dana
        </a>
    </div>
</div>
<?php else: ?>
<!-- Legacy Wallet Widget -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">Saldo Akun</h5>
    </div>
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <span>Total Saldo:</span>
            <span class="h4 mb-0 wallet-balance">Rp <?php echo $formatted_wallet_balance; ?></span>
        </div>
        
        <div class="d-flex justify-content-between align-items-center mb-2">
            <span>Ditahan untuk Bid:</span>
            <span>Rp <?php echo $formatted_hold_amount; ?></span>
        </div>
        
        <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
            <span>Tersedia untuk Tarik:</span>
            <span>Rp <?php echo $formatted_available_withdrawal; ?></span>
        </div>
        
        <div class="d-grid gap-2">
            <a href="topup.php" class="btn btn-primary">
                <i class="fa fa-plus-circle me-2"></i>Top Up Saldo
            </a>
            <a href="withdraw.php" class="btn btn-outline-secondary">
                <i class="fa fa-money-bill-wave me-2"></i>Tarik Dana
            </a>
        </div>
    </div>
</div>
<?php endif; ?>
