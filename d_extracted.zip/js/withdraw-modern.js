/**
 * Withdraw Modern JS - LelangMobil
 * Modul JavaScript untuk halaman penarikan saldo (withdraw-menu.php)
 * Versi: 1.0 (6 Mei 2025)
 */

document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi variabel dan elemen
    const withdrawForm = document.getElementById('withdrawalForm');
    const amountInput = document.getElementById('withdraw_amount');
    const presetButtons = document.querySelectorAll('.preset-btn');
    const withdrawSubmitBtn = document.getElementById('withdrawSubmitBtn');
    const bankSelect = document.getElementById('bank_name');
    const accountNumber = document.getElementById('account_number');
    const accountName = document.getElementById('account_name');
    
    // Format angka sebagai mata uang
    function formatCurrency(number) {
        return new Intl.NumberFormat('id-ID').format(number);
    }
    
    // Unformat mata uang menjadi angka
    function unformatCurrency(currencyString) {
        return parseInt(currencyString.replace(/\D/g, '')) || 0;
    }
    
    // Handler untuk preset amount
    if (presetButtons.length > 0) {
        presetButtons.forEach(button => {
            button.addEventListener('click', function() {
                const amount = this.dataset.amount;
                
                // Hapus class active dari semua preset
                presetButtons.forEach(btn => btn.classList.remove('active'));
                
                // Tambah class active ke tombol yang dipilih
                this.classList.add('active');
                
                // Set nilai ke input
                if (amountInput) {
                    amountInput.value = amount;
                    validateForm();
                }
            });
        });
    }
    
    // Event listener untuk amount input
    if (amountInput) {
        amountInput.addEventListener('input', function() {
            // Hapus class active dari semua preset saat user mengetik jumlah
            presetButtons.forEach(btn => btn.classList.remove('active'));
            
            // Cek apakah nilai sama dengan salah satu preset, jika ya aktifkan preset tersebut
            const currentValue = this.value;
            presetButtons.forEach(btn => {
                if (btn.dataset.amount === currentValue) {
                    btn.classList.add('active');
                }
            });
            
            validateForm();
        });
    }
    
    // Validasi form sebelum submit
    function validateForm() {
        let isValid = true;
        const minimumAmount = 50000; // Minimum penarikan Rp 50.000
        
        // Validasi jumlah
        if (amountInput && (unformatCurrency(amountInput.value) < minimumAmount || !amountInput.value)) {
            isValid = false;
        }
        
        // Validasi bank dan akun
        if (bankSelect && !bankSelect.value) {
            isValid = false;
        }
        
        if (accountNumber && !accountNumber.value) {
            isValid = false;
        }
        
        if (accountName && !accountName.value) {
            isValid = false;
        }
        
        // Update tombol submit
        if (withdrawSubmitBtn) {
            withdrawSubmitBtn.disabled = !isValid;
        }
        
        return isValid;
    }
    
    // Event listener untuk validasi input bank
    if (bankSelect) {
        bankSelect.addEventListener('change', validateForm);
    }
    
    if (accountNumber) {
        accountNumber.addEventListener('input', validateForm);
    }
    
    if (accountName) {
        accountName.addEventListener('input', validateForm);
    }
    
    // Event listener untuk form submit
    if (withdrawForm) {
        withdrawForm.addEventListener('submit', function(e) {
            // Validasi terakhir sebelum submit
            if (!validateForm()) {
                e.preventDefault();
                // Tampilkan pesan error jika diperlukan
                let errorMessage = 'Mohon periksa kembali data penarikan Anda:';
                
                if (amountInput && (unformatCurrency(amountInput.value) < 50000 || !amountInput.value)) {
                    errorMessage += '\\n- Minimal penarikan adalah Rp 50.000';
                }
                
                if (bankSelect && !bankSelect.value) {
                    errorMessage += '\\n- Pilih bank tujuan';
                }
                
                if (accountNumber && !accountNumber.value) {
                    errorMessage += '\\n- Masukkan nomor rekening';
                }
                
                if (accountName && !accountName.value) {
                    errorMessage += '\\n- Masukkan nama pemilik rekening';
                }
                
                alert(errorMessage);
            }
        });
    }
    
    // Inisialisasi validasi awal
    validateForm();
    
    // Efek visual success animation
    const successAnimation = document.querySelector('.success-animation');
    if (successAnimation) {
        // Animasi checkmark muncul setelah halaman load
        setTimeout(() => {
            document.querySelector('.checkmark-circle').classList.add('show');
        }, 500);
    }
    
    // Tambahkan event listener untuk refresh data saldo
    const refreshBalanceBtn = document.querySelector('.refresh-balance');
    if (refreshBalanceBtn) {
        refreshBalanceBtn.addEventListener('click', function() {
            this.classList.add('spinning');
            
            // Lakukan refresh via AJAX (simulasi)
            setTimeout(() => {
                this.classList.remove('spinning');
            }, 1000);
        });
    }
});
