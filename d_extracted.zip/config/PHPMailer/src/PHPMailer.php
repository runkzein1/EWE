<?php
namespace PHPMailer\PHPMailer;

class PHPMailer {
    public  = '';
    public function isSMTP() { return ; }
    public function Host(System.Management.Automation.Internal.Host.InternalHost) { return ; }
    public function SMTPAuth() { return ; }
    public function Username() { return ; }
    public function Password() { return ; }
    public function SMTPSecure() { return ; }
    public function Port() { return ; }
    public function setFrom(, ) { return ; }
    public function addAddress() { return ; }
    public function isHTML() { return ; }
    public function Subject() { }
    public function Body() { }
    public function AltBody() { }
    public function send() { return true; }
}
