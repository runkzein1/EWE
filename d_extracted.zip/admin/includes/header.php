<?php
// Include configuration, database connection and functions
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is admin
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../login.php");
    exit;
}

// Get current admin info
$admin_id = $_SESSION['user_id'];
$admin_sql = "SELECT * FROM users WHERE user_id = ? AND is_admin = 1";
$admin_stmt = $conn->prepare($admin_sql);
$admin_stmt->bind_param("i", $admin_id);
$admin_stmt->execute();
$admin_result = $admin_stmt->get_result();

if ($admin_result->num_rows == 0) {
    // If user is not admin, redirect to home
    session_destroy();
    header("Location: ../index.php");
    exit;
}

$admin = $admin_result->fetch_assoc();

// Get current page for active menu highlighting
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <title><?php echo isset($page_title) ? $page_title : "Admin Panel"; ?> - LelangMobil</title>
    <link rel="icon" href="../images/icon.png" type="image/gif" sizes="16x16">
    <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <!-- CSS Files -->
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="../css/mdb.min.css" rel="stylesheet" type="text/css">
    <link href="../css/plugins.css" rel="stylesheet" type="text/css">
    <link href="../css/style.css" rel="stylesheet" type="text/css">
    <link href="../css/coloring.css" rel="stylesheet" type="text/css">
    <!-- Admin Top-up Modern Style -->
    <link href="../css/admin-topup.css" rel="stylesheet" type="text/css">
    <!-- Admin specific CSS -->
    <style>
        .admin-sidebar {
            background-color: #1A1A1A;
            min-height: 100vh;
            padding-top: 20px;
        }
        .admin-sidebar .nav-link {
            color: #fff;
            border-radius: 0;
            padding: 12px 20px;
            margin-bottom: 5px;
        }
        .admin-sidebar .nav-link:hover,
        .admin-sidebar .nav-link.active {
            background-color: #0062cc;
            color: #fff;
        }
        .admin-sidebar .nav-link i {
            margin-right: 10px;
        }
        .content-wrapper {
            padding: 30px;
        }
        .stats-card {
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            background-color: #2a2a2a;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .stats-card i {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .stats-card h3 {
            font-size: 1.8rem;
            margin-bottom: 5px;
        }
        .stats-card p {
            color: #b5b5b5;
            margin-bottom: 0;
        }
        .admin-table {
            background-color: #2a2a2a;
            border-radius: 10px;
            overflow: hidden;
        }
        .admin-table th {
            background-color: #202020;
        }
        .breadcrumb {
            background-color: #2a2a2a;
            border-radius: 5px;
            padding: 10px 15px;
            margin-bottom: 20px;
        }
        .breadcrumb-item a {
            color: #6b6b6b;
        }
        .breadcrumb-item.active {
            color: #fff;
        }
        .breadcrumb-item+.breadcrumb-item::before {
            color: #6b6b6b;
        }
    </style>
</head>

<body class="dark-scheme">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 admin-sidebar">
                <div class="text-center mb-4">
                    <a href="index.php">
                        <img src="../images/logo.png" alt="LelangMobil Admin" style="max-width: 180px;">
                    </a>
                    <div class="mt-3">
                        <h6 class="mb-0">Admin Panel</h6>
                    </div>
                </div>

                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'index.php') ? 'active' : ''; ?>" href="index.php">
                            <i class="fa fa-dashboard"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'vehicles.php') ? 'active' : ''; ?>" href="vehicles.php">
                            <i class="fa fa-car"></i> Kendaraan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'users.php') ? 'active' : ''; ?>" href="users.php">
                            <i class="fa fa-users"></i> Pengguna
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'bids.php') ? 'active' : ''; ?>" href="bids.php">
                            <i class="fa fa-gavel"></i> Riwayat Bid
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'transactions.php') ? 'active' : ''; ?>" href="transactions.php">
                            <i class="fa fa-money"></i> Transaksi
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'settings.php') ? 'active' : ''; ?>" href="settings.php">
                            <i class="fa fa-cog"></i> Pengaturan
                        </a>
                    </li>
                    <li class="nav-item mt-5">
                        <a class="nav-link" href="../logout.php">
                            <i class="fa fa-sign-out"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-0">
                <!-- Top Navigation -->
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <i class="fa fa-bars"></i>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <a class="nav-link" href="../index.php" target="_blank">Lihat Website</a>
                                </li>
                            </ul>

                            <div class="d-flex align-items-center">
                                <div class="dropdown">
                                    <a class="dropdown-toggle d-flex align-items-center text-white text-decoration-none" id="navbarDropdownMenuLink" role="button" data-mdb-toggle="dropdown" aria-expanded="false">
                                        <img src="https://via.placeholder.com/32" class="rounded-circle" height="32" alt="Admin" loading="lazy">
                                        <span class="ms-2"><?php echo $admin['username']; ?></span>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
                                        <li>
                                            <a class="dropdown-item" href="profile.php">Profil Saya</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="settings.php">Pengaturan</a>
                                        </li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="../logout.php">Logout</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>

                <!-- Page Content -->
                <div class="content-wrapper">
                    <!-- Breadcrumbs -->
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Admin</a></li>
                            <?php if (isset($page_title)): ?>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo $page_title; ?></li>
                            <?php endif; ?>
                        </ol>
                    </nav>
