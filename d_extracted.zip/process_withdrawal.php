<?php
// Aktifkan error reporting dan logging untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Set ke 0 di production

// Atur timeout eksekusi agar tidak loading berulang
set_time_limit(10);
ini_set('max_execution_time', 10);

// Set error handler untuk menangkap error fatal
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("Error in process_withdrawal.php: [$errno] $errstr in $errfile:$errline");
    header("Location: error.php?reason=" . urlencode($errstr));
    exit;
});

// Memulai session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Koneksi ke database dengan konsistensi path
require_once 'config/database.php';
require_once 'config/functions.php';

// Cek login status
if (!isset($_SESSION['user_id'])) {
    // Redirect ke halaman login jika belum login
    header('Location: login.php');
    exit;
}

// Ambil data user
$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM users WHERE user_id = ?";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Tangani form penarikan saldo
if (isset($_POST['request_withdrawal'])) {
    // Ambil data form
    $withdraw_method = $_POST['withdraw_method'];
    $amount_str = $_POST['withdraw_amount'];
    $account_number = $_POST['account_number'];
    $account_name = $_POST['account_name'];
    $notes = isset($_POST['notes']) ? $_POST['notes'] : '';
    
    // Proses amount, hapus semua yang bukan angka
    $amount = preg_replace('/[^0-9]/', '', $amount_str);
    
    // Validasi
    $errors = [];
    
    // Cek amount
    if (empty($amount) || !is_numeric($amount)) {
        $errors[] = "Jumlah penarikan tidak valid";
    } else if ($amount < 50000) {
        $errors[] = "Minimal penarikan Rp 50.000";
    } else if ($amount > $user['balance']) {
        $errors[] = "Saldo Anda tidak mencukupi";
    }
    
    // Cek akun/rekening
    if (empty($account_number)) {
        $errors[] = "Nomor rekening/akun harus diisi";
    }
    
    if (empty($account_name)) {
        $errors[] = "Nama pemilik rekening/akun harus diisi";
    }
    
    // Jika tidak ada error, proses penarikan
    if (empty($errors)) {
        try {
            // Mulai transaksi
            $conn->begin_transaction();
            
            // 1. Kurangi saldo user
            $update_balance = "UPDATE users SET balance = balance - ? WHERE user_id = ?";
            $update_stmt = $conn->prepare($update_balance);
            $update_stmt->bind_param("di", $amount, $user_id);
            $update_stmt->execute();
            
            // 2. Tambahkan ke tabel transactions
            $transaction_sql = "INSERT INTO transactions (user_id, amount, type, status, method, account_number, account_name, notes) 
                                VALUES (?, ?, 'withdrawal', 'pending', ?, ?, ?, ?)";
            $transaction_stmt = $conn->prepare($transaction_sql);
            $transaction_stmt->bind_param("idssss", $user_id, $amount, $withdraw_method, $account_number, $account_name, $notes);
            $transaction_stmt->execute();
            
            // Commit transaksi
            $conn->commit();
            
            // Set success message
            $_SESSION['success_message'] = "Permintaan penarikan sebesar Rp " . number_format($amount, 0, ',', '.') . " berhasil diajukan. Tim kami akan memproses dalam 1x24 jam kerja.";
            
            // Redirect ke halaman account
            header('Location: account.php');
            exit;
            
        } catch (Exception $e) {
            // Rollback jika terjadi error
            $conn->rollback();
            $errors[] = "Terjadi kesalahan: " . $e->getMessage();
        }
    }
    
    // Jika ada error, simpan untuk ditampilkan
    if (!empty($errors)) {
        $_SESSION['error_messages'] = $errors;
    }
}

// Redirect kembali ke halaman account
header('Location: account.php');
exit;
?>
