<?php
/**
 * Helper functions for the car auction website
 */

// Include SQL query helper functions
$query_helpers_path = __DIR__ . '/query_helpers.php';
if (file_exists($query_helpers_path)) {
    require_once $query_helpers_path;
} else {
    error_log("Query helpers file not found at: " . $query_helpers_path);

    // Definisikan fungsi-fungsi yang dibutuhkan jika file tidak ada
    if (!function_exists('get_active_bids_count')) {
        function get_active_bids_count($conn, $user_id) {
            try {
                $sql = "SELECT COUNT(*) as total
                        FROM bids b
                        JOIN vehicles v ON b.vehicle_id = v.vehicle_id
                        WHERE b.bidder_id = ? AND v.auction_end > NOW()";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($row = $result->fetch_assoc()) {
                    return $row['total'];
                }
            } catch (Throwable $e) {
                error_log("Error getting active bids count: " . $e->getMessage());
            }
            return 0;
        }
    }

    if (!function_exists('get_auction_wins_count')) {
        function get_auction_wins_count($conn, $user_id) {
            try {
                $sql = "SELECT COUNT(*) as total
                        FROM bids b
                        JOIN vehicles v ON b.vehicle_id = v.vehicle_id
                        WHERE b.bidder_id = ?
                        AND v.status = 'ended'
                        AND b.bid_amount = v.current_price";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($row = $result->fetch_assoc()) {
                    return $row['total'];
                }
            } catch (Throwable $e) {
                error_log("Error getting wins count: " . $e->getMessage());
            }
            return 0;
        }
    }

    if (!function_exists('get_vehicle_query_base')) {
        function get_vehicle_query_base() {
            return "SELECT v.vehicle_id,
                   v.model AS title,
                   v.make AS brand,
                   v.image AS image_main,
                   v.start_price AS starting_price,
                   v.current_price AS current_bid,
                   v.auction_end AS end_date,
                   v.year,
                   v.description,
                   v.status,
                   v.seller_id,
                   v.created_at
            FROM vehicles v";
        }
    }
}

// Get setting from database
function get_setting($key, $default = '') {
    global $conn;

    $sql = "SELECT setting_value FROM settings WHERE setting_key = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['setting_value'];
    }

    return $default;
}

// Clean input data to prevent injection
function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Generate a random token
function generate_token($length = 32) {
    return bin2hex(random_bytes($length));
}

// This function has been moved to mailer.php

// Check if user is logged in
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Check if user is admin
function is_admin() {
    return (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == true);
}

// Redirect if not logged in
function require_login() {
    if (!is_logged_in()) {
        header("Location: login.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}

// Redirect if not admin
function require_admin() {
    if (!is_admin()) {
        header("Location: index.php");
        exit;
    }
}

// Format currency
function format_currency($amount) {
    return 'Rp. ' . number_format($amount, 0, ',', '.');
}

// Calculate time remaining in auction
function get_time_remaining($end_date) {
    $now = new DateTime();
    $end = new DateTime($end_date);
    $interval = $now->diff($end);

    if ($interval->invert == 1) {
        return 'Selesai';
    }

    if ($interval->days > 0) {
        return $interval->format('%d hari %H jam');
    } else {
        return $interval->format('%H jam %I menit');
    }
}

// Get user info by ID
function get_user_by_id($conn, $user_id) {
    $sql = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return false;
    }
}

// Process bid submission
function process_bid($conn, $vehicle_id, $user_id, $bid_amount) {
    // Get user balance
    $user = get_user_by_id($conn, $user_id);
    if (!$user) {
        return ['success' => false, 'message' => 'Pengguna tidak ditemukan.'];
    }

    // Check if user has enough balance
    if ($user['balance'] < $bid_amount) {
        return ['success' => false, 'message' => 'Saldo tidak mencukupi. Silakan top-up saldo Anda.'];
    }

    // Get current vehicle info
    $vehicle_sql = "SELECT * FROM vehicles WHERE vehicle_id = ?";
    $vehicle_stmt = $conn->prepare($vehicle_sql);
    $vehicle_stmt->bind_param("i", $vehicle_id);
    $vehicle_stmt->execute();
    $vehicle_result = $vehicle_stmt->get_result();

    if ($vehicle_result->num_rows == 0) {
        return ['success' => false, 'message' => 'Kendaraan tidak ditemukan.'];
    }

    $vehicle = $vehicle_result->fetch_assoc();

    // Check if auction is still active
    $now = new DateTime();
    $end_date = new DateTime($vehicle['auction_end']);

    if ($now > $end_date) {
        return ['success' => false, 'message' => 'Lelang sudah berakhir.'];
    }

    // Check if bid amount is higher than current bid
    $min_bid = $vehicle['current_bid'] ? $vehicle['current_bid'] * 1.05 : $vehicle['starting_price'];

    if ($bid_amount < $min_bid) {
        return ['success' => false, 'message' => 'Tawaran harus minimal 5% lebih tinggi dari tawaran saat ini.'];
    }

    // Start transaction
    $conn->begin_transaction();

    try {
        // Release hold on previous bidder's amount (if exists)
        if ($vehicle['current_bidder']) {
            // Add transaction record for releasing previous hold
            $release_sql = "INSERT INTO transactions (user_id, amount, type, status, notes) VALUES (?, ?, 'bid_release', 'completed', ?)";
            $release_stmt = $conn->prepare($release_sql);
            $release_notes = "Pengembalian dana untuk tawaran yang dikalahkan pada lelang: " . $vehicle['title'];
            $release_stmt->bind_param("ids", $vehicle['current_bidder'], $vehicle['current_bid'], $release_notes);
            $release_stmt->execute();

            // Update previous bidder's balance
            $update_prev_balance = "UPDATE users SET balance = balance + ? WHERE user_id = ?";
            $update_prev_stmt = $conn->prepare($update_prev_balance);
            $update_prev_stmt->bind_param("di", $vehicle['current_bid'], $vehicle['current_bidder']);
            $update_prev_stmt->execute();
        }

        // Add bid record
        $bid_sql = "INSERT INTO bids (vehicle_id, bidder_id, bid_amount) VALUES (?, ?, ?)";
        $bid_stmt = $conn->prepare($bid_sql);
        $bid_stmt->bind_param("iid", $vehicle_id, $user_id, $bid_amount);
        $bid_stmt->execute();

        // Add transaction record for hold
        $hold_sql = "INSERT INTO transactions (user_id, amount, type, status, notes) VALUES (?, ?, 'bid_hold', 'completed', ?)";
        $hold_stmt = $conn->prepare($hold_sql);
        $hold_notes = "Dana ditahan untuk tawaran pada lelang: " . $vehicle['title'];
        $hold_stmt->bind_param("ids", $user_id, $bid_amount, $hold_notes);
        $hold_stmt->execute();

        // Update user's balance
        $update_balance = "UPDATE users SET balance = balance - ? WHERE user_id = ?";
        $update_stmt = $conn->prepare($update_balance);
        $update_stmt->bind_param("di", $bid_amount, $user_id);
        $update_stmt->execute();

        // Update vehicle's current bid and bidder
        $update_vehicle = "UPDATE vehicles SET current_bid = ?, current_bidder = ? WHERE vehicle_id = ?";
        $update_vehicle_stmt = $conn->prepare($update_vehicle);
        $update_vehicle_stmt->bind_param("dii", $bid_amount, $user_id, $vehicle_id);
        $update_vehicle_stmt->execute();

        // Commit transaction
        $conn->commit();

        return ['success' => true, 'message' => 'Tawaran berhasil diajukan!'];
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        return ['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()];
    }
}

/**
 * Fungsi untuk menampilkan pesan dengan format yang konsisten
 *
 * @param string $type Tipe alert (success, danger, warning, info)
 * @param string $message Pesan yang akan ditampilkan
 * @return string HTML untuk menampilkan pesan
 */
function show_message($type, $message) {
    return '<div class="alert alert-' . $type . ' alert-dismissible fade show">
        ' . $message . '
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}

/**
 * Fungsi untuk mendapatkan thumbnail kendaraan
 *
 * @param string $image_path Path gambar yang akan dicek
 * @param string $default_image Gambar default jika gambar tidak ditemukan
 * @return string Path gambar yang akan digunakan
 */
function get_vehicle_thumbnail($image_path, $default_image = 'images/vehicles/default.jpg') {
    if (!empty($image_path) && file_exists($image_path)) {
        return $image_path;
    }
    return $default_image;
}

/**
 * Fungsi untuk memastikan direktori upload ada
 *
 * @param string $dir Path direktori yang akan dicek
 * @return boolean True jika direktori berhasil dibuat atau sudah ada
 */
function ensure_upload_dir($dir) {
    if (!file_exists($dir)) {
        return mkdir($dir, 0755, true);
    }
    return true;
}

/**
 * Fungsi untuk mendapatkan URL gambar dengan benar
 * Menangani path baik dari struktur lama maupun baru
 *
 * @param string $image_path Path gambar dari database
 * @return string Valid URL gambar
 */
function get_vehicle_image_url($image_path) {
    // Jika path tidak ada, kembalikan gambar placeholder
    if (empty($image_path)) {
        return 'images/cars/placeholder.jpg';
    }

    // Periksa apakah file ada
    if (file_exists($image_path)) {
        return $image_path;
    }

    // Jika file tidak ada, coba cari di direktori alternatif
    $filename = basename($image_path);
    $alt_paths = [
        'uploads/vehicles/' . $filename,
        'images/cars/' . $filename
    ];

    foreach ($alt_paths as $path) {
        if (file_exists($path)) {
            return $path;
        }
    }

    // Jika tidak ditemukan, kembalikan placeholder
    return 'images/cars/placeholder.jpg';
}

/**
 * Fungsi untuk mengecek apakah bid masih aktif
 *
 * @param array $bid Data bid dari database
 * @return boolean True jika bid masih aktif
 */
function is_bid_active($bid) {
    // Jika bid tidak valid, return false
    if (!is_array($bid) && !is_object($bid)) {
        return false;
    }

    // Convert bid ke array jika object
    if (is_object($bid)) {
        $bid = (array)$bid;
    }

    // Cek apakah end_date ada dan valid
    $end_date = get_value($bid, 'end_date', '');
    if (empty($end_date)) {
        return false;
    }

    // Bandingkan dengan waktu sekarang
    $now = new DateTime();
    $auction_end = new DateTime($end_date);

    return $now < $auction_end;
}

/**
 * Fungsi untuk mendapatkan sisa waktu bid dalam format yang mudah dibaca
 *
 * @param array $bid Data bid dari database
 * @return string Sisa waktu dalam format yang mudah dibaca
 */
function get_bid_remaining_time($bid) {
    // Jika bid tidak valid, return string kosong
    if (!is_array($bid) && !is_object($bid)) {
        return 'Tidak diketahui';
    }

    // Convert bid ke array jika object
    if (is_object($bid)) {
        $bid = (array)$bid;
    }

    // Cek apakah end_date ada dan valid
    $end_date = get_value($bid, 'end_date', '');
    if (empty($end_date)) {
        return 'Tidak diketahui';
    }

    // Hitung selisih waktu
    $now = new DateTime();
    $auction_end = new DateTime($end_date);

    if ($now > $auction_end) {
        return 'Lelang telah berakhir';
    }

    $interval = $now->diff($auction_end);

    // Format output berdasarkan interval
    if ($interval->days > 0) {
        return $interval->format('%a hari %h jam');
    } else if ($interval->h > 0) {
        return $interval->format('%h jam %i menit');
    } else {
        return $interval->format('%i menit %s detik');
    }
}

/* PENTING: Fungsi is_valid_result() didefinisikan di includes/validate-helper.php
 * Jangan mendefinisikan ulang di sini untuk menghindari fatal error
 * Berikut definisinya untuk referensi:
 *
 * function is_valid_result($result) {
 *     return $result && is_object($result) && method_exists($result, 'num_rows');
 * }
 */

/**
 * Fungsi untuk menyamarkan username untuk privacy
 *
 * @param string $username Username yang akan disamarkan
 * @param int $visible_start Jumlah karakter awal yang tetap terlihat
 * @param int $visible_end Jumlah karakter akhir yang tetap terlihat
 * @return string Username yang telah disamarkan
 */
function mask_username($username) {
    if (empty($username)) {
        return 'User-####';
    }

    $length = strlen($username);

    // Jika username terlalu pendek
    if ($length <= 4) {
        return substr($username, 0, 1) . '***';
    }

    // Username disamarkan: karakter pertama + asterisk + karakter terakhir
    return substr($username, 0, 1) .
           str_repeat('*', $length - 2) .
           substr($username, -1);
}

/**
 * Fungsi untuk mendapatkan nilai dari array/object dengan aman
 *
 * @param array|object $data Data array atau object
 * @param string $key Key yang ingin diambil
 * @param mixed $default Nilai default jika key tidak ada
 * @return mixed Nilai dari key atau default jika tidak ditemukan
 */
function get_value($data, $key, $default = '') {
    if (is_array($data)) {
        return isset($data[$key]) ? $data[$key] : $default;
    } else if (is_object($data)) {
        return isset($data->$key) ? $data->$key : $default;
    }
    return $default;
}

/**
 * Fungsi untuk memformat tanggal dengan aman
 *
 * @param array|object $data Data array atau object
 * @param string $key Key tanggal yang ingin diformat
 * @param string $format Format tanggal (default: d M Y H:i)
 * @return string Tanggal terformat atau string kosong jika tidak valid
 */
function get_formatted_date($data, $key, $format = 'd M Y H:i') {
    $date_string = get_value($data, $key, '');
    if (empty($date_string)) {
        return '';
    }

    try {
        $date = new DateTime($date_string);
        return $date->format($format);
    } catch (Exception $e) {
        return '';
    }
}

/**
 * Common Functions
 *
 * Contains all utility functions used throughout the application.
 */

/**
 * Redirect to a specific URL
 *
 * @param string $url URL to redirect to
 * @return void
 */
function redirect_to($url) {
    header("Location: " . $url);
    exit;
}

// Include config file if not already included
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/config.php';
}

/**
 * Sanitizes user input to prevent XSS attacks
 *
 * @param string $input The input to sanitize
 * @param int $filter The filter type to apply (defaults to FILTER_SANITIZE_SPECIAL_CHARS)
 * @return string The sanitized input
 */
function sanitize_input($input, $filter = FILTER_SANITIZE_SPECIAL_CHARS) {
    // FILTER_SANITIZE_STRING is deprecated in PHP 8.1+
    // Use FILTER_SANITIZE_SPECIAL_CHARS for XSS prevention
    return filter_var(trim($input), $filter);
}

/**
 * Logs error messages to the error log file
 *
 * @param string $message The error message to log
 * @return void
 */
function log_error($message) {
    if (defined('LOG_ERRORS') && LOG_ERRORS) {
        error_log('[' . date('Y-m-d H:i:s') . '] ' . $message . "\n", 3, ERROR_LOG_FILE);
    }
}

/**
 * Retrieves user data from the database
 *
 * @param mysqli $db The database connection
 * @param int $user_id The user ID
 * @return array|false The user data as an associative array, or false if not found
 */
function get_user_data($db, $user_id) {
    // Prepare query with parameterized statement to prevent SQL injection
    $query = "SELECT * FROM users WHERE user_id = ?";
    $stmt = mysqli_prepare($db, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user_data = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if ($user_data) {
            return $user_data;
        }
    }

    // Return demo data if user not found
    return [
        'user_id' => $user_id,
        'username' => 'User' . $user_id,
        'full_name' => 'Demo User',
        'email' => 'user' . $user_id . '@example.com',
        'phone' => '08123456789',
        'receive_notifications' => 1,
        'items_per_page' => DEFAULT_ITEMS_PER_PAGE,
        'profile_picture_filename' => null
    ];
}

/**
 * Retrieves user wallet information
 *
 * @param mysqli $db The database connection
 * @param int $user_id The user ID
 * @return array The wallet data
 */
function get_user_wallet($db, $user_id) {
    // First try to get wallet from users table
    $query = "SELECT balance FROM users WHERE user_id = ?";
    $stmt = mysqli_prepare($db, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user_data = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if ($user_data && isset($user_data['balance'])) {
            return [
                'balance' => $user_data['balance'],
                'last_updated' => date('Y-m-d H:i:s')
            ];
        }
    }

    // If not found in users table, try wallets table
    $query = "SELECT * FROM wallets WHERE user_id = ?";
    $stmt = mysqli_prepare($db, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $wallet_data = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if ($wallet_data) {
            return $wallet_data;
        }
    }

    // Return demo data if no wallet found
    return [
        'balance' => 5000000,
        'last_updated' => date('Y-m-d H:i:s')
    ];
}

/**
 * Retrieves user's active bids
 *
 * @param mysqli $db The database connection
 * @param int $user_id The user ID
 * @return array The active bids
 */
function get_user_active_bids($db, $user_id) {
    // Prepare query with parameterized statement
    $query = "SELECT b.*, v.model as vehicle_title, v.auction_end as auction_end_time,
              v.current_bid, v.image_main as item_image_url, v.vehicle_id
              FROM bids b
              JOIN vehicles v ON b.vehicle_id = v.vehicle_id
              WHERE b.bidder_id = ? AND v.auction_end > NOW()
              ORDER BY b.bid_time DESC";

    $stmt = mysqli_prepare($db, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $bids = [];

        while ($bid = mysqli_fetch_assoc($result)) {
            // Determine bid status
            $bid['is_winning'] = ($bid['bid_amount'] >= $bid['current_bid']);
            $bid['is_outbid'] = ($bid['bid_amount'] < $bid['current_bid']);
            $bid['auction_url'] = BASE_URL . 'vehicle.php?id=' . $bid['vehicle_id'];
            $bids[] = $bid;
        }

        mysqli_stmt_close($stmt);
        return $bids;
    }

    // Return empty array for demo
    return [];
}

/**
 * Retrieves user transactions
 *
 * @param mysqli $db The database connection
 * @param int $user_id The user ID
 * @param int $limit The maximum number of transactions to retrieve
 * @return array The transactions
 */
function get_user_transactions($db, $user_id, $limit = 10) {
    // Prepare query with parameterized statement
    $query = "SELECT * FROM transactions
              WHERE user_id = ?
              ORDER BY created_at DESC
              LIMIT ?";

    $stmt = mysqli_prepare($db, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'ii', $user_id, $limit);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $transactions = [];

        while ($transaction = mysqli_fetch_assoc($result)) {
            $transactions[] = $transaction;
        }

        mysqli_stmt_close($stmt);

        if (!empty($transactions)) {
            return $transactions;
        }
    }

    // Return demo data
    $transaction_types = ['deposit', 'withdrawal', 'bid_hold', 'bid_release', 'auction_win', 'refund', 'fee'];
    $statuses = ['completed', 'pending', 'failed'];
    $demo_transactions = [];

    for ($i = 0; $i < min(20, $limit); $i++) {
        $type = $transaction_types[array_rand($transaction_types)];
        $status = $statuses[array_rand($statuses)];
        $is_debit = in_array($type, ['withdrawal', 'bid_hold', 'fee']);

        $demo_transactions[] = [
            'transaction_id' => $i + 1,
            'user_id' => $user_id,
            'created_at' => date('Y-m-d H:i:s', time() - (86400 * $i)), // Past dates
            'amount' => ($is_debit ? -1 : 1) * rand(10000, 5000000),
            'type' => $type,
            'notes' => ucfirst(str_replace('_', ' ', $type)) . ' #' . rand(1000, 9999),
            'status' => $status
        ];
    }

    return $demo_transactions;
}

/**
 * Updates user profile information
 *
 * @param mysqli $db The database connection
 * @param int $user_id The user ID
 * @param array $profile_data The profile data to update
 * @return bool Whether the update was successful
 */
function update_user_profile($db, $user_id, $profile_data) {
    $allowed_fields = ['full_name', 'email', 'phone', 'address', 'city', 'postal_code'];
    $updates = [];
    $types = '';
    $values = [];

    // Filter profile data to only allowed fields
    foreach ($profile_data as $field => $value) {
        if (in_array($field, $allowed_fields)) {
            $updates[] = "{$field} = ?";
            $types .= 's'; // Assuming all fields are strings
            $values[] = $value;
        }
    }

    // Nothing to update
    if (empty($updates)) {
        return false;
    }

    // Add the user_id parameter
    $types .= 'i';
    $values[] = $user_id;

    // Prepare the update query
    $query = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
    $stmt = mysqli_prepare($db, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, $types, ...$values);
        $result = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        return $result;
    }

    // For demo, always return true
    return true;
}

/**
 * Changes user password
 *
 * @param mysqli $db The database connection
 * @param int $user_id The user ID
 * @param string $current_password The current password
 * @param string $new_password The new password
 * @return bool|string True if successful, error message otherwise
 */
function change_user_password($db, $user_id, $current_password, $new_password) {
    // Verify current password
    $query = "SELECT password_hash FROM users WHERE id = ?";
    $stmt = mysqli_prepare($db, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $stored_hash);

        if (mysqli_stmt_fetch($stmt)) {
            mysqli_stmt_close($stmt);

            // Verify the current password
            if (!password_verify($current_password, $stored_hash)) {
                return "Current password is incorrect.";
            }

            // Verify new password meets requirements
            if (strlen($new_password) < PASSWORD_MIN_LENGTH) {
                return "New password must be at least " . PASSWORD_MIN_LENGTH . " characters long.";
            }

            // Hash new password
            $new_hash = password_hash($new_password, PASSWORD_DEFAULT);

            // Update password
            $update_query = "UPDATE users SET password_hash = ? WHERE id = ?";
            $update_stmt = mysqli_prepare($db, $update_query);

            if ($update_stmt) {
                mysqli_stmt_bind_param($update_stmt, 'si', $new_hash, $user_id);
                $result = mysqli_stmt_execute($update_stmt);
                mysqli_stmt_close($update_stmt);

                return $result;
            }
        } else {
            mysqli_stmt_close($stmt);
            return "User not found.";
        }
    }

    // For demo, always return true
    return true;
}

/**
 * Updates user preferences
 *
 * @param mysqli $db The database connection
 * @param int $user_id The user ID
 * @param array $prefs The preferences to update
 * @return bool Whether the update was successful
 */
function update_user_preferences($db, $user_id, $prefs) {
    $allowed_fields = ['receive_notifications', 'items_per_page', 'newsletter_subscribed', 'site_theme'];
    $updates = [];
    $types = '';
    $values = [];

    // Filter preferences to only allowed fields
    foreach ($prefs as $field => $value) {
        if (in_array($field, $allowed_fields)) {
            $updates[] = "{$field} = ?";
            $types .= is_int($value) ? 'i' : 's'; // Determine parameter type
            $values[] = $value;
        }
    }

    // Nothing to update
    if (empty($updates)) {
        return false;
    }

    // Add the user_id parameter
    $types .= 'i';
    $values[] = $user_id;

    // Prepare the update query
    $query = "UPDATE user_preferences SET " . implode(', ', $updates) . " WHERE user_id = ?";
    $stmt = mysqli_prepare($db, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, $types, ...$values);
        $result = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        return $result;
    }

    // For demo, always return true
    return true;
}

/**
 * Handles profile picture upload
 *
 * @param mysqli $db The database connection
 * @param int $user_id The user ID
 * @param array $file The uploaded file data ($_FILES['profile_picture'])
 * @return bool|string True if successful, error message otherwise
 */
function handle_profile_picture_upload($db, $user_id, $file) {
    // Validate file
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $max_size = 2 * 1024 * 1024; // 2MB

    if (!in_array($file['type'], $allowed_types)) {
        return "Invalid file type. Only JPEG, PNG and GIF are allowed.";
    }

    if ($file['size'] > $max_size) {
        return "File is too large. Maximum size is 2MB.";
    }

    // Create profile pictures directory if it doesn't exist
    if (!is_dir(PROFILE_PICTURES_PATH)) {
        mkdir(PROFILE_PICTURES_PATH, 0755, true);
    }

    // Generate a unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'user_' . $user_id . '_' . time() . '.' . $extension;
    $target_path = PROFILE_PICTURES_PATH . $filename;

    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        // Update user profile picture in database
        $query = "UPDATE users SET profile_picture_filename = ? WHERE id = ?";
        $stmt = mysqli_prepare($db, $query);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'si', $filename, $user_id);
            $result = mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            return $result;
        }
    } else {
        return "Failed to upload file. Please try again.";
    }

    // For demo, always return true
    return true;
}
