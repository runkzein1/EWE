<?php
/**
 * File Keamanan untuk LelangMobil
 * Versi: 1.1
 * Tanggal: 2025-05-14
 * 
 * File ini berisi function keamanan untuk melindungi website dari:
 * - SQL Injection
 * - XSS Attacks
 * - CSRF Attacks
 * - Brute Force Attacks
 * - Session Hijacking
 * 
 * CATATAN PENTING: Semua fungsi dalam file ini menggunakan conditional declaration
 * untuk mencegah konflik dengan fungsi yang sudah ada di file lain (seperti functions.php).
 * Jika Anda ingin memodifikasi fungsi, pastikan untuk mempertahankan pola ini.
 */

// Ubah setting PHP untuk keamanan
ini_set('session.cookie_httponly', 1); // Mencegah JavaScript mengakses cookie session
ini_set('session.use_only_cookies', 1); // Hanya gunakan cookies untuk menyimpan session ID
ini_set('session.cookie_secure', 1); // Cookie hanya dikirim melalui HTTPS

// Proteksi terhadap XSS (Cross-Site Scripting)
if (!function_exists('xss_clean')) {
    function xss_clean($data) {
        // Hapus spasi di awal dan akhir
        if (is_string($data)) {
            $data = trim($data);
        }
        
        // Jika array, lakukan clean pada semua elemen
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = xss_clean($value);
            }
            return $data;
        }
        
        // Convert special characters to HTML entities
        return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    }
}

// CSRF Protection - Generate token
/**
 * CSRF Protection - Generate token
 * Improved version with token regeneration protection and longer lifespan
 */
if (!function_exists('generate_csrf_token')) {
    function generate_csrf_token() {
        // Initialize the token if it doesn't exist
        if (!isset($_SESSION['csrf_token']) || empty($_SESSION['csrf_token'])) {
            try {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                $_SESSION['csrf_token_time'] = time();
            } catch (Exception $e) {
                // Fallback if random_bytes fails
                $_SESSION['csrf_token'] = md5(uniqid(mt_rand(), true) . session_id() . time());
                $_SESSION['csrf_token_time'] = time();
                error_log("CSRF token generation used fallback method: " . $e->getMessage());
            }
        }
        
        // Only regenerate token if it's older than 2 hours
        if (isset($_SESSION['csrf_token_time']) && (time() - $_SESSION['csrf_token_time']) > 7200) {
            try {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                $_SESSION['csrf_token_time'] = time();
            } catch (Exception $e) {
                // Fallback if random_bytes fails
                $_SESSION['csrf_token'] = md5(uniqid(mt_rand(), true) . session_id() . time());
                $_SESSION['csrf_token_time'] = time();
                error_log("CSRF token regeneration used fallback method: " . $e->getMessage());
            }
        }
        
        return $_SESSION['csrf_token'];
    }
}

/**
 * CSRF Protection - Verify token with improved validation
 */
if (!function_exists('verify_csrf_token')) {
    function verify_csrf_token($token) {
        // Basic validation
        if (!isset($_SESSION['csrf_token']) || empty($_SESSION['csrf_token']) || empty($token)) {
            error_log("CSRF token validation failed: Token missing in session or request");
            return false;
        }
        
        // Compare submitted token with session token
        if ($token !== $_SESSION['csrf_token']) {
            error_log("CSRF token mismatch: Got " . substr($token, 0, 16) . "... but expected " . substr($_SESSION['csrf_token'], 0, 16) . "...");
            return false;
        }
        
        // Token is valid
        return true;
    }
}

// Generate token field untuk form
if (!function_exists('csrf_token_field')) {
    function csrf_token_field() {
        $token = generate_csrf_token();
        return '<input type="hidden" name="csrf_token" value="' . $token . '">';
    }
}

// Clean input data - check if function exists to avoid redeclaration
if (!function_exists('clean_input_secure')) {
    function clean_input_secure($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
        return $data;
    }
}

// Function to use instead of clean_input in security.php
// This ensures compatibility with existing code
if (!function_exists('security_clean_input')) {
    function security_clean_input($data) {
        // Use the function from functions.php if it's available,
        // otherwise use our secure version
        if (function_exists('clean_input')) {
            return clean_input($data);
        } else {
            return clean_input_secure($data);
        }
    }
}

// Prevent SQL Injection for numeric values
if (!function_exists('sanitize_int')) {
    function sanitize_int($input) {
        return filter_var($input, FILTER_VALIDATE_INT);
    }
}

// Prevent SQL Injection for decimal values
if (!function_exists('sanitize_float')) {
    function sanitize_float($input) {
        return filter_var($input, FILTER_VALIDATE_FLOAT);
    }
}

// Sanitize URL input
if (!function_exists('sanitize_url')) {
    function sanitize_url($url) {
        return filter_var($url, FILTER_SANITIZE_URL);
    }
}

// Generate secure random token - check if function exists to avoid redeclaration
if (!function_exists('generate_token_secure')) {
    function generate_token_secure($length = 32) {
        try {
            return bin2hex(random_bytes($length / 2));
        } catch (Exception $e) {
            // Fallback if random_bytes fails
            return md5(uniqid(mt_rand(), true) . time());
        }
    }
}

// Function to use instead of generate_token in security.php
// This ensures compatibility with existing code
if (!function_exists('security_generate_token')) {
    function security_generate_token($length = 32) {
        // Use the function from functions.php if it's available,
        // otherwise use our secure version
        if (function_exists('generate_token')) {
            return generate_token($length);
        } else {
            return generate_token_secure($length);
        }
    }
}

// Validate URL
if (!function_exists('is_valid_url')) {
    function is_valid_url($url) {
        return filter_var($url, FILTER_VALIDATE_URL) !== false;
    }
}
