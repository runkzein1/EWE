<?php
/**
 * Modern Transactions Page
 * LelangMobil Web App - Versi 2025
 */

// Aktifkan error reporting dan logging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 90);

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';
$user_id = $_SESSION['user_id'];

// Get user information
try {
    $user_sql = "SELECT * FROM users WHERE user_id = ?";
    $user_stmt = $conn->prepare($user_sql);
    $user_stmt->bind_param("i", $user_id);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    $user = $user_result->fetch_assoc();
} catch (Throwable $e) {
    die("Error fetching user data: " . $e->getMessage());
}

// Get Transactions with Pagination
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$items_per_page = 10;
$offset = ($page - 1) * $items_per_page;

// Get total count for pagination
$count_sql = "SELECT COUNT(*) as total FROM transactions WHERE user_id = ?";
$count_stmt = $conn->prepare($count_sql);
$count_stmt->bind_param("i", $user_id);
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_items = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_items / $items_per_page);

// Get paginated transactions
try {
    $transactions_sql = "SELECT * FROM transactions 
                        WHERE user_id = ? 
                        ORDER BY created_at DESC 
                        LIMIT ? OFFSET ?";
    $transactions_stmt = $conn->prepare($transactions_sql);
    $transactions_stmt->bind_param("iii", $user_id, $items_per_page, $offset);
    $transactions_stmt->execute();
    $transactions_result = $transactions_stmt->get_result();
} catch (Throwable $e) {
    error_log("Error fetching transactions: " . $e->getMessage());
    $error = "Gagal mengambil data transaksi: " . $e->getMessage();
}

// Aktifkan flag untuk halaman dashboard dan tema modern
$page_title = "Riwayat Transaksi";
$is_dashboard_page = true;
$use_modern_dashboard = true;

// Set variabel untuk komponen transaksi
$show_pagination = true;
$current_page = $page;

// Include header
include("includes/header.php");
?>

<!-- Main Content Container -->
<div class="container-fluid py-5">
    <?php if (!empty($success)): ?>
    <div class="modern-alert modern-alert-success mb-4 fade-in">
        <i class="fa fa-check-circle"></i>
        <div><?php echo $success; ?></div>
    </div>
    <?php endif; ?>
    
    <?php if (!empty($error)): ?>
    <div class="modern-alert modern-alert-danger mb-4 fade-in">
        <i class="fa fa-exclamation-circle"></i>
        <div><?php echo $error; ?></div>
    </div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Sidebar Navigation -->
        <div class="col-lg-3">
            <?php include("includes/account-navbar.php"); ?>
        </div>
        
        <!-- Main Content -->
        <div class="col-lg-9">
            <h2 class="mb-4 fade-in"><?php echo $page_title; ?></h2>
            
            <!-- Transactions Table Component -->
            <?php include("includes/transactions-table.php"); ?>
        </div>
    </div>
</div>

<?php include("includes/footer.php"); ?>
