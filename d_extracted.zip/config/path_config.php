<?php
/**
 * Path Configuration
 * LelangMobil Web App - Versi 2025
 * 
 * This file handles path detection and configuration for both development and production environments
 */

// Prevent direct access
if (!defined('SECURE_ACCESS') && basename($_SERVER['SCRIPT_FILENAME']) == basename(__FILE__)) {
    die('Direct access to this file is not allowed.');
}

// Define SECURE_ACCESS to allow inclusion in other files
if (!defined('SECURE_ACCESS')) {
    define('SECURE_ACCESS', true);
}

// Detect environment and set paths
class PathConfig {
    private static $instance = null;
    private $root_path;
    private $base_url;
    private $is_production;
    private $config_path;
    private $includes_path;
    private $uploads_path;
    private $logs_path;
    
    private function __construct() {
        // Detect if we're in production environment
        $this->is_production = (
            strpos($_SERVER['DOCUMENT_ROOT'] ?? '', '/home/lelang/public_html') !== false || 
            file_exists('/home/lelang/public_html')
        );
        
        // Set root path based on environment
        if ($this->is_production) {
            $this->root_path = '/home/lelang/public_html/';
            $this->base_url = '/';
        } else {
            // Development environment
            $this->root_path = dirname(dirname(__FILE__)) . '/';
            $this->base_url = '/';
        }
        
        // Set derived paths
        $this->config_path = $this->root_path . 'config/';
        $this->includes_path = $this->root_path . 'includes/';
        $this->uploads_path = $this->root_path . 'uploads/';
        $this->logs_path = $this->root_path . 'logs/';
        
        // Create required directories if they don't exist
        $this->ensureDirectoriesExist();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new PathConfig();
        }
        return self::$instance;
    }
    
    private function ensureDirectoriesExist() {
        $dirs = [
            $this->config_path,
            $this->includes_path,
            $this->uploads_path,
            $this->logs_path
        ];
        
        foreach ($dirs as $dir) {
            if (!file_exists($dir) && is_writable(dirname($dir))) {
                @mkdir($dir, 0755, true);
            }
        }
    }
    
    public function getRootPath() {
        return $this->root_path;
    }
    
    public function getBaseUrl() {
        return $this->base_url;
    }
    
    public function getConfigPath() {
        return $this->config_path;
    }
    
    public function getIncludesPath() {
        return $this->includes_path;
    }
    
    public function getUploadsPath() {
        return $this->uploads_path;
    }
    
    public function getLogsPath() {
        return $this->logs_path;
    }
    
    public function isProduction() {
        return $this->is_production;
    }
    
    public function getIncludePath($file) {
        // First try production path
        $prod_path = '/home/lelang/public_html/' . $file;
        if (file_exists($prod_path)) {
            return $prod_path;
        }
        
        // Then try relative path
        return $file;
    }
}

// Initialize path configuration
$path_config = PathConfig::getInstance();

// Define constants for backward compatibility
define('ROOT_PATH', $path_config->getRootPath());
define('BASE_URL', $path_config->getBaseUrl());
define('CONFIG_PATH', $path_config->getConfigPath());
define('INCLUDES_PATH', $path_config->getIncludesPath());
define('UPLOADS_PATH', $path_config->getUploadsPath());
define('LOGS_PATH', $path_config->getLogsPath());
define('IS_PRODUCTION', $path_config->isProduction());

/**
 * Helper function to include a file with proper path handling
 * @param string $file File path relative to root
 * @return bool True if file was included successfully
 */
function include_file($file) {
    global $path_config;
    
    // Try production path first
    $prod_path = '/home/lelang/public_html/' . $file;
    if (file_exists($prod_path)) {
        include_once($prod_path);
        return true;
    }
    
    // Then try relative path
    if (file_exists($file)) {
        include_once($file);
        return true;
    }
    
    // Finally try with root path
    $root_path = $path_config->getRootPath() . $file;
    if (file_exists($root_path)) {
        include_once($root_path);
        return true;
    }
    
    error_log("Failed to include file: $file");
    return false;
}

/**
 * Helper function to require a file with proper path handling
 * @param string $file File path relative to root
 * @return bool True if file was required successfully
 */
function require_file($file) {
    global $path_config;
    
    // Try production path first
    $prod_path = '/home/lelang/public_html/' . $file;
    if (file_exists($prod_path)) {
        require_once($prod_path);
        return true;
    }
    
    // Then try relative path
    if (file_exists($file)) {
        require_once($file);
        return true;
    }
    
    // Finally try with root path
    $root_path = $path_config->getRootPath() . $file;
    if (file_exists($root_path)) {
        require_once($root_path);
        return true;
    }
    
    // If we get here, the file doesn't exist
    throw new Exception("Required file not found: $file");
}
