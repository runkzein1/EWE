<?php
/**
 * CSS Loader untuk LelangMobil
 * File ini berisi semua CSS yang dibutuhkan oleh aplikasi
 * Versi: 1.0 (2 Mei 2025)
 */

// Base path for assets
$base_path = isset($base_path) ? $base_path : "";

// CSS Core - Wajib untuk semua halaman
$core_css = [
    'bootstrap.min.css',
    'mdb.min.css',
    'plugins.css',
    'style.css',
    'coloring.css'
];

// CSS Components - Komponen umum
$component_css = [
    'auction-badges.css',
    'car-card.css',
    'topup-withdraw.css',
    'trust-badges.css'
];

// CSS Modern & Premium Effects - Efek dan tema modern
$modern_css = [
    'lelangmobil-modern.css',
    'modern-effects.css',
    'premium-effects.css',
    'modern-dark-theme.css',
    'real-time-notifications.css',
    'wallet-modern-2025.css',
    'modern-2025.css',
    'account-modern-2025.css'
];

// CSS Dashboard & Account - Khusus halaman dashboard/account
$dashboard_css = [
    'lelangmobil-dashboard.css',
    'lelangmobil-financial.css',
    'bid-cards.css',
    'premium-dashboard.css',
    'modern-dashboard.css'
];

// CSS Ultra Modern & Automotive - Tema otomotif premium terbaru
$ultra_modern_css = [
    'ultra-modern.css',
    'premium-theme.css',
    'effects.css',
    'account-fixes.css',
    'wallet-modern.css',
    'bid-history-modern.css',
    'modern-background.css',
    'vehicle-modern.css',
    'wallet-premium.css',
    'profile-premium.css',
    'account-ultra-modern.css',
    'balance-components.css',
    'activity-components.css'
];

// Output Core CSS
foreach ($core_css as $css) {
    // Periksa apakah file ada sebelum di-output untuk menghindari 404
    if (file_exists(dirname(__DIR__) . '/css/' . $css)) {
        echo '<link href="' . $base_path . 'css/' . $css . '" rel="stylesheet" type="text/css">' . PHP_EOL;
    }
}

// Output Components CSS
foreach ($component_css as $css) {
    // Periksa apakah file ada sebelum di-output
    if (file_exists(dirname(__DIR__) . '/css/' . $css)) {
        echo '<link rel="stylesheet" href="' . $base_path . 'css/' . $css . '">' . PHP_EOL;
    }
}

// Output Modern CSS
foreach ($modern_css as $css) {
    // Periksa apakah file ada sebelum di-output
    if (file_exists(dirname(__DIR__) . '/css/' . $css)) {
        echo '<link rel="stylesheet" href="' . $base_path . 'css/' . $css . '">' . PHP_EOL;
    }
}

// Jika ini adalah halaman dashboard/account, output CSS Dashboard
if (isset($is_dashboard_page) && $is_dashboard_page) {
    foreach ($dashboard_css as $css) {
        // Periksa apakah file ada sebelum di-output
        if (file_exists(dirname(__DIR__) . '/css/' . $css)) {
            echo '<link rel="stylesheet" href="' . $base_path . 'css/' . $css . '">' . PHP_EOL;
        }
    }

    // Output Ultra Modern CSS jika menggunakan tema ultra-modern
    if (isset($use_ultra_modern) && $use_ultra_modern) {
        foreach ($ultra_modern_css as $css) {
            // Periksa apakah file ada sebelum di-output
            if (file_exists(dirname(__DIR__) . '/css/' . $css)) {
                echo '<link rel="stylesheet" href="' . $base_path . 'css/' . $css . '">' . PHP_EOL;
            }
        }
    }

    // Output tema khusus sesuai halaman
    $current_page = basename($_SERVER['PHP_SELF'], '.php');
    switch ($current_page) {
        case 'account':
            if (file_exists(dirname(__DIR__) . '/css/account-integration.css')) {
                echo '<link rel="stylesheet" href="' . $base_path . 'css/account-integration.css">' . PHP_EOL;
            }
            break;
        case 'vehicle':
            if (file_exists(dirname(__DIR__) . '/css/vehicle-premium.css')) {
                echo '<link rel="stylesheet" href="' . $base_path . 'css/vehicle-premium.css">' . PHP_EOL;
            }
            break;
        case 'topup':
        case 'topup-menu':
        case 'upload-payment':
            if (file_exists(dirname(__DIR__) . '/css/topup-premium.css')) {
                echo '<link rel="stylesheet" href="' . $base_path . 'css/topup-premium.css">' . PHP_EOL;
            }
            break;
        case 'transactions-menu':
            if (file_exists(dirname(__DIR__) . '/css/transaction-premium.css')) {
                echo '<link rel="stylesheet" href="' . $base_path . 'css/transaction-premium.css">' . PHP_EOL;
            }
            break;
        case 'withdraw-menu':
            if (file_exists(dirname(__DIR__) . '/css/withdraw-premium.css')) {
                echo '<link rel="stylesheet" href="' . $base_path . 'css/withdraw-premium.css">' . PHP_EOL;
            }
            break;
        case 'bids-menu':
            if (file_exists(dirname(__DIR__) . '/css/bids-premium.css')) {
                echo '<link rel="stylesheet" href="' . $base_path . 'css/bids-premium.css">' . PHP_EOL;
            }
            break;
        case 'profile-menu':
            if (file_exists(dirname(__DIR__) . '/css/profile-premium.css')) {
                echo '<link rel="stylesheet" href="' . $base_path . 'css/profile-premium.css">' . PHP_EOL;
            }
            break;
    }
}

// Color scheme - Selalu di-load terakhir untuk override tema sebelumnya
$color_scheme = 'css/colors/blue-teal.css';
if (file_exists(dirname(__DIR__) . '/' . $color_scheme)) {
    echo '<link id="colors" href="' . $base_path . $color_scheme . '" rel="stylesheet" type="text/css">' . PHP_EOL;
}

// Load error-fix CSS untuk memperbaiki masalah tampilan spesifik berdasarkan screenshot
if (file_exists(dirname(__DIR__) . '/css/error-fix.css')) {
    echo '<link href="' . $base_path . 'css/error-fix.css" rel="stylesheet" type="text/css">' . PHP_EOL;
}

// CSS Custom per halaman - tidak perlu cek file karena konten langsung dari PHP
if (isset($page_specific_css)) {
    echo $page_specific_css . PHP_EOL;
}
?>
