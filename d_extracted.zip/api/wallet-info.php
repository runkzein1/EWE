<?php
/**
 * Wallet Info API
 * Menyediakan informasi saldo wallet untuk user
 */

// Start session
session_start();

// Headers
header('Content-Type: application/json');

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized',
        'redirect' => 'login.php'
    ]);
    exit;
}

// Load koneksi database
require_once '../config/database.php';

$user_id = $_SESSION['user_id'];

try {
    // Query untuk mendapatkan saldo wallet
    $wallet_sql = "SELECT balance, last_update FROM wallets WHERE user_id = ? LIMIT 1";
    $wallet_stmt = $conn->prepare($wallet_sql);
    $wallet_stmt->bind_param('i', $user_id);
    $wallet_stmt->execute();
    $wallet_result = $wallet_stmt->get_result();
    
    if (!$wallet_result || $wallet_result->num_rows == 0) {
        // Jika wallet belum ada, buat wallet baru dengan saldo 0
        $create_wallet_sql = "INSERT INTO wallets (user_id, balance, last_update) VALUES (?, 0, NOW())";
        $create_wallet_stmt = $conn->prepare($create_wallet_sql);
        $create_wallet_stmt->bind_param('i', $user_id);
        $create_wallet_stmt->execute();
        
        // Return data wallet baru
        echo json_encode([
            'status' => 'success',
            'data' => [
                'balance' => 0,
                'formatted_balance' => '0',
                'last_update' => date('Y-m-d H:i:s'),
                'active_bids' => 0,
                'available_for_withdrawal' => 0
            ]
        ]);
    } else {
        // Get wallet data
        $wallet_data = $wallet_result->fetch_assoc();
        
        // Query untuk mendapatkan jumlah bid aktif
        $active_bids_sql = "SELECT COUNT(*) as count 
                          FROM bids b 
                          JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                          WHERE (b.user_id = ? OR b.bidder_id = ?) 
                          AND v.auction_end > NOW() 
                          AND v.status = 'active'";
        
        $active_bids_stmt = $conn->prepare($active_bids_sql);
        $active_bids_stmt->bind_param('ii', $user_id, $user_id);
        $active_bids_stmt->execute();
        $active_bids_result = $active_bids_stmt->get_result();
        $active_bids_data = $active_bids_result->fetch_assoc();
        $active_bids_count = $active_bids_data['count'] ?? 0;
        
        // Query untuk mendapatkan jumlah saldo yang sedang digunakan dalam bid aktif
        $hold_amount_sql = "SELECT COALESCE(SUM(b.bid_amount), 0) as total 
                          FROM bids b 
                          JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                          WHERE (b.user_id = ? OR b.bidder_id = ?) 
                          AND v.auction_end > NOW() 
                          AND v.status = 'active' 
                          AND b.bid_amount = v.current_bid";
        
        $hold_amount_stmt = $conn->prepare($hold_amount_sql);
        $hold_amount_stmt->bind_param('ii', $user_id, $user_id);
        $hold_amount_stmt->execute();
        $hold_amount_result = $hold_amount_stmt->get_result();
        $hold_amount_data = $hold_amount_result->fetch_assoc();
        $hold_amount = $hold_amount_data['total'] ?? 0;
        
        // Hitung saldo yang tersedia untuk withdrawal
        $available_for_withdrawal = max(0, $wallet_data['balance'] - $hold_amount);
        
        // Return data wallet
        echo json_encode([
            'status' => 'success',
            'data' => [
                'balance' => (float)$wallet_data['balance'],
                'formatted_balance' => number_format($wallet_data['balance'], 0, ',', '.'),
                'last_update' => $wallet_data['last_update'],
                'active_bids' => $active_bids_count,
                'hold_amount' => (float)$hold_amount,
                'formatted_hold_amount' => number_format($hold_amount, 0, ',', '.'),
                'available_for_withdrawal' => (float)$available_for_withdrawal,
                'formatted_available_for_withdrawal' => number_format($available_for_withdrawal, 0, ',', '.')
            ]
        ]);
    }
} catch (Exception $e) {
    // Error handling
    error_log("Error in wallet-info.php: " . $e->getMessage());
    
    echo json_encode([
        'status' => 'error',
        'message' => 'Terjadi kesalahan saat memuat data wallet'
    ]);
}
