<?php
// Ini adalah konten tab wallet yang akan dimasukkan ke account.php
// Untuk membuatnya modular dan mempermudah maintenance

// Ambil riwayat transaksi
$wallet_sql = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10";
$wallet_stmt = $conn->prepare($wallet_sql);
$wallet_stmt->bind_param("i", $user_id);
$wallet_stmt->execute();
$wallet_result = $wallet_stmt->get_result();

// Data bank yang tersedia
$banks = [
    ["code" => "bca", "name" => "Bank Central Asia (BCA)", "icon" => "fa-university"],
    ["code" => "bni", "name" => "Bank Negara Indonesia (BNI)", "icon" => "fa-university"],
    ["code" => "bri", "name" => "Bank Rakyat Indonesia (BRI)", "icon" => "fa-university"],
    ["code" => "mandiri", "name" => "Bank Mandiri", "icon" => "fa-university"],
    ["code" => "cimb", "name" => "CIMB Niaga", "icon" => "fa-university"],
    ["code" => "permata", "name" => "Bank Permata", "icon" => "fa-university"],
    ["code" => "gopay", "name" => "GoPay", "icon" => "fa-wallet"],
    ["code" => "ovo", "name" => "OVO", "icon" => "fa-wallet"],
    ["code" => "dana", "name" => "DANA", "icon" => "fa-wallet"]
];

?>

<div class="tab-pane" id="wallet">
    <div class="card mb-4 premium-card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0 fade-in"><i class="fa fa-wallet me-2 float"></i>Dompet Saya</h5>
        </div>
        <div class="wallet-logo pulse"></div>
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_messages'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <ul class="mb-0">
                    <?php foreach ($_SESSION['error_messages'] as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['error_messages']); ?>
        <?php endif; ?>
        <div class="wallet-card mb-4 shine">
            <div class="wallet-card-inner border-flow">
                <div class="wallet-header">
                    <div class="wallet-title fade-in">Saldo Anda</div>
                    <div class="wallet-chip pulse"></div>
                </div>
                <div class="balance-summary">
                    <h4>Ringkasan Saldo</h4>
                    <div class="balance-info-card">
                        <div class="balance-row">
                            <span class="balance-label">Saldo Tersedia</span>
                            <span class="balance-value">Rp <?php echo number_format($user['balance'] ?? 0, 0, ',', '.'); ?></span>
                        </div>
                        <div class="balance-row">
                            <span class="balance-label">Pending</span>
                            <span class="balance-value">Rp <?php 
                            // Hitung pending balance dari tabel bids
                            $pending_sql = "SELECT SUM(bid_amount) as pending FROM bids 
                                           WHERE bidder_id = ? AND is_winning = 0";
                            $pending_stmt = $conn->prepare($pending_sql);
                            $pending_stmt->bind_param("i", $user_id);
                            $pending_stmt->execute();
                            $pending_result = $pending_stmt->get_result();
                            $pending = $pending_result->fetch_assoc();
                            echo number_format($pending['pending'] ?? 0, 0, ',', '.');
                            ?></span>
                        </div>
                        <div class="balance-row">
                            <span class="balance-label">Total</span>
                            <span class="balance-value total">Rp <?php 
                            $total = ($user['balance'] ?? 0) + ($pending['pending'] ?? 0);
                            echo number_format($total, 0, ',', '.'); 
                            ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-6">
                <div class="transactions-wrapper">
                    <h4 class="mb-3 fade-in">Transaksi Terbaru</h4>
                    <?php if (!$wallet_result || $wallet_result->num_rows == 0): ?>
                        <div class="empty-state">
                            <i class="fas fa-receipt empty-icon"></i>
                            <p>Belum ada riwayat transaksi</p>
                        </div>
                    <?php else: ?>
                        <div class="transaction-list">
                            <?php while ($transaction = $wallet_result->fetch_assoc()): ?>
                                <div class="transaction-item">
                                    <div class="transaction-icon">
                                        <?php 
                                        $icon = 'fa-question-circle';
                                        $bg_class = 'bg-secondary';
                                        
                                        switch ($transaction['type']) {
                                            case 'deposit':
                                                $icon = 'fa-plus-circle';
                                                $bg_class = 'bg-success';
                                                break;
                                            case 'withdrawal':
                                                $icon = 'fa-money-bill-wave';
                                                $bg_class = 'bg-primary';
                                                break;
                                            case 'bid_hold':
                                                $icon = 'fa-gavel';
                                                $bg_class = 'bg-warning';
                                                break;
                                            case 'bid_release':
                                                $icon = 'fa-undo';
                                                $bg_class = 'bg-info';
                                                break;
                                            case 'winning_payment':
                                                $icon = 'fa-trophy';
                                                $bg_class = 'bg-danger';
                                                break;
                                        }
                                        ?>
                                        <div class="icon-circle <?php echo $bg_class; ?>">
                                            <i class="fas <?php echo $icon; ?>"></i>
                                        </div>
                                    </div>
                                    <div class="transaction-details">
                                        <div class="transaction-title">
                                            <?php 
                                            switch ($transaction['type']) {
                                                case 'deposit':
                                                    echo 'Top-up';
                                                    break;
                                                case 'withdrawal':
                                                    echo 'Penarikan';
                                                    break;
                                                case 'bid_hold':
                                                    echo 'Hold Bid';
                                                    break;
                                                case 'bid_release':
                                                    echo 'Release Bid';
                                                    break;
                                                case 'winning_payment':
                                                    echo 'Pembayaran Lelang';
                                                    break;
                                                default:
                                                    echo $transaction['type'];
                                            }
                                            ?>
                                        </div>
                                        <div class="transaction-date"><?php echo date('d M Y H:i', strtotime($transaction['created_at'])); ?></div>
                                    </div>
                                    <div class="transaction-amount <?php echo ($transaction['type'] == 'deposit' || $transaction['type'] == 'bid_release') ? 'income' : 'expense'; ?>">
                                        <?php echo ($transaction['type'] == 'deposit' || $transaction['type'] == 'bid_release') ? '+' : '-'; ?> 
                                        Rp <?php echo number_format($transaction['amount'], 0, ',', '.'); ?>
                                    </div>
                                    <div class="transaction-status">
                                        <?php if ($transaction['status'] == 'pending'): ?>
                                            <span class="status-badge pending">Menunggu</span>
                                        <?php elseif ($transaction['status'] == 'completed'): ?>
                                            <span class="status-badge completed">Selesai</span>
                                        <?php elseif ($transaction['status'] == 'rejected'): ?>
                                            <span class="status-badge rejected">Ditolak</span>
                                        <?php else: ?>
                                            <span class="status-badge"><?php echo $transaction['status']; ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                        <div class="text-center mt-3">
                            <a href="wallet-history.php" class="view-all-link">Lihat Semua Transaksi <i class="fas fa-arrow-right"></i></a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-6">
                <div class="wallet-actions">
                    <a href="topup.php" class="wallet-action-btn topup-btn ripple-effect">
                        <i class="fas fa-plus-circle float"></i> Top Up
                    </a>
                    <a href="withdraw.php" class="wallet-action-btn withdraw-btn ripple-effect">
                        <i class="fas fa-money-bill-wave float"></i> Withdraw
                    </a>
                    <button type="button" class="quick-action-btn premium-btn" data-bs-toggle="modal" data-bs-target="#transferModal">
                        <i class="fas fa-exchange-alt"></i>
                        <span>Transfer</span>
                    </button>
                    <button type="button" class="quick-action-btn premium-btn" onclick="location.href='wallet-history.php'">
                        <i class="fas fa-history"></i>
                        <span>Histori</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Withdraw Modal -->
<div class="modal fade" id="withdrawModal" tabindex="-1" aria-labelledby="withdrawModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="withdrawModalLabel">Withdraw Saldo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="process_withdrawal.php" method="post">
                <div class="modal-body">
                    <div class="balance-info mb-4">
                        <p class="balance-title">Saldo Tersedia</p>
                        <div class="balance-value float">Rp <?php echo number_format($user['balance'], 0, ',', '.'); ?></div>
                    </div>
                    
                    <div class="form-group mb-4">
                        <label class="form-label">Pilih Metode Penarikan</label>
                        <div class="withdraw-methods">
                            <?php foreach ($banks as $index => $bank): ?>
                            <div class="withdraw-method <?php echo $index === 0 ? 'active' : ''; ?>" data-bank="<?php echo $bank['code']; ?>">
                                <div class="withdraw-method-icon">
                                    <i class="fas <?php echo $bank['icon']; ?>"></i>
                                </div>
                                <div class="withdraw-method-name"><?php echo $bank['name']; ?></div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="withdraw_method" id="withdrawMethod" value="<?php echo $banks[0]['code']; ?>">
                    </div>
                    
                    <div class="form-group mb-4">
                        <label class="form-label" for="withdrawAmount">Jumlah Penarikan</label>
                        <div class="amount-presets">
                            <div class="amount-preset active" data-amount="100000">
                                <div class="amount-preset-value">Rp 100.000</div>
                            </div>
                            <div class="amount-preset" data-amount="500000">
                                <div class="amount-preset-value">Rp 500.000</div>
                            </div>
                            <div class="amount-preset" data-amount="1000000">
                                <div class="amount-preset-value">Rp 1.000.000</div>
                            </div>
                            <div class="amount-preset" data-amount="2500000">
                                <div class="amount-preset-value">Rp 2.500.000</div>
                            </div>
                            <div class="amount-preset" data-amount="5000000">
                                <div class="amount-preset-value">Rp 5.000.000</div>
                            </div>
                            <div class="amount-preset" data-amount="10000000">
                                <div class="amount-preset-value">Rp 10.000.000</div>
                            </div>
                        </div>
                        <input type="text" class="form-control" id="withdrawAmount" name="withdraw_amount" value="100.000" required>
                    </div>
                    
                    <div class="form-group mb-4">
                        <label class="form-label" for="accountNumber">Nomor Rekening / Akun</label>
                        <input type="text" class="form-control" id="accountNumber" name="account_number" placeholder="Masukkan nomor rekening" required>
                    </div>
                    
                    <div class="form-group mb-4">
                        <label class="form-label" for="accountName">Nama Pemilik Rekening / Akun</label>
                        <input type="text" class="form-control" id="accountName" name="account_name" placeholder="Masukkan nama pemilik" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="withdrawNotes">Catatan (opsional)</label>
                        <textarea class="form-control" id="withdrawNotes" name="notes" rows="2" placeholder="Tambahkan catatan jika diperlukan"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="request_withdrawal" class="btn btn-primary">Ajukan Penarikan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Withdraw Methods Selection
    const withdrawMethods = document.querySelectorAll('.withdraw-method');
    const withdrawMethodInput = document.getElementById('withdrawMethod');
    
    withdrawMethods.forEach(method => {
        method.addEventListener('click', function() {
            // Remove active class from all methods
            withdrawMethods.forEach(m => m.classList.remove('active'));
            
            // Add active class to selected method
            this.classList.add('active');
            
            // Update hidden input
            withdrawMethodInput.value = this.getAttribute('data-bank');
        });
    });
    
    // Amount Presets for Withdraw
    const amountPresets = document.querySelectorAll('.amount-preset');
    const withdrawAmountInput = document.getElementById('withdrawAmount');
    
    amountPresets.forEach(preset => {
        preset.addEventListener('click', function() {
            // Remove active class from all presets
            amountPresets.forEach(p => p.classList.remove('active'));
            
            // Add active class to selected preset
            this.classList.add('active');
            
            // Update input value with formatted amount
            const amount = parseInt(this.getAttribute('data-amount'));
            withdrawAmountInput.value = new Intl.NumberFormat('id-ID').format(amount);
        });
    });
    
    // Format withdraw amount on input
    if (withdrawAmountInput) {
        withdrawAmountInput.addEventListener('input', function() {
            // Remove all non-digits
            const value = this.value.replace(/\D/g, '');
            
            // Format with thousand separator
            if (value) {
                this.value = new Intl.NumberFormat('id-ID').format(value);
            }
            
            // Reset active state on presets
            amountPresets.forEach(preset => {
                const presetAmount = preset.getAttribute('data-amount');
                if (presetAmount === value) {
                    preset.classList.add('active');
                } else {
                    preset.classList.remove('active');
                }
            });
        });
    }
});
</script>
