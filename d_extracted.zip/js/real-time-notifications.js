/**
 * Real-time Notifications System
 * LelangMobil - Modern Web App 2025
 * 
 * Fitur:
 * - Polling untuk notifikasi baru
 * - Push notifications (jika browser support)
 * - Animasi dan efek visual modern
 * - Badge counter untuk notifikasi belum dibaca
 */

class NotificationSystem {
    constructor(options = {}) {
        this.options = {
            pollingInterval: 30000, // 30 detik
            maxNotifications: 10,
            soundEnabled: true,
            desktopEnabled: true,
            ...options
        };
        
        this.notificationCount = 0;
        this.notifications = [];
        this.initialized = false;
        this.pollingTimer = null;
        
        // Element references
        this.notificationContainer = document.getElementById('notification-container');
        this.notificationBadge = document.getElementById('notification-badge');
        this.notificationToggle = document.getElementById('notification-toggle');
        this.notificationList = document.getElementById('notification-list');
        this.notificationSound = new Audio('sounds/notification.mp3');
        
        // Bind methods
        this.initialize = this.initialize.bind(this);
        this.fetchNotifications = this.fetchNotifications.bind(this);
        this.renderNotifications = this.renderNotifications.bind(this);
        this.showNotification = this.showNotification.bind(this);
        this.markAsRead = this.markAsRead.bind(this);
        this.toggleNotifications = this.toggleNotifications.bind(this);
        this.requestDesktopPermission = this.requestDesktopPermission.bind(this);
    }
    
    initialize() {
        if (this.initialized) return;
        
        if (!this.notificationContainer) {
            console.warn('Notification container not found. Creating dynamically.');
            this.createNotificationElements();
        }
        
        // Add event listeners
        if (this.notificationToggle) {
            this.notificationToggle.addEventListener('click', this.toggleNotifications);
        }
        
        // Check for desktop notification permission
        if (this.options.desktopEnabled && 'Notification' in window) {
            if (Notification.permission !== 'granted' && Notification.permission !== 'denied') {
                // Add permission request button
                const permissionBtn = document.createElement('button');
                permissionBtn.className = 'notification-permission-btn';
                permissionBtn.innerHTML = '<i class="fas fa-bell"></i> Aktifkan Notifikasi Desktop';
                permissionBtn.addEventListener('click', this.requestDesktopPermission);
                
                if (this.notificationContainer) {
                    this.notificationContainer.appendChild(permissionBtn);
                }
            }
        }
        
        // Initial fetch
        this.fetchNotifications();
        
        // Start polling
        this.pollingTimer = setInterval(this.fetchNotifications, this.options.pollingInterval);
        this.initialized = true;
    }
    
    createNotificationElements() {
        // Create notification container if it doesn't exist
        this.notificationContainer = document.createElement('div');
        this.notificationContainer.id = 'notification-container';
        this.notificationContainer.className = 'notification-container';
        
        // Create notification toggle button
        this.notificationToggle = document.createElement('button');
        this.notificationToggle.id = 'notification-toggle';
        this.notificationToggle.className = 'notification-toggle';
        this.notificationToggle.innerHTML = '<i class="fas fa-bell"></i>';
        
        // Create notification badge
        this.notificationBadge = document.createElement('span');
        this.notificationBadge.id = 'notification-badge';
        this.notificationBadge.className = 'notification-badge';
        this.notificationBadge.style.display = 'none';
        
        // Create notification list
        this.notificationList = document.createElement('div');
        this.notificationList.id = 'notification-list';
        this.notificationList.className = 'notification-list';
        this.notificationList.style.display = 'none';
        
        // Assemble elements
        this.notificationToggle.appendChild(this.notificationBadge);
        this.notificationContainer.appendChild(this.notificationToggle);
        this.notificationContainer.appendChild(this.notificationList);
        
        // Add to body
        document.body.appendChild(this.notificationContainer);
    }
    
    async fetchNotifications() {
        try {
            const response = await fetch('api/notifications.php');
            if (!response.ok) throw new Error('Network response was not ok');
            
            const data = await response.json();
            this.processNewNotifications(data);
        } catch (error) {
            console.error('Error fetching notifications:', error);
        }
    }
    
    processNewNotifications(data) {
        if (!data || !data.notifications) return;
        
        const newNotifications = data.notifications.filter(notification => {
            return !this.notifications.some(existing => existing.id === notification.id);
        });
        
        if (newNotifications.length > 0) {
            // Add new notifications to our collection
            this.notifications = [...newNotifications, ...this.notifications]
                .slice(0, this.options.maxNotifications);
            
            // Update notification count
            this.notificationCount += newNotifications.length;
            this.updateBadge();
            
            // Render updated notifications
            this.renderNotifications();
            
            // Show toast for each new notification
            newNotifications.forEach(notification => {
                this.showNotification(notification);
            });
            
            // Play sound if enabled
            if (this.options.soundEnabled && this.notificationSound) {
                this.notificationSound.play().catch(err => console.error('Sound play error:', err));
            }
            
            // Send desktop notification if enabled
            if (this.options.desktopEnabled && Notification.permission === 'granted') {
                newNotifications.forEach(notification => {
                    const desktopNotification = new Notification('LelangMobil', {
                        body: notification.message,
                        icon: 'images/logo/favicon.png'
                    });
                    
                    desktopNotification.onclick = () => {
                        window.focus();
                        if (notification.url) {
                            window.location.href = notification.url;
                        }
                    };
                });
            }
        }
    }
    
    renderNotifications() {
        if (!this.notificationList) return;
        
        if (this.notifications.length === 0) {
            this.notificationList.innerHTML = '<div class="empty-notification">Tidak ada notifikasi baru</div>';
            return;
        }
        
        this.notificationList.innerHTML = '';
        
        this.notifications.forEach(notification => {
            const notificationItem = document.createElement('div');
            notificationItem.className = `notification-item ${notification.read ? 'read' : 'unread'}`;
            notificationItem.dataset.id = notification.id;
            
            // Create notification content
            const content = document.createElement('div');
            content.className = 'notification-content';
            
            // Create notification icon based on type
            const iconClass = this.getIconClass(notification.type);
            content.innerHTML = `
                <div class="notification-icon ${notification.type}">
                    <i class="${iconClass}"></i>
                </div>
                <div class="notification-details">
                    <div class="notification-message">${notification.message}</div>
                    <div class="notification-time">${this.formatTime(notification.timestamp)}</div>
                </div>
            `;
            
            // Add actions
            const actions = document.createElement('div');
            actions.className = 'notification-actions';
            
            // Mark as read button
            if (!notification.read) {
                const readBtn = document.createElement('button');
                readBtn.className = 'mark-read-btn';
                readBtn.innerHTML = '<i class="fas fa-check"></i>';
                readBtn.title = 'Tandai Telah Dibaca';
                readBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.markAsRead(notification.id);
                });
                actions.appendChild(readBtn);
            }
            
            notificationItem.appendChild(content);
            notificationItem.appendChild(actions);
            
            // Add click event to navigate
            if (notification.url) {
                notificationItem.addEventListener('click', () => {
                    window.location.href = notification.url;
                    this.markAsRead(notification.id);
                });
            }
            
            this.notificationList.appendChild(notificationItem);
        });
    }
    
    getIconClass(type) {
        const iconMap = {
            'bid': 'fas fa-gavel',
            'auction': 'fas fa-tag',
            'payment': 'fas fa-credit-card',
            'system': 'fas fa-cog',
            'user': 'fas fa-user',
            'success': 'fas fa-check-circle',
            'warning': 'fas fa-exclamation-triangle',
            'info': 'fas fa-info-circle'
        };
        
        return iconMap[type] || 'fas fa-bell';
    }
    
    formatTime(timestamp) {
        const date = new Date(timestamp * 1000);
        const now = new Date();
        const diffMs = now - date;
        const diffSecs = Math.floor(diffMs / 1000);
        const diffMins = Math.floor(diffSecs / 60);
        const diffHours = Math.floor(diffMins / 60);
        const diffDays = Math.floor(diffHours / 24);
        
        if (diffDays > 0) {
            return `${diffDays} hari yang lalu`;
        } else if (diffHours > 0) {
            return `${diffHours} jam yang lalu`;
        } else if (diffMins > 0) {
            return `${diffMins} menit yang lalu`;
        } else {
            return 'Baru saja';
        }
    }
    
    updateBadge() {
        if (!this.notificationBadge) return;
        
        if (this.notificationCount > 0) {
            this.notificationBadge.textContent = this.notificationCount > 9 ? '9+' : this.notificationCount;
            this.notificationBadge.style.display = 'flex';
        } else {
            this.notificationBadge.style.display = 'none';
        }
    }
    
    showNotification(notification) {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = `notification-toast ${notification.type}`;
        
        const iconClass = this.getIconClass(notification.type);
        toast.innerHTML = `
            <div class="notification-toast-icon">
                <i class="${iconClass}"></i>
            </div>
            <div class="notification-toast-content">
                <div class="notification-toast-message">${notification.message}</div>
            </div>
            <button class="notification-toast-close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        // Add to body
        document.body.appendChild(toast);
        
        // Show with animation
        setTimeout(() => toast.classList.add('show'), 10);
        
        // Add click handlers
        const closeBtn = toast.querySelector('.notification-toast-close');
        closeBtn.addEventListener('click', () => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        });
        
        if (notification.url) {
            toast.addEventListener('click', (e) => {
                if (e.target !== closeBtn && !closeBtn.contains(e.target)) {
                    window.location.href = notification.url;
                    this.markAsRead(notification.id);
                }
            });
        }
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }
    
    async markAsRead(notificationId) {
        try {
            const response = await fetch('api/notifications.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'mark_read',
                    notification_id: notificationId
                })
            });
            
            if (!response.ok) throw new Error('Network response was not ok');
            
            // Update local state
            const notificationIndex = this.notifications.findIndex(n => n.id === notificationId);
            if (notificationIndex !== -1) {
                if (!this.notifications[notificationIndex].read) {
                    this.notifications[notificationIndex].read = true;
                    this.notificationCount--;
                    this.updateBadge();
                    this.renderNotifications();
                }
            }
        } catch (error) {
            console.error('Error marking notification as read:', error);
        }
    }
    
    toggleNotifications() {
        if (!this.notificationList) return;
        
        const isVisible = this.notificationList.style.display !== 'none';
        
        this.notificationList.style.display = isVisible ? 'none' : 'block';
        
        if (!isVisible) {
            // Mark all as read when opened
            this.notifications.forEach(notification => {
                if (!notification.read) {
                    this.markAsRead(notification.id);
                }
            });
        }
    }
    
    requestDesktopPermission() {
        if (!('Notification' in window)) {
            alert('Browser Anda tidak mendukung notifikasi desktop');
            return;
        }
        
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                // Remove the permission button if it exists
                const permissionBtn = document.querySelector('.notification-permission-btn');
                if (permissionBtn) {
                    permissionBtn.remove();
                }
                
                // Show confirmation
                this.showNotification({
                    id: 'system-notification-enabled',
                    type: 'success',
                    message: 'Notifikasi desktop telah diaktifkan',
                    timestamp: Math.floor(Date.now() / 1000)
                });
            }
        });
    }
    
    // Clean up when no longer needed
    destroy() {
        if (this.pollingTimer) {
            clearInterval(this.pollingTimer);
        }
        
        // Remove event listeners
        if (this.notificationToggle) {
            this.notificationToggle.removeEventListener('click', this.toggleNotifications);
        }
        
        this.initialized = false;
    }
}

// Initialize on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
    // Create global notification instance
    window.notificationSystem = new NotificationSystem();
    window.notificationSystem.initialize();
});
