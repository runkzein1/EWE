<?php
// Tambahkan timeout untuk mencegah loading tak berakhir
set_time_limit(30); // 30 detik maksimum untuk halaman index

// Include configuration, database connection and functions
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';
require_once 'config/security.php';
require_once 'config/performance.php'; // Add performance monitoring

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Tambahkan error handler global untuk mencegah crash yang tidak tertangkap
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("Error [$errno] $errstr - $errfile:$errline");
    // Untuk error fatal, kita tampilkan halaman error yang user-friendly
    if ($errno == E_ERROR || $errno == E_USER_ERROR || $errno == E_CORE_ERROR) {
        echo "<div style='text-align:center; margin:50px;'><h2>Maaf, terjadi kesalahan</h2>";
        echo "<p>Sistem sedang mengalami gangguan. Silakan coba beberapa saat lagi.</p></div>";
        exit(1);
    }
    return true; // Untuk error non-fatal, kita biarkan PHP menanganinya
});

// Get featured vehicles (active auctions ordered by end date)
$featured_sql = "SELECT v.*
                FROM vehicles v
                WHERE v.status = 'active'
                ORDER BY v.auction_end ASC
                LIMIT 6";
$featured_result = $conn->query($featured_sql);

// Get ending soon auctions dengan error handling dan pendekatan minimalis (tanpa kolom image)
try {
    $ending_sql = "SELECT vehicle_id, model, year, make, CONCAT(SUBSTRING(description, 1, 100), '...') as short_desc,
              /* Kolom image dihilangkan karena bermasalah */
              current_bid, DATE_FORMAT(auction_end, '%d %b %Y') as formatted_end_date, auction_end as end_date
              FROM vehicles
              WHERE status = 'active'
              ORDER BY auction_end ASC
              LIMIT 3";
    $ending_result = $conn->query($ending_sql);

    if (!$ending_result) {
        error_log("Error querying ending soon auctions: " . $conn->error);
        $ending_result = false;
    }
} catch (Throwable $e) {
    error_log("Exception querying ending soon auctions: " . $e->getMessage());
    $ending_result = false;
}

// Get popular makes - kembali menggunakan kolom 'make' yang tersedia di server produksi
try {
    $makes_sql = "SELECT make, COUNT(*) as count
                FROM vehicles
                WHERE make IS NOT NULL
                GROUP BY make
                ORDER BY count DESC
                LIMIT 8";
    $makes_result = $conn->query($makes_sql);

    if (!$makes_result) {
        error_log("Error querying popular makes: " . $conn->error);
        $makes_result = false;
    }
} catch (Throwable $e) {
    error_log("Exception querying popular makes: " . $e->getMessage());
    $makes_result = false;
}

// Page title
$page_title = "LelangMobil - Platform Lelang Mobil Online Terpercaya";
?>

<?php
if (file_exists('/home/lelang/public_html/includes/header.php')) {
    include('/home/lelang/public_html/includes/header.php');
} else {
    include('includes/header.php');
}
?>
<link rel="stylesheet" href="css/car-card.css">

<!-- Hero Section -->
<div id="top"></div>
<section id="section-hero" class="jarallax">
    <img src="images/background/1.jpg" class="jarallax-img" alt="">
    <div class="container position-relative z1000 wow fadeInDown">
        <div class="row align-items-center position-relative">
            <div class="spacer-double d-lg-none d-sm-block"></div>
            <div class="col-lg-12 z1000">
                <div class="spacer-double"></div>
                <h5 class="mb-4 s2">
                    <span class="wow fadeInRight" data-wow-delay=".2s">
                        <i class="id-color fa fa-calendar-o"></i>Platform Lelang Online
                    </span>
                    <span class="wow fadeInRight" data-wow-delay=".2s">
                        <i class="id-color fa fa-map-marker"></i>Indonesia
                    </span>
                </h5>
                <h1 class="ultra-big text-uppercase mb-4 wow fadeInRight">
                    <span class="wow fadeInLeft" data-wow-delay=".4s">Platform</span>
                    <span class="text-line">Lelang</span>
                    <span class="text-gradient">Mobil</span>
                    <span class="text-line wow fadeInRight" data-wow-delay=".4s">Online</span> Terpercaya
                </h1>
            </div>
            <div class="col-lg-4 sm-hide">
                <img src="images/misc/car-blue.png" class="sm-img-fluid position-absolute top-0 end-0 anim-up-down wow fadeInDown" alt="">
            </div>
            <div class="clearfix"></div>
            <div class="col-lg-1 col-2">
                <img src="images/misc/arrow-up-right.png" class="img-fluid wow fadeInLeft" alt="">
            </div>
            <div class="col-lg-5 col-10">
                <div class="position-relative">
                    <p class="lead no-bottom wow fadeInLeft">Temukan mobil impian Anda melalui sistem lelang online yang transparan dan aman. Dapatkan harga terbaik dari berbagai pilihan kendaraan berkualitas.</p>
                </div>
            </div>

            <div class="spacer-single d-lg-none d-sm-block"></div>

            <div class="col-lg-3">
                <a class="btn-main big wow fadeInLeft" href="auctions.php">Lihat Lelang</a>
                <?php if(!isset($_SESSION['user_id'])): ?>
                <a class="btn-main big wow fadeInLeft ms-2" href="register.php">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="de-gradient-edge-bottom"></div>
</section>

<!-- Car Brands -->
<section aria-label="section" class="no-top no-bottom">
    <div class="wow fadeInRight d-flex">
      <div class="de-marquee-list wow">
        <div class="d-item">
          <?php if ($makes_result->num_rows > 0): ?>
            <?php while ($make = $makes_result->fetch_assoc()): ?>
              <span class="d-item-txt"><?php echo $make['make']; ?></span>
              <span class="d-item-display">
                <i class="d-item-block"></i>
              </span>
            <?php endwhile; ?>
          <?php else: ?>
            <span class="d-item-txt">Toyota</span>
            <span class="d-item-display"><i class="d-item-block"></i></span>
            <span class="d-item-txt">Honda</span>
            <span class="d-item-display"><i class="d-item-block"></i></span>
            <span class="d-item-txt">BMW</span>
            <span class="d-item-display"><i class="d-item-block"></i></span>
            <span class="d-item-txt">Mercedes</span>
            <span class="d-item-display"><i class="d-item-block"></i></span>
          <?php endif; ?>
         </div>
      </div>
    </div>
</section>

<!-- Stylish Menu Section -->
<section id="section-menu" class="pt-0 pb-0">
    <?php
    try {
        if (file_exists('/home/lelang/public_html/includes/stylish-menu.php')) {
            include('/home/lelang/public_html/includes/stylish-menu.php');
        } else {
            include('includes/stylish-menu.php');
        }
    } catch (Throwable $e) {
        error_log("Error including stylish-menu.php in index.php: " . $e->getMessage());
        echo '<div class="alert alert-warning">
            <p>Menu tidak dapat dimuat. Silakan refresh halaman.</p>
        </div>';
    }
    ?>
</section>

<!-- About Section -->
<section id="section-about" aria-label="section" class="no-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-12" data-jarallax-element="-50">
                <p class="lead big wow fadeInUp">Selamat datang di LelangMobil, platform lelang mobil online terpercaya di Indonesia. Kami menyediakan tempat bagi penjual dan pembeli untuk bertemu dan bertransaksi dalam sistem lelang yang transparan, aman, dan efisien.</p>
            </div>
        </div>
    </div>
</section>

<!-- Featured Auctions -->
<section id="section-cars">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="subtitle wow fadeInUp mb-3">Lelang Terbaru</div>
                <h2 class="wow fadeInUp" data-wow-delay=".2s">Mobil Pilihan</h2>
            </div>
            <div class="col-lg-6 text-lg-end">
                <a href="auctions.php" class="btn-main wow fadeInUp" data-wow-delay=".4s">Lihat Semua Lelang</a>
            </div>
        </div>

        <div class="spacer-single"></div>

        <div class="row g-4">
            <?php if ($featured_result->num_rows > 0): ?>
                <?php while ($vehicle = $featured_result->fetch_assoc()): ?>
                    <div class="col-lg-4 col-md-6 mb30 wow fadeInUp">
                        <div class="de-car-item hover-shadow rounded-lg overflow-hidden">
                            <div class="de-image-hover-2 position-relative">
                                <?php if ($vehicle['reserve_price'] > 0): ?>
                                    <div class="premium-badge">Premium</div>
                                <?php endif; ?>

                                <div class="auction-status-badge <?php echo $vehicle['status']; ?>">
                                    <?php
                                        switch($vehicle['status']) {
                                            case 'upcoming':
                                                echo '<i class="fa fa-clock"></i> Akan Datang';
                                                break;
                                            case 'active':
                                                echo '<i class="fa fa-gavel"></i> Sedang Berlangsung';
                                                break;
                                            case 'ended':
                                                echo '<i class="fa fa-flag-checkered"></i> Selesai';
                                                break;
                                            case 'sold':
                                                echo '<i class="fa fa-check-circle"></i> Terjual';
                                                break;
                                            default:
                                                echo '<i class="fa fa-info-circle"></i> ' . ucfirst($vehicle['status']);
                                        }
                                    ?>
                                </div>

                                <img src="<?php echo !empty($vehicle['main_image']) ? get_vehicle_image_url($vehicle['main_image']) : 'images/cars/placeholder.jpg'; ?>" class="img-fluid w-100" alt="<?php echo $vehicle['title']; ?>">

                                <div class="d-overlay">
                                    <a href="vehicle.php?id=<?php echo $vehicle['vehicle_id']; ?>" class="btn-main">
                                        <?php echo ($vehicle['status'] == 'active') ? 'Lelang Sekarang' : 'Lihat Detail'; ?>
                                    </a>
                                </div>

                                <?php
                                // Calculate time remaining
                                $now = new DateTime();
                                $end_date = new DateTime($vehicle['auction_end']);
                                $time_remaining = "";

                                if ($vehicle['status'] == 'active') {
                                    $interval = $now->diff($end_date);
                                    if ($interval->days > 0) {
                                        $time_remaining = "{$interval->days} hari {$interval->h} jam";
                                    } elseif ($interval->h > 0) {
                                        $time_remaining = "{$interval->h} jam {$interval->i} menit";
                                    } else {
                                        $time_remaining = "{$interval->i} menit {$interval->s} detik";
                                    }
                                ?>
                                    <div class="timer-box">
                                        <div class="countdown-wrapper">
                                            <span class="text-light"><i class="fa fa-clock-o"></i> Sisa:</span>
                                            <div class="countdown-timer"><?php echo $time_remaining; ?></div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>

                            <div class="car-details px-4 py-3">
                                <div class="d-flex justify-content-between align-items-start">
                                    <h4 class="mb-1">
                                        <a href="vehicle.php?id=<?php echo $vehicle['vehicle_id']; ?>" class="text-decoration-none">
                                            <?php echo $vehicle['title']; ?>
                                        </a>
                                    </h4>
                                    <span class="car-year badge bg-dark text-light"><?php echo $vehicle['year']; ?></span>
                                </div>

                                <div class="car-subtitle text-muted mb-3 d-flex align-items-center">
                                    <i class="fa fa-car me-1"></i> <?php echo $vehicle['make']; ?> <?php echo $vehicle['model']; ?>
                                </div>

                                <div class="car-metrics d-flex justify-content-between py-2 border-top border-bottom">
                                    <div class="metric text-center">
                                        <i class="fa fa-tachometer"></i>
                                        <p class="mb-0"><?php echo number_format($vehicle['mileage'], 0, ',', '.'); ?> km</p>
                                    </div>
                                    <div class="metric text-center">
                                        <i class="fa fa-star"></i>
                                        <p class="mb-0"><?php echo $vehicle['condition_rating']; ?>/10</p>
                                    </div>
                                    <div class="metric text-center">
                                        <i class="fa fa-users"></i>
                                        <p class="mb-0"><?php echo rand(3, 15); ?> Penawar</p>
                                    </div>
                                </div>

                                <div class="price-box py-3 text-center">
                                    <?php if ($vehicle['current_bid']): ?>
                                        <div class="small">Bid Tertinggi Saat Ini</div>
                                        <h3 class="price text-gradient mb-0"><?php echo format_currency($vehicle['current_bid']); ?></h3>
                                    <?php else: ?>
                                        <div class="small">Harga Awal</div>
                                        <h3 class="price text-gradient mb-0"><?php echo format_currency($vehicle['starting_price']); ?></h3>
                                    <?php endif; ?>
                                </div>

                                <div class="action-box d-grid gap-2">
                                    <a href="vehicle.php?id=<?php echo $vehicle['vehicle_id']; ?>" class="btn-main btn-fullwidth">Ajukan Bid</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info">
                        Belum ada lelang aktif saat ini. Silakan cek kembali nanti.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- How It Works -->
<section id="section-steps" class="jarallax">
    <img src="images/background/4.jpg" class="jarallax-img" alt="">
    <div class="de-gradient-edge-top"></div>
    <div class="container position-relative z1000">
        <div class="row">
            <div class="col-lg-6">
                <div class="subtitle wow fadeInUp mb-3">Panduan</div>
                <h2 class="wow fadeInUp" data-wow-delay=".2s">Cara Kerjanya</h2>
            </div>
        </div>

        <div class="spacer-single"></div>

        <div class="row">
            <div class="col-lg-4 col-md-6 mb-sm-30">
                <div class="de-step">
                    <h4 class="wow fadeInUp">1. Mendaftar</h4>
                    <p class="wow fadeInUp">Daftar akun Anda secara gratis dan verifikasi profil Anda untuk mulai mengikuti lelang.</p>
                    <a href="register.php" class="btn-main mt10">Daftar Sekarang</a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-sm-30">
                <div class="de-step">
                    <h4 class="wow fadeInUp">2. Deposit Saldo</h4>
                    <p class="wow fadeInUp">Top-up saldo akun Anda untuk dapat mengikuti lelang dan memberikan penawaran.</p>
                    <a href="account.php#topup" class="btn-main mt10">Top-up Saldo</a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-sm-30">
                <div class="de-step">
                    <h4 class="wow fadeInUp">3. Ikuti Lelang</h4>
                    <p class="wow fadeInUp">Pilih mobil yang Anda minati, lakukan penawaran, dan menangkan lelang.</p>
                    <a href="auctions.php" class="btn-main mt10">Lihat Lelang</a>
                </div>
            </div>
        </div>
    </div>
    <div class="de-gradient-edge-bottom"></div>
</section>

<!-- Ending Soon Auctions -->
<section id="section-ending-soon" class="pt-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3 text-center">
                <div class="subtitle wow fadeInUp mb-3">Jangan Lewatkan</div>
                <h2 class="text-uppercase wow fadeInUp" data-wow-delay=".2s"><span class="text-gradient">Lelang</span> <span class="id-color">Segera Berakhir</span></h2>
                <div class="de-separator"></div>
            </div>
        </div>

        <div class="row">
            <?php
            // Query untuk lelang yang akan segera berakhir
            $ending_soon_query = "SELECT v.*, MAX(b.bid_amount) as current_bid
                              FROM vehicles v
                              LEFT JOIN bids b ON v.vehicle_id = b.vehicle_id
                              WHERE v.status = 'active' AND v.auction_end <= DATE_ADD(NOW(), INTERVAL 3 DAY)
                              GROUP BY v.vehicle_id
                              ORDER BY v.auction_end ASC
                              LIMIT 3";
            $ending_soon_result = $conn->query($ending_soon_query);
            ?>

            <?php if($ending_soon_result->num_rows > 0): ?>
                <?php $delay = 0; ?>
                <?php while($vehicle = $ending_soon_result->fetch_assoc()): ?>
                    <div class="col-lg-4 col-md-6 mb30 wow fadeInUp" data-wow-delay="<?php echo $delay; ?>s">
                        <div class="de-car-item hover-shadow rounded-lg overflow-hidden">
                            <div class="de-image-hover-2 position-relative">
                                <?php if ($vehicle['reserve_price'] > 0): ?>
                                    <div class="premium-badge">Premium</div>
                                <?php endif; ?>

                                <div class="auction-status-badge <?php echo $vehicle['status']; ?>">
                                    <?php
                                        switch($vehicle['status']) {
                                            case 'upcoming':
                                                echo '<i class="fa fa-clock"></i> Akan Datang';
                                                break;
                                            case 'active':
                                                echo '<i class="fa fa-gavel"></i> Segera Berakhir';
                                                break;
                                            case 'ended':
                                                echo '<i class="fa fa-flag-checkered"></i> Selesai';
                                                break;
                                            case 'sold':
                                                echo '<i class="fa fa-check-circle"></i> Terjual';
                                                break;
                                            default:
                                                echo '<i class="fa fa-info-circle"></i> ' . ucfirst($vehicle['status']);
                                        }
                                    ?>
                                </div>

                                <img src="<?php echo !empty($vehicle['main_image']) ? get_vehicle_image_url($vehicle['main_image']) : 'images/cars/placeholder.jpg'; ?>" class="img-fluid w-100" alt="<?php echo $vehicle['title']; ?>">

                                <div class="d-overlay">
                                    <a href="vehicle.php?id=<?php echo $vehicle['vehicle_id']; ?>" class="btn-main">
                                        <i class="fa fa-gavel me-2"></i> Lelang Sekarang
                                    </a>
                                </div>

                                <?php
                                // Calculate time remaining
                                $now = new DateTime();
                                $end_date = new DateTime($vehicle['auction_end']);
                                $time_remaining = "";

                                if($vehicle['status'] == 'active') {
                                    $interval = $now->diff($end_date);
                                    if($interval->days > 0) {
                                        $time_remaining = "{$interval->days} hari {$interval->h} jam";
                                    } elseif($interval->h > 0) {
                                        $time_remaining = "{$interval->h} jam {$interval->i} menit";
                                    } else {
                                        $time_remaining = "{$interval->i} menit {$interval->s} detik";
                                    }
                                ?>
                                    <div class="timer-box">
                                        <div class="countdown-wrapper">
                                            <span class="text-warning"><i class="fa fa-exclamation-triangle"></i> Berakhir dalam:</span>
                                            <div class="countdown-timer text-warning"><?php echo $time_remaining; ?></div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>

                            <div class="car-details px-4 py-3">
                                <div class="d-flex justify-content-between align-items-start">
                                    <h4 class="mb-1">
                                        <a href="vehicle.php?id=<?php echo $vehicle['vehicle_id']; ?>" class="text-decoration-none">
                                            <?php echo $vehicle['title']; ?>
                                        </a>
                                    </h4>
                                    <span class="car-year badge bg-dark text-light"><?php echo $vehicle['year']; ?></span>
                                </div>

                                <div class="car-subtitle text-muted mb-3 d-flex align-items-center">
                                    <i class="fa fa-car me-1"></i> <?php echo $vehicle['make']; ?> <?php echo $vehicle['model']; ?>
                                </div>

                                <div class="car-metrics d-flex justify-content-between py-2 border-top border-bottom">
                                    <div class="metric text-center">
                                        <i class="fa fa-tachometer"></i>
                                        <p class="mb-0"><?php echo number_format($vehicle['mileage'], 0, ',', '.'); ?> km</p>
                                    </div>
                                    <div class="metric text-center">
                                        <i class="fa fa-star"></i>
                                        <p class="mb-0"><?php echo $vehicle['condition_rating']; ?>/10</p>
                                    </div>
                                    <div class="metric text-center">
                                        <i class="fa fa-users"></i>
                                        <p class="mb-0"><?php echo rand(3, 15); ?> Penawar</p>
                                    </div>
                                </div>

                                <div class="price-box py-3 text-center">
                                    <?php if($vehicle['current_bid']): ?>
                                        <div class="small">Bid Tertinggi Saat Ini</div>
                                        <h3 class="price text-gradient mb-0"><?php echo format_currency($vehicle['current_bid']); ?></h3>
                                    <?php else: ?>
                                        <div class="small">Harga Awal</div>
                                        <h3 class="price text-gradient mb-0"><?php echo format_currency($vehicle['starting_price']); ?></h3>
                                    <?php endif; ?>
                                </div>

                                <div class="action-box d-grid gap-2">
                                    <a href="vehicle.php?id=<?php echo $vehicle['vehicle_id']; ?>" class="btn-main btn-fullwidth">Ajukan Bid</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $delay += 0.2; ?>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center">
                    <p>Tidak ada lelang yang akan segera berakhir saat ini.</p>
                </div>
            <?php endif; ?>
        </div>

        <?php if($ending_soon_result->num_rows > 0): ?>
            <div class="spacer-single"></div>
            <div class="text-center wow fadeInUp">
                <a href="auction.php" class="btn-main">Lihat Semua Lelang</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Testimonials -->
<section id="section-testimonial" class="jarallax pb-60">
    <img src="images/background/5.jpg" class="jarallax-img" alt="">
    <div class="de-gradient-edge-top"></div>
    <div class="container position-relative z1000">
        <div class="row align-items-center">
            <div class="col-lg-12 text-center">
                <div class="subtitle wow fadeInUp mb-3 text-light">Pendapat Mereka</div>
                <h2 class="wow fadeInUp text-uppercase text-light" data-wow-delay=".2s">
                    <span class="text-gradient">Testimoni</span>
                    <span class="id-color">Pengguna Kami</span>
                </h2>
            </div>
        </div>

        <div class="spacer-single"></div>

        <div class="row g-4">
            <div class="col-lg-6 wow fadeInLeft">
                <div class="de-box-testimonial">
                    <div class="de-box-testimonial-top">
                        <i class="fa fa-quote-left fa-3x id-color"></i>
                    </div>
                    <div class="de-box-testimonial-content">
                        <blockquote>
                            Saya sangat puas dengan pengalaman lelang di LelangMobil. Prosesnya transparan dan saya berhasil mendapatkan mobil impian dengan harga yang kompetitif. Staf sangat membantu dan selalu siap menjawab semua pertanyaan saya.
                        </blockquote>
                    </div>
                    <div class="de-box-testimonial-bottom">
                        <div class="de-box-testimonial-avatar">
                            <img src="images/people/1.jpg" class="img-fluid" alt="">
                        </div>
                        <div class="de-box-testimonial-name">
                            <h4>Budi Santoso</h4>
                            <p class="mb-0">Pembeli - Jakarta</p>
                            <div class="de-box-testimonial-stars">
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 wow fadeInRight">
                <div class="de-box-testimonial">
                    <div class="de-box-testimonial-top">
                        <i class="fa fa-quote-left fa-3x id-color"></i>
                    </div>
                    <div class="de-box-testimonial-content">
                        <blockquote>
                            Platform yang sangat mudah digunakan. Saya berhasil menjual mobil saya dengan harga yang lebih baik daripada jika dijual langsung ke dealer. Proses verifikasi cepat dan dana langsung masuk ke rekening saya setelah lelang selesai.
                        </blockquote>
                    </div>
                    <div class="de-box-testimonial-bottom">
                        <div class="de-box-testimonial-avatar">
                            <img src="images/people/2.jpg" class="img-fluid" alt="">
                        </div>
                        <div class="de-box-testimonial-name">
                            <h4>Dewi Anggraini</h4>
                            <p class="mb-0">Penjual - Surabaya</p>
                            <div class="de-box-testimonial-stars">
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star-half-o text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 wow fadeInLeft">
                <div class="de-box-testimonial">
                    <div class="de-box-testimonial-top">
                        <i class="fa fa-quote-left fa-3x id-color"></i>
                    </div>
                    <div class="de-box-testimonial-content">
                        <blockquote>
                            Proses verifikasi yang cepat dan dukungan pelanggan yang responsif. Saya sangat merekomendasikan LelangMobil kepada siapa saja yang ingin membeli atau menjual kendaraan. Keamanan transaksi juga sangat terjamin.
                        </blockquote>
                    </div>
                    <div class="de-box-testimonial-bottom">
                        <div class="de-box-testimonial-avatar">
                            <img src="images/people/3.jpg" class="img-fluid" alt="">
                        </div>
                        <div class="de-box-testimonial-name">
                            <h4>Ahmad Fauzi</h4>
                            <p class="mb-0">Pembeli & Penjual - Bandung</p>
                            <div class="de-box-testimonial-stars">
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 wow fadeInRight">
                <div class="de-box-testimonial">
                    <div class="de-box-testimonial-top">
                        <i class="fa fa-quote-left fa-3x id-color"></i>
                    </div>
                    <div class="de-box-testimonial-content">
                        <blockquote>
                            LelangMobil memberikan pilihan kendaraan yang berkualitas. Saya mengikuti beberapa lelang sebelum akhirnya mendapatkan mobil yang tepat untuk keluarga saya. Dokumentasi kendaraan lengkap dan kondisi sesuai dengan deskripsi.
                        </blockquote>
                    </div>
                    <div class="de-box-testimonial-bottom">
                        <div class="de-box-testimonial-avatar">
                            <img src="images/people/4.jpg" class="img-fluid" alt="">
                        </div>
                        <div class="de-box-testimonial-name">
                            <h4>Siti Rahayu</h4>
                            <p class="mb-0">Pembeli - Semarang</p>
                            <div class="de-box-testimonial-stars">
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star text-warning"></i>
                                <i class="fa fa-star-half-o text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="spacer-double"></div>

        <div class="text-center wow fadeInUp">
            <a href="how-it-works.php" class="btn-main">Mulai Lelang Sekarang</a>
        </div>
    </div>
    <div class="de-gradient-edge-bottom"></div>
</section>

<?php
if (file_exists('/home/lelang/public_html/includes/footer.php')) {
    include('/home/lelang/public_html/includes/footer.php');
} else {
    include('includes/footer.php');
}
?>
