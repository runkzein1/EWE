<?php
/**
 * File validasi untuk menghindari error PHP di LelangMobil
 * Versi: 1.2
 * Tanggal: 2025-05-02
 * 
 * PENTING: File ini harus diimpor setelah functions.php
 * karena beberapa fungsi di sini menggunakan fungsi dari functions.php
 * 
 * Helper ini digunakan untuk mencegah berbagai error PHP umum seperti:
 * - Undefined variable
 * - Calling a method on non-object
 * - Accessing offset on non-array
 * - Undefined index/property in array/object
 * - Invalid argument supplied for foreach
 * - Passing null to non-nullable parameters
 */

/**
 * Fungsi untuk validasi akses ke objek database
 * @param mixed $result Hasil query dari database
 * @return bool True jika objek valid, false jika tidak
 */
function is_valid_result($result) {
    return $result && is_object($result) && method_exists($result, 'num_rows');
}

/**
 * Safe access to mysqli_result fetch_assoc
 * @param mixed $result MySQLi result object
 * @param int $position Position untuk data_seek, default 0
 * @return array|false Array hasil fetch atau false jika gagal
 */
function safe_fetch_assoc($result, $position = 0) {
    if (is_valid_result($result)) {
        $result->data_seek($position);
        return $result->fetch_assoc();
    }
    return false;
}

/**
 * Safe access to properties with defaults untuk transaction
 * @param array $transaction Array transaksi
 * @param string $key Property yang ingin diakses
 * @param mixed $default Nilai default jika property tidak ada
 * @return mixed Nilai property atau default
 */
function get_transaction_value($transaction, $key, $default = '') {
    if (!is_array($transaction)) {
        return $default;
    }
    return isset($transaction[$key]) ? $transaction[$key] : $default;
}

/**
 * Format status transaksi dengan badge HTML
 * @param array $transaction Array transaksi
 * @return string HTML badge sesuai status
 */
function get_transaction_status_badge($transaction) {
    if (!is_array($transaction)) {
        return '<span class="badge premium-badge premium-badge-secondary">Unknown</span>';
    }
    
    $status = isset($transaction['status']) ? $transaction['status'] : 'unknown';
    
    switch($status) {
        case 'completed':
            return '<span class="badge premium-badge premium-badge-success">Selesai</span>';
        case 'pending':
            return '<span class="badge premium-badge premium-badge-warning">Menunggu</span>';
        case 'rejected':
            return '<span class="badge premium-badge premium-badge-danger">Ditolak</span>';
        default:
            return '<span class="badge premium-badge premium-badge-info">' . ucfirst($status) . '</span>';
    }
}

/**
 * Format transaction type dengan icon dan label
 * @param array $transaction Array transaksi
 * @return array [icon, label]
 */
function get_transaction_type_info($transaction) {
    if (!is_array($transaction)) {
        return ['fa-exchange-alt', 'Transaksi'];
    }
    
    $type = isset($transaction['type']) ? $transaction['type'] : '';
    
    switch($type) {
        case 'deposit':
            return ['fa-plus-circle text-success', 'Top Up'];
        case 'withdrawal':
            return ['fa-minus-circle text-danger', 'Withdraw'];
        case 'bid_hold':
            return ['fa-lock text-warning', 'Hold Bid'];
        case 'bid_release':
            return ['fa-unlock text-info', 'Release Bid'];
        case 'winning_payment':
            return ['fa-trophy text-warning', 'Pembayaran Menang'];
        default:
            return ['fa-exchange-alt', ucfirst($type)];
    }
}

/**
 * PENTING: Fungsi-fungsi berikut didefinisikan di config/functions.php:
 * - is_bid_active($bid): Cek apakah bid masih aktif berdasarkan tanggal akhir
 * - get_bid_remaining_time($bid): Menghitung sisa waktu sampai bid berakhir
 * - get_value($data, $key, $default): Mengambil nilai dari array/object dengan aman
 * - get_formatted_date($data, $key, $format): Format tanggal dengan aman
 * 
 * Jangan mendefinisikan ulang di sini untuk menghindari fatal error function redeclaration
 */

/**
 * Format angka ke format mata uang dengan aman
 * Menggunakan format_currency dari functions.php
 * @param mixed $number Angka yang akan diformat
 * @return string Angka yang sudah diformat
 */
function safe_format_currency($number) {
    // Pastikan format_currency() tersedia
    if (function_exists('format_currency')) {
        return format_currency($number);
    }
    
    // Fallback jika format_currency tidak tersedia
    if (!is_numeric($number)) {
        $number = 0;
    }
    return number_format($number, 0, ',', '.');
}

/**
 * Fungsi untuk mengecek apakah suatu tanggal masih aktif (belum berlalu)
 * Catatan: Fungsi ini membutuhkan get_value() dari functions.php
 * 
 * @param mixed $array Array atau object yang berisi tanggal
 * @param string $key Key date yang akan diakses
 * @return bool True jika masih aktif, false jika sudah berakhir
 */
function is_active_date($array, $key) {
    // Pastikan get_value() tersedia dari functions.php
    if (!function_exists('get_value')) {
        // Jika tidak tersedia, gunakan fallback sederhana
        if (is_array($array)) {
            $value = isset($array[$key]) ? $array[$key] : null;
        } elseif (is_object($array)) {
            $value = isset($array->$key) ? $array->$key : null;
        } else {
            return false;
        }
    } else {
        // Gunakan get_value dari functions.php
        $value = get_value($array, $key, null);
    }
    
    if ($value && strtotime($value)) {
        return strtotime($value) >= time();
    }
    return false;
}
