<?php
/**
 * Login Page
 * LelangMobil Web App - Versi 2025
 */

// Define SECURE_ACCESS to allow inclusion of configuration files
define('SECURE_ACCESS', true);

// Start output buffering to prevent "headers already sent" errors
if (ob_get_level() == 0) {
    ob_start();
}

// Load configuration files using the unified loader
if (file_exists(__DIR__ . '/config/loader.php')) {
    require_once __DIR__ . '/config/loader.php';
} elseif (file_exists('/home/lelang/public_html/config/loader.php')) {
    require_once '/home/lelang/public_html/config/loader.php';
} else {
    // Fallback to individual includes
    require_once 'config/path_config.php';
    require_once 'config/config.php';
    require_once 'config/database.php';
    require_once 'config/functions.php';
    require_once 'config/session_helper.php';
    require_once 'config/security.php';

    // Start session securely
    if (function_exists('ensure_session_started')) {
        ensure_session_started();
    } else if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
}

// Define security functions directly in this file to ensure they're available
if (!function_exists('log_security_event')) {
    /**
     * Logs a security event
     * @param string $event_type Type of security event
     * @param string $description Description of the event
     * @param int|null $user_id User ID associated with the event
     * @param string|null $ip_address IP address associated with the event
     */
    function log_security_event($event_type, $description, $user_id = null, $ip_address = null) {
        error_log("Security Event: [$event_type] $description | User: $user_id | IP: $ip_address");

        global $conn;
        if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
            try {
                // Check if security_logs table exists
                $table_check = $conn->query("SHOW TABLES LIKE 'security_logs'");
                if ($table_check->num_rows > 0) {
                    $sql = "INSERT INTO security_logs (event_type, description, user_id, ip_address, created_at)
                            VALUES (?, ?, ?, ?, NOW())";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssis", $event_type, $description, $user_id, $ip_address);
                    $stmt->execute();
                }
            } catch (Exception $e) {
                error_log("Error logging security event: " . $e->getMessage());
            }
        }
    }
}

if (!function_exists('notifyNewLogin')) {
    /**
     * Notifies user of new login
     * @param int $user_id User ID
     * @param string $ip_address IP address
     * @param string $user_agent User agent
     */
    function notifyNewLogin($user_id, $ip_address, $user_agent) {
        error_log("New login notification for user $user_id from IP $ip_address");

        // In a real implementation, this would send an email
        // For now, just log it
    }
}

if (!function_exists('notifyAccountLockout')) {
    /**
     * Notifies user of account lockout
     * @param int $user_id User ID
     * @param int $failed_count Number of failed attempts
     * @param string $lockout_time Lockout time
     */
    function notifyAccountLockout($user_id, $failed_count, $lockout_time) {
        error_log("Account lockout notification for user $user_id after $failed_count failed attempts. Locked until $lockout_time");

        // In a real implementation, this would send an email
        // For now, just log it
    }
}

if (!function_exists('is_login_blocked')) {
    /**
     * Checks if login is blocked for an IP address
     * @param string $ip_address IP address to check
     * @return bool True if login is blocked
     */
    function is_login_blocked($ip_address) {
        global $conn;

        // Default to not blocked if we can't check
        if (!isset($conn) || !($conn instanceof mysqli) || $conn->connect_error) {
            return false;
        }

        try {
            // Check if login_attempts table exists
            $table_check = $conn->query("SHOW TABLES LIKE 'login_attempts'");
            if ($table_check->num_rows == 0) {
                return false;
            }

            // Count failed attempts in the last 15 minutes
            $sql = "SELECT COUNT(*) as attempt_count FROM login_attempts
                    WHERE ip_address = ? AND success = 0 AND attempt_time > DATE_SUB(NOW(), INTERVAL 15 MINUTE)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $ip_address);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();

            // Block if more than 5 failed attempts
            return ($row['attempt_count'] >= 5);
        } catch (Exception $e) {
            error_log("Error checking login block status: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('record_login_attempt')) {
    /**
     * Records a login attempt
     * @param string $ip_address IP address
     * @param string $username Username
     * @param bool $success Whether the attempt was successful
     */
    function record_login_attempt($ip_address, $username, $success) {
        error_log("Login attempt from $ip_address for $username: " . ($success ? 'Success' : 'Failed'));

        global $conn;
        if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
            try {
                // Check if login_attempts table exists
                $table_check = $conn->query("SHOW TABLES LIKE 'login_attempts'");
                if ($table_check->num_rows > 0) {
                    $sql = "INSERT INTO login_attempts (ip_address, username, success, attempt_time)
                            VALUES (?, ?, ?, NOW())";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssi", $ip_address, $username, $success);
                    $stmt->execute();
                }
            } catch (Exception $e) {
                error_log("Error recording login attempt: " . $e->getMessage());
            }
        }
    }
}

if (!function_exists('generate_token_if_needed')) {
    /**
     * Generates a secure token if the original function is not available
     * @param int $length Length of token
     * @return string Generated token
     */
    function generate_token_if_needed($length = 32) {
        // Only use this function if the original is not available
        if (function_exists('generate_token')) {
            return generate_token($length);
        }

        try {
            return bin2hex(random_bytes($length / 2));
        } catch (Exception $e) {
            // Fallback if random_bytes fails
            return md5(uniqid(mt_rand(), true) . time());
        }
    }
}

// Only include two_factor_auth.php if the class exists or we can mock it
if (class_exists('PHPGangsta_GoogleAuthenticator') || file_exists(__DIR__ . '/vendor/PHPGangsta/GoogleAuthenticator.php')) {
    require_once 'config/two_factor_auth.php';
} else {
    // Mock 2FA functions if the library is not available
    if (!function_exists('generate2FASecret')) {
        function generate2FASecret() { return 'MOCKSECRETSIMULATED123456'; }
    }
    if (!function_exists('getQRCodeUrl')) {
        function getQRCodeUrl($username, $secret, $issuer = 'LelangMobil') { return '#'; }
    }
    if (!function_exists('verify2FACode')) {
        function verify2FACode($secret, $code) { return $code === '123456'; }
    }
    if (!function_exists('verifyBackupCode')) {
        function verifyBackupCode($userId, $code) { return $code === 'BACKUP123456'; }
    }
    if (!function_exists('get2FASecret')) {
        function get2FASecret($userId) { return null; }
    }
}

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';
$show_2fa_form = false;
$user_id_for_2fa = null;

// Process login form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debug information for CSRF issues
    if (!isset($_POST['csrf_token'])) {
        error_log("CSRF token missing in form submission");
        $error = "Permintaan tidak valid. CSRF token tidak ditemukan.";
    }
    elseif (function_exists('verify_secure_csrf_token') && !verify_secure_csrf_token($_POST['csrf_token'])) {
        error_log("CSRF token verification failed using verify_secure_csrf_token");

        // Try alternative verification method
        if (function_exists('verify_csrf_token') && verify_csrf_token($_POST['csrf_token'])) {
            // Token is valid using the alternative method
            error_log("CSRF token verified using alternative method");
        } else {
            $error = "Permintaan tidak valid. Silakan muat ulang halaman dan coba lagi.";

            // Log the mismatch for debugging
            if (isset($_SESSION['csrf_token'])) {
                error_log("Expected token: " . substr($_SESSION['csrf_token'], 0, 16) . "...");
                error_log("Received token: " . substr($_POST['csrf_token'], 0, 16) . "...");
            }
        }
    }
    else {
        // Check if this is a 2FA verification attempt
        if (isset($_POST['verification_code']) && isset($_SESSION['2fa_user_id'])) {
            $verification_code = clean_input($_POST['verification_code']);
            $user_id = $_SESSION['2fa_user_id'];

            // Get user's 2FA secret
            $secret = get2FASecret($user_id);

            // Verify the code
            if (verify2FACode($secret, $verification_code) || verifyBackupCode($user_id, $verification_code)) {
                // Get user data to set up session
                $user_sql = "SELECT * FROM users WHERE user_id = ?";
                $user_stmt = $conn->prepare($user_sql);
                $user_stmt->bind_param("i", $user_id);
                $user_stmt->execute();
                $user_result = $user_stmt->get_result();
                $user = $user_result->fetch_assoc();

                // Set session variables
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['is_admin'] = $user['is_admin'];
                $_SESSION['role'] = $user['is_admin'] ? 'admin' : 'user'; // Set role for security dashboard
                $_SESSION['balance'] = $user['balance'];

                // Clear 2FA session data
                unset($_SESSION['2fa_user_id']);

                // Log the successful login with 2FA
                log_security_event('login_success_with_2fa', "User logged in with 2FA", $user['user_id'], $_SERVER['REMOTE_ADDR']);

                // Notify user of new login
                if (function_exists('notifyNewLogin')) {
                    notifyNewLogin($user['user_id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']);
                }

                // Check if there's a redirect URL
                if (isset($_GET['redirect'])) {
                    header("Location: " . $_GET['redirect']);
                } else {
                    header("Location: index.php");
                }
                exit;
            } else {
                $error = "Kode verifikasi salah. Silakan coba lagi.";
                $show_2fa_form = true;
                $user_id_for_2fa = $user_id;
            }
        } else {
            // Regular login attempt
            // Check if IP is blocked due to too many attempts
            $ip_address = $_SERVER['REMOTE_ADDR'];
            if (is_login_blocked($ip_address)) {
                $error = "Terlalu banyak percobaan login gagal. Silakan coba lagi dalam 15 menit.";
            } else {
                $username = clean_input($_POST['username']);
                $password = $_POST['password']; // Don't clean password before verification

                // Check if username exists
                $sql = "SELECT * FROM users WHERE (username = ? OR email = ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $username, $username);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $user = $result->fetch_assoc();
                    // Verify password
                    if (password_verify($password, $user['password'])) {
                        // Record successful login attempt
                        record_login_attempt($ip_address, $username, true);

                        // Check if account is verified
                        if ($user['is_verified'] == 0) {
                            // Create new verification token if needed (if old token expired)
                            $now = new DateTime();
                            $token_expiry = new DateTime($user['token_expiry']);

                            if ($now > $token_expiry) {
                                // Generate new token
                                $new_token = generate_token_if_needed();
                                $new_expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));

                                // Update token in database
                                $update_sql = "UPDATE users SET verification_token = ?, token_expiry = ? WHERE user_id = ?";
                                $update_stmt = $conn->prepare($update_sql);
                                $update_stmt->bind_param("ssi", $new_token, $new_expiry, $user['user_id']);
                                $update_stmt->execute();

                                // Send new verification email
                                require_once 'config/mailer.php';
                                send_verification_email($conn, $user['email'], $new_token, $user['user_id']);

                                $error = "Akun Anda belum diverifikasi. Kami telah mengirimkan email verifikasi baru ke alamat email Anda. Silakan periksa email Anda (termasuk folder spam) dan klik tautan verifikasi untuk mengaktifkan akun Anda.";
                            } else {
                                $error = "Akun Anda belum diverifikasi. Silakan periksa email Anda (termasuk folder spam) untuk tautan verifikasi, atau coba lagi dalam beberapa saat.";
                            }
                        } else {
                            // Check if user has 2FA enabled
                            if (isset($user['two_factor_enabled']) && $user['two_factor_enabled'] == 1) {
                                // Set session variable for 2FA verification
                                $_SESSION['2fa_user_id'] = $user['user_id'];
                                $show_2fa_form = true;
                                $user_id_for_2fa = $user['user_id'];
                            } else {
                                // Set session variables
                                $_SESSION['user_id'] = $user['user_id'];
                                $_SESSION['username'] = $user['username'];
                                $_SESSION['email'] = $user['email'];
                                $_SESSION['is_admin'] = $user['is_admin'];
                                $_SESSION['role'] = $user['is_admin'] ? 'admin' : 'user'; // Set role for security dashboard
                                $_SESSION['balance'] = $user['balance'];

                                // Log successful login
                                log_security_event('login_success', "User logged in successfully", $user['user_id'], $_SERVER['REMOTE_ADDR']);

                                // Notify user of new login
                                if (function_exists('notifyNewLogin')) {
                                    notifyNewLogin($user['user_id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']);
                                }

                                // Check if there's a redirect URL
                                if (isset($_GET['redirect'])) {
                                    header("Location: " . $_GET['redirect']);
                                } else {
                                    header("Location: index.php");
                                }
                                exit;
                            }
                        }
                    } else {
                        // Record failed login attempt
                        record_login_attempt($ip_address, $username, false);

                        // Increment failed login count for user
                        if (isset($user['failed_login_count'])) {
                            $failed_count = $user['failed_login_count'] + 1;
                            $update_sql = "UPDATE users SET failed_login_count = ? WHERE user_id = ?";
                            $update_stmt = $conn->prepare($update_sql);
                            $update_stmt->bind_param("ii", $failed_count, $user['user_id']);
                            $update_stmt->execute();

                            // Lock account if too many failed attempts
                            if ($failed_count >= 5) {
                                $lockout_time = date('Y-m-d H:i:s', strtotime('+15 minutes'));
                                $lock_sql = "UPDATE users SET account_locked_until = ? WHERE user_id = ?";
                                $lock_stmt = $conn->prepare($lock_sql);
                                $lock_stmt->bind_param("si", $lockout_time, $user['user_id']);
                                $lock_stmt->execute();

                                // Log account lockout
                                log_security_event('account_lockout', "Account locked due to too many failed login attempts", $user['user_id'], $_SERVER['REMOTE_ADDR']);

                                // Notify user of account lockout
                                if (function_exists('notifyAccountLockout')) {
                                    notifyAccountLockout($user['user_id'], $failed_count, $lockout_time);
                                }
                            }
                        }

                        $error = "Username atau password salah.";
                    }
                } else {
                    // Record failed login attempt
                    record_login_attempt($ip_address, $username, false);
                    $error = "Username atau password salah.";
                }
            }
        }
    }
}

// Page title for header
$page_title = "Masuk - LelangMobil";
?>

<?php
// Include header file with path detection
if (file_exists(INCLUDES_PATH . 'header.php')) {
    include(INCLUDES_PATH . 'header.php');
} elseif (file_exists('/home/lelang/public_html/includes/header.php')) {
    include('/home/lelang/public_html/includes/header.php');
} else {
    include('includes/header.php');
}
?>

<div id="top"></div>
<section id="subheader" class="jarallax text-light">
    <img src="images/background/2.jpg" class="jarallax-img" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="subtitle wow fadeInUp mb-3">LelangMobil</div>
            </div>
            <div class="col-lg-6">
                <h2 class="wow fadeInUp mb20" data-wow-delay=".2s">Masuk</h2>
            </div>
        </div>
    </div>
</section>

<section aria-label="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="de-box">
                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php if(strpos($error, 'belum diverifikasi') !== false): ?>
                            <div class="alert alert-info">
                                <p>Tidak menerima email verifikasi? <a href="resend_verification.php">Kirim ulang email verifikasi</a></p>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if(!empty($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>

                    <?php if ($show_2fa_form): ?>
                        <!-- Two-Factor Authentication Form -->
                        <div class="text-center mb-4">
                            <i class="fas fa-shield-alt fa-3x text-primary mb-3"></i>
                            <h3>Verifikasi Dua Faktor</h3>
                            <p>Silakan masukkan kode verifikasi dari aplikasi autentikator Anda.</p>
                        </div>

                        <form class="form-border" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . (isset($_GET['redirect']) ? '?redirect=' . urlencode($_GET['redirect']) : '')); ?>">
                            <?php
                            if (function_exists('csrf_token_input_field')) {
                                echo csrf_token_input_field();
                            } else if (function_exists('csrf_token_field')) {
                                echo csrf_token_field();
                            } else {
                                // Fallback to manual token generation
                                $token = isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : (function_exists('generate_secure_csrf_token') ? generate_secure_csrf_token() : md5(uniqid()));
                                echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token) . '">';
                            }
                            ?>
                            <div class="row justify-content-center">
                                <div class="col-md-6">
                                    <div class="field-set">
                                        <label>Kode Verifikasi:</label>
                                        <input type="text" name="verification_code" class="form-control text-center"
                                            pattern="[0-9]*" inputmode="numeric" autocomplete="one-time-code"
                                            maxlength="6" required autofocus>
                                    </div>
                                </div>

                                <div class="col-lg-12 text-center">
                                    <div class="spacer-20"></div>
                                    <button class="btn-main" type="submit">Verifikasi</button>
                                    <div class="spacer-20"></div>
                                    <p><small>Tidak memiliki akses ke aplikasi autentikator? Gunakan kode cadangan yang telah Anda simpan.</small></p>
                                </div>
                            </div>
                        </form>
                    <?php else: ?>
                        <!-- Regular Login Form -->
                        <form class="form-border" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . (isset($_GET['redirect']) ? '?redirect=' . urlencode($_GET['redirect']) : '')); ?>">
                            <?php
                            if (function_exists('csrf_token_input_field')) {
                                echo csrf_token_input_field();
                            } else if (function_exists('csrf_token_field')) {
                                echo csrf_token_field();
                            } else {
                                // Fallback to manual token generation
                                $token = isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : (function_exists('generate_secure_csrf_token') ? generate_secure_csrf_token() : md5(uniqid()));
                                echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token) . '">';
                            }
                            ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="field-set">
                                        <label>Username atau Email:</label>
                                        <input type="text" name="username" class="form-control" required>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="field-set">
                                        <label>Password:</label>
                                        <input type="password" name="password" class="form-control" required>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="spacer-20"></div>
                                    <button class="btn-main" type="submit">Masuk</button>
                                    <div class="spacer-20"></div>
                                    <p>Belum memiliki akun? <a href="register.php">Daftar di sini</a></p>
                                    <p><a href="forgot-password.php">Lupa password?</a></p>

                                    <?php if(!empty($error)): ?>
                                    <div class="spacer-10"></div>
                                    <p><small>Masalah saat login? <a href="login_troubleshooter.php">Diagnosa masalah login</a> atau <a href="cookie_test.php">uji fungsi cookie</a></small></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Include footer file with path detection
if (file_exists(INCLUDES_PATH . 'footer.php')) {
    include(INCLUDES_PATH . 'footer.php');
} elseif (file_exists('/home/lelang/public_html/includes/footer.php')) {
    include('/home/lelang/public_html/includes/footer.php');
} else {
    include('includes/footer.php');
}
?>
