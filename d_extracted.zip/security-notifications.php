<?php
/**
 * Security Notification Center for LelangMobil
 * Version: 1.0 (14 Mei 2025)
 *
 * This page displays security notifications for users and allows them
 * to manage their notification preferences.
 */

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Include necessary files
require_once 'config/database.php';
require_once 'config/security.php';
require_once 'config/security_notifications.php';

// Initialize variables
$user_id = $_SESSION['user_id'];
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;
$success_message = '';
$error_message = '';

// Get user's notification preferences
$preferences = getNotificationPreferences($user_id);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // CSRF token validation
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        
        // Mark notification as read
        if (isset($_POST['mark_read']) && isset($_POST['notification_id'])) {
            $notification_id = intval($_POST['notification_id']);
            
            if (markSecurityNotificationAsRead($notification_id, $user_id)) {
                $success_message = 'Notification marked as read.';
            } else {
                $error_message = 'Failed to mark notification as read.';
            }
        }
        
        // Mark all notifications as read
        if (isset($_POST['mark_all_read'])) {
            if (markAllSecurityNotificationsAsRead($user_id)) {
                $success_message = 'All notifications marked as read.';
            } else {
                $error_message = 'Failed to mark all notifications as read.';
            }
        }
        
        // Delete notification
        if (isset($_POST['delete']) && isset($_POST['notification_id'])) {
            $notification_id = intval($_POST['notification_id']);
            
            if (deleteSecurityNotification($notification_id, $user_id)) {
                $success_message = 'Notification deleted.';
            } else {
                $error_message = 'Failed to delete notification.';
            }
        }
        
        // Update notification preferences
        if (isset($_POST['update_preferences'])) {
            $types = [
                'default',
                'login_related',
                'password_changes',
                'account_changes',
                'suspicious_activity'
            ];
            
            $allSuccess = true;
            
            foreach ($types as $type) {
                $emailEnabled = isset($_POST['email_' . $type]) ? true : false;
                $smsEnabled = isset($_POST['sms_' . $type]) ? true : false;
                $pushEnabled = isset($_POST['push_' . $type]) ? true : false;
                $inAppEnabled = isset($_POST['in_app_' . $type]) ? true : false;
                
                if (!updateNotificationPreferences($user_id, $type, $emailEnabled, $smsEnabled, $pushEnabled, $inAppEnabled)) {
                    $allSuccess = false;
                }
            }
            
            if ($allSuccess) {
                $success_message = 'Notification preferences updated successfully.';
                $preferences = getNotificationPreferences($user_id);
            } else {
                $error_message = 'Failed to update some notification preferences.';
            }
        }
    }
}

// Get notifications
$notificationsData = getAllSecurityNotifications($user_id, $page, $per_page);
$notifications = $notificationsData['notifications'];
$pagination = $notificationsData['pagination'];

// Set page title
$page_title = 'Security Notifications';

// Include header
include_once 'includes/header.php';
?>

<div class="container mt-5 mb-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-shield-alt"></i> Security Center
                    </h5>
                </div>
                <div class="list-group list-group-flush">
                    <a href="account.php" class="list-group-item list-group-item-action">
                        <i class="fas fa-user"></i> Account Settings
                    </a>
                    <a href="security-notifications.php" class="list-group-item list-group-item-action active">
                        <i class="fas fa-bell"></i> Security Alerts
                        <?php 
                        $unreadCount = count(getUnreadSecurityNotifications($user_id, 1));
                        if ($unreadCount > 0): 
                        ?>
                        <span class="badge bg-danger float-end"><?php echo $unreadCount; ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="two-factor-setup.php" class="list-group-item list-group-item-action">
                        <i class="fas fa-key"></i> Two-Factor Authentication
                    </a>
                    <a href="change-password.php" class="list-group-item list-group-item-action">
                        <i class="fas fa-lock"></i> Change Password
                    </a>
                    <a href="login-activity.php" class="list-group-item list-group-item-action">
                        <i class="fas fa-history"></i> Login Activity
                    </a>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card shadow-sm mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <?php echo generateCSRFToken(); ?>
                        <button type="submit" name="mark_all_read" class="btn btn-outline-primary w-100 mb-2">
                            <i class="fas fa-check-double"></i> Mark All As Read
                        </button>
                    </form>
                    <a href="#preferences" class="btn btn-outline-secondary w-100">
                        <i class="fas fa-cog"></i> Notification Settings
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            
            <!-- Notifications -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-bell"></i> Security Notifications
                    </h5>
                    <span class="badge bg-light text-dark">
                        <?php echo $pagination['total']; ?> Total
                    </span>
                </div>
                <div class="card-body p-0">
                    <?php if (empty($notifications)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-bell-slash fa-3x text-muted mb-3"></i>
                            <p class="text-muted">You don't have any security notifications.</p>
                        </div>
                    <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($notifications as $notification): ?>
                                <div class="list-group-item list-group-item-action notification-item <?php echo $notification['is_read'] ? '' : 'unread'; ?>">
                                    <div class="d-flex w-100 justify-content-between align-items-center">
                                        <h6 class="mb-1">
                                            <?php if ($notification['is_important']): ?>
                                                <span class="badge bg-danger me-1">Important</span>
                                            <?php endif; ?>
                                            <?php echo $notification['title']; ?>
                                        </h6>
                                        <small class="text-muted">
                                            <?php echo timeAgo($notification['created_at']); ?>
                                        </small>
                                    </div>
                                    <p class="mb-1 notification-message">
                                        <?php echo nl2br(htmlspecialchars($notification['message'])); ?>
                                    </p>
                                    <div class="notification-actions mt-2">
                                        <?php if (!$notification['is_read']): ?>
                                            <form method="post" class="d-inline">
                                                <?php echo generateCSRFToken(); ?>
                                                <input type="hidden" name="notification_id" value="<?php echo $notification['notification_id']; ?>">
                                                <button type="submit" name="mark_read" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-check"></i> Mark as Read
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <?php if ($notification['requires_action'] && $notification['action_url']): ?>
                                            <a href="<?php echo $notification['action_url']; ?>" class="btn btn-sm btn-danger">
                                                <i class="fas fa-exclamation-triangle"></i> Take Action
                                            </a>
                                        <?php endif; ?>
                                        
                                        <form method="post" class="d-inline delete-form">
                                            <?php echo generateCSRFToken(); ?>
                                            <input type="hidden" name="notification_id" value="<?php echo $notification['notification_id']; ?>">
                                            <button type="submit" name="delete" class="btn btn-sm btn-outline-secondary delete-btn">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <?php if ($pagination['last_page'] > 1): ?>
                    <div class="card-footer">
                        <nav aria-label="Notifications pagination">
                            <ul class="pagination justify-content-center mb-0">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php for ($i = max(1, $page - 2); $i <= min($pagination['last_page'], $page + 2); $i++): ?>
                                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $pagination['last_page']): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Notification Preferences -->
            <div class="card shadow-sm" id="preferences">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-cog"></i> Notification Preferences
                    </h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <?php echo generateCSRFToken(); ?>
                        
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>Notification Type</th>
                                        <th class="text-center">Email</th>
                                        <th class="text-center">SMS</th>
                                        <th class="text-center">Push</th>
                                        <th class="text-center">In-App</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <strong>Default Settings</strong>
                                            <div class="small text-muted">Applied to all notification types unless overridden</div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="email_default" id="email_default" 
                                                    <?php echo isset($preferences['default']) && $preferences['default']['email_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="sms_default" id="sms_default" 
                                                    <?php echo isset($preferences['default']) && $preferences['default']['sms_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="push_default" id="push_default" 
                                                    <?php echo isset($preferences['default']) && $preferences['default']['push_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="in_app_default" id="in_app_default" 
                                                    <?php echo isset($preferences['default']) && $preferences['default']['in_app_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Login Notifications</strong>
                                            <div class="small text-muted">New login events, suspicious login attempts</div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="email_login_related" id="email_login_related" 
                                                    <?php echo isset($preferences['login_related']) && $preferences['login_related']['email_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="sms_login_related" id="sms_login_related" 
                                                    <?php echo isset($preferences['login_related']) && $preferences['login_related']['sms_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="push_login_related" id="push_login_related" 
                                                    <?php echo isset($preferences['login_related']) && $preferences['login_related']['push_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="in_app_login_related" id="in_app_login_related" 
                                                    <?php echo isset($preferences['login_related']) && $preferences['login_related']['in_app_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Password Changes</strong>
                                            <div class="small text-muted">Password updates, reset requests</div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="email_password_changes" id="email_password_changes" 
                                                    <?php echo isset($preferences['password_changes']) && $preferences['password_changes']['email_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="sms_password_changes" id="sms_password_changes" 
                                                    <?php echo isset($preferences['password_changes']) && $preferences['password_changes']['sms_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="push_password_changes" id="push_password_changes" 
                                                    <?php echo isset($preferences['password_changes']) && $preferences['password_changes']['push_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="in_app_password_changes" id="in_app_password_changes" 
                                                    <?php echo isset($preferences['password_changes']) && $preferences['password_changes']['in_app_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Account Changes</strong>
                                            <div class="small text-muted">Email updates, profile changes</div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="email_account_changes" id="email_account_changes" 
                                                    <?php echo isset($preferences['account_changes']) && $preferences['account_changes']['email_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="sms_account_changes" id="sms_account_changes" 
                                                    <?php echo isset($preferences['account_changes']) && $preferences['account_changes']['sms_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="push_account_changes" id="push_account_changes" 
                                                    <?php echo isset($preferences['account_changes']) && $preferences['account_changes']['push_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="in_app_account_changes" id="in_app_account_changes" 
                                                    <?php echo isset($preferences['account_changes']) && $preferences['account_changes']['in_app_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Suspicious Activity</strong>
                                            <div class="small text-muted">Potential account compromise, unusual behavior</div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="email_suspicious_activity" id="email_suspicious_activity" 
                                                    <?php echo isset($preferences['suspicious_activity']) && $preferences['suspicious_activity']['email_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="sms_suspicious_activity" id="sms_suspicious_activity" 
                                                    <?php echo isset($preferences['suspicious_activity']) && $preferences['suspicious_activity']['sms_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="push_suspicious_activity" id="push_suspicious_activity" 
                                                    <?php echo isset($preferences['suspicious_activity']) && $preferences['suspicious_activity']['push_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" name="in_app_suspicious_activity" id="in_app_suspicious_activity" 
                                                    <?php echo isset($preferences['suspicious_activity']) && $preferences['suspicious_activity']['in_app_enabled'] ? 'checked' : ''; ?>>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="text-end mt-3">
                            <button type="submit" name="update_preferences" class="btn btn-primary">
                                <i class="fas fa-save"></i> Save Preferences
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Confirm deletion of notifications
document.querySelectorAll('.delete-form').forEach(form => {
    form.addEventListener('submit', function(e) {
        if (!confirm('Are you sure you want to delete this notification?')) {
            e.preventDefault();
        }
    });
});
</script>

<style>
.notification-item {
    border-left: 3px solid transparent;
}

.notification-item.unread {
    background-color: rgba(0, 123, 255, 0.05);
    border-left-color: #007bff;
}

.notification-message {
    white-space: pre-line;
}

.delete-btn {
    opacity: 0.5;
    transition: opacity 0.2s;
}

.notification-item:hover .delete-btn {
    opacity: 1;
}
</style>

<?php
// Helper function to display time ago
function timeAgo($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return 'just now';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
    } else {
        return date('j M Y', $time);
    }
}

include_once 'includes/footer.php';
?>
