/**
 * Transaction Modern 2025 JavaScript
 * Untuk mendukung fitur modern pada transaction table
 */

// Fungsi untuk mengekspor transaction data ke CSV
function exportTransactions() {
    // Dapatkan data dari tabel
    const table = document.querySelector('.transaction-table-2025');
    if (!table) {
        showToast('error', 'Tidak ada data transaksi yang dapat diekspor');
        return;
    }
    
    const headers = [];
    const headerCells = table.querySelectorAll('thead th');
    headerCells.forEach(cell => {
        headers.push(cell.innerText.trim());
    });
    
    let csvContent = headers.join(',') + '\n';
    
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
        const rowData = [];
        const cells = row.querySelectorAll('td');
        cells.forEach(cell => {
            // Bersihkan data dari karakter khusus
            let cellText = cell.innerText.trim().replace(/,/g, ';');
            // Jika cell mengandung status, ambil hanya teksnya
            if (cell.querySelector('.transaction-status-2025')) {
                cellText = cell.querySelector('.transaction-status-2025').innerText.trim().replace(/,/g, ';');
            }
            rowData.push('"' + cellText + '"');
        });
        csvContent += rowData.join(',') + '\n';
    });
    
    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `transaksi_${formatDate(new Date())}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showToast('success', 'Data transaksi berhasil diekspor');
}

// Fungsi untuk menampilkan toast notification
function showToast(type, message) {
    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type} fade-in-up`;
    
    const icon = document.createElement('i');
    icon.className = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
    
    const messageSpan = document.createElement('span');
    messageSpan.textContent = message;
    
    toast.appendChild(icon);
    toast.appendChild(messageSpan);
    
    // Cek apakah container toast sudah ada, jika belum buat baru
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container';
        document.body.appendChild(toastContainer);
    }
    
    toastContainer.appendChild(toast);
    
    // Auto hapus toast setelah 3 detik
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

// Helper untuk memformat tanggal
function formatDate(date) {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
}

// Event listener saat DOM loaded
document.addEventListener('DOMContentLoaded', function() {
    // Auto-animate statistics pada halaman dashboard
    const statItems = document.querySelectorAll('.profile-stat-item-2025');
    if (statItems.length > 0) {
        statItems.forEach((item, index) => {
            setTimeout(() => {
                item.classList.add('fade-in-up');
            }, 100 * index);
        });
    }
    
    // Add toast styling if not exists
    if (!document.querySelector('#toast-styles')) {
        const style = document.createElement('style');
        style.id = 'toast-styles';
        style.innerHTML = `
            .toast-container {
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 9999;
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            .toast-notification {
                padding: 12px 20px;
                border-radius: 8px;
                color: white;
                display: flex;
                align-items: center;
                gap: 10px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                cursor: pointer;
                transition: all 0.3s ease;
            }
            .toast-success {
                background: linear-gradient(135deg, #28c76f, #1f9d57);
            }
            .toast-error {
                background: linear-gradient(135deg, #ea5455, #d13e3f);
            }
            .toast-info {
                background: linear-gradient(135deg, #00cfe8, #00a8bc);
            }
            .toast-notification.fade-out {
                opacity: 0;
                transform: translateY(10px);
            }
        `;
        document.head.appendChild(style);
    }
});
