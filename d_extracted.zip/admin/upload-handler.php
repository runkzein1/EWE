<?php
// Include database connection and functions
require_once '../config/database.php';
require_once '../config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is admin
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Define upload directories
$vehicle_images_dir = '../uploads/vehicles/';
$payment_proofs_dir = '../uploads/payment_proof/';
$temp_uploads_dir = '../uploads/temp/';

// Ensure the upload directories exist
foreach ([$vehicle_images_dir, $payment_proofs_dir, $temp_uploads_dir] as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Function to generate a safe filename
function generate_safe_filename($original_name) {
    $extension = pathinfo($original_name, PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . date('Ymd_His') . '.' . $extension;
    return $filename;
}

// Handle AJAX file uploads
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = [];
    
    // Vehicle image upload
    if (isset($_POST['action']) && $_POST['action'] === 'vehicle_image_upload') {
        $vehicle_id = isset($_POST['vehicle_id']) ? intval($_POST['vehicle_id']) : 0;
        
        if ($vehicle_id <= 0) {
            // If no vehicle ID, save to temp directory for later association
            $upload_dir = $temp_uploads_dir;
        } else {
            $upload_dir = $vehicle_images_dir . $vehicle_id . '/';
            
            // Create vehicle-specific directory if it doesn't exist
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
        }
        
        if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['file'];
            
            // Validate file type
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            
            if (!in_array($file_extension, $allowed_extensions)) {
                $response = [
                    'success' => false,
                    'message' => 'Format file tidak valid. Hanya file JPG, JPEG, PNG, dan GIF yang diperbolehkan.'
                ];
            } else {
                // Check file size (max 5MB)
                if ($file['size'] > 5 * 1024 * 1024) {
                    $response = [
                        'success' => false,
                        'message' => 'Ukuran file terlalu besar. Maksimum 5MB.'
                    ];
                } else {
                    // Generate a safe filename
                    $filename = generate_safe_filename($file['name']);
                    $file_path = $upload_dir . $filename;
                    
                    // Move the uploaded file
                    if (move_uploaded_file($file['tmp_name'], $file_path)) {
                        if ($vehicle_id > 0) {
                            // Add to database if vehicle ID is provided
                            $is_main = isset($_POST['is_main']) && $_POST['is_main'] == 1 ? 1 : 0;
                            
                            // If setting as main image, unset previous main image
                            if ($is_main) {
                                $unset_sql = "UPDATE vehicle_images SET is_main = 0 WHERE vehicle_id = ?";
                                $unset_stmt = $conn->prepare($unset_sql);
                                $unset_stmt->bind_param("i", $vehicle_id);
                                $unset_stmt->execute();
                            }
                            
                            // Store relative path from root
                            $relative_path = 'uploads/vehicles/' . $vehicle_id . '/' . $filename;
                            
                            $insert_sql = "INSERT INTO vehicle_images (vehicle_id, image_url, is_main) VALUES (?, ?, ?)";
                            $insert_stmt = $conn->prepare($insert_sql);
                            $insert_stmt->bind_param("isi", $vehicle_id, $relative_path, $is_main);
                            
                            if ($insert_stmt->execute()) {
                                $image_id = $conn->insert_id;
                                
                                // If this is the main image, also update vehicle record
                                if ($is_main) {
                                    $update_vehicle_sql = "UPDATE vehicles SET image_main = ? WHERE vehicle_id = ?";
                                    $update_vehicle_stmt = $conn->prepare($update_vehicle_sql);
                                    $update_vehicle_stmt->bind_param("si", $relative_path, $vehicle_id);
                                    $update_vehicle_stmt->execute();
                                }
                                
                                $response = [
                                    'success' => true,
                                    'message' => 'Gambar berhasil diunggah.',
                                    'image_id' => $image_id,
                                    'image_url' => $relative_path,
                                    'file_name' => $filename,
                                    'is_main' => $is_main
                                ];
                            } else {
                                // Delete file if database insert fails
                                unlink($file_path);
                                $response = [
                                    'success' => false,
                                    'message' => 'Gagal menyimpan data gambar ke database.'
                                ];
                            }
                        } else {
                            // Just return path for temporary uploads
                            $response = [
                                'success' => true,
                                'message' => 'Gambar berhasil diunggah ke direktori sementara.',
                                'file_name' => $filename,
                                'file_path' => 'uploads/temp/' . $filename
                            ];
                        }
                    } else {
                        $response = [
                            'success' => false,
                            'message' => 'Gagal memindahkan file yang diunggah.'
                        ];
                    }
                }
            }
        } else {
            $response = [
                'success' => false,
                'message' => 'Terjadi kesalahan dalam upload file: ' . $_FILES['file']['error']
            ];
        }
    }
    
    // Payment proof upload
    else if (isset($_POST['action']) && $_POST['action'] === 'payment_proof_upload') {
        $transaction_id = isset($_POST['transaction_id']) ? intval($_POST['transaction_id']) : 0;
        
        if ($transaction_id <= 0) {
            $response = [
                'success' => false,
                'message' => 'ID transaksi tidak valid.'
            ];
        } else {
            if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['file'];
                
                // Validate file type
                $allowed_extensions = ['jpg', 'jpeg', 'png', 'pdf'];
                $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                
                if (!in_array($file_extension, $allowed_extensions)) {
                    $response = [
                        'success' => false,
                        'message' => 'Format file tidak valid. Hanya file JPG, JPEG, PNG, dan PDF yang diperbolehkan.'
                    ];
                } else {
                    // Check file size (max 2MB)
                    if ($file['size'] > 2 * 1024 * 1024) {
                        $response = [
                            'success' => false,
                            'message' => 'Ukuran file terlalu besar. Maksimum 2MB.'
                        ];
                    } else {
                        // Generate a safe filename
                        $filename = 'payment_' . $transaction_id . '_' . generate_safe_filename($file['name']);
                        $file_path = $payment_proofs_dir . $filename;
                        
                        // Move the uploaded file
                        if (move_uploaded_file($file['tmp_name'], $file_path)) {
                            // Update transaction record
                            $relative_path = 'uploads/payment_proof/' . $filename;
                            
                            $update_sql = "UPDATE transactions SET payment_proof = ? WHERE transaction_id = ?";
                            $update_stmt = $conn->prepare($update_sql);
                            $update_stmt->bind_param("si", $relative_path, $transaction_id);
                            
                            if ($update_stmt->execute()) {
                                $response = [
                                    'success' => true,
                                    'message' => 'Bukti pembayaran berhasil diunggah.',
                                    'file_name' => $filename,
                                    'file_path' => $relative_path
                                ];
                            } else {
                                // Delete file if database update fails
                                unlink($file_path);
                                $response = [
                                    'success' => false,
                                    'message' => 'Gagal menyimpan data bukti pembayaran ke database.'
                                ];
                            }
                        } else {
                            $response = [
                                'success' => false,
                                'message' => 'Gagal memindahkan file yang diunggah.'
                            ];
                        }
                    }
                }
            } else {
                $response = [
                    'success' => false,
                    'message' => 'Terjadi kesalahan dalam upload file: ' . $_FILES['file']['error']
                ];
            }
        }
    }
    
    // Set Main Image
    else if (isset($_POST['action']) && $_POST['action'] === 'set_main_image') {
        $image_id = isset($_POST['image_id']) ? intval($_POST['image_id']) : 0;
        $vehicle_id = isset($_POST['vehicle_id']) ? intval($_POST['vehicle_id']) : 0;
        
        if ($image_id <= 0 || $vehicle_id <= 0) {
            $response = [
                'success' => false,
                'message' => 'ID gambar atau kendaraan tidak valid.'
            ];
        } else {
            // Verify the image belongs to the vehicle
            $verify_sql = "SELECT * FROM vehicle_images WHERE image_id = ? AND vehicle_id = ?";
            $verify_stmt = $conn->prepare($verify_sql);
            $verify_stmt->bind_param("ii", $image_id, $vehicle_id);
            $verify_stmt->execute();
            $verify_result = $verify_stmt->get_result();
            
            if ($verify_result->num_rows > 0) {
                $conn->begin_transaction();
                
                try {
                    // Unset all main images for this vehicle
                    $unset_sql = "UPDATE vehicle_images SET is_main = 0 WHERE vehicle_id = ?";
                    $unset_stmt = $conn->prepare($unset_sql);
                    $unset_stmt->bind_param("i", $vehicle_id);
                    $unset_stmt->execute();
                    
                    // Set this image as main
                    $set_sql = "UPDATE vehicle_images SET is_main = 1 WHERE image_id = ?";
                    $set_stmt = $conn->prepare($set_sql);
                    $set_stmt->bind_param("i", $image_id);
                    $set_stmt->execute();
                    
                    // Get the image URL
                    $image_sql = "SELECT image_url FROM vehicle_images WHERE image_id = ?";
                    $image_stmt = $conn->prepare($image_sql);
                    $image_stmt->bind_param("i", $image_id);
                    $image_stmt->execute();
                    $image_result = $image_stmt->get_result();
                    $image = $image_result->fetch_assoc();
                    
                    // Update vehicle's main image
                    $update_vehicle_sql = "UPDATE vehicles SET image_main = ? WHERE vehicle_id = ?";
                    $update_vehicle_stmt = $conn->prepare($update_vehicle_sql);
                    $update_vehicle_stmt->bind_param("si", $image['image_url'], $vehicle_id);
                    $update_vehicle_stmt->execute();
                    
                    $conn->commit();
                    
                    $response = [
                        'success' => true,
                        'message' => 'Gambar utama berhasil diubah.'
                    ];
                } catch (Exception $e) {
                    $conn->rollback();
                    $response = [
                        'success' => false,
                        'message' => 'Terjadi kesalahan: ' . $e->getMessage()
                    ];
                }
            } else {
                $response = [
                    'success' => false,
                    'message' => 'Gambar tidak ditemukan atau tidak terkait dengan kendaraan ini.'
                ];
            }
        }
    }
    
    // Image Delete 
    else if (isset($_POST['action']) && $_POST['action'] === 'delete_image') {
        $image_id = isset($_POST['image_id']) ? intval($_POST['image_id']) : 0;
        
        if ($image_id <= 0) {
            $response = [
                'success' => false,
                'message' => 'ID gambar tidak valid.'
            ];
        } else {
            // Get image info
            $image_sql = "SELECT * FROM vehicle_images WHERE image_id = ?";
            $image_stmt = $conn->prepare($image_sql);
            $image_stmt->bind_param("i", $image_id);
            $image_stmt->execute();
            $image_result = $image_stmt->get_result();
            
            if ($image_result->num_rows > 0) {
                $image = $image_result->fetch_assoc();
                $file_path = '../' . $image['image_url'];
                
                // Delete from database
                $delete_sql = "DELETE FROM vehicle_images WHERE image_id = ?";
                $delete_stmt = $conn->prepare($delete_sql);
                $delete_stmt->bind_param("i", $image_id);
                
                if ($delete_stmt->execute()) {
                    // Delete file from server
                    if (file_exists($file_path)) {
                        unlink($file_path);
                    }
                    
                    // If this was the main image, update the vehicle record
                    if ($image['is_main']) {
                        // Find another image to make main
                        $new_main_sql = "SELECT * FROM vehicle_images WHERE vehicle_id = ? LIMIT 1";
                        $new_main_stmt = $conn->prepare($new_main_sql);
                        $new_main_stmt->bind_param("i", $image['vehicle_id']);
                        $new_main_stmt->execute();
                        $new_main_result = $new_main_stmt->get_result();
                        
                        if ($new_main_result->num_rows > 0) {
                            // Set another image as main
                            $new_main = $new_main_result->fetch_assoc();
                            
                            $update_main_sql = "UPDATE vehicle_images SET is_main = 1 WHERE image_id = ?";
                            $update_main_stmt = $conn->prepare($update_main_sql);
                            $update_main_stmt->bind_param("i", $new_main['image_id']);
                            $update_main_stmt->execute();
                            
                            // Update vehicle record
                            $update_vehicle_sql = "UPDATE vehicles SET image_main = ? WHERE vehicle_id = ?";
                            $update_vehicle_stmt = $conn->prepare($update_vehicle_sql);
                            $update_vehicle_stmt->bind_param("si", $new_main['image_url'], $image['vehicle_id']);
                            $update_vehicle_stmt->execute();
                        } else {
                            // No more images, set main to NULL
                            $update_vehicle_sql = "UPDATE vehicles SET image_main = NULL WHERE vehicle_id = ?";
                            $update_vehicle_stmt = $conn->prepare($update_vehicle_sql);
                            $update_vehicle_stmt->bind_param("i", $image['vehicle_id']);
                            $update_vehicle_stmt->execute();
                        }
                    }
                    
                    $response = [
                        'success' => true,
                        'message' => 'Gambar berhasil dihapus.'
                    ];
                } else {
                    $response = [
                        'success' => false,
                        'message' => 'Gagal menghapus data gambar dari database.'
                    ];
                }
            } else {
                $response = [
                    'success' => false,
                    'message' => 'Gambar tidak ditemukan.'
                ];
            }
        }
    }
    
    // Invalid action
    else {
        $response = [
            'success' => false,
            'message' => 'Aksi tidak valid.'
        ];
    }
    
    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
?>
