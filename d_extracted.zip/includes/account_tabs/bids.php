<?php
// Ensure this file is included by account.php and has access to $db, $user_id, $user_bids, $csrf_token

if (!defined('ROOT_PATH')) {
    die("Direct access not allowed.");
}

// $user_bids should be an array of the user's active bids, fetched in account.php
// Each bid item should ideally contain: auction_title, bid_amount, bid_time, auction_end_time, item_image_url, auction_url, auction_id, is_winning, is_outbid (booleans)

?>

<h4>My Active Bids</h4>
<hr>

<?php if (isset($user_bids) && !empty($user_bids)): ?>
    <div class="list-group">
        <?php foreach ($user_bids as $bid): ?>
            <a href="<?php echo htmlspecialchars($bid['auction_url'] ?? (BASE_URL . 'auctions.php?id=' . ($bid['auction_id'] ?? ''))); ?>" class="list-group-item list-group-item-action flex-column align-items-start mb-3 shadow-sm modern-bid-item">
                <div class="row">
                    <?php if (!empty($bid['item_image_url'])): ?>
                    <div class="col-md-2 col-sm-3 text-center">
                        <img src="<?php echo htmlspecialchars($bid['item_image_url']); ?>" alt="<?php echo htmlspecialchars($bid['auction_title'] ?? 'Item'); ?>" class="img-fluid rounded" style="max-height: 100px; margin-top: 10px;">
                    </div>
                    <?php endif; ?>
                    <div class="<?php echo !empty($bid['item_image_url']) ? 'col-md-10 col-sm-9' : 'col-12'; ?>">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1 auction-title-link"><?php echo htmlspecialchars($bid['auction_title'] ?? 'Auction Item'); ?></h5>
                            <small class="text-muted">Ends: <?php echo htmlspecialchars(date("d M Y, H:i", strtotime($bid['auction_end_time'] ?? 'N/A'))); ?></small>
                        </div>
                        <p class="mb-1">Your Bid: <strong class="text-success">Rp <?php echo number_format($bid['bid_amount'] ?? 0, 2, ',', '.'); ?></strong></p>
                        <small class="text-muted">Placed on: <?php echo htmlspecialchars(date("d M Y, H:i", strtotime($bid['bid_time'] ?? 'N/A'))); ?></small>
                        
                        <div class="mt-2">
                        <?php if (isset($bid['is_winning']) && $bid['is_winning'] === true): ?>
                            <span class="badge bg-success"><i class="fas fa-check-circle"></i> Currently Winning</span>
                        <?php elseif (isset($bid['is_outbid']) && $bid['is_outbid'] === true): ?>
                            <span class="badge bg-danger"><i class="fas fa-exclamation-triangle"></i> Outbid</span>
                        <?php elseif (isset($bid['status'])): // Generic status if specific flags aren't set ?>
                            <span class="badge bg-info"><?php echo htmlspecialchars(ucfirst($bid['status'])); ?></span>
                        <?php else: ?>
                            <span class="badge bg-primary">Active Bid</span>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <div class="alert alert-info" role="alert">
        You have no active bids at the moment. <a href="<?php echo htmlspecialchars(BASE_URL . 'auctions.php'); ?>" class="alert-link">Explore auctions</a> and place your bids!
    </div>
<?php endif; ?>

<h5 class="mt-5">Bid History</h5>
<hr>
<p class="text-muted">For a comprehensive overview of all your past and current bidding activities, please visit the dedicated bid history page.</p>
<a href="<?php echo htmlspecialchars(BASE_URL . 'bids-history.php'); // Corrected to a more likely page name or use your actual page ?>" class="btn btn-outline-primary"><i class="fas fa-history"></i> View Full Bid History</a>

<!-- Add Font Awesome if not already included globally for icons -->
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> -->
<style>
    .auction-title-link {
        color: #007bff; /* Bootstrap primary blue, or your theme's link color */
        text-decoration: none;
    }
    .auction-title-link:hover {
        text-decoration: underline;
    }
    .modern-bid-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;
        transition: all 0.2s ease-in-out;
    }
</style>
