/**
 * Wallet Modern 2025 JavaScript
 * Implementasi fitur wallet/saldo real-time untuk LelangMobil
 * dengan pendekatan ultra-minimalis
 */

// Namespace untuk sistem wallet
const WalletSystem = {
    // Data saldo dan informasi wallet
    data: {
        balance: 0,
        formattedBalance: '0',
        activeBids: 0,
        holdAmount: 0,
        formattedHoldAmount: '0',
        availableForWithdrawal: 0,
        formattedAvailableForWithdrawal: '0',
        lastUpdate: null,
        refreshInterval: null
    },
    
    // Inisialisasi sistem wallet
    init: function(options = {}) {
        this.options = {
            refreshInterval: 30000, // 30 detik
            autoRefresh: true,
            walletEndpoint: '/api/wallet-info.php',
            walletDisplaySelector: '.wallet-balance',
            ...options
        };
        
        // Load data wallet awal
        this.refreshWalletData();
        
        // Setup auto refresh jika diaktifkan
        if (this.options.autoRefresh) {
            this.startAutoRefresh();
        }
        
        // Setup event listeners
        this.setupEventListeners();
        
        return this;
    },
    
    // Setup event listeners
    setupEventListeners: function() {
        // Refresh wallet ketika tab menjadi aktif
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') {
                this.refreshWalletData();
            }
        });
        
        // Listen untuk event custom wallet-updated
        document.addEventListener('wallet-updated', (e) => {
            if (e.detail && e.detail.refresh) {
                this.refreshWalletData();
            }
        });
    },
    
    // Mulai auto refresh
    startAutoRefresh: function() {
        // Bersihkan interval yang sudah ada jika ada
        if (this.data.refreshInterval) {
            clearInterval(this.data.refreshInterval);
        }
        
        // Set interval baru
        this.data.refreshInterval = setInterval(() => {
            this.refreshWalletData();
        }, this.options.refreshInterval);
    },
    
    // Stop auto refresh
    stopAutoRefresh: function() {
        if (this.data.refreshInterval) {
            clearInterval(this.data.refreshInterval);
            this.data.refreshInterval = null;
        }
    },
    
    // Refresh data wallet
    refreshWalletData: function() {
        fetch(this.options.walletEndpoint)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // Update data wallet
                    this.updateWalletData(data.data);
                    
                    // Update display
                    this.updateWalletDisplay();
                } else if (data.status === 'error' && data.redirect) {
                    // Redirect jika tidak terautentikasi
                    window.location.href = data.redirect;
                }
            })
            .catch(error => {
                console.error('Error refreshing wallet data:', error);
            });
    },
    
    // Update data wallet
    updateWalletData: function(data) {
        this.data.balance = data.balance || 0;
        this.data.formattedBalance = data.formatted_balance || '0';
        this.data.activeBids = data.active_bids || 0;
        this.data.holdAmount = data.hold_amount || 0;
        this.data.formattedHoldAmount = data.formatted_hold_amount || '0';
        this.data.availableForWithdrawal = data.available_for_withdrawal || 0;
        this.data.formattedAvailableForWithdrawal = data.formatted_available_for_withdrawal || '0';
        this.data.lastUpdate = data.last_update || new Date().toISOString();
        
        // Dispatch event bahwa wallet telah diupdate
        const event = new CustomEvent('wallet-data-updated', {
            detail: { walletData: this.data }
        });
        document.dispatchEvent(event);
    },
    
    // Update tampilan wallet di UI
    updateWalletDisplay: function() {
        // Update elemen saldo
        const balanceElements = document.querySelectorAll(this.options.walletDisplaySelector);
        if (balanceElements.length > 0) {
            balanceElements.forEach(el => {
                // Check jika elemen memiliki data-format attribute
                const format = el.dataset.format || 'balance';
                let valueToDisplay = '';
                
                switch (format) {
                    case 'balance':
                        valueToDisplay = this.data.formattedBalance;
                        break;
                    case 'available':
                        valueToDisplay = this.data.formattedAvailableForWithdrawal;
                        break;
                    case 'hold':
                        valueToDisplay = this.data.formattedHoldAmount;
                        break;
                    default:
                        valueToDisplay = this.data.formattedBalance;
                }
                
                // Check if element is an input
                if (el.tagName === 'INPUT') {
                    el.value = valueToDisplay;
                } else {
                    el.textContent = valueToDisplay;
                }
                
                // Tambahkan animasi update jika balance berubah
                el.classList.add('balance-updated');
                setTimeout(() => {
                    el.classList.remove('balance-updated');
                }, 1000);
            });
        }
        
        // Update elemen active bids jika ada
        const activeBidsElements = document.querySelectorAll('.active-bids-count');
        if (activeBidsElements.length > 0) {
            activeBidsElements.forEach(el => {
                el.textContent = this.data.activeBids;
            });
        }
    },
    
    // Kirim perintah top up
    requestTopUp: function(amount, paymentMethod, callback) {
        // Validasi input
        amount = parseFloat(amount);
        if (isNaN(amount) || amount <= 0) {
            callback({ 
                status: 'error', 
                message: 'Jumlah top up tidak valid' 
            });
            return;
        }
        
        // Prepare data
        const formData = new FormData();
        formData.append('amount', amount);
        formData.append('payment_method', paymentMethod);
        formData.append('action', 'topup');
        
        // Send request
        fetch('/api/transaction-processor.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        })
        .then(response => response.json())
        .then(data => {
            // Refresh wallet data jika sukses
            if (data.status === 'success') {
                this.refreshWalletData();
                
                // Kirim notifikasi jika sistem notifikasi tersedia
                if (window.NotificationSystem) {
                    window.NotificationSystem.notifyTransactionSuccess(
                        data.transaction_id || 0,
                        'deposit',
                        data.amount || amount
                    );
                }
            }
            
            // Call callback
            if (callback && typeof callback === 'function') {
                callback(data);
            }
        })
        .catch(error => {
            console.error('Error processing top up:', error);
            if (callback && typeof callback === 'function') {
                callback({ 
                    status: 'error', 
                    message: 'Terjadi kesalahan saat memproses top up' 
                });
            }
        });
    },
    
    // Kirim perintah withdrawal
    requestWithdrawal: function(amount, bankAccount, bankName, accountName, callback) {
        // Validasi input
        amount = parseFloat(amount);
        if (isNaN(amount) || amount <= 0) {
            callback({ 
                status: 'error', 
                message: 'Jumlah penarikan tidak valid' 
            });
            return;
        }
        
        if (!bankAccount || !bankName || !accountName) {
            callback({ 
                status: 'error', 
                message: 'Data rekening tidak lengkap' 
            });
            return;
        }
        
        // Validate enough available balance
        if (amount > this.data.availableForWithdrawal) {
            callback({ 
                status: 'error', 
                message: 'Saldo tidak mencukupi untuk penarikan' 
            });
            return;
        }
        
        // Prepare data
        const formData = new FormData();
        formData.append('amount', amount);
        formData.append('bank_account', bankAccount);
        formData.append('bank_name', bankName);
        formData.append('account_name', accountName);
        formData.append('action', 'withdraw');
        
        // Send request
        fetch('/api/transaction-processor.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        })
        .then(response => response.json())
        .then(data => {
            // Refresh wallet data jika sukses
            if (data.status === 'success') {
                this.refreshWalletData();
                
                // Kirim notifikasi jika sistem notifikasi tersedia
                if (window.NotificationSystem) {
                    window.NotificationSystem.notifyTransactionSuccess(
                        data.transaction_id || 0,
                        'withdrawal',
                        data.amount || amount
                    );
                }
            }
            
            // Call callback
            if (callback && typeof callback === 'function') {
                callback(data);
            }
        })
        .catch(error => {
            console.error('Error processing withdrawal:', error);
            if (callback && typeof callback === 'function') {
                callback({ 
                    status: 'error', 
                    message: 'Terjadi kesalahan saat memproses penarikan' 
                });
            }
        });
    }
};

// Inisialisasi wallet system ketika DOM ready
document.addEventListener('DOMContentLoaded', function() {
    // Tambahkan CSS untuk animasi balance update jika belum ada
    if (!document.getElementById('wallet-styles')) {
        const style = document.createElement('style');
        style.id = 'wallet-styles';
        style.textContent = `
            .balance-updated {
                animation: balanceUpdate 1s ease;
            }
            
            @keyframes balanceUpdate {
                0% {
                    color: inherit;
                }
                50% {
                    color: #28c76f;
                }
                100% {
                    color: inherit;
                }
            }
            
            .wallet-balance {
                transition: color 0.3s ease;
            }
            
            .balance-card-2025 {
                border-radius: 12px;
                background: linear-gradient(135deg, #3a7bd5, #00d2ff);
                padding: 25px;
                color: white;
                position: relative;
                overflow: hidden;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                margin-bottom: 20px;
            }
            
            .balance-card-2025::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgcGF0dGVyblRyYW5zZm9ybT0icm90YXRlKDQ1KSI+PHJlY3QgaWQ9InBhdHRlcm4tYmciIHdpZHRoPSI0MDAiIGhlaWdodD0iNDAwIiBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDUpIj48L3JlY3Q+PGNpcmNsZSBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMSlAIiBjeD0iMjAiIGN5PSIyMCIgcj0iMSI+PC9jaXJjbGU+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCBmaWxsPSJ1cmwoI3BhdHRlcm4pIiBoZWlnaHQ9IjEwMCUiIHdpZHRoPSIxMDAlIj48L3JlY3Q+PC9zdmc+');
                opacity: 0.1;
            }
            
            .balance-title-2025 {
                font-size: 0.9rem;
                opacity: 0.8;
                margin-bottom: 5px;
            }
            
            .balance-amount-2025 {
                font-size: 2rem;
                font-weight: 700;
                margin-bottom: 15px;
            }
            
            .balance-info-2025 {
                display: flex;
                justify-content: space-between;
                font-size: 0.85rem;
                margin-top: 20px;
                padding-top: 15px;
                border-top: 1px solid rgba(255,255,255,0.2);
            }
            
            .balance-info-item-2025 {
                display: flex;
                flex-direction: column;
            }
            
            .balance-info-label-2025 {
                opacity: 0.8;
                margin-bottom: 5px;
            }
            
            .balance-info-value-2025 {
                font-weight: 600;
            }
            
            .balance-actions-2025 {
                display: flex;
                gap: 10px;
                margin-top: 15px;
            }
            
            .balance-action-btn-2025 {
                padding: 10px 15px;
                border-radius: 8px;
                font-weight: 600;
                font-size: 0.9rem;
                display: flex;
                align-items: center;
                gap: 8px;
                background: rgba(255,255,255,0.2);
                color: white;
                border: none;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            
            .balance-action-btn-2025:hover {
                background: rgba(255,255,255,0.3);
                transform: translateY(-2px);
            }
        `;
        document.head.appendChild(style);
    }
    
    // Cek apakah ada wallet balance di halaman
    const walletElements = document.querySelectorAll('.wallet-balance');
    if (walletElements.length > 0) {
        // Inisialisasi wallet system
        WalletSystem.init();
    }
});

// Expose globally
window.WalletSystem = WalletSystem;
