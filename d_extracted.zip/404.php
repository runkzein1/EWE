<?php
/**
 * 404 Error Page
 * Versi: 1.0 (15 Mei 2025)
 */

// Set page title
$page_title = "404 - Halaman Tidak Ditemukan | LelangMobil";
$is_error_page = true;

// Include header
if (file_exists('/home/lelang/public_html/includes/header.php')) {
    include('/home/lelang/public_html/includes/header.php');
} else {
    include("includes/header.php");
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <div class="error-page">
                <h1 class="display-1 fw-bold text-primary">404</h1>
                <h2 class="mb-4">Halaman Tidak Ditemukan</h2>
                <p class="lead mb-4">Maaf, halaman yang Anda cari tidak dapat ditemukan. Halaman mungkin telah dipindahkan, dihapus, atau URL yang Anda masukkan salah.</p>
                <div class="error-actions">
                    <a href="index.php" class="btn btn-primary btn-lg me-3">
                        <i class="fas fa-home me-2"></i>Kembali ke Beranda
                    </a>
                    <a href="contact.php" class="btn btn-outline-primary btn-lg">
                        <i class="fas fa-envelope me-2"></i>Hubungi Kami
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
if (file_exists('/home/lelang/public_html/includes/footer.php')) {
    include('/home/lelang/public_html/includes/footer.php');
} else {
    include("includes/footer.php");
}
?>
