<?php
/**
 * Session Handler
 * 
 * Manages user sessions and authentication.
 */

// Include config file if not already included
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/config.php';
}

// Start session if not already started
if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    // Configure session parameters
    ini_set('session.cookie_httponly', 1); // Prevent JavaScript access to session cookie
    ini_set('session.use_only_cookies', 1); // Force sessions to only use cookies
    
    if (defined('SESSION_NAME') && SESSION_NAME) {
        session_name(SESSION_NAME);
    }
    
    if (defined('SESSION_LIFETIME') && SESSION_LIFETIME) {
        ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
        session_set_cookie_params(SESSION_LIFETIME);
    }
    
    session_start();
}

/**
 * Checks if user is logged in
 * 
 * @return bool Whether the user is logged in
 */
function is_user_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Logs in a user
 * 
 * @param int $user_id The user ID
 * @param string $username The username
 * @param bool $remember Whether to remember the user
 * @return void
 */
function user_login($user_id, $username, $remember = false) {
    // Set session variables
    $_SESSION['user_id'] = $user_id;
    $_SESSION['username'] = $username;
    $_SESSION['logged_in_time'] = time();
    
    // Generate CSRF token
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    
    // Set remember cookie if requested
    if ($remember) {
        $token = bin2hex(random_bytes(32));
        $expires = time() + (86400 * 30); // 30 days
        setcookie('remember_token', $token, $expires, '/', '', true, true);
        
        // Store token in database for later verification
        // This would require a remember_tokens table in the database
        // store_remember_token($user_id, $token, date('Y-m-d H:i:s', $expires));
    }
    
    // Log the login
    log_error("User {$username} (ID: {$user_id}) logged in");
}

/**
 * Logs out a user
 * 
 * @return void
 */
function user_logout() {
    $user_id = $_SESSION['user_id'] ?? 0;
    $username = $_SESSION['username'] ?? 'Unknown';
    
    // Unset all session variables
    $_SESSION = [];
    
    // Delete the session cookie
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }
    
    // Remove remember cookie
    setcookie('remember_token', '', time() - 3600, '/', '', true, true);
    
    // Destroy the session
    session_destroy();
    
    // Log the logout
    log_error("User {$username} (ID: {$user_id}) logged out");
}

/**
 * Checks if user session has expired
 * 
 * @return bool Whether the session has expired
 */
function session_expired() {
    if (!isset($_SESSION['logged_in_time'])) {
        return true;
    }
    
    $expiry = defined('SESSION_LIFETIME') ? SESSION_LIFETIME : 86400;
    return (time() - $_SESSION['logged_in_time']) > $expiry;
}

/**
 * Refreshes the user session
 * 
 * @return void
 */
function refresh_session() {
    $_SESSION['logged_in_time'] = time();
}

/**
 * Check for remember me cookie and auto-login if valid
 * 
 * @param mysqli $db Database connection
 * @return bool Whether auto-login was successful
 */
function check_remember_cookie($db) {
    if (!isset($_COOKIE['remember_token']) || empty($_COOKIE['remember_token'])) {
        return false;
    }
    
    $token = $_COOKIE['remember_token'];
    
    // Verify token in database
    // This would require a remember_tokens table in the database
    // $user = verify_remember_token($db, $token);
    
    // If token is valid, auto-login the user
    // if ($user) {
    //     user_login($user['id'], $user['username'], true);
    //     return true;
    // }
    
    // If token is invalid, remove it
    setcookie('remember_token', '', time() - 3600, '/', '', true, true);
    return false;
}

// Check for session expiry
if (is_user_logged_in() && session_expired()) {
    user_logout();
    redirect_to(BASE_URL . 'login.php?expired=1');
}

// Refresh session if user is logged in
if (is_user_logged_in()) {
    refresh_session();
}
