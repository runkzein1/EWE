<?php
/**
 * Performance Optimizer untuk LelangMobil
 * Script ini meningkatkan performa loading halaman dengan mengoptimalkan:
 * - Caching database queries
 * - Asset loading (JS/CSS)
 * - PHP execution
 * - Output buffering
 */

// Cache directory
define('CACHE_DIR', dirname(__DIR__) . '/cache');

// Memastikan direktori cache tersedia
if (!file_exists(CACHE_DIR)) {
    mkdir(CACHE_DIR, 0755, true);
}

/**
 * Class DatabaseQueryCache
 * Mengimplementasikan caching untuk query database yang sering digunakan
 */
class DatabaseQueryCache {
    private $cache_enabled = true;
    private $cache_lifetime = 300; // 5 menit (dalam detik)
    private $cache_prefix = 'db_query_';
    
    /**
     * Mengaktifkan atau menonaktifkan cache
     */
    public function enableCache($enabled = true) {
        $this->cache_enabled = $enabled;
    }
    
    /**
     * Set cache lifetime
     */
    public function setCacheLifetime($seconds) {
        $this->cache_lifetime = max(60, $seconds); // Minimum 1 menit
    }
    
    /**
     * Mendapatkan data dari cache atau menjalankan query jika cache tidak ada
     */
    public function getOrExecute($conn, $query, $params = [], $types = '') {
        $cache_key = $this->generateCacheKey($query, $params);
        
        // Cek apakah cache aktif
        if (!$this->cache_enabled) {
            return $this->executeQuery($conn, $query, $params, $types);
        }
        
        // Coba dapatkan dari cache
        $cached_data = $this->getFromCache($cache_key);
        if ($cached_data !== false) {
            return $cached_data;
        }
        
        // Execute query jika tidak ada di cache
        $result = $this->executeQuery($conn, $query, $params, $types);
        
        // Simpan ke cache
        $this->saveToCache($cache_key, $result);
        
        return $result;
    }
    
    /**
     * Eksekusi query database (non-cached)
     */
    private function executeQuery($conn, $query, $params = [], $types = '') {
        // Safety check jika koneksi bermasalah
        if (!$conn || mysqli_connect_error()) {
            return ['error' => 'Database connection failed: ' . mysqli_connect_error()];
        }
        
        try {
            $stmt = $conn->prepare($query);
            
            if (!$stmt) {
                return ['error' => $conn->error];
            }
        } catch (Throwable $e) {
            return ['error' => 'Prepare statement error: ' . $e->getMessage()];
        }
        
        // Bind parameters jika ada
        if (!empty($params)) {
            try {
                if (empty($types)) {
                    // Generate types string otomatis
                    $types = '';
                    foreach ($params as $param) {
                        if (is_int($param)) {
                            $types .= 'i';
                        } elseif (is_double($param) || is_float($param)) {
                            $types .= 'd';
                        } elseif (is_string($param)) {
                            $types .= 's';
                        } else {
                            $types .= 'b'; // BLOB
                        }
                    }
                }
                
                // Pastikan jumlah parameter sesuai dengan jumlah placeholder di query
                $expected_params = substr_count($query, '?');
                if (count($params) != $expected_params) {
                    return ['error' => "Parameter count mismatch: expected $expected_params parameters, got " . count($params)];
                }
                
                // Pastikan tipe parameter sesuai dengan jumlah parameter
                if (strlen($types) != count($params)) {
                    // Reset otomatis jika tidak sesuai
                    $types = str_repeat('s', count($params)); // Default ke string
                }
                
                $stmt->bind_param($types, ...$params);
            } catch (Throwable $e) {
                return ['error' => 'Bind parameter error: ' . $e->getMessage()];
            }
        }
        
        // Execute dengan timeout dan safety
        $start_time = microtime(true);
        try {
            $execute_success = $stmt->execute();
            $execution_time = microtime(true) - $start_time;
            
            if (!$execute_success) {
                return ['error' => $stmt->error];
            }
            
            // Cek execution time untuk debug
            if ($execution_time > 2) { // Lebih dari 2 detik dianggap lambat
                error_log("Slow query detected: $query (execution time: {$execution_time}s)");
            }
        } catch (Throwable $e) {
            $execution_time = microtime(true) - $start_time;
            error_log("Query execution error: " . $e->getMessage() . " in query: $query");
            return ['error' => 'Query execution error: ' . $e->getMessage()];
        }
        
        // Get result untuk SELECT queries
        if (stripos(trim($query), 'SELECT') === 0) {
            $result = $stmt->get_result();
            $data = [];
            
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            
            $stmt->close();
            
            return [
                'data' => $data,
                'execution_time' => $execution_time,
                'count' => count($data),
                'timestamp' => time()
            ];
        }
        
        // Return untuk non-SELECT queries (INSERT, UPDATE, DELETE)
        $affected_rows = $stmt->affected_rows;
        $insert_id = $stmt->insert_id;
        $stmt->close();
        
        return [
            'affected_rows' => $affected_rows,
            'insert_id' => $insert_id,
            'execution_time' => $execution_time,
            'timestamp' => time()
        ];
    }
    
    /**
     * Generate cache key dari query dan params
     */
    private function generateCacheKey($query, $params) {
        // Normalize query (hapus spasi berlebih)
        $normalized_query = preg_replace('/\s+/', ' ', trim($query));
        
        // Combine query dan parameter values
        $key_parts = [$normalized_query];
        
        foreach ($params as $param) {
            $key_parts[] = (string)$param;
        }
        
        // Buat key yang unik menggunakan md5
        return $this->cache_prefix . md5(implode('|', $key_parts));
    }
    
    /**
     * Dapatkan data dari cache
     */
    private function getFromCache($key) {
        $cache_file = CACHE_DIR . '/' . $key . '.cache';
        
        if (!file_exists($cache_file)) {
            return false;
        }
        
        // Cek expired
        $mtime = filemtime($cache_file);
        if (time() - $mtime > $this->cache_lifetime) {
            // Cache expired, delete file
            @unlink($cache_file);
            return false;
        }
        
        // Read cached data
        $data = file_get_contents($cache_file);
        return unserialize($data);
    }
    
    /**
     * Simpan data ke cache
     */
    private function saveToCache($key, $data) {
        $cache_file = CACHE_DIR . '/' . $key . '.cache';
        
        try {
            file_put_contents($cache_file, serialize($data));
        } catch (Exception $e) {
            error_log("Error saving to cache: " . $e->getMessage());
        }
    }
    
    /**
     * Invalidate (hapus) cache untuk pattern tertentu
     */
    public function invalidateCache($pattern = '') {
        $pattern = empty($pattern) ? $this->cache_prefix . '*' : $this->cache_prefix . $pattern . '*';
        
        // Find matching cache files
        $matching_files = glob(CACHE_DIR . '/' . $pattern . '.cache');
        
        // Delete each file
        foreach ($matching_files as $file) {
            @unlink($file);
        }
    }
}

/**
 * Class AssetOptimizer
 * Mengoptimalkan loading asset (JS/CSS)
 */
class AssetOptimizer {
    private $css_files = [];
    private $js_files = [];
    private $async_js_files = [];
    private $defer_js_files = [];
    private $use_minified = true;
    private $combine_files = true;
    
    /**
     * Tambahkan CSS file
     */
    public function addCss($file, $media = 'all') {
        $this->css_files[] = [
            'file' => $file,
            'media' => $media
        ];
    }
    
    /**
     * Tambahkan JavaScript file
     */
    public function addJs($file, $async = false, $defer = false) {
        if ($async) {
            $this->async_js_files[] = $file;
        } elseif ($defer) {
            $this->defer_js_files[] = $file;
        } else {
            $this->js_files[] = $file;
        }
    }
    
    /**
     * Set penggunaan minified files
     */
    public function useMinified($use = true) {
        $this->use_minified = $use;
    }
    
    /**
     * Set combine files
     */
    public function combineFiles($combine = true) {
        $this->combine_files = $combine;
    }
    
    /**
     * Dapatkan optimized CSS output
     */
    public function getCssOutput() {
        $output = '';
        
        // Group by media
        $grouped_by_media = [];
        foreach ($this->css_files as $css) {
            $media = $css['media'];
            if (!isset($grouped_by_media[$media])) {
                $grouped_by_media[$media] = [];
            }
            $grouped_by_media[$media][] = $css['file'];
        }
        
        // Output each media group
        foreach ($grouped_by_media as $media => $files) {
            $css_urls = [];
            
            foreach ($files as $file) {
                $css_urls[] = $this->getOptimizedAssetUrl($file, 'css');
            }
            
            // Output HTML
            if (count($css_urls) > 0) {
                foreach ($css_urls as $url) {
                    $output .= '<link rel="stylesheet" href="' . $url . '" media="' . $media . '">' . PHP_EOL;
                }
            }
        }
        
        return $output;
    }
    
    /**
     * Dapatkan optimized JS output
     */
    public function getJsOutput() {
        $output = '';
        
        // Regular JS
        foreach ($this->js_files as $file) {
            $url = $this->getOptimizedAssetUrl($file, 'js');
            $output .= '<script src="' . $url . '"></script>' . PHP_EOL;
        }
        
        // Async JS
        foreach ($this->async_js_files as $file) {
            $url = $this->getOptimizedAssetUrl($file, 'js');
            $output .= '<script src="' . $url . '" async></script>' . PHP_EOL;
        }
        
        // Defer JS
        foreach ($this->defer_js_files as $file) {
            $url = $this->getOptimizedAssetUrl($file, 'js');
            $output .= '<script src="' . $url . '" defer></script>' . PHP_EOL;
        }
        
        return $output;
    }
    
    /**
     * Dapatkan optimized asset URL (minified or original)
     */
    private function getOptimizedAssetUrl($file, $type) {
        if (!$this->use_minified) {
            return $file;
        }
        
        // Check jika minified version tersedia
        $minified_file = $this->getMinifiedFileName($file);
        
        // Jika file minified ada, gunakan itu
        if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/' . $minified_file)) {
            return $minified_file;
        }
        
        // Return original file jika tidak ada minified version
        return $file;
    }
    
    /**
     * Dapatkan minified filename dari original filename
     */
    private function getMinifiedFileName($file) {
        $path_parts = pathinfo($file);
        
        // Jika sudah .min, return as is
        if (strpos($path_parts['filename'], '.min') !== false) {
            return $file;
        }
        
        // Tambahkan .min sebelum extension
        return $path_parts['dirname'] . '/' . $path_parts['filename'] . '.min.' . $path_parts['extension'];
    }
}

/**
 * Class OutputBuffer
 * Mengoptimalkan output buffering dan compression
 */
class OutputBuffer {
    private $buffer_started = false;
    private $use_gzip = true;
    private $cache_control_headers = true;
    
    /**
     * Start output buffering
     */
    public function start() {
        if ($this->buffer_started) {
            return;
        }
        
        // Start output buffering
        ob_start();
        $this->buffer_started = true;
        
        // Set cache control headers jika diaktifkan
        if ($this->cache_control_headers) {
            $this->setCacheControlHeaders();
        }
    }
    
    /**
     * Set cache control headers
     */
    public function setCacheControlHeaders($max_age = 3600) {
        header('Cache-Control: max-age=' . $max_age . ', must-revalidate');
    }
    
    /**
     * Set no-cache headers
     */
    public function setNoCacheHeaders() {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
    
    /**
     * Flush buffer dan akhiri output
     */
    public function end() {
        if (!$this->buffer_started) {
            return;
        }
        
        // Get current buffer content
        $content = ob_get_clean();
        $this->buffer_started = false;
        
        // Apply GZIP compression jika diaktifkan
        if ($this->use_gzip && extension_loaded('zlib') && !ini_get('zlib.output_compression') && isset($_SERVER['HTTP_ACCEPT_ENCODING']) && strpos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip') !== false) {
            header('Content-Encoding: gzip');
            $content = gzencode($content, 9);
        }
        
        // Output content
        echo $content;
    }
    
    /**
     * Aktifkan/nonaktifkan GZIP compression
     */
    public function useGzip($use = true) {
        $this->use_gzip = $use;
    }
    
    /**
     * Aktifkan/nonaktifkan cache control headers
     */
    public function useCacheControlHeaders($use = true) {
        $this->cache_control_headers = $use;
    }
}

/**
 * Class PageLoadOptimizer
 * Main class untuk mengoptimalkan loading halaman
 */
class PageLoadOptimizer {
    private $db_cache;
    private $asset_optimizer;
    private $output_buffer;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->db_cache = new DatabaseQueryCache();
        $this->asset_optimizer = new AssetOptimizer();
        $this->output_buffer = new OutputBuffer();
    }
    
    /**
     * Dapatkan database cache instance
     */
    public function getDbCache() {
        return $this->db_cache;
    }
    
    /**
     * Dapatkan asset optimizer instance
     */
    public function getAssetOptimizer() {
        return $this->asset_optimizer;
    }
    
    /**
     * Dapatkan output buffer instance
     */
    public function getOutputBuffer() {
        return $this->output_buffer;
    }
    
    /**
     * Mulai optimasi halaman
     */
    public function start() {
        // Start output buffering
        $this->output_buffer->start();
        
        // Set default settings
        $this->db_cache->enableCache(true);
        $this->asset_optimizer->useMinified(true);
    }
    
    /**
     * End optimasi halaman dan flush output
     */
    public function end() {
        $this->output_buffer->end();
    }
}

// Instansiasi global optimizer
$PageLoadOptimizer = new PageLoadOptimizer();

// Export functions untuk penggunaan mudah

/**
 * Dapatkan atau eksekusi query dengan caching
 */
function db_get_cached($conn, $query, $params = [], $types = '') {
    global $PageLoadOptimizer;
    return $PageLoadOptimizer->getDbCache()->getOrExecute($conn, $query, $params, $types);
}

/**
 * Invalidate cache untuk query tertentu
 */
function db_invalidate_cache($pattern = '') {
    global $PageLoadOptimizer;
    $PageLoadOptimizer->getDbCache()->invalidateCache($pattern);
}

/**
 * Tambahkan CSS file ke optimizer
 */
function add_css($file, $media = 'all') {
    global $PageLoadOptimizer;
    $PageLoadOptimizer->getAssetOptimizer()->addCss($file, $media);
}

/**
 * Tambahkan JS file ke optimizer
 */
function add_js($file, $async = false, $defer = false) {
    global $PageLoadOptimizer;
    $PageLoadOptimizer->getAssetOptimizer()->addJs($file, $async, $defer);
}

/**
 * Dapatkan optimized CSS output
 */
function get_optimized_css() {
    global $PageLoadOptimizer;
    return $PageLoadOptimizer->getAssetOptimizer()->getCssOutput();
}

/**
 * Dapatkan optimized JS output
 */
function get_optimized_js() {
    global $PageLoadOptimizer;
    return $PageLoadOptimizer->getAssetOptimizer()->getJsOutput();
}

/**
 * Start page optimization
 */
function start_page_optimization() {
    global $PageLoadOptimizer;
    $PageLoadOptimizer->start();
}

/**
 * End page optimization
 */
function end_page_optimization() {
    global $PageLoadOptimizer;
    $PageLoadOptimizer->end();
}

// Inisialisasi optimasi halaman
start_page_optimization();
