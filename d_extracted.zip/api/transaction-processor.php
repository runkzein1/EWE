<?php
/**
 * Transaction Processor API
 * Endpoint untuk memproses transaksi (topup, withdrawal, dll)
 */

// Start session
session_start();

// Headers
header('Content-Type: application/json');

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Anda harus login untuk melakukan transaksi',
        'redirect' => 'login.php'
    ]);
    exit;
}

// Pastikan request menggunakan metode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method'
    ]);
    exit;
}

// Pastikan action tersedia
if (!isset($_POST['action']) || empty($_POST['action'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Action is required'
    ]);
    exit;
}

// Load koneksi database
require_once '../config/database.php';

// Variabel dasar
$user_id = $_SESSION['user_id'];
$action = $_POST['action'];
$response = ['status' => 'error', 'message' => 'Unprocessed request'];

// CSRF Protection (best practice)
// Implement actual CSRF protection here in production

// Process based on action
switch ($action) {
    case 'topup':
        $response = processTopup($conn, $user_id);
        break;
    case 'withdraw':
        $response = processWithdrawal($conn, $user_id);
        break;
    case 'cancel_transaction':
        $response = cancelTransaction($conn, $user_id);
        break;
    case 'upload_payment_proof':
        $response = uploadPaymentProof($conn, $user_id);
        break;
    default:
        $response = [
            'status' => 'error',
            'message' => 'Invalid action'
        ];
}

// Output response
echo json_encode($response);
exit;

/**
 * Process topup request
 */
function processTopup($conn, $user_id) {
    // Validate required fields
    if (!isset($_POST['amount']) || empty($_POST['amount']) || !isset($_POST['payment_method']) || empty($_POST['payment_method'])) {
        return [
            'status' => 'error',
            'message' => 'Amount and payment method are required'
        ];
    }

    // Sanitize input
    $amount = filter_var(
        preg_replace('/[^0-9]/', '', $_POST['amount']), 
        FILTER_SANITIZE_NUMBER_INT
    );
    $payment_method = filter_var($_POST['payment_method'], FILTER_SANITIZE_STRING);
    
    // Validate amount
    if ($amount <= 0) {
        return [
            'status' => 'error',
            'message' => 'Invalid amount'
        ];
    }
    
    try {
        // Start transaction
        $conn->begin_transaction();
        
        // Generate reference number
        $reference = 'TOP' . time() . rand(1000, 9999);
        
        // Insert transaction
        $insert_sql = "INSERT INTO transactions (user_id, type, amount, status, payment_method, reference_number, created_at) 
                      VALUES (?, 'deposit', ?, 'pending', ?, ?, NOW())";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param('idss', $user_id, $amount, $payment_method, $reference);
        $insert_stmt->execute();
        
        // Get transaction ID
        $transaction_id = $conn->insert_id;
        
        // Commit transaction
        $conn->commit();
        
        // Generate payment instructions
        $payment_instructions = generatePaymentInstructions($payment_method, $amount, $reference);
        
        return [
            'status' => 'success',
            'message' => 'Top up request has been created',
            'transaction_id' => $transaction_id,
            'reference' => $reference,
            'amount' => $amount,
            'payment_method' => $payment_method,
            'payment_instructions' => $payment_instructions,
            'redirect' => 'upload-payment.php?id=' . $transaction_id
        ];
        
    } catch (Exception $e) {
        // Rollback jika ada error
        if ($conn->ping()) {
            $conn->rollback();
        }
        
        error_log("Error in processTopup: " . $e->getMessage());
        
        return [
            'status' => 'error',
            'message' => 'Terjadi kesalahan saat memproses top up'
        ];
    }
}

/**
 * Process withdrawal request
 */
function processWithdrawal($conn, $user_id) {
    // Validate required fields
    if (!isset($_POST['amount']) || empty($_POST['amount']) || 
        !isset($_POST['bank_account']) || empty($_POST['bank_account']) || 
        !isset($_POST['bank_name']) || empty($_POST['bank_name']) || 
        !isset($_POST['account_name']) || empty($_POST['account_name'])) {
        
        return [
            'status' => 'error',
            'message' => 'Amount and bank information are required'
        ];
    }

    // Sanitize input
    $amount = filter_var(
        preg_replace('/[^0-9]/', '', $_POST['amount']), 
        FILTER_SANITIZE_NUMBER_INT
    );
    $bank_account = filter_var($_POST['bank_account'], FILTER_SANITIZE_STRING);
    $bank_name = filter_var($_POST['bank_name'], FILTER_SANITIZE_STRING);
    $account_name = filter_var($_POST['account_name'], FILTER_SANITIZE_STRING);
    
    // Validate amount
    if ($amount <= 0) {
        return [
            'status' => 'error',
            'message' => 'Invalid amount'
        ];
    }
    
    try {
        // Check available balance
        $wallet_sql = "SELECT balance FROM wallets WHERE user_id = ?";
        $wallet_stmt = $conn->prepare($wallet_sql);
        $wallet_stmt->bind_param('i', $user_id);
        $wallet_stmt->execute();
        $wallet_result = $wallet_stmt->get_result();
        
        if (!$wallet_result || $wallet_result->num_rows == 0) {
            return [
                'status' => 'error',
                'message' => 'Wallet not found'
            ];
        }
        
        $wallet = $wallet_result->fetch_assoc();
        
        // Check hold amount for active bids
        $hold_amount_sql = "SELECT COALESCE(SUM(b.bid_amount), 0) as total 
                          FROM bids b 
                          JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                          WHERE (b.user_id = ? OR b.bidder_id = ?) 
                          AND v.auction_end > NOW() 
                          AND v.status = 'active' 
                          AND b.bid_amount = v.current_bid";
        
        $hold_amount_stmt = $conn->prepare($hold_amount_sql);
        $hold_amount_stmt->bind_param('ii', $user_id, $user_id);
        $hold_amount_stmt->execute();
        $hold_amount_result = $hold_amount_stmt->get_result();
        $hold_amount_data = $hold_amount_result->fetch_assoc();
        $hold_amount = $hold_amount_data['total'] ?? 0;
        
        // Calculate available balance
        $available_balance = $wallet['balance'] - $hold_amount;
        
        if ($amount > $available_balance) {
            return [
                'status' => 'error',
                'message' => 'Insufficient balance'
            ];
        }
        
        // Start transaction
        $conn->begin_transaction();
        
        // Generate reference number
        $reference = 'WDR' . time() . rand(1000, 9999);
        
        // Insert transaction
        $insert_sql = "INSERT INTO transactions (user_id, type, amount, status, payment_method, reference_number, notes, created_at) 
                     VALUES (?, 'withdrawal', ?, 'pending', 'bank_transfer', ?, ?, NOW())";
        $notes = "Bank: $bank_name, Account: $bank_account, Name: $account_name";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param('idss', $user_id, $amount, $reference, $notes);
        $insert_stmt->execute();
        
        // Get transaction ID
        $transaction_id = $conn->insert_id;
        
        // Deduct from wallet (immediately for withdrawals)
        $update_wallet_sql = "UPDATE wallets SET balance = balance - ?, last_update = NOW() WHERE user_id = ?";
        $update_wallet_stmt = $conn->prepare($update_wallet_sql);
        $update_wallet_stmt->bind_param('di', $amount, $user_id);
        $update_wallet_stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        return [
            'status' => 'success',
            'message' => 'Withdrawal request has been created and will be processed by admin',
            'transaction_id' => $transaction_id,
            'reference' => $reference,
            'amount' => $amount
        ];
        
    } catch (Exception $e) {
        // Rollback jika ada error
        if ($conn->ping()) {
            $conn->rollback();
        }
        
        error_log("Error in processWithdrawal: " . $e->getMessage());
        
        return [
            'status' => 'error',
            'message' => 'Terjadi kesalahan saat memproses penarikan'
        ];
    }
}

/**
 * Cancel transaction
 */
function cancelTransaction($conn, $user_id) {
    // Validate required fields
    if (!isset($_POST['transaction_id']) || empty($_POST['transaction_id'])) {
        return [
            'status' => 'error',
            'message' => 'Transaction ID is required'
        ];
    }

    // Sanitize input
    $transaction_id = filter_var($_POST['transaction_id'], FILTER_SANITIZE_NUMBER_INT);
    
    try {
        // Check if transaction exists and belongs to user
        $transaction_sql = "SELECT * FROM transactions WHERE transaction_id = ? AND user_id = ?";
        $transaction_stmt = $conn->prepare($transaction_sql);
        $transaction_stmt->bind_param('ii', $transaction_id, $user_id);
        $transaction_stmt->execute();
        $transaction_result = $transaction_stmt->get_result();
        
        if (!$transaction_result || $transaction_result->num_rows == 0) {
            return [
                'status' => 'error',
                'message' => 'Transaction not found'
            ];
        }
        
        $transaction = $transaction_result->fetch_assoc();
        
        // Check if transaction is still pending
        if ($transaction['status'] !== 'pending') {
            return [
                'status' => 'error',
                'message' => 'Only pending transactions can be cancelled'
            ];
        }
        
        // Start transaction
        $conn->begin_transaction();
        
        // Update transaction status
        $update_sql = "UPDATE transactions SET status = 'cancelled', updated_at = NOW() WHERE transaction_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param('i', $transaction_id);
        $update_stmt->execute();
        
        // If transaction is withdrawal, return amount to wallet
        if ($transaction['type'] === 'withdrawal') {
            $update_wallet_sql = "UPDATE wallets SET balance = balance + ?, last_update = NOW() WHERE user_id = ?";
            $update_wallet_stmt = $conn->prepare($update_wallet_sql);
            $update_wallet_stmt->bind_param('di', $transaction['amount'], $user_id);
            $update_wallet_stmt->execute();
        }
        
        // Commit transaction
        $conn->commit();
        
        return [
            'status' => 'success',
            'message' => 'Transaction has been cancelled',
            'transaction_id' => $transaction_id
        ];
        
    } catch (Exception $e) {
        // Rollback jika ada error
        if ($conn->ping()) {
            $conn->rollback();
        }
        
        error_log("Error in cancelTransaction: " . $e->getMessage());
        
        return [
            'status' => 'error',
            'message' => 'Terjadi kesalahan saat membatalkan transaksi'
        ];
    }
}

/**
 * Upload payment proof
 */
function uploadPaymentProof($conn, $user_id) {
    // Validate required fields
    if (!isset($_POST['transaction_id']) || empty($_POST['transaction_id']) || !isset($_FILES['payment_proof'])) {
        return [
            'status' => 'error',
            'message' => 'Transaction ID and payment proof are required'
        ];
    }

    // Sanitize input
    $transaction_id = filter_var($_POST['transaction_id'], FILTER_SANITIZE_NUMBER_INT);
    
    try {
        // Check if transaction exists and belongs to user
        $transaction_sql = "SELECT * FROM transactions WHERE transaction_id = ? AND user_id = ?";
        $transaction_stmt = $conn->prepare($transaction_sql);
        $transaction_stmt->bind_param('ii', $transaction_id, $user_id);
        $transaction_stmt->execute();
        $transaction_result = $transaction_stmt->get_result();
        
        if (!$transaction_result || $transaction_result->num_rows == 0) {
            return [
                'status' => 'error',
                'message' => 'Transaction not found'
            ];
        }
        
        $transaction = $transaction_result->fetch_assoc();
        
        // Check if transaction is still pending
        if ($transaction['status'] !== 'pending') {
            return [
                'status' => 'error',
                'message' => 'Only pending transactions can be updated with payment proof'
            ];
        }
        
        // Check file upload
        if ($_FILES['payment_proof']['error'] !== UPLOAD_ERR_OK) {
            return [
                'status' => 'error',
                'message' => 'File upload failed'
            ];
        }
        
        // Validate file type
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
        $file_type = $_FILES['payment_proof']['type'];
        
        if (!in_array($file_type, $allowed_types)) {
            return [
                'status' => 'error',
                'message' => 'Invalid file type. Only JPG, PNG, and PDF are allowed'
            ];
        }
        
        // Validate file size (max 5MB)
        $file_size = $_FILES['payment_proof']['size'];
        if ($file_size > 5 * 1024 * 1024) {
            return [
                'status' => 'error',
                'message' => 'File size is too large. Maximum size is 5MB'
            ];
        }
        
        // Create upload directory if not exists
        $upload_dir = '../uploads/payment_proofs/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        // Generate unique filename
        $file_extension = pathinfo($_FILES['payment_proof']['name'], PATHINFO_EXTENSION);
        $new_filename = 'payment_' . $transaction_id . '_' . time() . '.' . $file_extension;
        $upload_path = $upload_dir . $new_filename;
        
        // Move uploaded file
        if (!move_uploaded_file($_FILES['payment_proof']['tmp_name'], $upload_path)) {
            return [
                'status' => 'error',
                'message' => 'Failed to upload file'
            ];
        }
        
        // Start transaction
        $conn->begin_transaction();
        
        // Update transaction status and payment proof
        $update_sql = "UPDATE transactions SET status = 'verification', payment_proof = ?, updated_at = NOW() WHERE transaction_id = ?";
        $payment_proof_path = 'uploads/payment_proofs/' . $new_filename;
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param('si', $payment_proof_path, $transaction_id);
        $update_stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        return [
            'status' => 'success',
            'message' => 'Payment proof has been uploaded and will be verified by admin',
            'transaction_id' => $transaction_id,
            'payment_proof' => $payment_proof_path
        ];
        
    } catch (Exception $e) {
        // Rollback jika ada error
        if ($conn->ping()) {
            $conn->rollback();
        }
        
        error_log("Error in uploadPaymentProof: " . $e->getMessage());
        
        return [
            'status' => 'error',
            'message' => 'Terjadi kesalahan saat mengupload bukti pembayaran'
        ];
    }
}

/**
 * Generate payment instructions
 */
function generatePaymentInstructions($payment_method, $amount, $reference) {
    $instructions = [];
    
    // Format amount
    $formatted_amount = number_format($amount, 0, ',', '.');
    
    switch ($payment_method) {
        case 'bank_transfer':
            $instructions = [
                'bank_name' => 'Bank BCA',
                'account_number' => '1234567890',
                'account_name' => 'PT LelangMobil Indonesia',
                'amount' => $formatted_amount,
                'reference' => $reference,
                'steps' => [
                    'Transfer ke rekening di atas dengan jumlah tepat sesuai nominal',
                    'Simpan bukti transfer',
                    'Upload bukti transfer di halaman upload bukti pembayaran',
                    'Admin akan verifikasi pembayaran Anda dalam 1x24 jam'
                ]
            ];
            break;
        case 'virtual_account':
            $instructions = [
                'bank_name' => 'Bank Mandiri',
                'virtual_account' => '8800' . str_pad($_SESSION['user_id'], 10, '0', STR_PAD_LEFT),
                'amount' => $formatted_amount,
                'reference' => $reference,
                'steps' => [
                    'Transfer ke virtual account di atas dengan jumlah tepat sesuai nominal',
                    'Saldo akan otomatis bertambah setelah pembayaran berhasil',
                    'Tidak perlu upload bukti transfer untuk pembayaran via virtual account'
                ]
            ];
            break;
        case 'e_wallet':
            $instructions = [
                'wallet_name' => 'Gopay',
                'phone' => '081234567890',
                'amount' => $formatted_amount,
                'reference' => $reference,
                'steps' => [
                    'Transfer ke nomor Gopay di atas dengan jumlah tepat sesuai nominal',
                    'Simpan bukti transfer',
                    'Upload bukti transfer di halaman upload bukti pembayaran',
                    'Admin akan verifikasi pembayaran Anda dalam 1x24 jam'
                ]
            ];
            break;
        default:
            $instructions = [
                'message' => 'Metode pembayaran tidak tersedia'
            ];
    }
    
    return $instructions;
}
