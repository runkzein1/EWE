<?php
/**
 * Two-Factor Authentication (2FA) Implementation for LelangMobil
 * Version: 1.0 (14 Mei 2025)
 *
 * This file manages the 2FA functionality for the LelangMobil platform
 * utilizing time-based one-time passwords (TOTP).
 */

// Include PHPGangsta GoogleAuthenticator library if not already included
if (!class_exists('PHPGangsta_GoogleAuthenticator')) {
    require_once __DIR__ . '/../vendor/PHPGangsta/GoogleAuthenticator.php';
}

/**
 * Generate a new secret key for 2FA setup
 * 
 * @return string Secret key for TOTP
 */
function generate2FASecret() {
    $authenticator = new PHPGangsta_GoogleAuthenticator();
    return $authenticator->createSecret();
}

/**
 * Generate the QR code URL for Google Authenticator
 * 
 * @param string $username User's username
 * @param string $secret Secret key for TOTP
 * @param string $issuer Name of the issuer (site name)
 * @return string URL for QR code
 */
function getQRCodeUrl($username, $secret, $issuer = 'LelangMobil') {
    $authenticator = new PHPGangsta_GoogleAuthenticator();
    return $authenticator->getQRCodeGoogleUrl($issuer . ':' . $username, $secret, $issuer);
}

/**
 * Verify the TOTP code entered by the user
 * 
 * @param string $secret User's secret key
 * @param string $code Code entered by the user
 * @return bool True if the code is valid, false otherwise
 */
function verify2FACode($secret, $code) {
    $authenticator = new PHPGangsta_GoogleAuthenticator();
    return $authenticator->verifyCode($secret, $code, 2); // 2 = 2*30sec clock tolerance
}

/**
 * Generate backup codes for user
 * 
 * @param int $count Number of backup codes to generate
 * @return array Array of backup codes
 */
function generateBackupCodes($count = 10) {
    $backupCodes = [];
    for ($i = 0; $i < $count; $i++) {
        $backupCodes[] = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 10));
    }
    return $backupCodes;
}

/**
 * Store backup codes in the database
 * 
 * @param int $userId User ID
 * @param array $codes Array of backup codes
 * @return bool True on success, false on failure
 */
function storeBackupCodes($userId, $codes) {
    global $conn;
    
    // First, delete any existing backup codes for this user
    $sql = "DELETE FROM two_factor_backup_codes WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    
    // Insert new backup codes
    $sql = "INSERT INTO two_factor_backup_codes (user_id, backup_code, is_used) VALUES (?, ?, 0)";
    $stmt = $conn->prepare($sql);
    
    foreach ($codes as $code) {
        $stmt->bind_param("is", $userId, $code);
        if (!$stmt->execute()) {
            return false;
        }
    }
    
    return true;
}

/**
 * Verify backup code
 * 
 * @param int $userId User ID
 * @param string $code Backup code to verify
 * @return bool True if the code is valid, false otherwise
 */
function verifyBackupCode($userId, $code) {
    global $conn;
    
    $sql = "SELECT backup_code_id FROM two_factor_backup_codes 
            WHERE user_id = ? AND backup_code = ? AND is_used = 0";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $userId, $code);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $backupCodeId = $row['backup_code_id'];
        
        // Mark the code as used
        $updateSql = "UPDATE two_factor_backup_codes SET is_used = 1, used_at = NOW() WHERE backup_code_id = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("i", $backupCodeId);
        $updateStmt->execute();
        
        return true;
    }
    
    return false;
}

/**
 * Enable 2FA for a user
 * 
 * @param int $userId User ID
 * @param string $secret Secret key for TOTP
 * @return bool True on success, false on failure
 */
function enable2FA($userId, $secret) {
    global $conn;
    
    // Check if 2FA is already enabled
    $sql = "SELECT two_factor_secret FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        if (!empty($row['two_factor_secret'])) {
            return false; // 2FA already enabled
        }
    }
    
    // Generate backup codes
    $backupCodes = generateBackupCodes();
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update user with 2FA secret
        $sql = "UPDATE users SET 
                    two_factor_secret = ?,
                    two_factor_enabled = 1,
                    two_factor_enabled_at = NOW()
                WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $secret, $userId);
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to update user with 2FA secret");
        }
        
        // Store backup codes
        if (!storeBackupCodes($userId, $backupCodes)) {
            throw new Exception("Failed to store backup codes");
        }
        
        // Log the event
        logSecurityEvent('two_factor_enabled', "User enabled two-factor authentication", $userId, $_SERVER['REMOTE_ADDR']);
        
        // Commit transaction
        $conn->commit();
        
        return [
            'success' => true,
            'backup_codes' => $backupCodes
        ];
    } catch (Exception $e) {
        $conn->rollback();
        error_log("2FA Enable Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Disable 2FA for a user
 * 
 * @param int $userId User ID
 * @return bool True on success, false on failure
 */
function disable2FA($userId) {
    global $conn;
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update user to disable 2FA
        $sql = "UPDATE users SET 
                    two_factor_secret = NULL,
                    two_factor_enabled = 0,
                    two_factor_enabled_at = NULL
                WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to disable 2FA for user");
        }
        
        // Delete backup codes
        $sql = "DELETE FROM two_factor_backup_codes WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to delete backup codes");
        }
        
        // Log the event
        logSecurityEvent('two_factor_disabled', "User disabled two-factor authentication", $userId, $_SERVER['REMOTE_ADDR']);
        
        // Commit transaction
        $conn->commit();
        
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        error_log("2FA Disable Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Check if 2FA is enabled for a user
 * 
 * @param int $userId User ID
 * @return bool True if 2FA is enabled, false otherwise
 */
function is2FAEnabled($userId) {
    global $conn;
    
    $sql = "SELECT two_factor_enabled FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row['two_factor_enabled'] == 1;
    }
    
    return false;
}

/**
 * Get the 2FA secret for a user
 * 
 * @param int $userId User ID
 * @return string|null The 2FA secret or null if not found
 */
function get2FASecret($userId) {
    global $conn;
    
    $sql = "SELECT two_factor_secret FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row['two_factor_secret'];
    }
    
    return null;
}

/**
 * Get unused backup codes for a user
 * 
 * @param int $userId User ID
 * @return array Array of unused backup codes
 */
function getUnusedBackupCodes($userId) {
    global $conn;
    
    $codes = [];
    
    $sql = "SELECT backup_code FROM two_factor_backup_codes 
            WHERE user_id = ? AND is_used = 0";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $codes[] = $row['backup_code'];
    }
    
    return $codes;
}

/**
 * Regenerate backup codes for a user
 * 
 * @param int $userId User ID
 * @return array|bool New backup codes on success, false on failure
 */
function regenerateBackupCodes($userId) {
    $newCodes = generateBackupCodes();
    
    if (storeBackupCodes($userId, $newCodes)) {
        return $newCodes;
    }
    
    return false;
}

/**
 * Create required database tables for 2FA if they don't exist
 */
function create2FATables() {
    global $conn;
    
    $sql = "
    CREATE TABLE IF NOT EXISTS `two_factor_backup_codes` (
      `backup_code_id` INT AUTO_INCREMENT PRIMARY KEY,
      `user_id` INT NOT NULL,
      `backup_code` VARCHAR(20) NOT NULL,
      `is_used` TINYINT(1) DEFAULT 0,
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      `used_at` DATETIME NULL DEFAULT NULL,
      KEY `idx_two_factor_user` (`user_id`),
      KEY `idx_two_factor_code` (`backup_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";
    
    if (!$conn->query($sql)) {
        error_log("Failed to create 2FA tables: " . $conn->error);
        return false;
    }
    
    // Add 2FA columns to users table if they don't exist
    $alterSql = "
    ALTER TABLE `users` 
    ADD COLUMN IF NOT EXISTS `two_factor_secret` VARCHAR(100) NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS `two_factor_enabled` TINYINT(1) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS `two_factor_enabled_at` DATETIME NULL DEFAULT NULL;
    ";
    
    if (!$conn->query($alterSql)) {
        error_log("Failed to alter users table for 2FA: " . $conn->error);
        return false;
    }
    
    return true;
}

/**
 * Require 2FA for a specific user group
 * 
 * @param string $role Role to require 2FA for (e.g., 'admin', 'staff', 'all')
 * @param bool $required Whether to require 2FA
 * @return bool Success status
 */
function require2FAForRole($role, $required = true) {
    global $conn;
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Update system settings
        $sql = "UPDATE system_settings 
                SET setting_value = ?, updated_at = NOW() 
                WHERE setting_key = ?";
        $stmt = $conn->prepare($sql);
        $value = $required ? '1' : '0';
        $settingKey = 'require_2fa_' . strtolower($role);
        $stmt->bind_param("ss", $value, $settingKey);
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to update system settings");
        }
        
        // Log the event
        logSecurityEvent(
            'two_factor_requirement_changed', 
            "2FA requirement for '{$role}' users set to " . ($required ? 'required' : 'optional'),
            $_SESSION['user_id'] ?? null,
            $_SERVER['REMOTE_ADDR']
        );
        
        // Commit transaction
        $conn->commit();
        
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        error_log("2FA Requirement Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Check if 2FA is required for a user based on their role
 * 
 * @param int $userId User ID
 * @return bool True if 2FA is required
 */
function is2FARequired($userId) {
    global $conn;
    
    // Get user role
    $sql = "SELECT is_admin FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $role = $row['is_admin'] ? 'admin' : 'user';
        
        // Check general setting first
        $sql = "SELECT setting_value FROM system_settings WHERE setting_key = 'enable_2fa'";
        $result = $conn->query($sql);
        
        if ($row = $result->fetch_assoc()) {
            if ($row['setting_value'] == '0') {
                return false; // 2FA is globally disabled
            }
        }
        
        // Check role-specific setting
        $sql = "SELECT setting_value FROM system_settings WHERE setting_key = ?";
        $stmt = $conn->prepare($sql);
        $settingKey = 'require_2fa_' . $role;
        $stmt->bind_param("s", $settingKey);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            return $row['setting_value'] == '1';
        }
        
        // Check all users setting
        $sql = "SELECT setting_value FROM system_settings WHERE setting_key = 'require_2fa_all'";
        $result = $conn->query($sql);
        
        if ($row = $result->fetch_assoc()) {
            return $row['setting_value'] == '1';
        }
    }
    
    return false; // Default to not required
}

// Create 2FA tables if they don't exist (called when this file is included)
create2FATables();
