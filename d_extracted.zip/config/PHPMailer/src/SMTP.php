<?php
namespace PHPMailer\PHPMailer;

class SMTP {
    // Dummy class
}
