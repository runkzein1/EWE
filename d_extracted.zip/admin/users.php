<?php
// Set page title
$page_title = "Manajemen Pengguna";

// Include header
include 'includes/header.php';

// Process actions (verify, admin, delete)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $user_id = intval($_GET['id']);
    
    // Validate user exists
    $check_sql = "SELECT * FROM users WHERE user_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $user = $check_result->fetch_assoc();
        
        switch ($action) {
            case 'verify':
                // Verify user
                $verify_sql = "UPDATE users SET is_verified = 1 WHERE user_id = ?";
                $verify_stmt = $conn->prepare($verify_sql);
                $verify_stmt->bind_param("i", $user_id);
                
                if ($verify_stmt->execute()) {
                    $success = "Pengguna berhasil diverifikasi.";
                } else {
                    $error = "Gagal memverifikasi pengguna.";
                }
                break;
                
            case 'make_admin':
                // Make user admin
                $admin_sql = "UPDATE users SET is_admin = 1 WHERE user_id = ?";
                $admin_stmt = $conn->prepare($admin_sql);
                $admin_stmt->bind_param("i", $user_id);
                
                if ($admin_stmt->execute()) {
                    $success = "Pengguna berhasil dijadikan admin.";
                } else {
                    $error = "Gagal menjadikan pengguna sebagai admin.";
                }
                break;
                
            case 'remove_admin':
                // Remove admin privileges
                $remove_admin_sql = "UPDATE users SET is_admin = 0 WHERE user_id = ?";
                $remove_admin_stmt = $conn->prepare($remove_admin_sql);
                $remove_admin_stmt->bind_param("i", $user_id);
                
                if ($remove_admin_stmt->execute()) {
                    $success = "Hak akses admin berhasil dicabut.";
                } else {
                    $error = "Gagal mencabut hak akses admin.";
                }
                break;
                
            case 'delete':
                // Delete user
                $delete_sql = "DELETE FROM users WHERE user_id = ?";
                $delete_stmt = $conn->prepare($delete_sql);
                $delete_stmt->bind_param("i", $user_id);
                
                if ($delete_stmt->execute()) {
                    $success = "Pengguna berhasil dihapus.";
                } else {
                    $error = "Gagal menghapus pengguna.";
                }
                break;
        }
    } else {
        $error = "Pengguna tidak ditemukan.";
    }
}

// Pagination
$items_per_page = 15;
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($current_page - 1) * $items_per_page;

// Filtering
$where_clause = "1=1"; // Default to show all users
$params = [];
$param_types = "";

// Search
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = "%" . clean_input($_GET['search']) . "%";
    $where_clause .= " AND (username LIKE ? OR email LIKE ? OR full_name LIKE ?)";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $param_types .= "sss";
}

// Filter verified/unverified
if (isset($_GET['verified']) && $_GET['verified'] !== '') {
    $verified = intval($_GET['verified']);
    $where_clause .= " AND is_verified = ?";
    $params[] = $verified;
    $param_types .= "i";
}

// Filter admin/regular
if (isset($_GET['admin']) && $_GET['admin'] !== '') {
    $admin = intval($_GET['admin']);
    $where_clause .= " AND is_admin = ?";
    $params[] = $admin;
    $param_types .= "i";
}

// Count total users matching criteria
$count_sql = "SELECT COUNT(*) as total FROM users WHERE $where_clause";
$count_stmt = $conn->prepare($count_sql);
if (!empty($params)) {
    $count_stmt->bind_param($param_types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$count_row = $count_result->fetch_assoc();
$total_items = $count_row['total'];
$total_pages = ceil($total_items / $items_per_page);

// Get users with pagination
$users_sql = "SELECT * FROM users WHERE $where_clause ORDER BY created_at DESC LIMIT ?, ?";
$params[] = $offset;
$params[] = $items_per_page;
$param_types .= "ii";

$users_stmt = $conn->prepare($users_sql);
$users_stmt->bind_param($param_types, ...$params);
$users_stmt->execute();
$users_result = $users_stmt->get_result();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Manajemen Pengguna</h1>
    <a href="user-form.php" class="btn btn-primary">
        <i class="fa fa-plus"></i> Tambah Pengguna
    </a>
</div>

<?php if(isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<?php if(isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<!-- Filter Form -->
<div class="de-box mb-4">
    <form action="" method="get" class="row g-3">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control" placeholder="Cari username, email, atau nama..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        </div>
        <div class="col-md-2">
            <select name="verified" class="form-control form-select">
                <option value="">Status Verifikasi</option>
                <option value="1" <?php echo (isset($_GET['verified']) && $_GET['verified'] == '1') ? 'selected' : ''; ?>>Terverifikasi</option>
                <option value="0" <?php echo (isset($_GET['verified']) && $_GET['verified'] == '0') ? 'selected' : ''; ?>>Belum Verifikasi</option>
            </select>
        </div>
        <div class="col-md-2">
            <select name="admin" class="form-control form-select">
                <option value="">Jenis Pengguna</option>
                <option value="1" <?php echo (isset($_GET['admin']) && $_GET['admin'] == '1') ? 'selected' : ''; ?>>Admin</option>
                <option value="0" <?php echo (isset($_GET['admin']) && $_GET['admin'] == '0') ? 'selected' : ''; ?>>Regular</option>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">Filter</button>
        </div>
        <div class="col-md-2">
            <a href="users.php" class="btn btn-secondary w-100">Reset</a>
        </div>
    </form>
</div>

<!-- Users Table -->
<div class="de-box">
    <div class="table-responsive">
        <table class="table table-hover admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Nama Lengkap</th>
                    <th>Saldo</th>
                    <th>Status</th>
                    <th>Tanggal Daftar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($users_result->num_rows > 0): ?>
                    <?php while ($user = $users_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $user['user_id']; ?></td>
                            <td>
                                <?php echo $user['username']; ?>
                                <?php if ($user['is_admin']): ?>
                                    <span class="badge bg-primary ms-1">Admin</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $user['email']; ?></td>
                            <td><?php echo $user['full_name']; ?></td>
                            <td><?php echo format_currency($user['balance']); ?></td>
                            <td>
                                <?php if ($user['is_verified']): ?>
                                    <span class="badge bg-success">Terverifikasi</span>
                                <?php else: ?>
                                    <span class="badge bg-warning">Belum Verifikasi</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('d M Y', strtotime($user['created_at'])); ?></td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton<?php echo $user['user_id']; ?>" data-mdb-toggle="dropdown" aria-expanded="false">
                                        Aksi
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton<?php echo $user['user_id']; ?>">
                                        <li><a class="dropdown-item" href="user-form.php?id=<?php echo $user['user_id']; ?>"><i class="fa fa-edit"></i> Edit</a></li>
                                        <li><a class="dropdown-item" href="user-detail.php?id=<?php echo $user['user_id']; ?>"><i class="fa fa-eye"></i> Lihat Detail</a></li>
                                        
                                        <?php if (!$user['is_verified']): ?>
                                            <li><a class="dropdown-item" href="users.php?action=verify&id=<?php echo $user['user_id']; ?>" onclick="return confirm('Yakin ingin memverifikasi pengguna ini?')"><i class="fa fa-check"></i> Verifikasi</a></li>
                                        <?php endif; ?>
                                        
                                        <?php if (!$user['is_admin']): ?>
                                            <li><a class="dropdown-item" href="users.php?action=make_admin&id=<?php echo $user['user_id']; ?>" onclick="return confirm('Yakin ingin menjadikan pengguna ini sebagai admin?')"><i class="fa fa-key"></i> Jadikan Admin</a></li>
                                        <?php else: ?>
                                            <li><a class="dropdown-item" href="users.php?action=remove_admin&id=<?php echo $user['user_id']; ?>" onclick="return confirm('Yakin ingin mencabut hak akses admin dari pengguna ini?')"><i class="fa fa-ban"></i> Cabut Admin</a></li>
                                        <?php endif; ?>
                                        
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item text-danger" href="users.php?action=delete&id=<?php echo $user['user_id']; ?>" onclick="return confirm('PERINGATAN: Tindakan ini akan menghapus semua data terkait pengguna ini. Yakin ingin menghapus?')"><i class="fa fa-trash"></i> Hapus</a></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center">Tidak ada pengguna yang ditemukan</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center mt-4">
                <?php if ($current_page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo "users.php?" . http_build_query(array_merge($_GET, ['page' => $current_page - 1])); ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                        <a class="page-link" href="<?php echo "users.php?" . http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($current_page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo "users.php?" . http_build_query(array_merge($_GET, ['page' => $current_page + 1])); ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
