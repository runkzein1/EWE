<?php
/**
 * Database Connection
 *
 * Establishes connection to the MySQL database using configuration parameters.
 */

// Include config file if not already included
if (!defined('DB_HOST') && !defined('DB_SERVER')) {
    require_once __DIR__ . '/config.php';
}

// Establish database connection
try {
    // Support both DB_HOST/DB_USER/DB_PASS naming and DB_SERVER/DB_USERNAME/DB_PASSWORD naming
    $host = defined('DB_SERVER') ? DB_SERVER : DB_HOST;
    $user = defined('DB_USERNAME') ? DB_USERNAME : DB_USER;
    $pass = defined('DB_PASSWORD') ? DB_PASSWORD : DB_PASS;
    $dbname = DB_NAME;

    $db = mysqli_connect($host, $user, $pass, $dbname);

    // Check connection
    if (mysqli_connect_errno()) {
        throw new Exception("Database Connection Failed: " . mysqli_connect_error());
    }

    // Set character set
    mysqli_set_charset($db, 'utf8mb4');

    // Create alias for $conn to maintain compatibility with both naming conventions
    $conn = $db;

} catch (Exception $e) {
    // Log error
    if (defined('LOG_ERRORS') && LOG_ERRORS) {
        error_log("Database Connection Error: " . $e->getMessage());
    }

    // Display error message (only in development mode)
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        die("Database Connection Error: " . $e->getMessage());
    } else {
        die("A database error occurred. Please try again later or contact the administrator.");
    }
}
