<?php
// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';
require_once 'config/mailer.php';

// Start session
session_start();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';

// Process forgot password form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = clean_input($_POST['email']);
    
    // Check if email exists
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Generate reset token
        $token = generate_token();
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Update user with reset token
        $update_sql = "UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE user_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ssi", $token, $expiry, $user['user_id']);
        
        if ($update_stmt->execute()) {
            // Send password reset email
            send_reset_password_email($conn, $email, $token, $user['user_id']);
            
            $success = "Tautan reset password telah dikirim ke alamat email Anda. Silakan periksa email Anda (termasuk folder spam) dan klik tautan reset password.";
        } else {
            $error = "Terjadi kesalahan. Silakan coba lagi.";
        }
    } else {
        // Don't reveal if email exists or not for security
        $success = "Jika alamat email Anda terdaftar di sistem kami, tautan reset password akan dikirimkan ke alamat tersebut.";
    }
}

// Page title for header
$page_title = "Lupa Password - LelangMobil";
?>

<?php include 'includes/header.php'; ?>

<div id="top"></div>
<section id="subheader" class="jarallax text-light">
    <img src="images/background/2.jpg" class="jarallax-img" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="subtitle wow fadeInUp mb-3">LelangMobil</div>
            </div>
            <div class="col-lg-6">
                <h2 class="wow fadeInUp mb20" data-wow-delay=".2s">Lupa Password</h2>
            </div>
        </div>
    </div>
</section>

<section aria-label="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="de-box">
                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if(!empty($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <form class="form-border" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="field-set">
                                    <label>Alamat Email:</label>
                                    <input type="email" name="email" class="form-control" required>
                                    <small class="text-muted">Masukkan alamat email yang terdaftar pada akun Anda.</small>
                                </div>
                            </div>
                            
                            <div class="col-lg-12">
                                <div class="spacer-20"></div>
                                <button class="btn-main" type="submit">Reset Password</button>
                                <div class="spacer-20"></div>
                                <p>Ingat password Anda? <a href="login.php">Masuk di sini</a></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
