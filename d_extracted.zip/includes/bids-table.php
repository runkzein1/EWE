<?php
/**
 * Modern Bids Table
 * LelangMobil Web App - Versi 2025
 */

// Pastikan bids_result (query result) sudah diambil datanya sebelum memanggil komponen ini
if (!isset($bids_result)) {
    die("Error: Bids data not loaded.");
}
?>

<div class="modern-card fade-in">
    <div class="modern-card-header">
        <h2 class="modern-card-title"><i class="fa fa-gavel"></i> Riwayat Bid Saya</h2>
        
        <div class="bids-filters">
            <select id="filterBidStatus" class="modern-form-control form-select-sm">
                <option value="">Semua Status</option>
                <option value="active">Aktif</option>
                <option value="won">Menang</option>
                <option value="outbid">Dikalahkan</option>
                <option value="ended">Selesai</option>
            </select>
        </div>
    </div>
    
    <div class="modern-card-body p-0">
        <?php if (!$bids_result || $bids_result->num_rows == 0): ?>
            <div class="p-4 text-center">
                <div class="empty-state">
                    <i class="fa fa-gavel fa-3x text-muted mb-3"></i>
                    <h5>Belum Ada Bid</h5>
                    <p class="text-muted">Belum ada riwayat bid yang Anda lakukan.</p>
                    <a href="auctions.php" class="modern-button modern-button-primary mt-3">
                        <i class="fa fa-search me-2"></i>Lihat Lelang Aktif
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="modern-table" id="bidsTable">
                    <thead>
                        <tr>
                            <th width="15%">Foto</th>
                            <th width="30%">Kendaraan</th>
                            <th width="15%">Jumlah Bid</th>
                            <th width="15%">Waktu Bid</th>
                            <th width="15%">Status</th>
                            <th width="10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Reset pointer ke awal data
                        if ($bids_result && $bids_result->num_rows > 0) {
                            $bids_result->data_seek(0);
                        }
                        
                        while ($bid = $bids_result->fetch_assoc()): 
                            // Set status badge
                            $now = new DateTime();
                            // Pastikan menggunakan auction_end yang merupakan nama kolom di database produksi
                            // Tetapi di query kita sudah mengaliaskan auction_end AS end_date
                            $end_date = new DateTime($bid['end_date']);
                            $is_ended = $end_date < $now;
                            
                            $status = 'active';
                            $status_label = 'Aktif';
                            $status_badge_color = 'info';
                            $status_icon = 'fa-clock';
                            
                            if ($is_ended) {
                                $status = 'ended';
                                $status_label = 'Selesai';
                                $status_badge_color = 'secondary';
                                $status_icon = 'fa-check';
                            }
                            
                            // Check if this is the current highest bid
                            $is_highest = false;
                            if (isset($bid['current_bid']) && isset($bid['bid_amount']) && $bid['bid_amount'] >= $bid['current_bid']) {
                                $is_highest = true;
                                
                                if ($is_ended) {
                                    $status = 'won';
                                    $status_label = 'Menang';
                                    $status_badge_color = 'success';
                                    $status_icon = 'fa-trophy';
                                }
                            } elseif (!$is_highest) {
                                $status = 'outbid';
                                $status_label = 'Dikalahkan';
                                $status_badge_color = 'warning';
                                $status_icon = 'fa-arrow-down';
                            }
                        ?>
                        <tr data-status="<?php echo $status; ?>">
                            <td>
                                <img src="images/no-image.svg" 
                                     alt="<?php echo htmlspecialchars($bid['make'] . ' ' . $bid['model']); ?>" 
                                     class="img-fluid rounded"
                                     style="max-height: 60px; object-fit: cover;">
                            </td>
                            <td>
                                <div class="d-flex flex-column">
                                    <strong><?php echo htmlspecialchars($bid['make'] . ' ' . $bid['model']); ?></strong>
                                    <small class="text-muted">ID Kendaraan: #<?php echo $bid['vehicle_id']; ?></small>
                                </div>
                            </td>
                            <td>
                                <span class="fw-bold">Rp<?php echo number_format($bid['bid_amount'], 0, ',', '.'); ?></span>
                                <?php if ($is_highest && !$is_ended): ?>
                                <span class="modern-badge modern-badge-success d-block mt-1"><i class="fa fa-check"></i> Tertinggi</span>
                                <?php elseif (!$is_highest): ?>
                                <span class="d-block text-muted mt-1"><small>Bid Tertinggi: Rp<?php echo number_format($bid['current_bid'], 0, ',', '.'); ?></small></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo date('d M Y', strtotime($bid['bid_time'])); ?>
                                <div class="text-muted"><small><?php echo date('H:i', strtotime($bid['bid_time'])); ?></small></div>
                            </td>
                            <td>
                                <span class="modern-badge modern-badge-<?php echo $status_badge_color; ?>">
                                    <i class="fa <?php echo $status_icon; ?>"></i> <?php echo $status_label; ?>
                                </span>
                            </td>
                            <td>
                                <a href="vehicle.php?id=<?php echo $bid['vehicle_id']; ?>" class="btn btn-sm btn-primary">
                                    <i class="fa fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    
    <?php if (isset($show_pagination) && $show_pagination): ?>
    <div class="modern-card-footer d-flex justify-content-between align-items-center">
        <div class="text-muted small">
            Menampilkan <?php echo $bids_result->num_rows; ?> bid
        </div>
        
        <?php if (isset($total_pages) && $total_pages > 1): ?>
        <nav>
            <ul class="pagination pagination-sm mb-0">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $i == $current_page ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Bids filter functionality
    const statusFilter = document.getElementById('filterBidStatus');
    const bidsTable = document.getElementById('bidsTable');
    
    if (statusFilter && bidsTable) {
        statusFilter.addEventListener('change', function() {
            const statusValue = this.value;
            const rows = bidsTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const rowStatus = row.getAttribute('data-status');
                
                if (!statusValue || rowStatus === statusValue) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});
</script>
