<?php
/**
 * Configuration Loader
 * LelangMobil Web App - Versi 2025
 * 
 * This file handles loading all required configuration files in the correct order
 */

// Prevent direct access
if (!defined('SECURE_ACCESS') && basename($_SERVER['SCRIPT_FILENAME']) == basename(__FILE__)) {
    die('Direct access to this file is not allowed.');
}

// Define SECURE_ACCESS to allow inclusion in other files
if (!defined('SECURE_ACCESS')) {
    define('SECURE_ACCESS', true);
}

// Start output buffering to prevent "headers already sent" errors
if (ob_get_level() == 0) {
    ob_start();
}

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to users
ini_set('log_errors', 1);     // Log errors instead

// Load path configuration first
require_once __DIR__ . '/path_config.php';

// Define a function to load configuration files with error handling
function load_config_file($file, $required = true) {
    $full_path = CONFIG_PATH . $file;
    $alt_path = __DIR__ . '/' . $file;
    
    if (file_exists($full_path)) {
        require_once $full_path;
        return true;
    } elseif (file_exists($alt_path)) {
        require_once $alt_path;
        return true;
    } elseif ($required) {
        // For required files, create a basic version if it doesn't exist
        create_default_config_file($file);
        
        // Try loading again
        if (file_exists($alt_path)) {
            require_once $alt_path;
            return true;
        }
        
        // If still not found, log error
        error_log("Required configuration file not found: $file");
        return false;
    }
    
    return false;
}

// Function to create default configuration files if they don't exist
function create_default_config_file($file) {
    $file_path = __DIR__ . '/' . $file;
    
    switch ($file) {
        case 'config.php':
            $content = '<?php
/**
 * Main Configuration File
 * LelangMobil Web App - Versi 2025
 */

// Debug mode (set to false in production)
define(\'DEBUG_MODE\', false);

// Error logging
define(\'LOG_ERRORS\', true);
define(\'ERROR_LOG_FILE\', LOGS_PATH . \'error.log\');

// Site information
define(\'SITE_NAME\', \'LelangMobil\');
define(\'SITE_DESCRIPTION\', \'Platform Lelang Mobil Online Terpercaya\');
define(\'SITE_EMAIL\', \'info@lelangmobil.com\');

// Database configuration
if (!defined(\'DB_HOST\')) define(\'DB_HOST\', \'localhost\');
if (!defined(\'DB_USER\')) define(\'DB_USER\', \'lelang_rz\');
if (!defined(\'DB_PASS\')) define(\'DB_PASS\', \'Arunk@123\');
if (!defined(\'DB_NAME\')) define(\'DB_NAME\', \'lelang_rz\');

// Session configuration
define(\'SESSION_NAME\', \'lelang_session\');
define(\'SESSION_LIFETIME\', 86400); // 24 hours in seconds

// Security settings
define(\'HASH_COST\', 12); // For password_hash
define(\'TOKEN_EXPIRY\', 3600); // 1 hour in seconds

// File upload settings
define(\'MAX_UPLOAD_SIZE\', 5242880); // 5MB in bytes
define(\'ALLOWED_EXTENSIONS\', \'jpg,jpeg,png,gif,pdf\');

// Default pagination
define(\'DEFAULT_ITEMS_PER_PAGE\', 10);

// Time zone
date_default_timezone_set(\'Asia/Jakarta\');
?>';
            break;
            
        case 'database.php':
            $content = '<?php
/**
 * Database Connection
 * LelangMobil Web App - Versi 2025
 */

// Database connection constants
// Use constants from config.php if defined, otherwise use defaults
if (!defined(\'DB_HOST\')) define(\'DB_HOST\', \'localhost\');
if (!defined(\'DB_USER\')) define(\'DB_USER\', \'lelang_rz\');
if (!defined(\'DB_PASS\')) define(\'DB_PASS\', \'Arunk@123\');
if (!defined(\'DB_NAME\')) define(\'DB_NAME\', \'lelang_rz\');

// For backward compatibility
if (!defined(\'DB_SERVER\')) define(\'DB_SERVER\', DB_HOST);
if (!defined(\'DB_USERNAME\')) define(\'DB_USERNAME\', DB_USER);
if (!defined(\'DB_PASSWORD\')) define(\'DB_PASSWORD\', DB_PASS);

// Attempt to connect to MySQL database with error handling
try {
    // Create connection
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }
    
    // Set character set
    $conn->set_charset("utf8");
    
} catch (Exception $e) {
    // Log the error
    error_log("Database connection error: " . $e->getMessage());
    
    // For production, show a user-friendly message
    echo \'<div style="padding: 20px; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 5px; margin: 20px;">
            <h3>Database Connection Error</h3>
            <p>Sorry, we are experiencing technical difficulties. Please try again later.</p>
         </div>\';
    exit;
}
?>';
            break;
            
        case 'functions.php':
            $content = '<?php
/**
 * Common Functions
 * LelangMobil Web App - Versi 2025
 */

// Clean input data
if (!function_exists(\'clean_input\')) {
    function clean_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data, ENT_QUOTES, \'UTF-8\');
        return $data;
    }
}

// Generate secure random token
if (!function_exists(\'generate_token\')) {
    function generate_token($length = 32) {
        try {
            return bin2hex(random_bytes($length / 2));
        } catch (Exception $e) {
            // Fallback if random_bytes fails
            return md5(uniqid(mt_rand(), true) . time());
        }
    }
}

// Format currency
if (!function_exists(\'format_currency\')) {
    function format_currency($amount) {
        return \'Rp \' . number_format($amount, 0, \',\', \'.\');
    }
}

// Check if user is logged in
if (!function_exists(\'is_logged_in\')) {
    function is_logged_in() {
        return isset($_SESSION[\'user_id\']) && !empty($_SESSION[\'user_id\']);
    }
}

// Check if user is admin
if (!function_exists(\'is_admin\')) {
    function is_admin() {
        return isset($_SESSION[\'is_admin\']) && $_SESSION[\'is_admin\'] == 1;
    }
}

// Redirect to URL
if (!function_exists(\'redirect_to\')) {
    function redirect_to($url) {
        header("Location: $url");
        exit;
    }
}

// Get time remaining in human-readable format
if (!function_exists(\'get_time_remaining\')) {
    function get_time_remaining($end_date) {
        $now = new DateTime();
        $end = new DateTime($end_date);
        $interval = $now->diff($end);
        
        if ($interval->invert) {
            return "Berakhir";
        }
        
        if ($interval->days > 0) {
            return $interval->format("%d hari %h jam");
        } elseif ($interval->h > 0) {
            return $interval->format("%h jam %i menit");
        } else {
            return $interval->format("%i menit %s detik");
        }
    }
}
?>';
            break;
            
        case 'session_helper.php':
            $content = '<?php
/**
 * Session Helper
 * LelangMobil Web App - Versi 2025
 */

// Start session securely
function ensure_session_started() {
    if (session_status() == PHP_SESSION_NONE && !headers_sent()) {
        // Configure session for better security
        ini_set(\'session.cookie_httponly\', 1);
        ini_set(\'session.use_only_cookies\', 1);
        
        if (defined(\'SESSION_NAME\') && SESSION_NAME) {
            session_name(SESSION_NAME);
        }
        
        if (defined(\'SESSION_LIFETIME\') && SESSION_LIFETIME) {
            ini_set(\'session.gc_maxlifetime\', SESSION_LIFETIME);
            session_set_cookie_params(SESSION_LIFETIME);
        }
        
        return session_start();
    }
    
    return (session_status() == PHP_SESSION_ACTIVE);
}

// Generate CSRF token
function generate_secure_csrf_token() {
    ensure_session_started();
    
    try {
        $token = bin2hex(random_bytes(32));
    } catch (Exception $e) {
        $token = md5(uniqid(mt_rand(), true) . session_id() . time());
    }
    
    $_SESSION[\'csrf_token\'] = $token;
    $_SESSION[\'csrf_token_time\'] = time();
    
    return $token;
}

// Verify CSRF token
function verify_secure_csrf_token($token) {
    ensure_session_started();
    
    if (empty($token) || empty($_SESSION[\'csrf_token\'])) {
        return false;
    }
    
    return hash_equals($_SESSION[\'csrf_token\'], $token);
}

// Generate CSRF token input field
function csrf_token_input_field() {
    $token = isset($_SESSION[\'csrf_token\']) ? $_SESSION[\'csrf_token\'] : generate_secure_csrf_token();
    return \'<input type="hidden" name="csrf_token" value="\' . htmlspecialchars($token) . \'">\';
}
?>';
            break;
    }
    
    // Create the file if content is defined
    if (isset($content)) {
        file_put_contents($file_path, $content);
        return true;
    }
    
    return false;
}

// Load configuration files in the correct order
load_config_file('config.php', true);
load_config_file('database.php', true);
load_config_file('functions.php', true);
load_config_file('session_helper.php', true);
load_config_file('security.php', false);

// Start session securely
if (function_exists('ensure_session_started')) {
    ensure_session_started();
} else {
    // Fallback if ensure_session_started is not defined
    if (session_status() == PHP_SESSION_NONE && !headers_sent()) {
        session_start();
    }
}

// Set error log file if defined
if (defined('ERROR_LOG_FILE') && defined('LOG_ERRORS') && LOG_ERRORS) {
    ini_set('error_log', ERROR_LOG_FILE);
}
