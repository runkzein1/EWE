<?php
/**
 * Main Configuration File
 * LelangMobil Web App - Versi 2025
 */

// Debug mode (set to false in production)
define('DEBUG_MODE', false);

// Error logging
define('LOG_ERRORS', true);
define('ERROR_LOG_FILE', dirname(__DIR__) . '/logs/error.log');

// Base URL (adjust for your environment)
// Detect if we're in production environment
if (strpos($_SERVER['DOCUMENT_ROOT'], '/home/lelang/public_html') !== false) {
    define('BASE_URL', '/');
    define('ROOT_PATH', '/home/lelang/public_html/');
} else {
    define('BASE_URL', '/');
    define('ROOT_PATH', dirname(__DIR__) . '/');
}

// Site information
define('SITE_NAME', 'LelangMobil');
define('SITE_DESCRIPTION', 'Platform Lelang Mobil Online Terpercaya');
define('SITE_EMAIL', 'info@lelangmobil.com');

// Database configuration
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'lelang_rz');
if (!defined('DB_PASS')) define('DB_PASS', 'Arunk@123');
if (!defined('DB_NAME')) define('DB_NAME', 'lelang_rz');

// Session configuration
define('SESSION_NAME', 'lelang_session');
define('SESSION_LIFETIME', 86400); // 24 hours in seconds

// Security settings
define('HASH_COST', 12); // For password_hash
define('TOKEN_EXPIRY', 3600); // 1 hour in seconds

// File upload settings
define('MAX_UPLOAD_SIZE', 5242880); // 5MB in bytes
define('ALLOWED_EXTENSIONS', 'jpg,jpeg,png,gif,pdf');
define('UPLOAD_DIR', dirname(__DIR__) . '/uploads/');

// Default pagination
define('DEFAULT_ITEMS_PER_PAGE', 10);

// Time zone
date_default_timezone_set('Asia/Jakarta');

// Load environment-specific configuration if exists
$env_config = __DIR__ . '/config.env.php';
if (file_exists($env_config)) {
    require_once $env_config;
}
?>