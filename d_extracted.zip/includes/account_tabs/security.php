<?php
// Ensure this file is included by account.php and has access to $db, $user_id, $csrf_token

if (!defined('ROOT_PATH')) {
    die("Direct access not allowed."); // Basic security check
}
?>

<h4>Security & Password</h4>
<hr>
<form action="<?php echo htmlspecialchars(BASE_URL . 'account.php?tab=security'); ?>" method="POST">
    <input type="hidden" name="action" value="change_password">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

    <div class="mb-3">
        <label for="current_password" class="form-label">Current Password</label>
        <input type="password" class="form-control" id="current_password" name="current_password" required>
    </div>

    <div class="mb-3">
        <label for="new_password" class="form-label">New Password</label>
        <input type="password" class="form-control" id="new_password" name="new_password" required minlength="8">
        <small class="form-text text-muted">Must be at least 8 characters long.</small>
    </div>

    <div class="mb-3">
        <label for="confirm_password" class="form-label">Confirm New Password</label>
        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="8">
    </div>

    <button type="submit" class="btn btn-primary">Change Password</button>
</form>
