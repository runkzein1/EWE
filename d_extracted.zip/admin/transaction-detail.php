<?php
// Set page title
$page_title = "Detail Transaksi";

// Include header
include 'includes/header.php';

// Check if transaction ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: transactions.php");
    exit;
}

$transaction_id = intval($_GET['id']);

// Get transaction information with related user data
$transaction_sql = "SELECT t.*, 
                   u.username, u.email, u.balance,
                   a.username as admin_username
                   FROM transactions t 
                   JOIN users u ON t.user_id = u.user_id 
                   LEFT JOIN users a ON t.admin_id = a.user_id
                   WHERE t.transaction_id = ?";
$transaction_stmt = $conn->prepare($transaction_sql);
$transaction_stmt->bind_param("i", $transaction_id);
$transaction_stmt->execute();
$transaction_result = $transaction_stmt->get_result();

if ($transaction_result->num_rows == 0) {
    header("Location: transactions.php");
    exit;
}

$transaction = $transaction_result->fetch_assoc();

// Get reference data if it exists (bid or vehicle)
$reference_data = null;
if ($transaction['reference_id']) {
    // Check if reference is to a bid
    if (in_array($transaction['type'], ['bid_hold', 'bid_release'])) {
        $bid_sql = "SELECT b.*, v.title as vehicle_title, v.vehicle_id, u.username as bidder_username
                   FROM bids b 
                   JOIN vehicles v ON b.vehicle_id = v.vehicle_id
                   JOIN users u ON b.bidder_id = u.user_id
                   WHERE b.bid_id = ?";
        $bid_stmt = $conn->prepare($bid_sql);
        $bid_stmt->bind_param("i", $transaction['reference_id']);
        $bid_stmt->execute();
        $bid_result = $bid_stmt->get_result();
        
        if ($bid_result->num_rows > 0) {
            $reference_data = $bid_result->fetch_assoc();
            $reference_data['type'] = 'bid';
        }
    }
    // Check if reference is to a vehicle (winning payment)
    else if ($transaction['type'] == 'winning_payment') {
        $vehicle_sql = "SELECT v.*, u.username as seller_username
                       FROM vehicles v
                       JOIN users u ON v.seller_id = u.user_id
                       WHERE v.vehicle_id = ?";
        $vehicle_stmt = $conn->prepare($vehicle_sql);
        $vehicle_stmt->bind_param("i", $transaction['reference_id']);
        $vehicle_stmt->execute();
        $vehicle_result = $vehicle_stmt->get_result();
        
        if ($vehicle_result->num_rows > 0) {
            $reference_data = $vehicle_result->fetch_assoc();
            $reference_data['type'] = 'vehicle';
        }
    }
}

// Get related transactions (e.g., bid_hold and corresponding bid_release)
$related_transactions = [];
if ($transaction['reference_id']) {
    $related_sql = "SELECT t.*, u.username 
                   FROM transactions t
                   JOIN users u ON t.user_id = u.user_id
                   WHERE t.reference_id = ? AND t.transaction_id != ?
                   ORDER BY t.created_at DESC";
    $related_stmt = $conn->prepare($related_sql);
    $related_stmt->bind_param("ii", $transaction['reference_id'], $transaction_id);
    $related_stmt->execute();
    $related_result = $related_stmt->get_result();
    
    if ($related_result->num_rows > 0) {
        while ($row = $related_result->fetch_assoc()) {
            $related_transactions[] = $row;
        }
    }
}

// Handle actions if any
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Only allow actions on pending transactions
    if ($transaction['status'] == 'pending') {
        $conn->begin_transaction();
        
        try {
            if (isset($_POST['approve_transaction'])) {
                // Update transaction status
                $update_sql = "UPDATE transactions SET status = 'completed', admin_id = ?, updated_at = NOW() WHERE transaction_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("ii", $admin_id, $transaction_id);
                $update_stmt->execute();
                
                // If it's a deposit, update user balance
                if ($transaction['type'] == 'deposit') {
                    $update_balance_sql = "UPDATE users SET balance = balance + ? WHERE user_id = ?";
                    $update_balance_stmt = $conn->prepare($update_balance_sql);
                    $update_balance_stmt->bind_param("di", $transaction['amount'], $transaction['user_id']);
                    $update_balance_stmt->execute();
                }
                
                $conn->commit();
                $success = "Transaksi berhasil disetujui.";
                
                // Refresh transaction data
                $transaction_stmt->execute();
                $transaction_result = $transaction_stmt->get_result();
                $transaction = $transaction_result->fetch_assoc();
            } 
            else if (isset($_POST['reject_transaction'])) {
                $rejection_reason = clean_input($_POST['rejection_reason']);
                
                // Update transaction status
                $update_sql = "UPDATE transactions SET status = 'rejected', admin_id = ?, updated_at = NOW(), notes = CONCAT(notes, ' | Alasan penolakan: ', ?) WHERE transaction_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("isi", $admin_id, $rejection_reason, $transaction_id);
                $update_stmt->execute();
                
                $conn->commit();
                $success = "Transaksi berhasil ditolak.";
                
                // Refresh transaction data
                $transaction_stmt->execute();
                $transaction_result = $transaction_stmt->get_result();
                $transaction = $transaction_result->fetch_assoc();
            }
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Terjadi kesalahan: " . $e->getMessage();
        }
    } else {
        $error = "Hanya transaksi dengan status 'pending' yang dapat diproses.";
    }
}

$page_title = "Detail Transaksi #" . $transaction_id;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><?php echo $page_title; ?></h1>
    <div>
        <a href="transactions.php" class="btn btn-secondary">
            <i class="fa fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<?php if(isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<?php if(isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6">
        <!-- Transaction Information -->
        <div class="de-box mb-4">
            <h5 class="mb-3">Informasi Transaksi</h5>
            <table class="table">
                <tr>
                    <th width="35%">ID Transaksi</th>
                    <td><?php echo $transaction['transaction_id']; ?></td>
                </tr>
                <tr>
                    <th>Jumlah</th>
                    <td>
                        <?php 
                        $amount_class = in_array($transaction['type'], ['deposit', 'bid_release']) ? 'text-success' : 'text-danger';
                        $prefix = in_array($transaction['type'], ['deposit', 'bid_release']) ? '+' : '-';
                        echo '<span class="'.$amount_class.'">'.$prefix.' '.format_currency($transaction['amount']).'</span>'; 
                        ?>
                    </td>
                </tr>
                <tr>
                    <th>Tipe</th>
                    <td>
                        <?php 
                        switch ($transaction['type']) {
                            case 'deposit':
                                echo '<span class="badge bg-success">Top-up Saldo</span>';
                                break;
                            case 'withdrawal':
                                echo '<span class="badge bg-warning">Penarikan</span>';
                                break;
                            case 'bid_hold':
                                echo '<span class="badge bg-info">Dana Tertahan (Bid)</span>';
                                break;
                            case 'bid_release':
                                echo '<span class="badge bg-secondary">Pengembalian Dana (Outbid)</span>';
                                break;
                            case 'winning_payment':
                                echo '<span class="badge bg-primary">Pembayaran Lelang (Menang)</span>';
                                break;
                            default:
                                echo $transaction['type'];
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <?php 
                        switch ($transaction['status']) {
                            case 'pending':
                                echo '<span class="badge bg-warning">Menunggu Persetujuan</span>';
                                break;
                            case 'completed':
                                echo '<span class="badge bg-success">Selesai</span>';
                                break;
                            case 'rejected':
                                echo '<span class="badge bg-danger">Ditolak</span>';
                                break;
                            default:
                                echo $transaction['status'];
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th>Waktu Dibuat</th>
                    <td><?php echo date('d M Y H:i:s', strtotime($transaction['created_at'])); ?></td>
                </tr>
                <tr>
                    <th>Terakhir Diubah</th>
                    <td><?php echo date('d M Y H:i:s', strtotime($transaction['updated_at'])); ?></td>
                </tr>
                <tr>
                    <th>Catatan</th>
                    <td><?php echo $transaction['notes'] ? nl2br($transaction['notes']) : 'Tidak ada catatan'; ?></td>
                </tr>
                <tr>
                    <th>Admin Pemroses</th>
                    <td><?php echo $transaction['admin_username'] ? $transaction['admin_username'] : 'Belum diproses'; ?></td>
                </tr>
                <?php if ($transaction['payment_proof']) {
                // Get file extension
                $file_ext = pathinfo($transaction['payment_proof'], PATHINFO_EXTENSION);
                echo '<tr>';
                echo '<th>Bukti Pembayaran</th>';
                echo '<td class="payment-proof-container">';
                if (in_array(strtolower($file_ext), ['jpg', 'jpeg', 'png', 'gif'])) {
                    echo '<div class="proof-preview">';
                    echo '<a href="../uploads/' . $transaction['payment_proof'] . '" target="_blank" class="proof-link">';
                    echo '<img src="../uploads/' . $transaction['payment_proof'] . '" alt="Bukti Pembayaran" class="img-fluid rounded">';
                    echo '</a>';
                    echo '<div class="proof-actions">';
                    echo '<a href="../uploads/' . $transaction['payment_proof'] . '" download class="btn btn-sm btn-outline-primary me-2"><i class="fa fa-download"></i> Download</a>';
                    echo '<a href="../uploads/' . $transaction['payment_proof'] . '" target="_blank" class="btn btn-sm btn-outline-info"><i class="fa fa-search-plus"></i> Lihat Full</a>';
                    echo '</div>';
                    echo '</div>';
                } else {
                    echo '<div class="proof-file">';
                    echo '<i class="fa fa-file-' . ($file_ext == 'pdf' ? 'pdf' : 'alt') . ' fa-2x text-primary"></i>';
                    echo '<div class="proof-file-info">';
                    echo '<span>' . $transaction['payment_proof'] . '</span>';
                    echo '<div class="proof-actions">';
                    echo '<a href="../uploads/' . $transaction['payment_proof'] . '" target="_blank" class="btn btn-sm btn-outline-primary me-2"><i class="fa fa-eye"></i> Lihat</a>';
                    echo '<a href="../uploads/' . $transaction['payment_proof'] . '" download class="btn btn-sm btn-outline-info"><i class="fa fa-download"></i> Download</a>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
                echo '</td>';
                echo '</tr>';
            }?>
                <tr>
                    <th>Payment ID</th>
                    <td><?php echo $transaction['payment_id'] ? $transaction['payment_id'] : 'Tidak ada'; ?></td>
                </tr>
                <tr>
                    <th>Bank/Metode Pembayaran</th>
                    <td><?php echo $transaction['payment_method'] ? $transaction['payment_method'] : 'Tidak ada'; ?></td>
                </tr>
                <tr>
                    <th>Bukti Transfer</th>
                    <td>
                        <?php if ($transaction['payment_proof']): ?>
                            <a href="../uploads/payment_proof/<?php echo $transaction['payment_proof']; ?>" target="_blank" class="btn btn-sm btn-primary">
                                <i class="fa fa-image"></i> Lihat Bukti Transfer
                            </a>
                        <?php else: ?>
                            Tidak ada bukti transfer
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
            
            <?php if ($transaction['status'] == 'pending'): ?>
                <div class="border-top pt-3 mt-3">
                    <div class="row">
                        <div class="col-md-6">
                            <form method="post" class="d-inline">
                                <button type="submit" name="approve_transaction" class="btn btn-success w-100" onclick="return confirm('Yakin ingin menyetujui transaksi ini?')">
                                    <i class="fa fa-check"></i> Setujui Transaksi
                                </button>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <button type="button" class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#rejectModal">
                                <i class="fa fa-times"></i> Tolak Transaksi
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if ($reference_data && $reference_data['type'] == 'bid'): ?>
        <!-- Referenced Bid Information (if applicable) -->
        <div class="de-box mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Informasi Bid Terkait</h5>
                <a href="bid-detail.php?id=<?php echo $reference_data['bid_id']; ?>" class="btn btn-sm btn-primary">
                    <i class="fa fa-eye"></i> Lihat Detail Bid
                </a>
            </div>
            <table class="table">
                <tr>
                    <th width="35%">ID Bid</th>
                    <td><?php echo $reference_data['bid_id']; ?></td>
                </tr>
                <tr>
                    <th>Kendaraan</th>
                    <td>
                        <a href="../vehicle.php?id=<?php echo $reference_data['vehicle_id']; ?>" target="_blank">
                            <?php echo $reference_data['vehicle_title']; ?>
                        </a>
                    </td>
                </tr>
                <tr>
                    <th>Penawar</th>
                    <td><?php echo $reference_data['bidder_username']; ?></td>
                </tr>
                <tr>
                    <th>Jumlah Bid</th>
                    <td><?php echo format_currency($reference_data['bid_amount']); ?></td>
                </tr>
                <tr>
                    <th>Waktu Bid</th>
                    <td><?php echo date('d M Y H:i:s', strtotime($reference_data['bid_time'])); ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <?php echo $reference_data['is_winning'] ? '<span class="badge bg-success">Tertinggi</span>' : '<span class="badge bg-secondary">Outbid</span>'; ?>
                    </td>
                </tr>
            </table>
        </div>
        <?php elseif ($reference_data && $reference_data['type'] == 'vehicle'): ?>
        <!-- Referenced Vehicle Information (if applicable) -->
        <div class="de-box mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Informasi Kendaraan Terkait</h5>
                <a href="vehicle-form.php?id=<?php echo $reference_data['vehicle_id']; ?>" class="btn btn-sm btn-primary">
                    <i class="fa fa-eye"></i> Lihat Detail Kendaraan
                </a>
            </div>
            <table class="table">
                <tr>
                    <th width="35%">ID Kendaraan</th>
                    <td><?php echo $reference_data['vehicle_id']; ?></td>
                </tr>
                <tr>
                    <th>Judul</th>
                    <td>
                        <a href="../vehicle.php?id=<?php echo $reference_data['vehicle_id']; ?>" target="_blank">
                            <?php echo $reference_data['title']; ?>
                        </a>
                    </td>
                </tr>
                <tr>
                    <th>Penjual</th>
                    <td><?php echo $reference_data['seller_username']; ?></td>
                </tr>
                <tr>
                    <th>Harga Awal</th>
                    <td><?php echo format_currency($reference_data['starting_price']); ?></td>
                </tr>
                <tr>
                    <th>Bid Tertinggi</th>
                    <td><?php echo format_currency($reference_data['current_bid']); ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <?php 
                        switch ($reference_data['status']) {
                            case 'active':
                                echo '<span class="badge bg-success">Aktif</span>';
                                break;
                            case 'ended':
                                echo '<span class="badge bg-warning">Berakhir</span>';
                                break;
                            case 'sold':
                                echo '<span class="badge bg-primary">Terjual</span>';
                                break;
                            case 'not_sold':
                                echo '<span class="badge bg-danger">Tidak Terjual</span>';
                                break;
                            default:
                                echo $reference_data['status'];
                        }
                        ?>
                    </td>
                </tr>
            </table>
        </div>
        <?php endif; ?>
        
        <!-- Related Transactions -->
        <?php if (!empty($related_transactions)): ?>
        <div class="de-box">
            <h5 class="mb-3">Transaksi Terkait</h5>
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Pengguna</th>
                            <th>Jumlah</th>
                            <th>Tipe</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($related_transactions as $rel_transaction): ?>
                            <tr>
                                <td>
                                    <a href="transaction-detail.php?id=<?php echo $rel_transaction['transaction_id']; ?>">
                                        #<?php echo $rel_transaction['transaction_id']; ?>
                                    </a>
                                </td>
                                <td><?php echo $rel_transaction['username']; ?></td>
                                <td><?php echo format_currency($rel_transaction['amount']); ?></td>
                                <td>
                                    <?php 
                                    switch ($rel_transaction['type']) {
                                        case 'deposit':
                                            echo '<span class="badge bg-success">Top-up</span>';
                                            break;
                                        case 'withdrawal':
                                            echo '<span class="badge bg-warning">Penarikan</span>';
                                            break;
                                        case 'bid_hold':
                                            echo '<span class="badge bg-info">Hold Bid</span>';
                                            break;
                                        case 'bid_release':
                                            echo '<span class="badge bg-secondary">Release Bid</span>';
                                            break;
                                        case 'winning_payment':
                                            echo '<span class="badge bg-primary">Pembayaran</span>';
                                            break;
                                        default:
                                            echo $rel_transaction['type'];
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                    switch ($rel_transaction['status']) {
                                        case 'pending':
                                            echo '<span class="badge bg-warning">Pending</span>';
                                            break;
                                        case 'completed':
                                            echo '<span class="badge bg-success">Selesai</span>';
                                            break;
                                        case 'rejected':
                                            echo '<span class="badge bg-danger">Ditolak</span>';
                                            break;
                                        default:
                                            echo $rel_transaction['status'];
                                    }
                                    ?>
                                </td>
                                <td><?php echo date('d M Y H:i', strtotime($rel_transaction['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="col-md-6">
        <!-- User Information -->
        <div class="de-box mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Informasi Pengguna</h5>
                <a href="user-detail.php?id=<?php echo $transaction['user_id']; ?>" class="btn btn-sm btn-primary">
                    <i class="fa fa-user"></i> Lihat Profil Pengguna
                </a>
            </div>
            <table class="table">
                <tr>
                    <th width="35%">ID Pengguna</th>
                    <td><?php echo $transaction['user_id']; ?></td>
                </tr>
                <tr>
                    <th>Username</th>
                    <td><?php echo $transaction['username']; ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo $transaction['email']; ?></td>
                </tr>
                <tr>
                    <th>Saldo Terkini</th>
                    <td><?php echo format_currency($transaction['balance']); ?></td>
                </tr>
            </table>
        </div>
        
        <!-- User's Transactions -->
        <div class="de-box">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Transaksi Lain Pengguna</h5>
                <a href="transactions.php?user_id=<?php echo $transaction['user_id']; ?>" class="btn btn-sm btn-primary">
                    <i class="fa fa-list"></i> Lihat Semua
                </a>
            </div>
            
            <?php
            // Get user's other transactions
            $user_transactions_sql = "SELECT * FROM transactions 
                                    WHERE user_id = ? AND transaction_id != ? 
                                    ORDER BY created_at DESC LIMIT 10";
            $user_transactions_stmt = $conn->prepare($user_transactions_sql);
            $user_transactions_stmt->bind_param("ii", $transaction['user_id'], $transaction_id);
            $user_transactions_stmt->execute();
            $user_transactions_result = $user_transactions_stmt->get_result();
            ?>
            
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tanggal</th>
                            <th>Jumlah</th>
                            <th>Tipe</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($user_transactions_result->num_rows > 0): ?>
                            <?php while ($user_transaction = $user_transactions_result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <a href="transaction-detail.php?id=<?php echo $user_transaction['transaction_id']; ?>">
                                            #<?php echo $user_transaction['transaction_id']; ?>
                                        </a>
                                    </td>
                                    <td><?php echo date('d M Y H:i', strtotime($user_transaction['created_at'])); ?></td>
                                    <td>
                                        <?php 
                                        $amount_class = in_array($user_transaction['type'], ['deposit', 'bid_release']) ? 'text-success' : 'text-danger';
                                        $prefix = in_array($user_transaction['type'], ['deposit', 'bid_release']) ? '+' : '-';
                                        echo '<span class="'.$amount_class.'">'.$prefix.' '.format_currency($user_transaction['amount']).'</span>'; 
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                        switch ($user_transaction['type']) {
                                            case 'deposit':
                                                echo '<span class="badge bg-success">Top-up</span>';
                                                break;
                                            case 'withdrawal':
                                                echo '<span class="badge bg-warning">Penarikan</span>';
                                                break;
                                            case 'bid_hold':
                                                echo '<span class="badge bg-info">Hold Bid</span>';
                                                break;
                                            case 'bid_release':
                                                echo '<span class="badge bg-secondary">Release Bid</span>';
                                                break;
                                            case 'winning_payment':
                                                echo '<span class="badge bg-primary">Pembayaran</span>';
                                                break;
                                            default:
                                                echo $user_transaction['type'];
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                        switch ($user_transaction['status']) {
                                            case 'pending':
                                                echo '<span class="badge bg-warning">Pending</span>';
                                                break;
                                            case 'completed':
                                                echo '<span class="badge bg-success">Selesai</span>';
                                                break;
                                            case 'rejected':
                                                echo '<span class="badge bg-danger">Ditolak</span>';
                                                break;
                                            default:
                                                echo $user_transaction['status'];
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">Pengguna ini tidak memiliki transaksi lain.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header">
                    <h5 class="modal-title" id="rejectModalLabel">Tolak Transaksi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="rejection_reason" class="form-label">Alasan Penolakan</label>
                        <textarea class="form-control" id="rejection_reason" name="rejection_reason" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="reject_transaction" class="btn btn-danger">Tolak Transaksi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
