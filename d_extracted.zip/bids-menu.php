<?php
// Aktifkan error reporting dan logging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data user
$user_query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "User tidak ditemukan.";
    header("Location: login.php");
    exit;
}

$user = $result->fetch_assoc();
$balance = $user['balance'] ?? 0;

// Query untuk mengambil bid aktif
$active_bids_sql = "SELECT b.*, v.title as vehicle_title, v.image as vehicle_image, v.end_time as auction_end_time, v.current_bid as current_highest 
                    FROM bids b 
                    JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                    WHERE b.user_id = ? AND v.end_time > NOW() 
                    ORDER BY b.bid_time DESC";
$stmt = $conn->prepare($active_bids_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$active_bids_result = $stmt->get_result();

// Query untuk mengambil riwayat bid
$bid_history_sql = "SELECT b.*, v.title as vehicle_title, v.image as vehicle_image, v.end_time as auction_end_time, v.current_bid as current_highest,
                    CASE 
                        WHEN v.end_time < NOW() AND v.winner_id = ? THEN 'win'
                        WHEN v.end_time < NOW() AND v.winner_id != ? THEN 'lose'
                        WHEN v.end_time > NOW() AND b.amount = v.current_bid THEN 'leading'
                        WHEN v.end_time > NOW() AND b.amount < v.current_bid THEN 'outbid'
                        ELSE 'pending'
                    END as bid_status
                    FROM bids b 
                    JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                    WHERE b.user_id = ? 
                    ORDER BY b.bid_time DESC";
$stmt = $conn->prepare($bid_history_sql);
$stmt->bind_param("iii", $user_id, $user_id, $user_id);
$stmt->execute();
$bid_history_result = $stmt->get_result();

// Ambil jumlah bid yang menang
$won_bids_sql = "SELECT COUNT(*) as won_count FROM vehicles WHERE winner_id = ? AND end_time < NOW()";
$stmt = $conn->prepare($won_bids_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$won_result = $stmt->get_result();
$won_row = $won_result->fetch_assoc();
$won_count = $won_row['won_count'] ?? 0;

// Ambil jumlah bid yang aktif
$active_count = $active_bids_result ? $active_bids_result->num_rows : 0;

// Ambil total bid yang pernah dibuat
$total_bids_sql = "SELECT COUNT(*) as total_count FROM bids WHERE user_id = ?";
$stmt = $conn->prepare($total_bids_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_result = $stmt->get_result();
$total_row = $total_result->fetch_assoc();
$total_count = $total_row['total_count'] ?? 0;

// Helper function untuk format status bid
function get_bid_status_badge($status) {
    switch ($status) {
        case 'win':
            return '<span class="badge bg-success">Menang</span>';
        case 'lose':
            return '<span class="badge bg-danger">Kalah</span>';
        case 'leading':
            return '<span class="badge bg-primary">Tertinggi</span>';
        case 'outbid':
            return '<span class="badge bg-warning">Tersaingi</span>';
        case 'pending':
            return '<span class="badge bg-secondary">Pending</span>';
        default:
            return '<span class="badge bg-secondary">' . ucfirst($status) . '</span>';
    }
}

// Helper function untuk format waktu tersisa
function get_time_remaining($end_time) {
    $now = new DateTime();
    $end = new DateTime($end_time);
    $interval = $now->diff($end);
    
    if ($interval->invert == 1) {
        return '<span class="text-danger">Berakhir</span>';
    }
    
    if ($interval->days > 0) {
        return $interval->days . ' hari ' . $interval->h . ' jam';
    } elseif ($interval->h > 0) {
        return $interval->h . ' jam ' . $interval->i . ' menit';
    } elseif ($interval->i > 0) {
        return $interval->i . ' menit ' . $interval->s . ' detik';
    } else {
        return $interval->s . ' detik';
    }
}

// Aktifkan flag untuk halaman dashboard dan tema ultra-modern
$page_title = "Bid Saya";
$is_dashboard_page = true;
$use_ultra_modern = true;
$use_premium_effects = true;
$modern_js_files = true;

// CSS tambahan untuk halaman ini
$page_specific_css = '<link href="css/bids-premium.css" rel="stylesheet" type="text/css">';

// JS tambahan untuk halaman ini
$page_specific_js = '<script src="js/bids-modern.js"></script>';

// Include header
include('includes/header.php');
?>

<div class="dashboard-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="page-title">Bid Saya</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                        <li class="breadcrumb-item"><a href="account.php">Akun Saya</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Bid Saya</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container py-5">
    <div class="row">
        <!-- Menu Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="account-menu-card">
                <div class="user-profile mb-4">
                    <div class="user-avatar">
                        <div class="avatar-text">
                            <?php echo strtoupper(substr($user['username'] ?? 'U', 0, 1)); ?>
                        </div>
                    </div>
                    <div class="user-info mt-2">
                        <h5 class="mb-1"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h5>
                        <p class="text-muted mb-0">ID: <?php echo $user['user_id']; ?></p>
                    </div>
                </div>
                
                <div class="menu-items">
                    <a href="account.php" class="menu-item">
                        <i class="fa fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="topup-menu.php" class="menu-item">
                        <i class="fa fa-wallet"></i> Top-up Saldo
                    </a>
                    <a href="withdraw-menu.php" class="menu-item">
                        <i class="fa fa-money-bill-wave"></i> Tarik Saldo
                    </a>
                    <a href="transactions-menu.php" class="menu-item">
                        <i class="fa fa-history"></i> Riwayat Transaksi
                    </a>
                    <a href="bids-menu.php" class="menu-item active">
                        <i class="fa fa-gavel"></i> Bid Saya
                    </a>
                    <a href="profile-menu.php" class="menu-item">
                        <i class="fa fa-user"></i> Profil
                    </a>
                    <a href="?logout=true" class="menu-item">
                        <i class="fa fa-sign-out-alt"></i> Keluar
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-lg-9">
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-primary">
                            <i class="fa fa-gavel"></i>
                        </div>
                        <div class="stat-content">
                            <h3 class="stat-value"><?php echo $total_count; ?></h3>
                            <p class="stat-label">Total Bid</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-success">
                            <i class="fa fa-trophy"></i>
                        </div>
                        <div class="stat-content">
                            <h3 class="stat-value"><?php echo $won_count; ?></h3>
                            <p class="stat-label">Lelang Dimenangkan</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-warning">
                            <i class="fa fa-hourglass-half"></i>
                        </div>
                        <div class="stat-content">
                            <h3 class="stat-value"><?php echo $active_count; ?></h3>
                            <p class="stat-label">Bid Aktif</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Active Bids -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fa fa-bolt me-2"></i>Bid Aktif</h5>
                        <div>
                            <button class="btn btn-sm btn-light" id="refreshActiveBidsBtn">
                                <i class="fa fa-sync-alt"></i> Refresh
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (!$active_bids_result || $active_bids_result->num_rows == 0): ?>
                        <div class="empty-state text-center py-5">
                            <div class="empty-state-icon mb-3">
                                <i class="fa fa-gavel fa-3x text-muted"></i>
                            </div>
                            <h4>Belum Ada Bid Aktif</h4>
                            <p class="text-muted">Anda belum memiliki bid aktif. Temukan mobil yang menarik dan mulai bid sekarang!</p>
                            <a href="vehicles.php" class="btn btn-primary mt-2">
                                <i class="fa fa-search me-2"></i>Jelajahi Mobil
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php while ($bid = $active_bids_result->fetch_assoc()): ?>
                                <div class="col-md-6 mb-4">
                                    <div class="active-bid-card">
                                        <div class="row g-0">
                                            <div class="col-4">
                                                <img src="<?php echo $bid['vehicle_image'] ?: 'img/vehicle-placeholder.jpg'; ?>" class="img-fluid rounded-start" alt="<?php echo htmlspecialchars($bid['vehicle_title']); ?>">
                                                <?php if ($bid['amount'] == $bid['current_highest']): ?>
                                                    <div class="bid-status leading">
                                                        <i class="fa fa-medal"></i> Tertinggi
                                                    </div>
                                                <?php else: ?>
                                                    <div class="bid-status outbid">
                                                        <i class="fa fa-arrow-down"></i> Tersaingi
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-8">
                                                <div class="card-body p-3">
                                                    <h5 class="card-title mb-1"><?php echo htmlspecialchars($bid['vehicle_title']); ?></h5>
                                                    <p class="bid-amount mb-1">
                                                        <strong>Bid Anda:</strong> Rp <?php echo number_format($bid['amount'], 0, ',', '.'); ?>
                                                    </p>
                                                    <p class="current-bid mb-1">
                                                        <strong>Tertinggi:</strong> Rp <?php echo number_format($bid['current_highest'], 0, ',', '.'); ?>
                                                    </p>
                                                    <div class="time-remaining mb-1">
                                                        <i class="fa fa-clock text-warning"></i> 
                                                        <span data-end="<?php echo $bid['auction_end_time']; ?>" class="countdown-timer">
                                                            <?php echo get_time_remaining($bid['auction_end_time']); ?>
                                                        </span>
                                                    </div>
                                                    <div class="mt-2">
                                                        <a href="vehicle-detail.php?id=<?php echo $bid['vehicle_id']; ?>" class="btn btn-sm btn-primary">
                                                            <i class="fa fa-eye me-1"></i>Lihat
                                                        </a>
                                                        <?php if ($bid['amount'] < $bid['current_highest']): ?>
                                                            <a href="vehicle-detail.php?id=<?php echo $bid['vehicle_id']; ?>#bid-section" class="btn btn-sm btn-warning">
                                                                <i class="fa fa-gavel me-1"></i>Bid Lagi
                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Bid History -->
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fa fa-history me-2"></i>Riwayat Bid</h5>
                        <div class="bid-filter">
                            <select class="form-select form-select-sm" id="bidStatusFilter">
                                <option value="">Semua Status</option>
                                <option value="win">Menang</option>
                                <option value="lose">Kalah</option>
                                <option value="leading">Tertinggi</option>
                                <option value="outbid">Tersaingi</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <?php if (!$bid_history_result || $bid_history_result->num_rows == 0): ?>
                        <div class="empty-state text-center py-5">
                            <div class="empty-state-icon mb-3">
                                <i class="fa fa-history fa-3x text-muted"></i>
                            </div>
                            <h4>Belum Ada Riwayat Bid</h4>
                            <p class="text-muted">Anda belum pernah melakukan bid apapun.</p>
                            <a href="vehicles.php" class="btn btn-primary mt-2">
                                <i class="fa fa-search me-2"></i>Jelajahi Mobil
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0" id="bidHistoryTable">
                                <thead>
                                    <tr>
                                        <th>Mobil</th>
                                        <th>Jumlah Bid</th>
                                        <th>Waktu Bid</th>
                                        <th>Bid Tertinggi</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($bid = $bid_history_result->fetch_assoc()): ?>
                                        <tr class="bid-history-row" data-status="<?php echo $bid['bid_status']; ?>">
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <img src="<?php echo $bid['vehicle_image'] ?: 'img/vehicle-placeholder.jpg'; ?>" alt="<?php echo htmlspecialchars($bid['vehicle_title']); ?>" class="bid-vehicle-thumbnail me-2">
                                                    <div class="bid-vehicle-info">
                                                        <div class="bid-vehicle-title"><?php echo htmlspecialchars($bid['vehicle_title']); ?></div>
                                                        <small class="text-muted">ID: <?php echo $bid['vehicle_id']; ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>Rp <?php echo number_format($bid['amount'], 0, ',', '.'); ?></td>
                                            <td><?php echo date('d M Y H:i', strtotime($bid['bid_time'])); ?></td>
                                            <td>Rp <?php echo number_format($bid['current_highest'], 0, ',', '.'); ?></td>
                                            <td><?php echo get_bid_status_badge($bid['bid_status']); ?></td>
                                            <td>
                                                <a href="vehicle-detail.php?id=<?php echo $bid['vehicle_id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
