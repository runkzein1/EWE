<?php
// Set page title
$page_title = "Detail Bid";

// Include header
include 'includes/header.php';

// Check if bid ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: bids.php");
    exit;
}

$bid_id = intval($_GET['id']);

// Get bid information with related vehicle and user data
$bid_sql = "SELECT b.*, 
            v.title as vehicle_title, v.description as vehicle_description, 
            v.starting_price, v.current_bid, v.auction_end, v.status as vehicle_status,
            u.username as bidder_username, u.email as bidder_email, u.balance as bidder_balance,
            (SELECT COUNT(*) FROM bids WHERE bidder_id = b.bidder_id) as total_bids_by_user,
            (SELECT COUNT(*) FROM bids WHERE vehicle_id = b.vehicle_id) as total_bids_on_vehicle
            FROM bids b 
            JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
            JOIN users u ON b.bidder_id = u.user_id 
            WHERE b.bid_id = ?";
$bid_stmt = $conn->prepare($bid_sql);
$bid_stmt->bind_param("i", $bid_id);
$bid_stmt->execute();
$bid_result = $bid_stmt->get_result();

if ($bid_result->num_rows == 0) {
    header("Location: bids.php");
    exit;
}

$bid = $bid_result->fetch_assoc();

// Get other bids on the same vehicle
$other_bids_sql = "SELECT b.*, u.username 
                  FROM bids b 
                  JOIN users u ON b.bidder_id = u.user_id 
                  WHERE b.vehicle_id = ? AND b.bid_id != ? 
                  ORDER BY b.bid_time DESC 
                  LIMIT 10";
$other_bids_stmt = $conn->prepare($other_bids_sql);
$other_bids_stmt->bind_param("ii", $bid['vehicle_id'], $bid_id);
$other_bids_stmt->execute();
$other_bids_result = $other_bids_stmt->get_result();

// Get user's other bids
$user_bids_sql = "SELECT b.*, v.title as vehicle_title 
                 FROM bids b 
                 JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                 WHERE b.bidder_id = ? AND b.bid_id != ? 
                 ORDER BY b.bid_time DESC 
                 LIMIT 10";
$user_bids_stmt = $conn->prepare($user_bids_sql);
$user_bids_stmt->bind_param("ii", $bid['bidder_id'], $bid_id);
$user_bids_stmt->execute();
$user_bids_result = $user_bids_stmt->get_result();

// Check if there's a related transaction for this bid
$transaction_sql = "SELECT * FROM transactions 
                   WHERE reference_id = ? AND 
                   (type = 'bid_hold' OR type = 'bid_release' OR type = 'winning_payment') 
                   ORDER BY created_at DESC";
$transaction_stmt = $conn->prepare($transaction_sql);
$transaction_stmt->bind_param("i", $bid_id);
$transaction_stmt->execute();
$transaction_result = $transaction_stmt->get_result();

// Handle actions
if (isset($_POST['action'])) {
    $action = clean_input($_POST['action']);
    
    // Only allow deleting non-winning bids
    if ($action == 'delete' && $bid['is_winning'] == 0) {
        $conn->begin_transaction();
        
        try {
            // Delete bid
            $delete_sql = "DELETE FROM bids WHERE bid_id = ?";
            $delete_stmt = $conn->prepare($delete_sql);
            $delete_stmt->bind_param("i", $bid_id);
            $delete_stmt->execute();
            
            // Release any held funds if there's a hold transaction
            $release_sql = "SELECT * FROM transactions 
                           WHERE reference_id = ? AND type = 'bid_hold' AND status = 'completed'";
            $release_stmt = $conn->prepare($release_sql);
            $release_stmt->bind_param("i", $bid_id);
            $release_stmt->execute();
            $release_result = $release_stmt->get_result();
            
            if ($release_result->num_rows > 0) {
                $hold_transaction = $release_result->fetch_assoc();
                
                // Create release transaction
                $release_funds_sql = "INSERT INTO transactions 
                                     (user_id, amount, type, status, notes, admin_id, reference_id) 
                                     VALUES (?, ?, 'bid_release', 'completed', ?, ?, ?)";
                $notes = "Release of funds from deleted bid #{$bid_id} for vehicle '{$bid['vehicle_title']}'";
                $release_funds_stmt = $conn->prepare($release_funds_sql);
                $release_funds_stmt->bind_param("idsii", $bid['bidder_id'], $hold_transaction['amount'], $notes, $admin_id, $bid_id);
                $release_funds_stmt->execute();
                
                // Update user balance
                $update_balance_sql = "UPDATE users SET balance = balance + ? WHERE user_id = ?";
                $update_balance_stmt = $conn->prepare($update_balance_sql);
                $update_balance_stmt->bind_param("di", $hold_transaction['amount'], $bid['bidder_id']);
                $update_balance_stmt->execute();
            }
            
            $conn->commit();
            // Redirect with success message
            header("Location: bids.php?success=bid_deleted");
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Terjadi kesalahan: " . $e->getMessage();
        }
    }
}

$page_title = "Detail Bid #" . $bid_id;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><?php echo $page_title; ?></h1>
    <div>
        <a href="bids.php" class="btn btn-secondary me-2">
            <i class="fa fa-arrow-left"></i> Kembali
        </a>
        <?php if (!$bid['is_winning']): ?>
            <form method="post" class="d-inline">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus bid ini? Jika ada dana yang ditahan akan dikembalikan ke pengguna.')">
                    <i class="fa fa-trash"></i> Hapus Bid
                </button>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php if(isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6">
        <!-- Bid Information -->
        <div class="de-box mb-4">
            <h5 class="mb-3">Informasi Bid</h5>
            <table class="table">
                <tr>
                    <th width="35%">ID Bid</th>
                    <td><?php echo $bid['bid_id']; ?></td>
                </tr>
                <tr>
                    <th>Jumlah Bid</th>
                    <td><?php echo format_currency($bid['bid_amount']); ?></td>
                </tr>
                <tr>
                    <th>Waktu Bid</th>
                    <td><?php echo date('d M Y H:i:s', strtotime($bid['bid_time'])); ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <?php if ($bid['is_winning']): ?>
                            <span class="badge bg-success">Bid Tertinggi</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Outbid</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>IP Address</th>
                    <td><?php echo $bid['ip_address'] ? $bid['ip_address'] : 'Tidak tercatat'; ?></td>
                </tr>
                <tr>
                    <th>User Agent</th>
                    <td><?php echo $bid['user_agent'] ? $bid['user_agent'] : 'Tidak tercatat'; ?></td>
                </tr>
                <tr>
                    <th>Catatan Admin</th>
                    <td><?php echo $bid['admin_notes'] ? $bid['admin_notes'] : 'Tidak ada catatan'; ?></td>
                </tr>
            </table>
        </div>
        
        <!-- Vehicle Information -->
        <div class="de-box mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Informasi Kendaraan</h5>
                <div>
                    <a href="../vehicle.php?id=<?php echo $bid['vehicle_id']; ?>" target="_blank" class="btn btn-sm btn-info me-2">
                        <i class="fa fa-eye"></i> Lihat
                    </a>
                    <a href="vehicle-form.php?id=<?php echo $bid['vehicle_id']; ?>" class="btn btn-sm btn-primary">
                        <i class="fa fa-edit"></i> Edit
                    </a>
                </div>
            </div>
            <table class="table">
                <tr>
                    <th width="35%">ID Kendaraan</th>
                    <td><?php echo $bid['vehicle_id']; ?></td>
                </tr>
                <tr>
                    <th>Judul</th>
                    <td><?php echo $bid['vehicle_title']; ?></td>
                </tr>
                <tr>
                    <th>Harga Awal</th>
                    <td><?php echo format_currency($bid['starting_price']); ?></td>
                </tr>
                <tr>
                    <th>Bid Tertinggi</th>
                    <td><?php echo $bid['current_bid'] ? format_currency($bid['current_bid']) : 'Belum ada bid'; ?></td>
                </tr>
                <tr>
                    <th>Waktu Berakhir</th>
                    <td><?php echo date('d M Y H:i:s', strtotime($bid['auction_end'])); ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <?php
                        switch ($bid['vehicle_status']) {
                            case 'upcoming':
                                echo '<span class="badge bg-info">Akan Datang</span>';
                                break;
                            case 'active':
                                echo '<span class="badge bg-success">Aktif</span>';
                                break;
                            case 'ended':
                                echo '<span class="badge bg-secondary">Berakhir</span>';
                                break;
                            case 'sold':
                                echo '<span class="badge bg-primary">Terjual</span>';
                                break;
                            case 'not_sold':
                                echo '<span class="badge bg-danger">Tidak Terjual</span>';
                                break;
                            default:
                                echo $bid['vehicle_status'];
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th>Total Bid</th>
                    <td><?php echo $bid['total_bids_on_vehicle']; ?> bid</td>
                </tr>
            </table>
        </div>
        
        <!-- Related Transactions -->
        <div class="de-box">
            <h5 class="mb-3">Transaksi Terkait</h5>
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tanggal</th>
                            <th>Jumlah</th>
                            <th>Tipe</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($transaction_result->num_rows > 0): ?>
                            <?php while ($transaction = $transaction_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $transaction['transaction_id']; ?></td>
                                    <td><?php echo date('d M Y H:i', strtotime($transaction['created_at'])); ?></td>
                                    <td><?php echo format_currency($transaction['amount']); ?></td>
                                    <td>
                                        <?php
                                        switch ($transaction['type']) {
                                            case 'bid_hold':
                                                echo '<span class="badge bg-info">Hold Bid</span>';
                                                break;
                                            case 'bid_release':
                                                echo '<span class="badge bg-secondary">Release Bid</span>';
                                                break;
                                            case 'winning_payment':
                                                echo '<span class="badge bg-primary">Pembayaran Menang</span>';
                                                break;
                                            default:
                                                echo $transaction['type'];
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        switch ($transaction['status']) {
                                            case 'pending':
                                                echo '<span class="badge bg-warning">Pending</span>';
                                                break;
                                            case 'completed':
                                                echo '<span class="badge bg-success">Selesai</span>';
                                                break;
                                            case 'rejected':
                                                echo '<span class="badge bg-danger">Ditolak</span>';
                                                break;
                                            default:
                                                echo $transaction['status'];
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">Tidak ada transaksi terkait dengan bid ini.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <!-- Bidder Information -->
        <div class="de-box mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Informasi Penawar</h5>
                <div>
                    <a href="user-detail.php?id=<?php echo $bid['bidder_id']; ?>" class="btn btn-sm btn-primary">
                        <i class="fa fa-user"></i> Lihat Profil
                    </a>
                </div>
            </div>
            <table class="table">
                <tr>
                    <th width="35%">ID Pengguna</th>
                    <td><?php echo $bid['bidder_id']; ?></td>
                </tr>
                <tr>
                    <th>Username</th>
                    <td><?php echo $bid['bidder_username']; ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo $bid['bidder_email']; ?></td>
                </tr>
                <tr>
                    <th>Saldo Terkini</th>
                    <td><?php echo format_currency($bid['bidder_balance']); ?></td>
                </tr>
                <tr>
                    <th>Total Bid Oleh Pengguna</th>
                    <td><?php echo $bid['total_bids_by_user']; ?> bid</td>
                </tr>
            </table>
        </div>
        
        <!-- Other Bids on This Vehicle -->
        <div class="de-box mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Bid Lain Pada Kendaraan Ini</h5>
                <a href="bids.php?vehicle_id=<?php echo $bid['vehicle_id']; ?>" class="btn btn-sm btn-primary">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Penawar</th>
                            <th>Jumlah</th>
                            <th>Waktu</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($other_bids_result->num_rows > 0): ?>
                            <?php while ($other_bid = $other_bids_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $other_bid['bid_id']; ?></td>
                                    <td><?php echo $other_bid['username']; ?></td>
                                    <td><?php echo format_currency($other_bid['bid_amount']); ?></td>
                                    <td><?php echo date('d M Y H:i', strtotime($other_bid['bid_time'])); ?></td>
                                    <td>
                                        <?php if ($other_bid['is_winning']): ?>
                                            <span class="badge bg-success">Tertinggi</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Outbid</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">Tidak ada bid lain pada kendaraan ini.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- User's Other Bids -->
        <div class="de-box">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Bid Lain Oleh Pengguna Ini</h5>
                <a href="bids.php?user_id=<?php echo $bid['bidder_id']; ?>" class="btn btn-sm btn-primary">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Kendaraan</th>
                            <th>Jumlah</th>
                            <th>Waktu</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($user_bids_result->num_rows > 0): ?>
                            <?php while ($user_bid = $user_bids_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $user_bid['bid_id']; ?></td>
                                    <td><?php echo $user_bid['vehicle_title']; ?></td>
                                    <td><?php echo format_currency($user_bid['bid_amount']); ?></td>
                                    <td><?php echo date('d M Y H:i', strtotime($user_bid['bid_time'])); ?></td>
                                    <td>
                                        <?php if ($user_bid['is_winning']): ?>
                                            <span class="badge bg-success">Tertinggi</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Outbid</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">Pengguna ini belum melakukan bid lain.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
