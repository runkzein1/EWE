<?php
// Include performance optimizer untuk optimasi loading desktop
require_once 'config/performance-optimizer.php';

// --- PERBAIKAN v2.5 --- Fast Loading Improvement ---
// Set hard timeout untuk mencegah loading tanpa henti
set_time_limit(7); // 7 detik maksimum - ditingkatkan sedikit agar halaman sempat dimuat
ini_set('max_execution_time', 7);

// Hanya redirect jika dalam mode debug
if (isset($_GET['debug'])) {
    header("Refresh: 10;url=error.php?reason=timeout&page=auctions");
}

// Handler error kustom
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("Error di auctions.php: [$errno] $errstr in $errfile:$errline");
    // Untuk error fatal, redirect ke halaman error
    if (in_array($errno, [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        header("Location: error.php?reason=" . urlencode($errstr));
        exit;
    }
    return true;
});

// Include configuration, database connection and functions
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Flag untuk menggunakan styling modern 2025
$use_modern_2025 = true;

// Pagination variables
$items_per_page = 9;
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($current_page - 1) * $items_per_page;

// Filtering
$where_clause = "1=1"; // Default to show all vehicles
$params = [];
$param_types = "";

// Check for filters
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = "%" . clean_input($_GET['search']) . "%";
    $where_clause .= " AND (model LIKE ? OR description LIKE ? OR make LIKE ? OR model LIKE ?)";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $param_types .= "ssss";
}

if (isset($_GET['status']) && !empty($_GET['status'])) {
    $status = clean_input($_GET['status']);
    $where_clause .= " AND status = ?";
    $params[] = $status;
    $param_types .= "s";
}

if (isset($_GET['make']) && !empty($_GET['make'])) {
    $make = clean_input($_GET['make']);
    $where_clause .= " AND make = ?";
    $params[] = $make;
    $param_types .= "s";
}

if (isset($_GET['min_price']) && is_numeric($_GET['min_price'])) {
    $min_price = floatval($_GET['min_price']);
    $where_clause .= " AND (current_bid >= ? OR starting_price >= ?)";
    $params[] = $min_price;
    $params[] = $min_price;
    $param_types .= "dd";
}

if (isset($_GET['max_price']) && is_numeric($_GET['max_price'])) {
    $max_price = floatval($_GET['max_price']);
    $where_clause .= " AND (current_bid <= ? OR (current_bid IS NULL AND starting_price <= ?))";
    $params[] = $max_price;
    $params[] = $max_price;
    $param_types .= "dd";
}

// Sorting
$order_by = "auction_end ASC"; // Default sort
if (isset($_GET['sort'])) {
    switch ($_GET['sort']) {
        case 'price_asc':
            $order_by = "COALESCE(current_bid, starting_price) ASC";
            break;
        case 'price_desc':
            $order_by = "COALESCE(current_bid, starting_price) DESC";
            break;
        case 'newest':
            $order_by = "created_at DESC";
            break;
        case 'ending_soon':
            $order_by = "auction_end ASC";
            break;
    }
}

// Menerapkan caching untuk queries berat, optimal untuk desktop
// Buat cache key berdasarkan filter dan pagination yang dipilih user
$filter_key = md5(json_encode(["where" => $where_clause, "params" => $params, "page" => $current_page]));

// Get total active vehicles (dengan cache)
$count_cache_key = "auctions_count_" . $filter_key;
$count_result = db_get_cached($conn,
                            "SELECT COUNT(*) as total FROM vehicles WHERE $where_clause AND status != 'sold'",
                            $params,
                            $param_types);

if (!isset($count_result['error']) && isset($count_result['data']) && count($count_result['data']) > 0) {
    $total_items = $count_result['data'][0]['total'];
} else {
    // Fallback ke query langsung
    $count_stmt = $conn->prepare("SELECT COUNT(*) as total FROM vehicles WHERE $where_clause AND status != 'sold'");

    if ($count_stmt) {
        $count_stmt->bind_param($param_types, ...$params);
        $count_stmt->execute();
        $count_res = $count_stmt->get_result();
        $count_row = $count_res->fetch_assoc();
        $total_items = $count_row ? $count_row['total'] : 0;
    } else {
        $total_items = 0;
        $error = "Error preparing count query: " . $conn->error;
    }
}

// Calculate total pages
$total_pages = ceil($total_items / $items_per_page);

// Make sure current page is valid
if ($current_page < 1) $current_page = 1;
if ($current_page > $total_pages && $total_pages > 0) $current_page = $total_pages;

// Get vehicles with pagination (dengan cache untuk desktop)
$vehicles_query = "SELECT v.*, COUNT(b.bid_id) as bid_count, COALESCE(MAX(b.bid_amount), 0) as highest_bid
         FROM vehicles v
         LEFT JOIN bids b ON v.vehicle_id = b.vehicle_id
         WHERE $where_clause AND v.status != 'sold'
         GROUP BY v.vehicle_id
         ORDER BY
            CASE WHEN v.status = 'active' THEN 1
                 WHEN v.status = 'upcoming' THEN 2
                 ELSE 3
            END,
            v.auction_end ASC
         LIMIT ?, ?";

// Buat parameter query
$stmt_params = $params;
$stmt_params[] = $offset;
$stmt_params[] = $items_per_page;
$stmt_param_types = $param_types . 'ii';

// Optimize dengan caching untuk desktop performance
$vehicles_cache_key = "auctions_list_" . $filter_key;
$vehicles_result = db_get_cached($conn, $vehicles_query, $stmt_params, $stmt_param_types);

if (!isset($vehicles_result['error']) && isset($vehicles_result['data'])) {
    // Hasil query dari cache
    $result_data = $vehicles_result['data'];

    // Convert ke custom class, bukan stdClass, karena stdClass tidak support method
    // PERBAIKAN: Mengubah implementasi agar konsisten dan bisa dipakai oleh semua PHP version
    class ResultWrapper {
        private $data;
        private $current_row = 0;
        public $num_rows;

        public function __construct($data) {
            $this->data = $data;
            $this->num_rows = count($data);
        }

        public function fetch_assoc() {
            if ($this->current_row >= $this->num_rows) {
                return null;
            }
            return $this->data[$this->current_row++];
        }

        public function data_seek($position) {
            $this->current_row = $position;
            return true;
        }
    }

    $result = new ResultWrapper($result_data);
} else {
    // Fallback query tanpa cache
    $stmt = $conn->prepare($vehicles_query);

    if ($stmt) {
        $stmt->bind_param($stmt_param_types, ...$stmt_params);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = false;
        echo '<div style="padding: 20px; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 5px; margin: 20px;">
            <h3>Error</h3>
            <p>Maaf, terjadi kesalahan saat memuat daftar lelang. Silakan coba lagi nanti.</p>
            <a href="index.php" class="btn btn-primary">Kembali ke Beranda</a>
        </div>';
    }
}

// Get makes for filter dropdown sesuai database produksi
try {
    $makes_sql = "SELECT DISTINCT make FROM vehicles WHERE make IS NOT NULL ORDER BY make";
    $makes_result = $conn->query($makes_sql);

    if (!$makes_result) {
        error_log("Error querying makes: " . $conn->error);
    }
} catch (Throwable $e) {
    error_log("Error in auctions.php makes query: " . $e->getMessage());
    $makes_result = false;
}

// Page title
$page_title = "Lelang Aktif";
include 'includes/header.php';
?>

<?php if ($use_modern_2025): ?>
<!-- Modern 2025 CSS untuk Auctions -->
<link rel="stylesheet" href="css/modern-2025.css">
<link rel="stylesheet" href="css/auctions-modern-2025.css">
<?php else: ?>
<!-- Legacy CSS untuk Auctions -->
<link rel="stylesheet" href="css/ultra-modern-vehicle.css">
<link rel="stylesheet" href="css/modern-vehicle.css">
<link rel="stylesheet" href="css/auction-premium.css">
<?php endif; ?>

<div id="top"></div>
<section id="subheader" class="jarallax text-light">
    <img src="images/background/2.jpg" class="jarallax-img" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="subtitle wow fadeInUp mb-3">LelangMobil</div>
            </div>
            <div class="col-lg-6">
                <h2 class="wow fadeInUp mb20" data-wow-delay=".2s">Lelang Mobil</h2>
            </div>
        </div>
    </div>
</section>

<section aria-label="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="de-box sticky-lg-top mb30" style="top: 100px;">
                    <h4>Filter</h4>
                    <form action="auctions.php" method="get" id="filter-form">
                        <div class="field-set mb20">
                            <input type="text" name="search" class="form-control" placeholder="Cari" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        </div>

                        <div class="field-set mb20">
                            <label>Status:</label>
                            <select name="status" class="form-control form-select">
                                <option value="">Semua Status</option>
                                <option value="upcoming" <?php echo (isset($_GET['status']) && $_GET['status'] == 'upcoming') ? 'selected' : ''; ?>>Akan Datang</option>
                                <option value="active" <?php echo (isset($_GET['status']) && $_GET['status'] == 'active') ? 'selected' : ''; ?>>Aktif</option>
                                <option value="ended" <?php echo (isset($_GET['status']) && $_GET['status'] == 'ended') ? 'selected' : ''; ?>>Selesai</option>
                            </select>
                        </div>

                        <div class="field-set mb20">
                            <label>Merek:</label>
                            <select name="make" class="form-control form-select">
                                <option value="">Semua Merek</option>
                                <?php while ($make = $makes_result->fetch_assoc()): ?>
                                    <option value="<?php echo $make['make']; ?>" <?php echo (isset($_GET['make']) && $_GET['make'] == $make['make']) ? 'selected' : ''; ?>><?php echo $make['make']; ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="field-set mb20">
                            <label>Harga Min (Rp):</label>
                            <input type="number" name="min_price" class="form-control" value="<?php echo isset($_GET['min_price']) ? htmlspecialchars($_GET['min_price']) : ''; ?>">
                        </div>

                        <div class="field-set mb20">
                            <label>Harga Max (Rp):</label>
                            <input type="number" name="max_price" class="form-control" value="<?php echo isset($_GET['max_price']) ? htmlspecialchars($_GET['max_price']) : ''; ?>">
                        </div>

                        <div class="field-set mb20">
                            <label>Urutkan:</label>
                            <select name="sort" class="form-control form-select">
                                <option value="ending_soon" <?php echo (!isset($_GET['sort']) || $_GET['sort'] == 'ending_soon') ? 'selected' : ''; ?>>Segera Berakhir</option>
                                <option value="price_asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_asc') ? 'selected' : ''; ?>>Harga Terendah</option>
                                <option value="price_desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_desc') ? 'selected' : ''; ?>>Harga Tertinggi</option>
                                <option value="newest" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'newest') ? 'selected' : ''; ?>>Terbaru</option>
                            </select>
                        </div>

                        <button type="submit" class="btn-main btn-fullwidth">Terapkan Filter</button>
                        <a href="auctions.php" class="btn-main btn-fullwidth mt10" style="background-color: #6c757d;">Reset Filter</a>
                    </form>
                </div>
            </div>

            <div class="col-lg-9">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="mb20"><?php echo $total_items; ?> Kendaraan Ditemukan</h3>
                    </div>

                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($vehicle = $result->fetch_assoc()): ?>
                            <div class="col-lg-4 col-md-6 mb30">
                                <div class="de-box">
                                    <div class="de-image-box">
                                        <img src="images/no-image.svg" class="img-fluid" alt="<?php echo isset($vehicle['model']) ? htmlspecialchars($vehicle['model']) : 'Kendaraan'; ?>" onerror="this.src='images/no-image.svg';">
                                        <?php if ($vehicle['status'] == 'upcoming'): ?>
                                            <div class="de-box-badge bg-primary">Akan Datang</div>
                                        <?php elseif ($vehicle['status'] == 'active'): ?>
                                            <div class="de-box-badge bg-success">Aktif</div>
                                        <?php elseif ($vehicle['status'] == 'ended'): ?>
                                            <div class="de-box-badge bg-secondary">Selesai</div>
                                        <?php endif; ?>

                                        <?php
                                        // Calculate time remaining with safe handling for missing auction_end
                                        $now = new DateTime();
                                        $time_remaining = "";

                                        // Check if auction_end exists and is not empty
                                        $auction_end = isset($vehicle['auction_end']) && !empty($vehicle['auction_end']) ? $vehicle['auction_end'] : null;

                                        if ($auction_end && $vehicle['status'] == 'active') {
                                            $end_date = new DateTime($auction_end);
                                            $interval = $now->diff($end_date);
                                            if ($interval->days > 0) {
                                                $time_remaining = "{$interval->days} hari lagi";
                                            } elseif ($interval->h > 0) {
                                                $time_remaining = "{$interval->h} jam lagi";
                                            } else {
                                                $time_remaining = "{$interval->i} menit lagi";
                                            }
                                        ?>
                                            <div class="de-box-time"><?php echo $time_remaining; ?></div>
                                        <?php } ?>
                                    </div>

                                    <div class="d-flex justify-content-between align-items-center mt-3">
                                        <h4 class="mb-0"><?php echo isset($vehicle['model']) ? htmlspecialchars($vehicle['make'] . ' ' . $vehicle['model']) : 'Kendaraan'; ?></h4>
                                        <span class="id-color"><?php echo isset($vehicle['year']) ? htmlspecialchars($vehicle['year']) : '-'; ?></span>
                                    </div>

                                    <div class="d-flex justify-content-between py-2">
                                        <span><?php echo isset($vehicle['make']) ? htmlspecialchars($vehicle['make']) : ''; ?> <?php echo isset($vehicle['model']) ? htmlspecialchars($vehicle['model']) : ''; ?></span>
                                        <span><?php echo isset($vehicle['mileage']) && is_numeric($vehicle['mileage']) ? number_format($vehicle['mileage'], 0, ',', '.') . ' km' : '-'; ?></span>
                                    </div>

                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <p class="mb-0">
                                                <?php if ($vehicle['current_bid']): ?>
                                                    <strong>Bid Saat Ini:</strong><br>
                                                    <span class="id-color h5"><?php echo format_currency($vehicle['current_bid']); ?></span>
                                                <?php else: ?>
                                                    <strong>Harga Awal:</strong><br>
                                                    <span class="id-color h5"><?php echo format_currency($vehicle['starting_price']); ?></span>
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                        <a href="vehicle.php?id=<?php echo $vehicle['vehicle_id']; ?>" class="btn-main">Lihat Detail</a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>

                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <div class="col-lg-12">
                                <div class="spacer-single"></div>
                                <nav aria-label="Page navigation">
                                    <ul class="pagination justify-content-center">
                                        <?php if ($current_page > 1): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="<?php echo "auctions.php?" . http_build_query(array_merge($_GET, ['page' => $current_page - 1])); ?>" aria-label="Previous">
                                                    <span aria-hidden="true">&laquo;</span>
                                                </a>
                                            </li>
                                        <?php endif; ?>

                                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                            <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                                                <a class="page-link" href="<?php echo "auctions.php?" . http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                                    <?php echo $i; ?>
                                                </a>
                                            </li>
                                        <?php endfor; ?>

                                        <?php if ($current_page < $total_pages): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="<?php echo "auctions.php?" . http_build_query(array_merge($_GET, ['page' => $current_page + 1])); ?>" aria-label="Next">
                                                    <span aria-hidden="true">&raquo;</span>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="col-lg-12">
                            <div class="de-box text-center py-5">
                                <h3>Tidak ada kendaraan yang ditemukan</h3>
                                <p>Coba ubah filter atau cari kembali nanti.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
