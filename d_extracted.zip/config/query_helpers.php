<?php
/**
 * SQL Query Helper Functions
 * File ini berisi fungsi-fungsi untuk membantu standardisasi query SQL
 * LelangMobil Web App - Versi 2025
 *
 * Standardisasi Nama Kolom (sesuai database di server produksi):
 * - model (sebelumnya: title, name) - nama model kendaraan
 * - make (bukan brand_name) - merk kendaraan
 * - image (sebelumnya: image_url, main_image) - gambar utama kendaraan
 * - start_price (sebelumnya: starting_price) - harga awal lelang
 * - current_price (sebelumnya: current_bid) - harga tawaran saat ini
 * - auction_end (sebelumnya: end_date) - tanggal berakhirnya lelang
 */

/**
 * PENTING: Setelah pemeriksaan, ternyata di server produksi kolom yang digunakan adalah 'make'
 * bukan 'brand_name' seperti yang kita rencanakan sebelumnya. Semua query telah disesuaikan
 * untuk menggunakan 'make' sebagai pengganti 'brand_name'.
 */

/**
 * Mendapatkan query dasar untuk tabel vehicles dengan standarisasi alias kolom
 * 
 * @return string Query SQL dasar untuk tabel vehicles
 */
function get_vehicle_query_base() {
    return "SELECT v.vehicle_id, 
                   v.model AS title, 
                   v.make AS brand,
                   v.image AS image_main,
                   v.start_price AS starting_price,
                   v.current_price AS current_bid, 
                   v.auction_end AS end_date,
                   v.year,
                   v.description,
                   v.status,
                   v.seller_id,
                   v.created_at
            FROM vehicles v";
}

/**
 * Mendapatkan query dasar untuk tabel vehicles dengan join ke tabel users
 * 
 * @return string Query SQL untuk tabel vehicles dengan join ke users
 */
function get_vehicle_with_seller_query() {
    return "SELECT v.vehicle_id, 
                   v.model AS title, 
                   v.make AS brand,
                   v.image AS image_main,
                   v.start_price AS starting_price,
                   v.current_price AS current_bid, 
                   v.auction_end AS end_date,
                   v.year,
                   v.description,
                   v.status,
                   v.seller_id,
                   v.created_at,
                   u.username AS seller_username
            FROM vehicles v
            LEFT JOIN users u ON v.seller_id = u.user_id";
}

/**
 * Mendapatkan query dasar untuk tabel bids dengan join ke tabel vehicles
 * 
 * @return string Query SQL untuk tabel bids dengan join ke vehicles
 */
function get_bids_query_base() {
    return "SELECT b.bid_id,
                   b.vehicle_id,
                   b.bidder_id,
                   b.bid_amount,
                   b.bid_time,
                   v.model AS title, 
                   v.make AS brand,
                   v.image AS image_main,
                   v.start_price AS starting_price,
                   v.current_price AS current_bid, 
                   v.auction_end AS end_date,
                   v.status AS vehicle_status
            FROM bids b
            LEFT JOIN vehicles v ON b.vehicle_id = v.vehicle_id";
}

/**
 * Mendapatkan total bid aktif untuk pengguna
 * 
 * @param mysqli $conn Koneksi database
 * @param int $user_id ID pengguna
 * @return int Jumlah bid aktif
 */
function get_active_bids_count($conn, $user_id) {
    try {
        // Perbaikan nama kolom dari auction_end ke auction_end (nama kolom asli)
        $sql = "SELECT COUNT(*) as total 
                FROM bids b 
                JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                WHERE b.bidder_id = ? AND v.auction_end > NOW()";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            return $row['total'];
        }
    } catch (Throwable $e) {
        error_log("Error getting active bids count: " . $e->getMessage());
    }
    return 0;
}

/**
 * Mendapatkan total kemenangan lelang untuk pengguna
 * 
 * @param mysqli $conn Koneksi database
 * @param int $user_id ID pengguna
 * @return int Jumlah kemenangan lelang
 */
function get_auction_wins_count($conn, $user_id) {
    try {
        // Tidak menggunakan alias tabel dan query yang sesuai dengan struktur database produksi
        $sql = "SELECT COUNT(*) as total 
                FROM bids 
                JOIN vehicles ON bids.vehicle_id = vehicles.vehicle_id 
                WHERE bids.bidder_id = ? 
                AND vehicles.status = 'ended' 
                AND bids.bid_amount = vehicles.current_bid";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            return $row['total'];
        }
    } catch (Throwable $e) {
        error_log("Error getting wins count: " . $e->getMessage());
    }
    return 0;
}

/**
 * Mendapatkan query untuk riwayat topup user
 * 
 * @return string Query SQL untuk riwayat topup
 */
function get_topup_history_query() {
    return "SELECT 
            t.transaction_id,
            t.amount,
            t.status,
            t.payment_proof,
            t.created_at,
            t.updated_at
        FROM transactions t
        WHERE t.user_id = ? AND t.type = 'topup'";
}

/**
 * Mendapatkan query untuk transaksi user
 * 
 * @return string Query SQL untuk transaksi user
 */
function get_transactions_query() {
    return "SELECT 
            t.transaction_id,
            t.amount,
            t.type,
            t.status,
            t.notes,
            t.created_at
        FROM transactions t
        WHERE t.user_id = ?";
}

/**
 * Mendapatkan data saldo user
 * 
 * @param mysqli $conn Koneksi database
 * @param int $user_id ID pengguna
 * @return array Informasi saldo user atau array kosong jika gagal
 */
function get_user_balance($conn, $user_id) {
    try {
        $sql = "SELECT balance, pending_balance FROM users WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            return $row;
        }
    } catch (Throwable $e) {
        error_log("Error getting user balance: " . $e->getMessage());
    }
    return ['balance' => 0, 'pending_balance' => 0];
}

/**
 * Mendapatkan query untuk notifikasi user
 * 
 * @return string Query SQL untuk notifikasi user
 */
function get_notifications_query() {
    return "SELECT 
            notification_id,
            user_id,
            type,
            message,
            url,
            is_read,
            created_at
        FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC";
}
