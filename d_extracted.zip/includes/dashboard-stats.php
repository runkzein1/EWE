<?php
/**
 * Dashboard Stats Component
 * LelangMobil Web App - Versi 2025
 */

// Set timeout yang lebih ketat untuk query di komponen ini
set_time_limit(5); // Maksimal 5 detik untuk eksekusi komponen ini

// Define default values upfront untuk mencegah komponen gagal sepenuhnya
$total_bids = 0;
$total_wins = 0;
$active_bids = 0;
$total_spent = 0;
$current_balance = 0;

// Pastikan data user sudah tersedia dengan cara yang tidak mematikan seluruh halaman
if (!isset($user) || !is_array($user)) {
    echo '<div class="modern-alert modern-alert-danger mb-4">
        <i class="fa fa-exclamation-circle"></i>
        <div>Error: Data user tidak tersedia.</div>
    </div>';
    return; // Keluar dari include tanpa mematikan seluruh halaman
}

// Query untuk statistik dasar dengan timeout safety
if (!isset($total_bids)) {
    try {
        // Gunakan micro-timeout untuk mencegah query terlalu lama
        $timeout_start = microtime(true);
        
        // Get total bids
        $bids_count_sql = "SELECT COUNT(*) as total FROM bids WHERE bidder_id = ?";
        $bids_count_stmt = $conn->prepare($bids_count_sql);
        $bids_count_stmt->bind_param("i", $user_id);
        $bids_count_result = $bids_count_stmt->execute();
        
        // Cek jika query tidak timeout
        if ($bids_count_result && (microtime(true) - $timeout_start) < 1) {
            $result = $bids_count_stmt->get_result();
            $total_bids = $result->fetch_assoc()['total'] ?? 0;
        } else {
            error_log("Query total_bids timeout or failed in dashboard-stats.php");
            $total_bids = 0; // Default
        }
    } catch (Throwable $e) {
        error_log("Error getting total bids: " . $e->getMessage());
        $total_bids = 0; // Default jika error
    }
}

if (!isset($total_wins)) {
    try {
        // Cek keberadaan fungsi helper
        if (function_exists('get_auction_wins_count')) {
            $total_wins = get_auction_wins_count($conn, $user_id);
        } else {
            // Implementasi langsung jika fungsi helper tidak ada menggunakan nama kolom yang benar
            $wins_sql = "SELECT COUNT(*) as total 
                      FROM bids 
                      JOIN vehicles ON bids.vehicle_id = vehicles.vehicle_id 
                      WHERE bids.bidder_id = ? 
                      AND vehicles.status = 'ended' 
                      AND bids.bid_amount = vehicles.current_bid";
            $wins_stmt = $conn->prepare($wins_sql);
            $wins_stmt->bind_param("i", $user_id);
            $wins_stmt->execute();
            $wins_result = $wins_stmt->get_result();
            $total_wins = $wins_result->fetch_assoc()['total'] ?? 0;
        }
    } catch (Throwable $e) {
        error_log("Error getting auction wins count: " . $e->getMessage());
        $total_wins = 0; // Nilai default jika error
    }
}

if (!isset($active_bids)) {
    // Get active bids (bids on active auctions) tanpa alias tabel untuk kompatibilitas
    try {
        $active_bids_sql = "SELECT COUNT(DISTINCT bids.vehicle_id) as total FROM bids 
                        JOIN vehicles ON bids.vehicle_id = vehicles.vehicle_id 
                        WHERE bids.bidder_id = ? AND vehicles.status = 'active'";
        $active_bids_stmt = $conn->prepare($active_bids_sql);
        $active_bids_stmt->bind_param("i", $user_id);
        $active_bids_stmt->execute();
        $active_bids_result = $active_bids_stmt->get_result();
        $active_bids = $active_bids_result->fetch_assoc()['total'] ?? 0;
    } catch (Throwable $e) {
        error_log("Error getting active bids count: " . $e->getMessage());
        $active_bids = 0; // Nilai default jika error
    }
}

if (!isset($total_spent)) {
    // Get total spent on auctions
    $spent_sql = "SELECT COALESCE(SUM(amount), 0) as total FROM transactions 
                 WHERE user_id = ? AND status = 'completed' 
                 AND (type = 'bid_win' OR type = 'bid_hold')";
    $spent_stmt = $conn->prepare($spent_sql);
    $spent_stmt->bind_param("i", $user_id);
    $spent_stmt->execute();
    $spent_result = $spent_stmt->get_result();
    $total_spent = $spent_result->fetch_assoc()['total'] ?? 0;
}
?>

<div class="modern-stats fade-in">
    <div class="modern-stat-card">
        <div class="modern-stat-icon">
            <i class="fa fa-wallet"></i>
        </div>
        <div class="modern-stat-info">
            <h4 class="modern-stat-value">Rp<?php echo number_format($user['balance'], 0, ',', '.'); ?></h4>
            <p class="modern-stat-title">Saldo Saat Ini</p>
        </div>
    </div>
    
    <div class="modern-stat-card">
        <div class="modern-stat-icon">
            <i class="fa fa-gavel"></i>
        </div>
        <div class="modern-stat-info">
            <h4 class="modern-stat-value"><?php echo number_format($total_bids, 0, ',', '.'); ?></h4>
            <p class="modern-stat-title">Total Bid</p>
        </div>
    </div>
    
    <div class="modern-stat-card">
        <div class="modern-stat-icon">
            <i class="fa fa-trophy"></i>
        </div>
        <div class="modern-stat-info">
            <h4 class="modern-stat-value"><?php echo number_format($total_wins, 0, ',', '.'); ?></h4>
            <p class="modern-stat-title">Lelang Dimenangkan</p>
        </div>
    </div>
    
    <div class="modern-stat-card">
        <div class="modern-stat-icon">
            <i class="fa fa-bolt"></i>
        </div>
        <div class="modern-stat-info">
            <h4 class="modern-stat-value"><?php echo number_format($active_bids, 0, ',', '.'); ?></h4>
            <p class="modern-stat-title">Bid Aktif</p>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-6">
        <div class="modern-card fade-in">
            <div class="modern-card-header">
                <h3 class="modern-card-title"><i class="fa fa-chart-pie"></i> Statistik Lelang</h3>
            </div>
            <div class="modern-card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="stat-label">Bid Menang</div>
                    <div class="progress flex-grow-1 mx-3" style="height: 8px;">
                        <?php 
                        $win_rate = $total_bids > 0 ? ($total_wins / $total_bids * 100) : 0;
                        ?>
                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $win_rate; ?>%" aria-valuenow="<?php echo $win_rate; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <div class="stat-value"><?php echo round($win_rate); ?>%</div>
                </div>

                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="stat-label">Bid Aktif</div>
                    <div class="progress flex-grow-1 mx-3" style="height: 8px;">
                        <?php 
                        $active_rate = $total_bids > 0 ? ($active_bids / $total_bids * 100) : 0;
                        ?>
                        <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo $active_rate; ?>%" aria-valuenow="<?php echo $active_rate; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <div class="stat-value"><?php echo round($active_rate); ?>%</div>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                    <div class="stat-label">Total Dihabiskan</div>
                    <div class="stat-value fw-bold">Rp<?php echo number_format($total_spent, 0, ',', '.'); ?></div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="modern-card fade-in">
            <div class="modern-card-header">
                <h3 class="modern-card-title"><i class="fa fa-clock"></i> Aktivitas Terakhir</h3>
            </div>
            <div class="modern-card-body p-0">
                <ul class="modern-timeline">
                    <?php 
                    // Get recent activities
                    $activities_sql = "SELECT t.transaction_id, t.type, t.amount, t.created_at, t.notes 
                                       FROM transactions t 
                                       WHERE t.user_id = ? 
                                       ORDER BY t.created_at DESC LIMIT 5";
                    $activities_stmt = $conn->prepare($activities_sql);
                    $activities_stmt->bind_param("i", $user_id);
                    $activities_stmt->execute();
                    $activities_result = $activities_stmt->get_result();
                    
                    if ($activities_result->num_rows > 0) {
                        while($activity = $activities_result->fetch_assoc()) {
                            // Set icon and message based on transaction type
                            $icon = 'fa-exchange-alt';
                            $activity_title = 'Transaksi';
                            
                            switch($activity['type']) {
                                case 'deposit':
                                    $icon = 'fa-arrow-down';
                                    $activity_title = 'Top Up';
                                    break;
                                case 'withdrawal':
                                    $icon = 'fa-arrow-up';
                                    $activity_title = 'Penarikan';
                                    break;
                                case 'bid_hold':
                                    $icon = 'fa-gavel';
                                    $activity_title = 'Bid Hold';
                                    break;
                                case 'bid_release':
                                    $icon = 'fa-undo';
                                    $activity_title = 'Bid Release';
                                    break;
                                case 'bid_win':
                                    $icon = 'fa-trophy';
                                    $activity_title = 'Menang Lelang';
                                    break;
                                case 'refund':
                                    $icon = 'fa-hand-holding-usd';
                                    $activity_title = 'Refund';
                                    break;
                            }
                    ?>
                    <li class="modern-timeline-item">
                        <div class="modern-timeline-badge">
                            <i class="fa <?php echo $icon; ?>"></i>
                        </div>
                        <div class="modern-timeline-content">
                            <h5 class="modern-timeline-title"><?php echo $activity_title; ?> - Rp<?php echo number_format($activity['amount'], 0, ',', '.'); ?></h5>
                            <span class="modern-timeline-time">
                                <i class="fa fa-calendar-alt me-1"></i> <?php echo date('d M Y, H:i', strtotime($activity['created_at'])); ?>
                            </span>
                            <?php if (!empty($activity['notes'])): ?>
                            <p class="mb-0 small"><?php echo htmlspecialchars($activity['notes']); ?></p>
                            <?php endif; ?>
                        </div>
                    </li>
                    <?php 
                        }
                    } else {
                        echo '<div class="p-4 text-center text-muted">Belum ada aktivitas terbaru.</div>';
                    }
                    ?>
                </ul>
                
                <?php if ($activities_result->num_rows > 0): ?>
                <div class="text-center p-3 border-top">
                    <a href="transactions-menu.php" class="modern-button modern-button-outline">
                        <i class="fa fa-eye me-2"></i>Lihat Semua Aktivitas
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
