<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Get error reason from URL parameter or set a default
$reason = isset($_GET['reason']) ? htmlspecialchars($_GET['reason']) : 'Terjadi kesalahan pada sistem.';

// Page title
$page_title = "Error - LelangMobil";
include 'includes/header.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="error-container text-center py-5">
                <i class="fa fa-exclamation-triangle fa-5x text-warning mb-4"></i>
                <h1 class="mb-4">Oops! Terjadi Kesalahan</h1>
                <div class="alert alert-warning">
                    <p><?php echo $reason; ?></p>
                </div>
                <p class="lead">Mohon maaf atas ketidaknyamanan ini. Tim teknis kami sedang bekerja untuk memperbaiki masalah.</p>
                <div class="mt-4">
                    <a href="index.php" class="btn btn-primary me-2">
                        <i class="fa fa-home me-2"></i>Kembali ke Beranda
                    </a>
                    <a href="auctions.php" class="btn btn-secondary">
                        <i class="fa fa-car me-2"></i>Lihat Lelang Lainnya
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
