<?php
// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';
require_once 'config/mailer.php';

$error = '';
$success = '';

// Process resend verification form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate input
    $email = clean_input($_POST['email']);
    
    // Check if email exists and is not verified
    $sql = "SELECT * FROM users WHERE email = ? AND is_verified = 0";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Generate new token
        $verification_token = generate_token();
        $token_expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        // Update token in database
        $update_sql = "UPDATE users SET verification_token = ?, token_expiry = ? WHERE user_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ssi", $verification_token, $token_expiry, $user['user_id']);
        
        if ($update_stmt->execute()) {
            // Send verification email
            if (send_verification_email($conn, $email, $verification_token, $user['user_id'])) {
                $success = "Email verifikasi telah dikirim ulang. Silakan periksa email Anda (termasuk folder spam).";
            } else {
                $error = "Gagal mengirim email verifikasi. Silakan coba lagi nanti.";
            }
        } else {
            $error = "Terjadi kesalahan. Silakan coba lagi nanti.";
        }
    } else {
        // Check if email exists but is already verified
        $check_sql = "SELECT * FROM users WHERE email = ? AND is_verified = 1";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $success = "Akun Anda sudah diverifikasi. Silakan login.";
        } else {
            $error = "Email tidak ditemukan atau belum terdaftar.";
        }
    }
}

// Page title
$page_title = "Kirim Ulang Verifikasi - LelangMobil";
?>

<?php include 'includes/header.php'; ?>

<div id="top"></div>
<section id="subheader" class="jarallax text-light">
    <img src="images/background/2.jpg" class="jarallax-img" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="subtitle wow fadeInUp mb-3">LelangMobil</div>
            </div>
            <div class="col-lg-6">
                <h2 class="wow fadeInUp mb20" data-wow-delay=".2s">Kirim Ulang Email Verifikasi</h2>
            </div>
        </div>
    </div>
</section>

<section aria-label="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="de-box">
                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if(!empty($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                        <p class="text-center">Silakan <a href="login.php">Login</a> setelah memverifikasi email Anda.</p>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <h5>Kirim Ulang Email Verifikasi</h5>
                            <p>Masukkan alamat email yang Anda gunakan untuk mendaftar. Kami akan mengirimkan email verifikasi baru ke alamat tersebut.</p>
                        </div>
                        <form class="form-border" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="field-set">
                                        <label>Email:</label>
                                        <input type="email" name="email" class="form-control" required>
                                    </div>
                                </div>
                                
                                <div class="col-lg-12">
                                    <div class="spacer-20"></div>
                                    <button class="btn-main" type="submit">Kirim Ulang Email Verifikasi</button>
                                </div>
                            </div>
                        </form>
                        <div class="spacer-20"></div>
                        <p class="text-center">Sudah memiliki akun terverifikasi? <a href="login.php">Login</a></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
