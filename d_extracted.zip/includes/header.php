<?php
// Include session helper if not already included
if (!function_exists('ensure_session_started')) {
    require_once __DIR__ . '/../config/session_helper.php';
}

// Start session securely
ensure_session_started();

// Update last activity and ensure session validity
if (session_status() == PHP_SESSION_ACTIVE) {
    $_SESSION['last_activity'] = time();

    // Regenerate session ID periodically (every 30 minutes)
    if (!isset($_SESSION['last_regeneration']) || (time() - $_SESSION['last_regeneration'] > 1800)) {
        regenerate_session_safely(true);
        $_SESSION['last_regeneration'] = time();
    }
}

// Base path for assets
$base_path = "";
// Deteksi jika kita berada di folder admin
if(strpos($_SERVER['PHP_SELF'], 'admin/') !== false) {
    $base_path = "../";
    // Sesuaikan path untuk include config dan database
    if (!defined('DB_NAME')) {
        require_once '../config/config.php';
        require_once '../config/database.php';
    }
} else {
    // Include config dan database connection dari root jika belum di-include
    if (!defined('DB_NAME')) {
        require_once 'config/config.php';
        require_once 'config/database.php';
    }
}

// Site title
$site_title = "LelangMobil - Platform Lelang Mobil Online";
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <title><?php echo $site_title; ?></title>
    <link rel="icon" href="<?php echo $base_path; ?>images/icon.png" type="image/gif" sizes="16x16">
    <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="<?php echo $site_title; ?>" name="description">
    <meta content="lelang mobil, auction, car auction, indonesia, online auction" name="keywords">
    <!-- CSS Files - Dikelola melalui css-loader.php -->
    <?php
    // Set default value untuk variabel kontrol CSS loader
    $is_dashboard_page = isset($is_dashboard_page) ? $is_dashboard_page : false;
    $use_ultra_modern = isset($use_ultra_modern) ? $use_ultra_modern : false;

    // Include CSS loader
    if (file_exists('/home/lelang/public_html/includes/css-loader.php')) {
        include_once '/home/lelang/public_html/includes/css-loader.php';
    } else {
        include_once 'css-loader.php';
    }
    ?>
    <!-- Modern Theme Activator -->
    <script src="<?php echo $base_path; ?>js/modern-theme-activator.js"></script>
</head>

<body class="dark-scheme">
    <div id="wrapper">
        <div class="scrollbar"></div>
        <!-- page preloader begin -->
        <div id="de-loader"></div>
        <!-- page preloader close -->

        <!-- header begin -->
        <header class="transparent">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="de-flex sm-pt10">
                            <div class="de-flex-col">
                                <div class="de-flex-col">
                                    <!-- logo begin -->
                                    <div id="logo">
                                        <a href="<?php echo $base_path; ?>index.php">
                                            <img class="logo-main" src="<?php echo $base_path; ?>images/logo.png" alt="">
                                            <img class="logo-mobile" src="<?php echo $base_path; ?>images/logo-mobile.png" alt="">
                                        </a>
                                    </div>
                                    <!-- logo close -->
                                </div>
                            </div>
                            <div class="de-flex-col header-col-mid">
                                <ul id="mainmenu">
                                    <li><a class="menu-item" href="<?php echo $base_path; ?>index.php">Home</a></li>
                                    <li><a class="menu-item" href="<?php echo $base_path; ?>auctions.php">Lelang Aktif</a></li>
                                    <li><a class="menu-item" href="<?php echo $base_path; ?>gallery.php">Galeri</a></li>
                                    <li><a class="menu-item" href="<?php echo $base_path; ?>how-it-works.php">Cara Kerja</a></li>
                                    <li><a class="menu-item" href="<?php echo $base_path; ?>contact.php">Kontak</a></li>
                                </ul>
                            </div>
                            <div class="de-flex-col">
                                <div class="menu_side_area">
                                    <?php if(isset($_SESSION['user_id'])): ?>
                                        <!-- Notifications Icon -->
                                        <div class="notification-container header-notification">
                                            <button id="notification-toggle" class="notification-toggle">
                                                <i class="fa fa-bell"></i>
                                                <span id="notification-badge" class="notification-badge" style="display: none;">0</span>
                                            </button>
                                            <div id="notification-list" class="notification-list" style="display: none;">
                                                <div class="notification-loading">
                                                    <i class="fa fa-spinner fa-spin"></i> Memuat notifikasi...
                                                </div>
                                            </div>
                                        </div>

                                        <a href="<?php echo $base_path; ?>account.php" class="btn-line"><i class="fa fa-user"></i> Akun Saya</a>
                                        <span style="margin: 0 10px;">|</span>
                                        <?php if(isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1): ?>
                                            <a href="<?php echo $base_path; ?>admin/index.php" class="btn-line"><i class="fa fa-cog"></i> Admin</a>
                                            <span style="margin: 0 10px;">|</span>
                                        <?php endif; ?>
                                        <a href="<?php echo $base_path; ?>logout.php" class="btn-line">Logout</a>
                                    <?php else: ?>
                                        <a href="<?php echo $base_path; ?>login.php" class="btn-line">Masuk</a>
                                        <span style="margin: 0 10px;">|</span>
                                        <a href="<?php echo $base_path; ?>register.php" class="btn-line">Daftar</a>
                                    <?php endif; ?>
                                    <span id="menu-btn"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- header close -->
        <!-- content begin -->
        <div class="no-bottom no-top" id="content">
            <!-- float text begin -->
            <div class="float-text">
                <div class="de_social-icons">
                    <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                    <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                    <a href="#"><i class="fa fa-instagram fa-lg"></i></a>
                </div>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <span>Saldo: Rp. <?php echo number_format($_SESSION['balance'], 0, ',', '.'); ?></span>
                <?php else: ?>
                    <span><a href="register.php">Daftar Sekarang</a></span>
                <?php endif; ?>
            </div>
            <!-- float text close -->
