<?php
// Ensure this file is included by account.php and has access to $db, $user_id, $user_data, $csrf_token

if (!defined('ROOT_PATH')) {
    die("Direct access not allowed."); // Basic security check
}
?>

<h4>Profile Settings</h4>
<hr>
<form action="<?php echo htmlspecialchars(BASE_URL . 'account.php?tab=profile'); ?>" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="action" value="update_profile">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

    <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user_data['username'] ?? ''); ?>" readonly disabled>
        <small class="form-text text-muted">Username cannot be changed.</small>
    </div>

    <div class="mb-3">
        <label for="full_name" class="form-label">Full Name</label>
        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user_data['full_name'] ?? ''); ?>" required>
    </div>

    <div class="mb-3">
        <label for="email" class="form-label">Email Address</label>
        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email'] ?? ''); ?>" required>
    </div>
    
    <div class="mb-3">
        <label for="phone" class="form-label">Phone Number</label>
        <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($user_data['phone_number'] ?? ($user_data['phone'] ?? '')); // Check for phone_number or phone ?>">
    </div>

    <!-- 
    <div class="mb-3">
        <label class="form-label">Current Profile Picture</label>
        <div>
            <?php 
            // Construct profile picture path carefully
            // Assuming profile pictures are stored in a specific directory like 'uploads/profile_pictures/'
            // And the filename is stored in $user_data['profile_picture_filename']
            $profile_pic_path = ROOT_PATH . 'uploads/profile_pictures/' . ($user_data['profile_picture_filename'] ?? 'default_avatar.png');
            $profile_pic_url = BASE_URL . 'uploads/profile_pictures/' . ($user_data['profile_picture_filename'] ?? 'default_avatar.png');
            if (!file_exists($profile_pic_path) || empty($user_data['profile_picture_filename'])){
                $profile_pic_url = BASE_URL . 'assets/images/default_avatar.png'; // Path to a default avatar
            }
            ?>
            <img src="<?php echo htmlspecialchars($profile_pic_url); ?>" alt="Profile Picture" class="img-thumbnail" style="max-width: 150px; max-height: 150px; margin-bottom: 10px;">
        </div>
        <label for="profile_picture" class="form-label">Update Profile Picture (Optional)</label>
        <input type="file" class="form-control" id="profile_picture" name="profile_picture" accept="image/jpeg, image/png, image/gif">
        <small class="form-text text-muted">Max file size: 2MB. Allowed types: JPG, PNG, GIF. Leave blank if not changing.</small>
    </div>
    -->
    
    <button type="submit" class="btn btn-primary">Update Profile</button>
</form>
