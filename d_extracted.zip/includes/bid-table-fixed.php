<?php
/**
 * Partial file untuk bid table yang sudah diperbaiki
 * File ini akan di-include di account.php
 */

// Pastikan user_id sudah didefinisikan
if (!isset($user_id) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
}

// Inisialisasi variabel bids
$active_bids_count = 0;
$winning_bids_count = 0;
$total_bids_count = 0;

// Query untuk mengambil penawaran user
$bids_sql = "SELECT b.*, v.make, v.model, v.year, v.auction_end AS end_date, v.starting_price 
             FROM bids b 
             LEFT JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
             WHERE b.bidder_id = ? 
             ORDER BY b.bid_time DESC";
$stmt = $conn->prepare($bids_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$bids_result = $stmt->get_result();

// Hitung jumlah bid aktif dan menang
if (is_valid_result($bids_result)) {
    $total_bids_count = $bids_result->num_rows;
    while ($bid = $bids_result->fetch_assoc()) {
        if (is_bid_active($bid)) {
            $active_bids_count++;
            if (get_value($bid, 'is_winning') == 1) {
                $winning_bids_count++;
            }
        }
    }
}
?>

<!-- Bids Grid -->
<div class="premium-card mt-4">
    <div class="card-body">
        <?php if (!is_valid_result($bids_result) || $bids_result->num_rows == 0): ?>
        <div class="text-center p-4">
            <div class="empty-state">
                <i class="fa fa-gavel fa-3x text-muted mb-3"></i>
                <h5>Belum Ada Penawaran</h5>
                <p class="text-muted">Anda belum membuat penawaran apapun.</p>
                <a href="vehicle-list.php" class="btn premium-btn premium-btn-primary mt-3">
                    <i class="fa fa-search me-2"></i>Lihat Kendaraan
                </a>
            </div>
        </div>
        <?php else: ?>
        <div class="bid-cards-grid">
            <?php 
            // Reset pointer
            if (is_valid_result($bids_result)) {
                $bids_result->data_seek(0);
                while ($bid = $bids_result->fetch_assoc()): 
                    // Tentukan status dan kelas
                    $status_class = "";
                    $status_text = "";
                    
                    if (is_bid_active($bid)) {
                        if (get_value($bid, 'is_winning') == 1) {
                            $status_class = "winning";
                            $status_text = "Tertinggi";
                        } else {
                            $status_class = "active";
                            $status_text = "Aktif";
                        }
                    } else {
                        if (get_value($bid, 'is_winning') == 1) {
                            $status_class = "won";
                            $status_text = "Menang";
                        } else {
                            $status_class = "ended";
                            $status_text = "Berakhir";
                        }
                    }
            ?>
            <div class="bid-card <?php echo $status_class; ?>">
                <div class="bid-card-header">
                    <div class="bid-status-badge <?php echo $status_class; ?>">
                        <?php if ($status_class == 'winning' || $status_class == 'won'): ?>
                            <i class="fa fa-trophy"></i>
                        <?php endif; ?>
                        <?php echo $status_text; ?>
                    </div>
                    <div class="bid-time">
                        <?php echo get_formatted_date($bid, 'bid_time', 'd M Y'); ?>
                    </div>
                </div>
                <div class="bid-card-image">
                    <img src="images/no-image.svg" alt="<?php echo get_value($bid, 'make') . ' ' . get_value($bid, 'model'); ?>">
                </div>
                <div class="bid-card-vehicle">
                    <h5><?php echo get_value($bid, 'make', 'Merek') . ' ' . get_value($bid, 'model', 'Model'); ?></h5>
                    <p class="text-muted"><?php echo get_value($bid, 'year', 'Tahun tidak diketahui'); ?></p>
                </div>
                <div class="bid-card-details">
                    <div class="bid-amount">
                        <span class="label">Bid Anda:</span>
                        <span class="amount">Rp <?php echo safe_format_currency(get_value($bid, 'bid_amount')); ?></span>
                    </div>
                    <div class="starting-price">
                        <span class="label">Harga Awal:</span>
                        <span class="price">Rp <?php echo safe_format_currency(get_value($bid, 'starting_price')); ?></span>
                    </div>
                </div>
                <div class="bid-card-footer">
                    <?php if (is_bid_active($bid)): ?>
                    <div class="countdown">
                        <i class="fa fa-clock me-1"></i>
                        Sisa: <?php echo get_bid_remaining_time($bid); ?>
                    </div>
                    <a href="vehicle.php?id=<?php echo get_value($bid, 'vehicle_id'); ?>" class="btn premium-btn premium-btn-sm premium-btn-primary">
                        <i class="fa fa-plus-circle me-1"></i>Naikkan Bid
                    </a>
                    <?php else: ?>
                    <div class="countdown ended">
                        <i class="fa fa-check-circle me-1"></i>
                        Lelang Berakhir
                    </div>
                    <a href="vehicle.php?id=<?php echo get_value($bid, 'vehicle_id'); ?>" class="btn premium-btn premium-btn-sm premium-btn-outline">
                        <i class="fa fa-eye me-1"></i>Detail
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php 
                endwhile; 
            }
            ?>
        </div>
        <?php endif; ?>
    </div>
</div>
