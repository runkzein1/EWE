<?php
/**
 * Trust Badges Component
 * Menampilkan badge kepercayaan dan jaminan untuk LelangMobil
 */
?>

<div class="trust-badges-container">
    <div class="trust-badge-title">Jaminan & Keamanan</div>
    
    <div class="trust-badges-row">
        <div class="trust-badge">
            <i class="fas fa-shield-alt"></i>
            <span>100% Aman & Terpercaya</span>
            <div class="badge-tooltip">Transaksi dijamin aman dengan sistem escrow dan keamanan data berlapis</div>
        </div>
        
        <div class="trust-badge">
            <i class="fas fa-check-circle"></i>
            <span>Terverifikasi OJK</span>
            <div class="badge-tooltip">Terdaftar dan diawasi oleh Otoritas Jasa Keuangan Indonesia</div>
        </div>
        
        <div class="trust-badge">
            <i class="fas fa-lock"></i>
            <span>Enkripsi 256-bit SSL</span>
            <div class="badge-tooltip">Data Anda dilindungi dengan teknologi enkripsi tingkat perbankan</div>
        </div>
        
        <div class="trust-badge">
            <i class="fas fa-certificate"></i>
            <span>Bersertifikat ISO 27001</span>
            <div class="badge-tooltip">Standar internasional untuk keamanan informasi</div>
        </div>
    </div>
    
    <div class="secure-payment-row">
        <div class="secure-title">Metode Pembayaran</div>
        <div class="payment-icons">
            <div class="payment-icon"><i class="fab fa-cc-visa"></i></div>
            <div class="payment-icon"><i class="fab fa-cc-mastercard"></i></div>
            <div class="payment-icon"><i class="fab fa-paypal"></i></div>
            <div class="payment-icon"><i class="fas fa-university"></i></div>
            <div class="payment-icon"><i class="fas fa-wallet"></i></div>
            <div class="payment-icon"><img src="images/icons/gopay.png" alt="GoPay"></div>
            <div class="payment-icon"><img src="images/icons/ovo.png" alt="OVO"></div>
            <div class="payment-icon"><img src="images/icons/dana.png" alt="DANA"></div>
        </div>
    </div>
    
    <div class="counter-stats">
        <div class="counter-item">
            <div class="counter-value">100,000+</div>
            <div class="counter-label">Pengguna Aktif</div>
        </div>
        <div class="counter-item">
            <div class="counter-value">50,000+</div>
            <div class="counter-label">Transaksi Sukses</div>
        </div>
        <div class="counter-item">
            <div class="counter-value">99.8%</div>
            <div class="counter-label">Tingkat Kepuasan</div>
        </div>
        <div class="counter-item">
            <div class="counter-value">4.9/5</div>
            <div class="counter-label">Rating Kepercayaan</div>
        </div>
    </div>
        </div>
        <div class="counter-item">
            <div class="counter-value">99.8%</div>
            <div class="counter-label">Puas</div>
        </div>
    </div>
</div>

<style>
.trust-badges-container {
    background: linear-gradient(135deg, rgba(33, 37, 41, 0.8), rgba(33, 37, 41, 0.9));
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 30px;
    border: 1px solid rgba(255, 215, 0, 0.3);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.trust-badge-title {
    font-size: 18px;
    font-weight: 700;
    text-align: center;
    margin-bottom: 15px;
    color: white;
    text-transform: uppercase;
    letter-spacing: 1px;
    position: relative;
    display: inline-block;
    padding-bottom: 10px;
    margin-left: auto;
    margin-right: auto;
    width: 100%;
}

.trust-badge-title:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 50px;
    height: 3px;
    background: linear-gradient(to right, var(--accent), var(--primary));
    border-radius: 3px;
}

.trust-badges-row {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.trust-badge {
    display: flex;
    align-items: center;
    background: linear-gradient(135deg, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.6));
    padding: 8px 15px;
    border-radius: 50px;
    margin: 5px;
    color: white;
    font-weight: 600;
    font-size: 14px;
    border: 1px solid rgba(255, 255, 255, 0.1);
}

.trust-badge i {
    margin-right: 8px;
    color: var(--accent);
    font-size: 16px;
}

.secure-payment-row {
    background: rgba(0, 0, 0, 0.2);
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 20px;
}

.secure-title {
    font-size: 14px;
    font-weight: 600;
    color: white;
    margin-bottom: 10px;
    text-align: center;
}

.payment-icons {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
}

.payment-icon {
    margin: 0 10px;
    font-size: 24px;
    color: rgba(255, 255, 255, 0.8);
    transition: all 0.3s ease;
}

.payment-icon:hover {
    color: var(--accent);
    transform: translateY(-3px);
}

.counter-stats {
    display: flex;
    justify-content: space-around;
    text-align: center;
}

.counter-item {
    padding: 10px;
}

.counter-value {
    font-size: 24px;
    font-weight: 700;
    color: var(--accent);
    margin-bottom: 5px;
}

.counter-label {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.7);
    text-transform: uppercase;
    letter-spacing: 1px;
}

@media (max-width: 768px) {
    .trust-badges-row {
        flex-direction: column;
        align-items: center;
    }
    
    .trust-badge {
        margin-bottom: 10px;
        width: 100%;
        justify-content: center;
    }
    
    .counter-stats {
        flex-direction: column;
    }
    
    .counter-item {
        margin-bottom: 15px;
    }
}
</style>
