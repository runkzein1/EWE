<?php
/**
 * Database Connection
 *
 * This file handles the database connection for the car auction website
 */

// Database connection constants
// Use constants from config.php if defined, otherwise use defaults
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'lelang_rz');
if (!defined('DB_PASS')) define('DB_PASS', 'Arunk@123');
if (!defined('DB_NAME')) define('DB_NAME', 'lelang_rz');

// For backward compatibility
if (!defined('DB_SERVER')) define('DB_SERVER', DB_HOST);
if (!defined('DB_USERNAME')) define('DB_USERNAME', DB_USER);
if (!defined('DB_PASSWORD')) define('DB_PASSWORD', DB_PASS);

// Enable secure database connection
define('DB_USE_SSL', false); // Set to true in production environment with SSL certificate

// Set connection timeout
$mysqli_driver = new mysqli_driver();
$mysqli_driver->report_mode = MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT;

// Set global execution time limit to prevent infinite loading
ini_set('max_execution_time', 10); // 10 seconds max execution time
ini_set('memory_limit', '64M');    // Memory limit to prevent resource exhaustion

// Attempt to connect to MySQL database with strict error handling
try {
    // Set timeout and buffer size for all connections
    ini_set('default_socket_timeout', 3); // 3 second timeout - stricter

    // Connection options array
    $connection_options = [];

    // Enable SSL if configured
    if (defined('DB_USE_SSL') && DB_USE_SSL) {
        $connection_options['ssl'] = [
            'verify_peer' => true,
            'verify_peer_name' => true
        ];
    }

    // Create connection with timeout options
    try {
        $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    } catch (Throwable $e) {
        // Try alternative connection parameters if first attempt fails
        error_log("First connection attempt failed, trying alternative parameters: " . $e->getMessage());
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    }

    // Check connection without using connect_error which might hang
    if (!$conn || $conn->connect_errno) {
        error_log("Database connection failed: " . ($conn ? $conn->connect_error : "Unable to connect to database"));
        throw new Exception("Koneksi database gagal: Silakan coba lagi nanti");
    }

    // Set character set and query timeout
    $conn->set_charset("utf8");

    // Set session wait_timeout to prevent sleeping connections
    $conn->query("SET SESSION wait_timeout=5");

    // Add a shorter query timeout
    $conn->options(MYSQLI_OPT_CONNECT_TIMEOUT, 3);

    // Set session variables for better performance
    $conn->query("SET SESSION wait_timeout=300"); // 5 minutes session timeout
    $conn->query("SET SESSION interactive_timeout=300");
    $conn->query("SET SESSION sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''))");

} catch (Exception $e) {
    // Log the error
    error_log("Database connection error: " . $e->getMessage());

    // For production, show a user-friendly message
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        // AJAX request
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Database connection error. Please try again later.']);
    } else {
        // Normal request
        echo '<div style="padding: 20px; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 5px; margin: 20px;">
                <h3>Database Connection Error</h3>
                <p>Sorry, we are experiencing technical difficulties. Please try again later.</p>
             </div>';
    }
    exit;
}
