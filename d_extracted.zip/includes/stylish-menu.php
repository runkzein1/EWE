<?php
// LelangMobil - Trust Indicators & Features Implementation
// This file creates a modern, trust-building section for the LelangMobil platform

// Get base path for assets
$current_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
$is_index = $current_url == '/' || $current_url == '/index.php';
$base_path = $is_index ? '' : '../';

// Define navigation menu items
$menu_items = array(
    array(
        'title' => 'Beranda',
        'description' => 'Kembali ke halaman utama',
        'icon' => 'fas fa-home',
        'image' => $base_path . 'images/menu/home.jpg',
        'url' => $base_path . 'index.php',
        'active' => (basename($_SERVER['PHP_SELF']) == 'index.php'),
        'notification' => false,
        'notification_text' => ''
    ),
    array(
        'title' => 'Lelang Aktif',
        'description' => 'Lihat semua lelang yang sedang berlangsung',
        'icon' => 'fas fa-gavel',
        'image' => $base_path . 'images/menu/auction.jpg',
        'url' => $base_path . 'auctions.php?status=active',
        'active' => (basename($_SERVER['PHP_SELF']) == 'auctions.php' && isset($_GET['status']) && $_GET['status'] == 'active'),
        'notification' => true,
        'notification_text' => 'Lelang Baru!'
    ),
    array(
        'title' => 'Semua Mobil',
        'description' => 'Lihat semua mobil yang tersedia',
        'icon' => 'fas fa-car',
        'image' => $base_path . 'images/menu/cars.jpg',
        'url' => $base_path . 'vehicles.php',
        'active' => (basename($_SERVER['PHP_SELF']) == 'vehicles.php'),
        'notification' => false,
        'notification_text' => ''
    ),
    array(
        'title' => 'Cara Kerja',
        'description' => 'Pelajari cara kerja lelang di platform kami',
        'icon' => 'fas fa-question-circle',
        'image' => $base_path . 'images/menu/how-it-works.jpg',
        'url' => $base_path . 'how-it-works.php',
        'active' => (basename($_SERVER['PHP_SELF']) == 'how-it-works.php'),
        'notification' => false,
        'notification_text' => ''
    ),
    array(
        'title' => 'Hubungi Kami',
        'description' => 'Pertanyaan? Hubungi tim kami',
        'icon' => 'fas fa-envelope',
        'image' => $base_path . 'images/menu/contact.jpg',
        'url' => $base_path . 'contact.php',
        'active' => (basename($_SERVER['PHP_SELF']) == 'contact.php'),
        'notification' => false,
        'notification_text' => ''
    ),
);

// Define trust features and statistics
$feature_items = array(
    array(
        'title' => 'LELANG TERJAMIN',
        'description' => 'Sistem lelang kami menjamin keamanan 100% dengan escrow payment dan verifikasi identitas untuk melindungi setiap transaksi Anda.',
        'icon' => 'fas fa-shield-check',
        'iconset' => '<div class="custom-icon shield-icon"><i class="fas fa-shield-alt"></i><i class="fas fa-check icon-small"></i></div>',
        'url' => $base_path . 'guarantee.php',
        'stat' => '100%',
        'stat_text' => 'SECURE',
        'logo_class' => 'secure-logo'
    ),
    array(
        'title' => 'INSPEKSI PROFESIONAL',
        'description' => 'Tim teknisi tersertifikasi melakukan inspeksi komprehensif 175+ poin pada setiap kendaraan sebelum dilelang di platform kami.',
        'icon' => 'fas fa-car-mechanic',
        'iconset' => '<div class="custom-icon inspection-icon"><i class="fas fa-car"></i><i class="fas fa-tools icon-small"></i></div>',
        'url' => $base_path . 'inspection.php',
        'stat' => '175+',
        'stat_text' => 'INSPECTION',
        'logo_class' => 'inspection-logo'
    ),
    array(
        'title' => 'KOMUNITAS PREMIUM',
        'description' => 'Bergabunglah dengan 15.000+ member eksklusif yang telah mempercayai LelangMobil untuk memperoleh kendaraan premium dengan nilai terbaik.',
        'icon' => 'fas fa-user-crown',
        'iconset' => '<div class="custom-icon users-icon"><i class="fas fa-users"></i><i class="fas fa-crown icon-small"></i></div>',
        'url' => $base_path . 'testimonials.php',
        'stat' => '15K+',
        'stat_text' => 'MEMBERS',
        'logo_class' => 'members-logo'
    ),
    array(
        'title' => 'REKOR TRANSAKSI',
        'description' => 'Dengan 8.500+ transaksi sukses, tingkat kepuasan pelanggan kami mencapai 98% - bukti komitmen kami terhadap kualitas.',
        'icon' => 'fas fa-medal',
        'iconset' => '<div class="custom-icon success-icon"><i class="fas fa-handshake"></i><i class="fas fa-medal icon-small"></i></div>',
        'url' => $base_path . 'success-stories.php',
        'stat' => '8.5K+',
        'stat_text' => 'DEALS',
        'logo_class' => 'deals-logo'
    ),
);

// Create menu image directory if it doesn't exist
$menu_image_dir = 'images/menu';
if (!file_exists($menu_image_dir)) {
    mkdir($menu_image_dir, 0755, true);

    // Generate placeholder menu images if they don't exist
    $menu_image_list = [
        'home-menu.jpg',
        'auction-menu.jpg',
        'premium-menu.jpg',
        'sell-menu.jpg',
        'how-menu.jpg'
    ];

    // Check if we have access to GD library to generate images
    if (function_exists('imagecreatetruecolor')) {
        foreach ($menu_image_list as $index => $image_name) {
            $image_path = $menu_image_dir . '/' . $image_name;
            
            if (!file_exists($image_path)) {
                // Create image
                $width = 800;
                $height = 400;
                $img = imagecreatetruecolor($width, $height);
                
                // Colors for different menu items
                $colors = [
                    [20, 30, 50],  // Home - Dark blue
                    [40, 80, 30],  // Auctions - Green
                    [80, 30, 40],  // Premium - Red
                    [60, 40, 20],  // Sell - Brown
                    [30, 40, 60]   // How it works - Blue
                ];
                
                // Use color based on index or default to dark blue
                $color_index = isset($colors[$index]) ? $index : 0;
                $r = $colors[$color_index][0];
                $g = $colors[$color_index][1];
                $b = $colors[$color_index][2];
                
                // Create colors
                $bg_color = imagecolorallocate($img, $r, $g, $b);
                $text_color = imagecolorallocate($img, 255, 255, 255);
                
                // Fill background
                imagefill($img, 0, 0, $bg_color);
                
                // Add text
                $menu_title = str_replace('-menu.jpg', '', $image_name);
                $menu_title = ucfirst($menu_title);
                $font_size = 5;
                
                // Center text
                $text_width = strlen($menu_title) * imagefontwidth($font_size);
                $text_x = ($width - $text_width) / 2;
                
                imagestring($img, $font_size, $text_x, $height/2 - 10, $menu_title, $text_color);
                
                // Add LelangMobil text
                $label = "LelangMobil";
                $label_width = strlen($label) * imagefontwidth(3);
                $label_x = ($width - $label_width) / 2;
                imagestring($img, 3, $label_x, $height/2 + 20, $label, $text_color);
                
                // Save the image
                imagejpeg($img, $image_path, 90);
                imagedestroy($img);
            }
        }
    }
}
?>

<!-- Include custom menu CSS -->
<link href="<?php echo $base_path; ?>css/menu-style.css" rel="stylesheet" type="text/css">

<!-- LelangMobil Trust Indicators -->
<div class="container my-5">
    <div class="row">
        <div class="col-lg-12 text-center mb-4">
            <div class="trust-heading-wrapper">
                <h2 class="trust-heading">Lelang Mobil <span class="text-gradient">Terpercaya</span> di Indonesia</h2>
                <div class="ratings-wrapper">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="ratings-count">Berdasarkan 3.457 ulasan</div>
                </div>
            </div>
            <p class="trust-subheading">Kenapa memilih LelangMobil untuk transaksi kendaraan Anda?</p>
            <div class="trust-highlight">Sudah <span class="highlight-count">12.654+</span> transaksi lelang berhasil dilakukan sejak 2020</div>
        </div>
    </div>
    
    <div class="trust-indicators-container">
        <div class="row">
            <?php foreach ($feature_items as $item): ?>
            <div class="col-md-6 col-lg-3 mb-4">
                <div class="trust-card animate-card">
                    <div class="trust-card-logo">
                        <div class="trust-logo-container">
                            <div class="trust-logo-circle <?php echo $item['logo_class']; ?>">
                                <?php echo $item['iconset']; ?>
                            </div>
                        </div>
                    </div>
                    <div class="trust-card-top">
                        <div class="trust-icon-container <?php echo $item['logo_class']; ?>">
                            <?php echo $item['iconset']; ?>
                        </div>
                        <div class="trust-stat-box">
                            <div class="stat-value-container">
                                <span class="trust-stat"><?php echo $item['stat']; ?></span>
                                <div class="pulse-circle"></div>
                            </div>
                            <span class="trust-stat-label"><?php echo $item['stat_text']; ?></span>
                        </div>
                    </div>
                    <div class="trust-card-content">
                        <h3 class="trust-title"><?php echo $item['title']; ?></h3>
                        <div class="trust-divider"></div>
                        <p class="trust-description"><?php echo $item['description']; ?></p>
                    </div>
                    <div class="trust-card-footer">
                        <a href="<?php echo $item['url']; ?>" class="trust-link">Pelajari Lebih Lanjut <i class="fa fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Certification Badges -->
    <div class="certification-container mt-5 text-center">
        <div class="row">
            <div class="col-lg-12 mb-4">
                <h3 class="certification-title">Platform Lelang Mobil <span class="premium-text">Bersertifikasi</span></h3>
                <div class="certification-subtitle">Standar keamanan dan kualitas tertinggi</div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="certification-badges">
                    <div class="certification-badge">
                        <div class="badge-icon premium-badge">
                            <i class="fas fa-lock"></i>
                            <div class="badge-glow"></div>
                        </div>
                        <span>Pembayaran Aman</span>
                        <div class="certification-detail">100% Secure Gateway</div>
                    </div>
                    <div class="certification-badge">
                        <div class="badge-icon premium-badge">
                            <i class="fas fa-certificate"></i>
                            <div class="badge-glow"></div>
                        </div>
                        <span>Dealer Bersertifikat</span>
                        <div class="certification-detail">Verified Partners</div>
                    </div>
                    <div class="certification-badge">
                        <div class="badge-icon premium-badge">
                            <i class="fas fa-check-circle"></i>
                            <div class="badge-glow"></div>
                        </div>
                        <span>Kendaraan Terverifikasi</span>
                        <div class="certification-detail">Quality Assured</div>
                    </div>
                    <div class="certification-badge">
                        <div class="badge-icon premium-badge">
                            <i class="fas fa-shield-alt"></i>
                            <div class="badge-glow"></div>
                        </div>
                        <span>Jaminan Uang Kembali</span>
                        <div class="certification-detail">100% Money Back</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="trusted-by-container mt-4">
            <div class="trusted-label">Dipercaya oleh:</div>
            <div class="trusted-logos">
                <div class="trusted-logo"><i class="fab fa-cc-visa"></i></div>
                <div class="trusted-logo"><i class="fab fa-cc-mastercard"></i></div>
                <div class="trusted-logo"><i class="fab fa-paypal"></i></div>
                <div class="trusted-logo"><i class="fas fa-university"></i></div>
            </div>
        </div>
    </div>
</div>
<!-- End LelangMobil Trust Indicators -->
