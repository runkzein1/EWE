<?php
/**
 * User Data Warning Banner
 * Shows a warning banner when using fallback user data
 */
if (isset($user['_is_fallback']) && $user['_is_fallback']): 
?>
<div class="alert alert-warning mb-4 fade-in-up">
    <div class="d-flex align-items-center">
        <i class="fas fa-exclamation-triangle fs-4 me-3"></i>
        <div>
            <strong>Perhatian:</strong> Kami mengalami kendala teknis saat memuat data pengguna lengkap Anda. 
            Beberapa fitur mungkin tidak tersedia. Tim kami sedang mengatasi masalah ini.
            <div class="mt-2">
                <a href="support.php" class="btn btn-sm btn-outline-dark">
                    <i class="fas fa-headset me-1"></i> Hubungi Support
                </a>
                <a href="account.php?refresh=1" class="btn btn-sm btn-outline-primary ms-2">
                    <i class="fas fa-sync-alt me-1"></i> Coba Lagi
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
