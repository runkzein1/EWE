/**
 * Profile Modern JS - LelangMobil
 * Modul JavaScript untuk halaman profil pengguna (profile-menu.php)
 * Versi: 1.0 (6 Mei 2025)
 */

document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi variabel dan elemen
    const profileForm = document.getElementById('profileForm');
    const passwordChangeForm = document.getElementById('passwordChangeForm');
    const photoUploadForm = document.getElementById('photoUploadForm');
    const fileInput = document.getElementById('profile_photo');
    const uploadArea = document.getElementById('uploadArea');
    const previewContainer = document.getElementById('previewContainer');
    const imagePreview = document.getElementById('imagePreview');
    const removeImageBtn = document.getElementById('removeImage');
    const uploadButton = document.getElementById('uploadButton');
    const currentPasswordInput = document.getElementById('current_password');
    const newPasswordInput = document.getElementById('new_password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    const passwordStrengthBar = document.getElementById('password-strength-bar');
    const passwordStrengthText = document.getElementById('password-strength-text');
    const passwordMatch = document.getElementById('password-match');
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');
    
    // Handler untuk drag & drop foto profil
    if (uploadArea && fileInput) {
        // Drag & drop events
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, preventDefaults, false);
        });
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        // Highlight drop area ketika file di-drag di atasnya
        ['dragenter', 'dragover'].forEach(eventName => {
            uploadArea.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, unhighlight, false);
        });
        
        function highlight() {
            uploadArea.classList.add('highlight');
        }
        
        function unhighlight() {
            uploadArea.classList.remove('highlight');
        }
        
        // Handle dropped files
        uploadArea.addEventListener('drop', handleDrop, false);
        
        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            
            if (files.length) {
                fileInput.files = files;
                handleFiles(files);
            }
        }
        
        // Handle selected files via file input
        fileInput.addEventListener('change', function() {
            handleFiles(this.files);
        });
        
        function handleFiles(files) {
            if (files.length) {
                const file = files[0];
                
                // Validasi tipe file
                const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
                if (!allowedTypes.includes(file.type)) {
                    alert('Hanya file JPEG, JPG dan PNG yang didukung.');
                    fileInput.value = '';
                    return;
                }
                
                // Validasi ukuran file (max 5MB)
                if (file.size > 5 * 1024 * 1024) {
                    alert('Ukuran file tidak boleh lebih dari 5MB.');
                    fileInput.value = '';
                    return;
                }
                
                // Preview gambar
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    previewContainer.classList.remove('d-none');
                    uploadButton.disabled = false;
                };
                reader.readAsDataURL(file);
            }
        }
        
        // Remove image preview
        if (removeImageBtn) {
            removeImageBtn.addEventListener('click', function() {
                previewContainer.classList.add('d-none');
                fileInput.value = '';
                uploadButton.disabled = true;
            });
        }
    }
    
    // Password strength meter
    if (newPasswordInput && passwordStrengthBar && passwordStrengthText) {
        newPasswordInput.addEventListener('input', function() {
            const password = this.value;
            const strength = calculatePasswordStrength(password);
            
            // Update progress bar
            passwordStrengthBar.style.width = strength.score + '%';
            passwordStrengthBar.className = 'progress-bar';
            passwordStrengthBar.classList.add('bg-' + strength.color);
            
            // Update text
            passwordStrengthText.textContent = 'Kekuatan password: ' + strength.label;
            
            // Check password match
            checkPasswordMatch();
        });
    }
    
    // Password match confirmation
    if (newPasswordInput && confirmPasswordInput && passwordMatch) {
        confirmPasswordInput.addEventListener('input', checkPasswordMatch);
    }
    
    function checkPasswordMatch() {
        if (!newPasswordInput.value || !confirmPasswordInput.value) {
            passwordMatch.textContent = '';
            return;
        }
        
        if (newPasswordInput.value === confirmPasswordInput.value) {
            passwordMatch.textContent = 'Password cocok';
            passwordMatch.className = 'form-text text-success';
        } else {
            passwordMatch.textContent = 'Password tidak cocok';
            passwordMatch.className = 'form-text text-danger';
        }
    }
    
    // Calculate password strength
    function calculatePasswordStrength(password) {
        // Jika password kosong
        if (!password) {
            return { score: 0, label: 'Belum diisi', color: 'secondary' };
        }
        
        let score = 0;
        
        // Panjang password
        if (password.length >= 8) score += 20;
        if (password.length >= 12) score += 10;
        
        // Kompleksitas
        if (/[a-z]/.test(password)) score += 10; // Huruf kecil
        if (/[A-Z]/.test(password)) score += 15; // Huruf besar
        if (/[0-9]/.test(password)) score += 15; // Angka
        if (/[^a-zA-Z0-9]/.test(password)) score += 20; // Karakter khusus
        
        // Variasi karakter
        const uniqueChars = [...new Set(password.split(''))].length;
        score += uniqueChars > 5 ? 10 : 0;
        
        // Tentukan kategori kekuatan
        let label, color;
        if (score < 30) {
            label = 'Sangat lemah';
            color = 'danger';
        } else if (score < 50) {
            label = 'Lemah';
            color = 'warning';
        } else if (score < 70) {
            label = 'Sedang';
            color = 'info';
        } else if (score < 90) {
            label = 'Kuat';
            color = 'primary';
        } else {
            label = 'Sangat kuat';
            color = 'success';
        }
        
        return { score, label, color };
    }
    
    // Toggle password visibility
    if (togglePasswordButtons.length > 0) {
        togglePasswordButtons.forEach(button => {
            button.addEventListener('click', function() {
                const targetId = this.dataset.target;
                const targetInput = document.getElementById(targetId);
                
                if (targetInput) {
                    // Toggle tipe input
                    if (targetInput.type === 'password') {
                        targetInput.type = 'text';
                        this.innerHTML = '<i class="fa fa-eye-slash"></i>';
                    } else {
                        targetInput.type = 'password';
                        this.innerHTML = '<i class="fa fa-eye"></i>';
                    }
                }
            });
        });
    }
    
    // Handle form submission
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            // Validasi form jika diperlukan
            // Di sini bisa ditambahkan validasi tambahan jika diperlukan
        });
    }
    
    // Handle password change form
    if (passwordChangeForm) {
        passwordChangeForm.addEventListener('submit', function(e) {
            // Validasi password baru dan konfirmasi password
            if (newPasswordInput.value !== confirmPasswordInput.value) {
                e.preventDefault();
                alert('Password baru dan konfirmasi password tidak cocok.');
                return;
            }
            
            // Validasi kekuatan password
            const strength = calculatePasswordStrength(newPasswordInput.value);
            if (strength.score < 50) {
                if (!confirm('Password Anda tergolong lemah. Lanjutkan?')) {
                    e.preventDefault();
                    return;
                }
            }
        });
    }
    
    // Smooth scroll to form sections
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
                
                // Highlight target section briefly
                targetElement.classList.add('highlight-section');
                setTimeout(() => {
                    targetElement.classList.remove('highlight-section');
                }, 1500);
            }
        });
    });
    
    // Success animation
    const successAnimation = document.querySelector('.success-animation');
    if (successAnimation) {
        setTimeout(() => {
            successAnimation.querySelector('.checkmark-circle').classList.add('animate');
        }, 500);
    }
});
