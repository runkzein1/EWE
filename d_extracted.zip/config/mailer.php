<?php
// Email configuration and functions for LelangMobil

// Get SMTP settings from database
function get_smtp_settings($conn) {
    $settings = array();
    $keys = array(
        'smtp_host', 
        'smtp_port', 
        'smtp_username', 
        'smtp_password', 
        'smtp_secure',
        'smtp_from_email',
        'smtp_from_name'
    );
    
    foreach ($keys as $key) {
        $sql = "SELECT setting_value FROM settings WHERE setting_key = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $key);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $settings[$key] = $row['setting_value'];
        } else {
            // Default values if not found in database
            switch ($key) {
                case 'smtp_host':
                    $settings[$key] = 'mail.lelangmobil.com';
                    break;
                case 'smtp_port':
                    $settings[$key] = '465';
                    break;
                case 'smtp_username':
                    $settings[$key] = 'support@lelangmobil.com';
                    break;
                case 'smtp_password':
                    $settings[$key] = 'Arunk@123';
                    break;
                case 'smtp_secure':
                    $settings[$key] = 'ssl';
                    break;
                case 'smtp_from_email':
                    $settings[$key] = 'support@lelangmobil.com';
                    break;
                case 'smtp_from_name':
                    $settings[$key] = 'LelangMobil';
                    break;
            }
        }
    }
    
    return $settings;
}

// Send email function using PHP's mail() function
function send_email($conn, $to, $subject, $body, $altBody = '') {
    $settings = get_smtp_settings($conn);
    
    // Email headers
    $headers = "From: {$settings['smtp_from_name']} <{$settings['smtp_from_email']}>\r\n";
    $headers .= "Reply-To: {$settings['smtp_from_email']}\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    // Attempt to send email
    $success = mail($to, $subject, $body, $headers);
    
    // Log if email fails
    if (!$success) {
        error_log("Email sending failed to: $to, subject: $subject");
    }
    
    return $success;
}

// Send verification email
function send_verification_email($conn, $email, $token, $user_id) {
    // Buat URL yang lebih andal dengan mempertimbangkan struktur direktori
    $base_url = 'http://' . $_SERVER['HTTP_HOST'];
    
    // Ambil direktori saat ini (jika bukan di root web server)
    $current_dir = dirname($_SERVER['PHP_SELF']);
    $current_dir = ($current_dir == '/' || $current_dir == '\\') ? '' : $current_dir;
    
    // Jika kita berada di subdirektori config, navigasi satu level ke atas
    if (basename($current_dir) == 'config') {
        $current_dir = dirname($current_dir);
    }
    
    $verify_url = $base_url . $current_dir . '/verify.php?token=' . $token . '&user_id=' . $user_id;
    
    $subject = 'Verifikasi Akun LelangMobil Anda';
    
    $body = '
    <html>
    <head>
        <title>Verifikasi Akun LelangMobil</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 5px; background-color: #f9f9f9;">
            <div style="text-align: center; margin-bottom: 20px;">
                <img src="http://' . $_SERVER['HTTP_HOST'] . '/images/logo.png" alt="LelangMobil Logo" style="max-width: 200px;">
            </div>
            <h2 style="color: #4a6ee0;">Verifikasi Akun LelangMobil Anda</h2>
            <p>Terima kasih telah mendaftar di LelangMobil! Untuk melanjutkan, silakan verifikasi alamat email Anda dengan mengklik tombol di bawah ini:</p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="' . $verify_url . '" style="background-color: #4a6ee0; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">Verifikasi Email</a>
            </div>
            <p>Atau salin dan tempel URL berikut ke browser Anda:</p>
            <p style="background-color: #eee; padding: 10px; border-radius: 4px; word-break: break-all;">' . $verify_url . '</p>
            <p>Link ini akan kedaluwarsa dalam 24 jam.</p>
            <p>Jika Anda tidak membuat permintaan ini, silakan abaikan email ini.</p>
            <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; font-size: 12px; color: #888;">
                <p>Email ini dikirim secara otomatis, mohon jangan balas.</p>
                <p>&copy; ' . date('Y') . ' LelangMobil. Seluruh hak cipta dilindungi.</p>
            </div>
        </div>
    </body>
    </html>';
    
    return send_email($conn, $email, $subject, $body);
}

// Send registration success email
function send_welcome_email($conn, $email, $username) {
    $login_url = 'http://' . $_SERVER['HTTP_HOST'] . '/login.php';
    
    $subject = 'Selamat Datang di LelangMobil';
    
    $body = '
    <html>
    <head>
        <title>Selamat Datang di LelangMobil</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 5px; background-color: #f9f9f9;">
            <div style="text-align: center; margin-bottom: 20px;">
                <img src="http://' . $_SERVER['HTTP_HOST'] . '/images/logo.png" alt="LelangMobil Logo" style="max-width: 200px;">
            </div>
            <h2 style="color: #4a6ee0;">Selamat Datang di LelangMobil, ' . $username . '!</h2>
            <p>Akun Anda telah berhasil diverifikasi. Sekarang Anda dapat masuk dan mulai menjelajahi lelang mobil yang tersedia.</p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="' . $login_url . '" style="background-color: #4a6ee0; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">Masuk Sekarang</a>
            </div>
            <p>Dengan akun LelangMobil, Anda dapat:</p>
            <ul style="padding-left: 20px;">
                <li>Mengikuti lelang kendaraan dari berbagai merk dan model</li>
                <li>Menawar kendaraan impian Anda dengan harga yang kompetitif</li>
                <li>Melacak dan mengelola tawaran Anda dengan mudah</li>
                <li>Menerima notifikasi tentang lelang yang segera berakhir</li>
            </ul>
            <p>Jika Anda memiliki pertanyaan, jangan ragu untuk menghubungi tim dukungan kami.</p>
            <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; font-size: 12px; color: #888;">
                <p>Email ini dikirim secara otomatis, mohon jangan balas.</p>
                <p>&copy; ' . date('Y') . ' LelangMobil. Seluruh hak cipta dilindungi.</p>
            </div>
        </div>
    </body>
    </html>';
    
    return send_email($conn, $email, $subject, $body);
}

// Send password reset email
function send_reset_password_email($conn, $email, $token, $user_id) {
    // Create a reliable URL considering directory structure
    $base_url = 'http://' . $_SERVER['HTTP_HOST'];
    
    // Get current directory (if not in web server root)
    $current_dir = dirname($_SERVER['PHP_SELF']);
    $current_dir = ($current_dir == '/' || $current_dir == '\\') ? '' : $current_dir;
    
    // If we are in a subdirectory like config, navigate one level up
    if (basename($current_dir) == 'config') {
        $current_dir = dirname($current_dir);
    }
    
    $reset_url = $base_url . $current_dir . '/reset-password.php?token=' . $token . '&user_id=' . $user_id;
    
    $subject = 'Reset Password LelangMobil';
    
    $body = '
    <html>
    <head>
        <title>Reset Password LelangMobil</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 5px; background-color: #f9f9f9;">
            <div style="text-align: center; margin-bottom: 20px;">
                <img src="http://' . $_SERVER['HTTP_HOST'] . '/images/logo.png" alt="LelangMobil Logo" style="max-width: 200px;">
            </div>
            <h2 style="color: #4a6ee0;">Reset Password LelangMobil</h2>
            <p>Kami menerima permintaan untuk reset password akun LelangMobil Anda. Silakan klik tombol di bawah ini untuk melanjutkan:</p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="' . $reset_url . '" style="background-color: #4a6ee0; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">Reset Password</a>
            </div>
            <p>Atau salin dan tempel URL berikut ke browser Anda:</p>
            <p style="background-color: #eee; padding: 10px; border-radius: 4px; word-break: break-all;">' . $reset_url . '</p>
            <p>Link ini akan kedaluwarsa dalam 1 jam.</p>
            <p>Jika Anda tidak membuat permintaan ini, silakan abaikan email ini dan password Anda tidak akan berubah.</p>
            <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; font-size: 12px; color: #888;">
                <p>Email ini dikirim secara otomatis, mohon jangan balas.</p>
                <p>&copy; ' . date('Y') . ' LelangMobil. Seluruh hak cipta dilindungi.</p>
            </div>
        </div>
    </body>
    </html>';
    
    return send_email($conn, $email, $subject, $body);
}
?>
