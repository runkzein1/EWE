/**
 * Transaction Filters JavaScript
 * Mengelola filter dan pencarian di halaman transaksi LelangMobil
 * Versi: 1.0 (2 Mei 2025)
 */

document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi filter transaksi
    initTransactionFilters();
    
    // Inisialisasi datepicker
    initDatepicker();
    
    // Inisialisasi export functionality
    initExportFunctions();
});

/**
 * Inisialisasi filter transaksi
 */
function initTransactionFilters() {
    // Referensi ke elemen filter
    const transactionType = document.getElementById('transaction-type');
    const transactionStatus = document.getElementById('transaction-status');
    const dateFrom = document.getElementById('date-from');
    const dateTo = document.getElementById('date-to');
    const filterButton = document.querySelector('.filter-transaction-btn');
    const resetButton = document.querySelector('.reset-filter-btn');
    const searchInput = document.querySelector('.transaction-search-input');
    
    // Tabel transaksi
    const transactionTable = document.querySelector('.transaction-table');
    const transactionRows = transactionTable ? transactionTable.querySelectorAll('tbody tr') : [];
    
    // Jika elemen tidak ditemukan, return
    if (!transactionTable || !filterButton) return;
    
    // Filter button click event
    filterButton.addEventListener('click', function() {
        const filterData = {
            type: transactionType ? transactionType.value : '',
            status: transactionStatus ? transactionStatus.value : '',
            dateFrom: dateFrom ? dateFrom.value : '',
            dateTo: dateTo ? dateTo.value : '',
            search: searchInput ? searchInput.value.toLowerCase() : ''
        };
        
        filterTransactions(transactionRows, filterData);
    });
    
    // Reset filter button
    if (resetButton) {
        resetButton.addEventListener('click', function() {
            if (transactionType) transactionType.value = '';
            if (transactionStatus) transactionStatus.value = '';
            if (dateFrom) dateFrom.value = '';
            if (dateTo) dateTo.value = '';
            if (searchInput) searchInput.value = '';
            
            // Show all rows
            transactionRows.forEach(row => {
                row.style.display = '';
            });
        });
    }
    
    // Realtime search with debounce untuk performa dan pengalaman pengguna yang lebih baik
    if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', function() {
            // Visual feedback untuk user
            this.classList.add('filtering');
            // Clear timeout sebelumnya
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                const filterData = {
                    type: transactionType ? transactionType.value : '',
                    status: transactionStatus ? transactionStatus.value : '',
                    dateFrom: dateFrom ? dateFrom.value : '',
                    dateTo: dateTo ? dateTo.value : '',
                    search: this.value.toLowerCase()
                };
                
                filterTransactions(transactionRows, filterData);
                // Hapus kelas filtering setelah selesai
                this.classList.remove('filtering');
            }, 300);
        });
    }
}

/**
 * Filter transaksi berdasarkan kriteria
 * @param {NodeList} rows - Rows to filter
 * @param {Object} filterData - Filter criteria
 */
function filterTransactions(rows, filterData) {
    if (!rows.length) return;
    
    // Counter untuk statistik
    let totalVisible = 0;
    let totalAmount = 0;
    
    rows.forEach(row => {
        let matchType = true;
        let matchStatus = true;
        let matchDate = true;
        let matchSearch = true;
        
        // Filter by type
        if (filterData.type) {
            const rowType = row.getAttribute('data-type');
            matchType = rowType === filterData.type;
        }
        
        // Filter by status
        if (filterData.status) {
            const rowStatus = row.getAttribute('data-status');
            matchStatus = rowStatus === filterData.status;
        }
        
        // Filter by date range
        if (filterData.dateFrom || filterData.dateTo) {
            const rowDateStr = row.getAttribute('data-date');
            if (rowDateStr) {
                const rowDate = new Date(rowDateStr);
                
                if (filterData.dateFrom) {
                    const fromDate = new Date(filterData.dateFrom);
                    matchDate = matchDate && rowDate >= fromDate;
                }
                
                if (filterData.dateTo) {
                    const toDate = new Date(filterData.dateTo);
                    toDate.setHours(23, 59, 59); // End of day
                    matchDate = matchDate && rowDate <= toDate;
                }
            }
        }
        
        // Filter by search text
        if (filterData.search) {
            const rowText = row.textContent.toLowerCase();
            matchSearch = rowText.includes(filterData.search);
        }
        
        // Show/hide row based on all filters
        const isVisible = matchType && matchStatus && matchDate && matchSearch;
        row.style.display = isVisible ? '' : 'none';
        
        // Count for statistics
        if (isVisible) {
            totalVisible++;
            const amountCell = row.querySelector('.transaction-amount');
            if (amountCell) {
                const amount = parseFloat(amountCell.getAttribute('data-amount') || 0);
                totalAmount += amount;
            }
        }
    });
    
    // Update filter stats if elements exist
    const statsElement = document.getElementById('filter-stats');
    if (statsElement) {
        statsElement.textContent = `Menampilkan ${totalVisible} dari ${rows.length} transaksi`;
    }
    
    const totalElement = document.getElementById('filter-total-amount');
    if (totalElement) {
        const formatter = new Intl.NumberFormat('id-ID');
        totalElement.textContent = `Total: Rp ${formatter.format(totalAmount)}`;
    }
}

/**
 * Inisialisasi datepicker
 */
function initDatepicker() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    
    // Set default date range (1 bulan terakhir)
    const today = new Date();
    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
    
    // Format dates for input
    const formatDate = (date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    };
    
    // Apply to date inputs if empty
    dateInputs.forEach(input => {
        if (input.id === 'date-from' && !input.value) {
            input.value = formatDate(oneMonthAgo);
        } else if (input.id === 'date-to' && !input.value) {
            input.value = formatDate(today);
        }
    });
}

/**
 * Inisialisasi fungsi export
 */
function initExportFunctions() {
    const exportButtons = document.querySelectorAll('.export-transaction-btn');
    
    exportButtons.forEach(button => {
        button.addEventListener('click', function() {
            const format = this.getAttribute('data-format');
            const tableId = this.getAttribute('data-table') || 'transaction-table';
            const table = document.getElementById(tableId);
            
            if (!table) return;
            
            if (format === 'csv') {
                exportTableToCSV(table, 'transaksi_lelangmobil.csv');
            } else if (format === 'pdf') {
                exportTableToPDF(table, 'transaksi_lelangmobil.pdf');
            } else if (format === 'excel') {
                exportTableToExcel(table, 'transaksi_lelangmobil.xlsx');
            }
        });
    });
}

/**
 * Export tabel ke CSV
 * @param {HTMLElement} table - Table element
 * @param {string} filename - Output filename
 */
function exportTableToCSV(table, filename) {
    const rows = table.querySelectorAll('tr');
    let csv = [];
    
    for (let i = 0; i < rows.length; i++) {
        const row = [];
        const cols = rows[i].querySelectorAll('td, th');
        
        for (let j = 0; j < cols.length; j++) {
            // Clean text and handle quotes
            let text = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/"/g, '""');
            row.push(`"${text}"`);
        }
        
        csv.push(row.join(','));
    }
    
    const csvText = csv.join('\n');
    const blob = new Blob([csvText], { type: 'text/csv;charset=utf-8;' });
    
    // Create download link
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

/**
 * Placeholder untuk export ke PDF
 * Perlu library eksternal seperti jsPDF
 */
function exportTableToPDF(table, filename) {
    alert('Fitur export ke PDF akan segera tersedia.');
    // Implementasi dengan jsPDF library
}

/**
 * Placeholder untuk export ke Excel
 * Perlu library eksternal seperti SheetJS
 */
function exportTableToExcel(table, filename) {
    alert('Fitur export ke Excel akan segera tersedia.');
    // Implementasi dengan SheetJS library
}
