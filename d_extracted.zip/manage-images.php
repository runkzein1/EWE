<?php
/**
 * LelangMobil - Vehicle Image Management
 * This page allows users to manage (add, remove, reorder) vehicle images
 */

session_start();
require_once 'config/database.php';
require_once 'config/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "Anda harus login untuk mengakses halaman ini.";
    $_SESSION['message_type'] = "danger";
    header("Location: login.php");
    exit();
}

// Get vehicle ID from URL
$vehicle_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Check if vehicle exists and belongs to the current user
$check_sql = "SELECT v.*, u.name as owner_name 
              FROM vehicles v 
              JOIN users u ON v.user_id = u.user_id 
              WHERE v.vehicle_id = ?";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("i", $vehicle_id);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['message'] = "Kendaraan tidak ditemukan.";
    $_SESSION['message_type'] = "danger";
    header("Location: my-vehicles.php");
    exit();
}

$vehicle = $result->fetch_assoc();

// Check if user is the owner of the vehicle or an admin
if ($vehicle['user_id'] != $_SESSION['user_id'] && $_SESSION['role'] !== 'admin') {
    $_SESSION['message'] = "Anda tidak berhak mengakses halaman ini.";
    $_SESSION['message_type'] = "danger";
    header("Location: my-vehicles.php");
    exit();
}

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Handle image uploads
    if (isset($_POST['action']) && $_POST['action'] === 'upload') {
        try {
            // Directory for vehicle images
            $make_safe = strtolower(preg_replace('/[^a-zA-Z0-9]/', '_', $vehicle['make']));
            $upload_dir = "uploads/vehicles/{$make_safe}/";
            
            // Create directory if it doesn't exist
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $model_safe = strtolower(preg_replace('/[^a-zA-Z0-9]/', '_', $vehicle['model']));
            
            // Check if images were uploaded
            if (!empty($_FILES['new_images']['name'][0])) {
                $allowed_types = ['image/jpeg', 'image/jpg', 'image/png'];
                $max_size = 20 * 1024 * 1024; // 20MB
                
                // Prepare image insert statement
                $insert_image = "INSERT INTO vehicle_images (vehicle_id, image_url, is_main, caption) VALUES (?, ?, ?, ?)";
                $image_stmt = $conn->prepare($insert_image);
                
                // Process each uploaded image
                for ($i = 0; $i < count($_FILES['new_images']['name']); $i++) {
                    // Check file type
                    if (!in_array($_FILES['new_images']['type'][$i], $allowed_types)) {
                        throw new Exception("File " . $_FILES['new_images']['name'][$i] . " bukan file gambar yang valid");
                    }
                    
                    // Check file size
                    if ($_FILES['new_images']['size'][$i] > $max_size) {
                        throw new Exception("File " . $_FILES['new_images']['name'][$i] . " terlalu besar (maks. 20MB)");
                    }
                    
                    // Get file extension and sanitize it
                    $file_extension = strtolower(pathinfo($_FILES['new_images']['name'][$i], PATHINFO_EXTENSION));
                    
                    // Generate a unique filename
                    $timestamp = time();
                    $random = mt_rand(1000, 9999);
                    $filename = $make_safe . '_' . $model_safe . '_' . $vehicle_id . '_' . $timestamp . '_' . $random . '_' . $i . '.' . $file_extension;
                    $target_file = $upload_dir . $filename;
                    
                    // Move uploaded file
                    if (move_uploaded_file($_FILES['new_images']['tmp_name'][$i], $target_file)) {
                        // Set as main image only if there are no other images
                        $is_main = 0; // Default not main
                        $image_url = $target_file;
                        $caption = isset($_POST['image_captions'][$i]) ? $_POST['image_captions'][$i] : '';
                        
                        $image_stmt->bind_param("isis", $vehicle_id, $image_url, $is_main, $caption);
                        $image_stmt->execute();
                    } else {
                        throw new Exception("Gagal mengupload gambar " . $_FILES['new_images']['name'][$i]);
                    }
                }
                
                // After all images are uploaded, make sure there's at least one main image
                $update_main_sql = "UPDATE vehicle_images SET is_main = CASE 
                                    WHEN (SELECT COUNT(*) FROM (SELECT * FROM vehicle_images WHERE vehicle_id = ? AND is_main = 1) as subq) = 0 
                                    AND image_id = (SELECT MIN(image_id) FROM (SELECT * FROM vehicle_images WHERE vehicle_id = ?) as subq2) 
                                    THEN 1 ELSE is_main END 
                                    WHERE vehicle_id = ?";
                                    
                $update_main_stmt = $conn->prepare($update_main_sql);
                $update_main_stmt->bind_param("iii", $vehicle_id, $vehicle_id, $vehicle_id);
                $update_main_stmt->execute();
                
                $_SESSION['message'] = "Gambar berhasil diunggah.";
                $_SESSION['message_type'] = "success";
            } else {
                $_SESSION['message'] = "Tidak ada gambar yang dipilih.";
                $_SESSION['message_type'] = "warning";
            }
        } catch (Exception $e) {
            $_SESSION['message'] = "Error: " . $e->getMessage();
            $_SESSION['message_type'] = "danger";
        }
        
        // Redirect to refresh the page
        header("Location: manage-images.php?id=" . $vehicle_id);
        exit();
    }
    
    // Handle setting main image
    if (isset($_POST['action']) && $_POST['action'] === 'set_main') {
        $image_id = intval($_POST['image_id']);
        
        // Update database to set this image as main
        $conn->begin_transaction();
        
        try {
            // First, set all images for this vehicle to not main
            $reset_sql = "UPDATE vehicle_images SET is_main = 0 WHERE vehicle_id = ?";
            $reset_stmt = $conn->prepare($reset_sql);
            $reset_stmt->bind_param("i", $vehicle_id);
            $reset_stmt->execute();
            
            // Then set the selected image as main
            $main_sql = "UPDATE vehicle_images SET is_main = 1 WHERE image_id = ? AND vehicle_id = ?";
            $main_stmt = $conn->prepare($main_sql);
            $main_stmt->bind_param("ii", $image_id, $vehicle_id);
            $main_stmt->execute();
            
            $conn->commit();
            
            $_SESSION['message'] = "Gambar utama berhasil diubah.";
            $_SESSION['message_type'] = "success";
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['message'] = "Error: " . $e->getMessage();
            $_SESSION['message_type'] = "danger";
        }
        
        // Redirect to refresh the page
        header("Location: manage-images.php?id=" . $vehicle_id);
        exit();
    }
    
    // Handle deleting an image
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $image_id = intval($_POST['image_id']);
        
        // Get image info before deleting
        $get_image_sql = "SELECT * FROM vehicle_images WHERE image_id = ? AND vehicle_id = ?";
        $get_image_stmt = $conn->prepare($get_image_sql);
        $get_image_stmt->bind_param("ii", $image_id, $vehicle_id);
        $get_image_stmt->execute();
        $image_result = $get_image_stmt->get_result();
        
        if ($image_result->num_rows > 0) {
            $image = $image_result->fetch_assoc();
            $was_main = $image['is_main'];
            $image_path = $image['image_url'];
            
            $conn->begin_transaction();
            
            try {
                // Delete from database
                $delete_sql = "DELETE FROM vehicle_images WHERE image_id = ? AND vehicle_id = ?";
                $delete_stmt = $conn->prepare($delete_sql);
                $delete_stmt->bind_param("ii", $image_id, $vehicle_id);
                $delete_stmt->execute();
                
                // Delete file from server if it exists
                if (file_exists($image_path)) {
                    unlink($image_path);
                }
                
                // If the deleted image was the main image, set a new main image
                if ($was_main) {
                    $update_main_sql = "UPDATE vehicle_images SET is_main = 1 
                                       WHERE vehicle_id = ? 
                                       ORDER BY image_id ASC 
                                       LIMIT 1";
                    $update_main_stmt = $conn->prepare($update_main_sql);
                    $update_main_stmt->bind_param("i", $vehicle_id);
                    $update_main_stmt->execute();
                }
                
                $conn->commit();
                
                $_SESSION['message'] = "Gambar berhasil dihapus.";
                $_SESSION['message_type'] = "success";
            } catch (Exception $e) {
                $conn->rollback();
                $_SESSION['message'] = "Error: " . $e->getMessage();
                $_SESSION['message_type'] = "danger";
            }
        } else {
            $_SESSION['message'] = "Gambar tidak ditemukan.";
            $_SESSION['message_type'] = "warning";
        }
        
        // Redirect to refresh the page
        header("Location: manage-images.php?id=" . $vehicle_id);
        exit();
    }
    
    // Handle updating captions
    if (isset($_POST['action']) && $_POST['action'] === 'update_captions') {
        $conn->begin_transaction();
        
        try {
            $image_ids = $_POST['image_ids'];
            $captions = $_POST['captions'];
            
            $update_sql = "UPDATE vehicle_images SET caption = ? WHERE image_id = ? AND vehicle_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            
            foreach ($image_ids as $index => $image_id) {
                $caption = isset($captions[$index]) ? $captions[$index] : '';
                $update_stmt->bind_param("sii", $caption, $image_id, $vehicle_id);
                $update_stmt->execute();
            }
            
            $conn->commit();
            
            $_SESSION['message'] = "Keterangan gambar berhasil diperbarui.";
            $_SESSION['message_type'] = "success";
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['message'] = "Error: " . $e->getMessage();
            $_SESSION['message_type'] = "danger";
        }
        
        // Redirect to refresh the page
        header("Location: manage-images.php?id=" . $vehicle_id);
        exit();
    }
}

// Get current images for the vehicle
$images_sql = "SELECT * FROM vehicle_images WHERE vehicle_id = ? ORDER BY is_main DESC, image_id ASC";
$images_stmt = $conn->prepare($images_sql);
$images_stmt->bind_param("i", $vehicle_id);
$images_stmt->execute();
$images_result = $images_stmt->get_result();
$images = [];

while ($row = $images_result->fetch_assoc()) {
    $images[] = $row;
}

$page_title = "Kelola Gambar Kendaraan - " . $vehicle['title'];

?>

<?php include 'includes/header.php'; ?>
<!-- Image Management CSS -->
<link rel="stylesheet" href="css/image-upload.css">

<div class="container-fluid mt-5 pt-5">
    <div class="container">
        <!-- Back button and title -->
        <div class="row mb-4">
            <div class="col-12">
                <a href="vehicle.php?id=<?php echo $vehicle_id; ?>" class="btn btn-outline-light mb-3">
                    <i class="fa fa-arrow-left"></i> Kembali ke Detail Kendaraan
                </a>
                <h2 class="mb-3"><?php echo $vehicle['title']; ?></h2>
                <p class="text-muted">
                    <?php echo $vehicle['year']; ?> • 
                    <?php echo $vehicle['make']; ?> • 
                    <?php echo $vehicle['model']; ?>
                </p>
            </div>
        </div>
        
        <!-- Alert messages -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?php echo $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['message']; ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
        <?php endif; ?>
        
        <!-- Current Images Section -->
        <div class="row mb-5">
            <div class="col-12">
                <div class="card bg-dark border-secondary">
                    <div class="card-header bg-dark border-secondary d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Gambar Kendaraan Saat Ini</h4>
                        <span class="badge badge-primary"><?php echo count($images); ?> Gambar</span>
                    </div>
                    <div class="card-body">
                        <?php if (count($images) > 0): ?>
                            <form id="caption-form" method="post" action="manage-images.php?id=<?php echo $vehicle_id; ?>">
                                <input type="hidden" name="action" value="update_captions">
                                
                                <div class="row">
                                    <?php foreach ($images as $image): ?>
                                        <div class="col-lg-3 col-md-4 col-6 mb-4">
                                            <div class="image-card <?php echo $image['is_main'] ? 'is-main' : ''; ?>">
                                                <div class="image-container">
                                                    <img src="<?php echo get_vehicle_image_url($image['image_url']); ?>" 
                                                         alt="<?php echo $vehicle['title']; ?>" 
                                                         class="img-fluid">
                                                    
                                                    <?php if ($image['is_main']): ?>
                                                        <span class="main-badge">Utama</span>
                                                    <?php endif; ?>
                                                    
                                                    <div class="image-actions">
                                                        <?php if (!$image['is_main']): ?>
                                                            <form method="post" action="manage-images.php?id=<?php echo $vehicle_id; ?>" class="d-inline">
                                                                <input type="hidden" name="action" value="set_main">
                                                                <input type="hidden" name="image_id" value="<?php echo $image['image_id']; ?>">
                                                                <button type="submit" class="btn btn-sm btn-warning" title="Jadikan Utama">
                                                                    <i class="fa fa-star"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                        
                                                        <form method="post" action="manage-images.php?id=<?php echo $vehicle_id; ?>" 
                                                              class="d-inline delete-image-form" 
                                                              data-image-id="<?php echo $image['image_id']; ?>">
                                                            <input type="hidden" name="action" value="delete">
                                                            <input type="hidden" name="image_id" value="<?php echo $image['image_id']; ?>">
                                                            <button type="button" class="btn btn-sm btn-danger delete-image-btn" title="Hapus Gambar">
                                                                <i class="fa fa-trash"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                                
                                                <div class="caption-container mt-2">
                                                    <input type="hidden" name="image_ids[]" value="<?php echo $image['image_id']; ?>">
                                                    <input type="text" 
                                                           name="captions[]" 
                                                           class="form-control form-control-sm caption-input" 
                                                           placeholder="Keterangan gambar..."
                                                           value="<?php echo htmlspecialchars($image['caption']); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <div class="text-right mt-3">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-save"></i> Simpan Keterangan
                                    </button>
                                </div>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                <i class="fa fa-exclamation-triangle"></i> Belum ada gambar yang diunggah untuk kendaraan ini.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Upload New Images Section -->
        <div class="row">
            <div class="col-12">
                <div class="card bg-dark border-secondary">
                    <div class="card-header bg-dark border-secondary">
                        <h4 class="mb-0">Unggah Gambar Baru</h4>
                    </div>
                    <div class="card-body">
                        <form action="manage-images.php?id=<?php echo $vehicle_id; ?>" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="upload">
                            
                            <!-- Enhanced File Upload Area -->
                            <div class="lelang-image-uploader" id="vehicle-image-uploader">
                                <div class="upload-area">
                                    <input type="file" name="new_images[]" id="vehicle-images" accept="image/jpeg,image/jpg,image/png" multiple required>
                                    <div class="icon"><i class="fa fa-cloud-upload-alt"></i></div>
                                    <p class="upload-text">Klik atau seret foto kendaraan ke sini</p>
                                    <p class="upload-info">Format JPG, JPEG, PNG (maksimal 20MB per file)</p>
                                </div>
                                
                                <div class="file-size-warning"></div>
                                <div class="file-type-error"></div>
                                
                                <div class="upload-limit-info">
                                    <span><i class="fa fa-info-circle"></i> Tambahkan lebih banyak foto untuk meningkatkan daya tarik</span>
                                </div>
                                
                                <div class="upload-progress-bar">
                                    <div class="upload-progress-value"></div>
                                </div>
                                
                                <div class="image-preview-container">
                                    <div class="image-preview-list">
                                        <!-- Image previews will be added here by JavaScript -->
                                    </div>
                                </div>
                            </div>
                            
                            <div class="text-right mt-4">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fa fa-upload"></i> Unggah Gambar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- Custom CSS for image management -->
<style>
.image-card {
    background: #2a2a2a;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
    transition: all 0.3s ease;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.image-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
}

.image-card.is-main {
    border: 2px solid #f6a21e;
}

.image-container {
    position: relative;
    overflow: hidden;
    padding-top: 75%; /* 4:3 Aspect Ratio */
    background: #1a1a1a;
}

.image-container img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.main-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    background: #f6a21e;
    color: black;
    font-size: 0.7rem;
    font-weight: bold;
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    z-index: 2;
}

.image-actions {
    position: absolute;
    bottom: 10px;
    right: 10px;
    display: flex;
    gap: 5px;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.image-container:hover .image-actions {
    opacity: 1;
}

.caption-container {
    padding: 0.5rem;
    flex-grow: 1;
}

.caption-input {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: white;
}

.caption-input:focus {
    background: rgba(255, 255, 255, 0.15);
    border-color: #f6a21e;
    color: white;
    box-shadow: none;
}

.tips-box {
    background: rgba(30, 30, 30, 0.5);
    border-radius: 8px;
    padding: 1rem;
    border-left: 3px solid #f6a21e;
}
</style>

<!-- Image Management JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle delete image confirmation
    const deleteButtons = document.querySelectorAll('.delete-image-btn');
    
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            if (confirm('Anda yakin ingin menghapus gambar ini?')) {
                this.closest('form').submit();
            }
        });
    });
    
    // Initialize the enhanced image uploader for the new images section
    initImageUploader();
});

function initImageUploader() {
    const uploader = document.getElementById('vehicle-image-uploader');
    if (!uploader) return;

    const fileInput = document.getElementById('vehicle-images');
    const uploadArea = document.querySelector('.upload-area');
    const previewContainer = document.querySelector('.image-preview-list');
    const fileSizeWarning = document.querySelector('.file-size-warning');
    const fileTypeError = document.querySelector('.file-type-error');
    
    // Max file size (20MB in bytes)
    const MAX_FILE_SIZE = 20 * 1024 * 1024;
    
    // Allowed file types
    const ALLOWED_TYPES = ['image/jpeg', 'image/jpg', 'image/png'];
    
    // Store file objects for form submission
    let uploadedFiles = [];
    
    // Handle drag and drop events
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, highlight, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, unhighlight, false);
    });
    
    function highlight() {
        uploadArea.classList.add('drag-over');
    }
    
    function unhighlight() {
        uploadArea.classList.remove('drag-over');
    }
    
    // Handle file drop
    uploadArea.addEventListener('drop', handleDrop, false);
    
    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        if (files.length > 0) {
            handleFiles(files);
        }
    }
    
    // Handle file selection via input
    fileInput.addEventListener('change', function() {
        handleFiles(this.files);
    });
    
    function handleFiles(files) {
        // Reset warnings
        fileSizeWarning.style.display = 'none';
        fileTypeError.style.display = 'none';
        
        Array.from(files).forEach(file => {
            // Check file type
            if (!ALLOWED_TYPES.includes(file.type)) {
                fileTypeError.style.display = 'block';
                fileTypeError.textContent = `File ${file.name} bukan format gambar yang valid (hanya JPG, JPEG, PNG).`;
                return;
            }
            
            // Check file size
            if (file.size > MAX_FILE_SIZE) {
                fileSizeWarning.style.display = 'block';
                fileSizeWarning.textContent = `File ${file.name} melebihi batas ukuran 20MB.`;
                return;
            }
            
            // Add valid file to our collection
            uploadedFiles.push({
                file: file,
                id: generateUniqueId()
            });
        });
        
        // Update UI
        renderPreviews();
        
        // Clear the file input
        fileInput.value = '';
    }
    
    function renderPreviews() {
        // Clear the preview container
        previewContainer.innerHTML = '';
        
        // Generate preview for each file
        uploadedFiles.forEach((item, index) => {
            const preview = createPreviewElement(item, index);
            previewContainer.appendChild(preview);
        });
    }
    
    function createPreviewElement(item, index) {
        const previewItem = document.createElement('div');
        previewItem.className = 'image-preview-item';
        previewItem.dataset.id = item.id;
        
        // Create image preview
        const reader = new FileReader();
        reader.onload = function(e) {
            // Image container
            const imgWrap = document.createElement('div');
            imgWrap.className = 'preview-img-wrap';
            
            // Image element
            const img = document.createElement('img');
            img.src = e.target.result;
            img.className = 'preview-img';
            imgWrap.appendChild(img);
            
            // Preview tools
            const tools = document.createElement('div');
            tools.className = 'preview-tools';
            
            // Delete button
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'preview-tool-btn delete';
            deleteBtn.innerHTML = '<i class="fa fa-trash"></i>';
            deleteBtn.title = 'Hapus';
            deleteBtn.addEventListener('click', function() {
                removeFile(item.id);
            });
            
            tools.appendChild(deleteBtn);
            imgWrap.appendChild(tools);
            
            previewItem.appendChild(imgWrap);
            
            // File info badge
            const infoBadge = document.createElement('div');
            infoBadge.className = 'image-count-badge';
            const fileSize = (item.file.size / (1024 * 1024)).toFixed(1);
            infoBadge.textContent = `${fileSize}MB`;
            imgWrap.appendChild(infoBadge);
        };
        
        reader.readAsDataURL(item.file);
        return previewItem;
    }
    
    function removeFile(id) {
        // Find the index of the file to remove
        const index = uploadedFiles.findIndex(item => item.id === id);
        if (index === -1) return;
        
        // Remove the file
        uploadedFiles.splice(index, 1);
        
        // Update UI
        renderPreviews();
    }
    
    function generateUniqueId() {
        return 'img_' + Math.random().toString(36).substr(2, 9);
    }
}
</script>
