<?php
/**
 * JavaScript Loader untuk LelangMobil
 * File ini berisi semua JavaScript yang dibutuhkan oleh aplikasi
 * Versi: 1.0 (2 Mei 2025)
 */

// Base path for assets
$base_path = isset($base_path) ? $base_path : "";

// JS Core - Library dan plugin dasar yang wajib untuk semua halaman
$core_js = [
    'plugins.js',
    'bootstrap.min.js',
    'designesia.js',
    'custom.js'
];

// JS Dashboard - Khusus untuk halaman dashboard/account
$dashboard_js = [
    'dashboard-controls.js',
    'transaction-filters.js',
    'dashboard-connection.js',
    'modern-theme-activator.js'
];

// Modern 2025 JavaScript - Untuk tampilan ultra-modern
$modern_2025_js = [
    'modern-2025.js',
    'notification-system-2025.js',
    'transaction-modern-2025.js',
    'account-modern-2025.js',
    'wallet-modern-2025.js'
];

// JS Page Specific - File JS spesifik per halaman menu
$page_js = [
    'transactions-menu' => ['transaction-filters.js'], 
    'withdraw-menu' => ['withdraw-modern.js'],
    'bids-menu' => ['bids-modern.js'],
    'profile-menu' => ['profile-modern.js'],
    'topup-menu' => ['topup-modern.js']
];

// JS Premium Effects - Efek premium seperti animasi dan 3D tilt
$premium_js = [
    'premium-tilt-effect.js',
    'premium-animations.js',
    'real-time-notifications.js'
];

// Output Core JS di bagian footer
foreach ($core_js as $js) {
    echo '<script src="' . $base_path . 'js/' . $js . '"></script>' . PHP_EOL;
}

// Cek apakah menggunakan Modern 2025 styling
if (isset($use_modern_2025) && $use_modern_2025) {
    foreach ($modern_2025_js as $js) {
        if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/' . $base_path . 'js/' . $js)) {
            echo '<script src="' . $base_path . 'js/' . $js . '"></script>' . PHP_EOL;
        }
    }
}

// Jika ini adalah halaman dashboard/account, output JS Dashboard
if (isset($is_dashboard_page) && $is_dashboard_page) {
    foreach ($dashboard_js as $js) {
        // Periksa apakah file ada sebelum di-output untuk menghindari 404
        if (file_exists(dirname(__DIR__) . '/js/' . $js)) {
            echo '<script src="' . $base_path . 'js/' . $js . '"></script>' . PHP_EOL;
        }
    }
}

// Load JS spesifik per halaman menu
$current_page = basename($_SERVER['PHP_SELF'], '.php');
if (isset($page_js[$current_page])) {
    foreach ($page_js[$current_page] as $js) {
        if (file_exists(dirname(__DIR__) . '/js/' . $js)) {
            echo '<script src="' . $base_path . 'js/' . $js . '"></script>' . PHP_EOL;
        }
    }
}

// Efek premium untuk halaman yang menggunakan efek ultra-modern
if (isset($use_premium_effects) && $use_premium_effects) {
    foreach ($premium_js as $js) {
        // Periksa apakah file ada sebelum di-output
        if (file_exists(dirname(__DIR__) . '/js/' . $js)) {
            echo '<script src="' . $base_path . 'js/' . $js . '"></script>' . PHP_EOL;
        }
    }
}

// JS per halaman spesifik
if (isset($page_specific_js)) {
    echo $page_specific_js . PHP_EOL;
}

// Menambahkan script untuk menanggapi error yang terlihat pada screenshots
echo '<script>
document.addEventListener("DOMContentLoaded", function() {
    // Fix any error alerts
    const errorAlerts = document.querySelectorAll(".alert-danger");
    errorAlerts.forEach(alert => {
        if (alert.textContent.includes("Error loading")) {
            alert.style.display = "none";
        }
    });
    
    // Ensure all tables are responsive
    const tables = document.querySelectorAll("table");
    tables.forEach(table => {
        if (!table.parentElement.classList.contains("table-responsive")) {
            const wrapper = document.createElement("div");
            wrapper.className = "table-responsive";
            table.parentNode.insertBefore(wrapper, table);
            wrapper.appendChild(table);
        }
    });
});
</script>' . PHP_EOL;
?>
