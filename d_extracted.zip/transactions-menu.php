<?php
// Aktifkan error reporting dan logging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data user
$user_query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "User tidak ditemukan.";
    header("Location: login.php");
    exit;
}

$user = $result->fetch_assoc();
$balance = $user['balance'] ?? 0;

// Inisialisasi variabel transaksi
$total_deposit = 0;
$total_withdrawal = 0;
$hold_amount = 0;

// Query untuk mengambil transaksi user
$transactions_sql = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($transactions_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$transactions_result = $stmt->get_result();

// Helper function untuk format status transaksi
function get_transaction_status_badge($status) {
    switch ($status) {
        case 'completed':
            return '<span class="badge bg-success">Selesai</span>';
        case 'pending':
            return '<span class="badge bg-warning">Menunggu</span>';
        case 'verification':
            return '<span class="badge bg-info">Verifikasi</span>';
        case 'rejected':
            return '<span class="badge bg-danger">Ditolak</span>';
        case 'cancelled':
            return '<span class="badge bg-secondary">Dibatalkan</span>';
        default:
            return '<span class="badge bg-secondary">' . ucfirst($status) . '</span>';
    }
}

// Helper function untuk format jenis transaksi
function get_transaction_type_info($type) {
    switch ($type) {
        case 'deposit':
            return [
                'icon' => 'fa-arrow-alt-circle-up',
                'label' => 'Top Up',
                'text_class' => 'text-success'
            ];
        case 'withdrawal':
            return [
                'icon' => 'fa-arrow-alt-circle-down',
                'label' => 'Penarikan',
                'text_class' => 'text-danger'
            ];
        case 'bid':
            return [
                'icon' => 'fa-gavel',
                'label' => 'Bid',
                'text_class' => 'text-primary'
            ];
        case 'bid_win':
            return [
                'icon' => 'fa-trophy',
                'label' => 'Menang Lelang',
                'text_class' => 'text-warning'
            ];
        case 'bid_refund':
            return [
                'icon' => 'fa-undo',
                'label' => 'Refund Bid',
                'text_class' => 'text-info'
            ];
        default:
            return [
                'icon' => 'fa-exchange-alt',
                'label' => ucfirst($type),
                'text_class' => 'text-secondary'
            ];
    }
}

// Hitung total deposit, withdrawal, dan hold amount
if ($transactions_result && $transactions_result->num_rows > 0) {
    while ($tx = $transactions_result->fetch_assoc()) {
        if ($tx['type'] == 'deposit' && $tx['status'] == 'completed') {
            $total_deposit += (float)$tx['amount'];
        } elseif ($tx['type'] == 'withdrawal' && $tx['status'] == 'completed') {
            $total_withdrawal += (float)$tx['amount'];
        } elseif ($tx['type'] == 'bid' && $tx['status'] != 'completed' && $tx['status'] != 'cancelled') {
            $hold_amount += (float)$tx['amount'];
        }
    }
}

// Reset result pointer for displaying
if ($transactions_result) {
    $transactions_result->data_seek(0);
}

// Aktifkan flag untuk halaman dashboard dan tema ultra-modern
$page_title = "Riwayat Transaksi";
$is_dashboard_page = true;
$use_ultra_modern = true;
$use_premium_effects = true;
$modern_js_files = true;

// CSS tambahan untuk halaman ini
$page_specific_css = '<link href="css/transaction-premium.css" rel="stylesheet" type="text/css">';

// JS tambahan untuk halaman ini
$page_specific_js = '<script src="js/transaction-filters.js"></script>';

// Include header
include('includes/header.php');
?>

<div class="dashboard-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="page-title">Riwayat Transaksi</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                        <li class="breadcrumb-item"><a href="account.php">Akun Saya</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Riwayat Transaksi</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container py-5">
    <div class="row">
        <!-- Menu Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="account-menu-card">
                <div class="user-profile mb-4">
                    <div class="user-avatar">
                        <div class="avatar-text">
                            <?php echo strtoupper(substr($user['username'] ?? 'U', 0, 1)); ?>
                        </div>
                    </div>
                    <div class="user-info mt-2">
                        <h5 class="mb-1"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h5>
                        <p class="text-muted mb-0">ID: <?php echo $user['user_id']; ?></p>
                    </div>
                </div>
                
                <div class="menu-items">
                    <a href="account.php" class="menu-item">
                        <i class="fa fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="topup-menu.php" class="menu-item">
                        <i class="fa fa-wallet"></i> Top-up Saldo
                    </a>
                    <a href="withdraw-menu.php" class="menu-item">
                        <i class="fa fa-money-bill-wave"></i> Tarik Saldo
                    </a>
                    <a href="transactions-menu.php" class="menu-item active">
                        <i class="fa fa-history"></i> Riwayat Transaksi
                    </a>
                    <a href="bids-menu.php" class="menu-item">
                        <i class="fa fa-gavel"></i> Bid Saya
                    </a>
                    <a href="profile-menu.php" class="menu-item">
                        <i class="fa fa-user"></i> Profil
                    </a>
                    <a href="?logout=true" class="menu-item">
                        <i class="fa fa-sign-out-alt"></i> Keluar
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-lg-9">
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-primary">
                            <i class="fa fa-wallet"></i>
                        </div>
                        <div class="stat-content">
                            <h3 class="stat-value">Rp <?php echo number_format($balance, 0, ',', '.'); ?></h3>
                            <p class="stat-label">Saldo Saat Ini</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-success">
                            <i class="fa fa-arrow-alt-circle-up"></i>
                        </div>
                        <div class="stat-content">
                            <h3 class="stat-value">Rp <?php echo number_format($total_deposit, 0, ',', '.'); ?></h3>
                            <p class="stat-label">Total Deposit</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon bg-warning">
                            <i class="fa fa-money-bill-wave"></i>
                        </div>
                        <div class="stat-content">
                            <h3 class="stat-value">Rp <?php echo number_format($total_withdrawal, 0, ',', '.'); ?></h3>
                            <p class="stat-label">Total Penarikan</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fa fa-filter me-2"></i>Filter Transaksi</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="transaction-type" class="form-label">Jenis Transaksi</label>
                            <select class="form-select" id="transaction-type">
                                <option value="">Semua Transaksi</option>
                                <option value="deposit">Top Up / Deposit</option>
                                <option value="withdrawal">Penarikan Dana</option>
                                <option value="bid">Bid</option>
                                <option value="bid_win">Menang Lelang</option>
                                <option value="bid_refund">Refund Bid</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="transaction-status" class="form-label">Status Transaksi</label>
                            <select class="form-select" id="transaction-status">
                                <option value="">Semua Status</option>
                                <option value="completed">Selesai</option>
                                <option value="pending">Menunggu</option>
                                <option value="verification">Verifikasi</option>
                                <option value="rejected">Ditolak</option>
                                <option value="cancelled">Dibatalkan</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="transaction-date" class="form-label">Rentang Waktu</label>
                            <select class="form-select" id="transaction-date">
                                <option value="">Semua Waktu</option>
                                <option value="today">Hari Ini</option>
                                <option value="week">Minggu Ini</option>
                                <option value="month">Bulan Ini</option>
                                <option value="year">Tahun Ini</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fa fa-history me-2"></i>Riwayat Transaksi</h5>
                        <div>
                            <button class="btn btn-sm btn-light" id="refreshTransactionsBtn">
                                <i class="fa fa-sync-alt"></i> Refresh
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <?php if (!$transactions_result || $transactions_result->num_rows == 0): ?>
                        <div class="empty-state p-5 text-center">
                            <div class="empty-state-icon mb-3">
                                <i class="fa fa-receipt fa-3x text-muted"></i>
                            </div>
                            <h4>Belum Ada Transaksi</h4>
                            <p class="text-muted">Anda belum memiliki riwayat transaksi apapun.</p>
                            <a href="topup-menu.php" class="btn btn-primary mt-2">
                                <i class="fa fa-plus-circle me-2"></i>Mulai dengan Top Up
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Tanggal</th>
                                        <th>Jenis</th>
                                        <th>Jumlah</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($transaction = $transactions_result->fetch_assoc()): ?>
                                        <?php $type_info = get_transaction_type_info($transaction['type']); ?>
                                        <tr class="transaction-row" data-type="<?php echo $transaction['type']; ?>" data-status="<?php echo $transaction['status']; ?>">
                                            <td>#<?php echo $transaction['transaction_id']; ?></td>
                                            <td><?php echo date('d M Y H:i', strtotime($transaction['created_at'])); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="transaction-icon me-2 <?php echo $type_info['text_class']; ?>">
                                                        <i class="fa <?php echo $type_info['icon']; ?>"></i>
                                                    </div>
                                                    <?php echo $type_info['label']; ?>
                                                </div>
                                            </td>
                                            <td class="<?php echo ($transaction['type'] == 'deposit' || $transaction['type'] == 'bid_refund') ? 'text-success' : 'text-danger'; ?>">
                                                <?php if ($transaction['type'] == 'deposit' || $transaction['type'] == 'bid_refund'): ?>
                                                    + Rp <?php echo number_format($transaction['amount'], 0, ',', '.'); ?>
                                                <?php else: ?>
                                                    - Rp <?php echo number_format($transaction['amount'], 0, ',', '.'); ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo get_transaction_status_badge($transaction['status']); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#transactionModal<?php echo $transaction['transaction_id']; ?>">
                                                    <i class="fa fa-eye"></i>
                                                </button>
                                                <?php if ($transaction['status'] == 'pending' && $transaction['type'] == 'deposit'): ?>
                                                    <a href="upload-payment.php?id=<?php echo $transaction['transaction_id']; ?>" class="btn btn-sm btn-success">
                                                        <i class="fa fa-upload"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Transaction Detail Modals -->
<?php if ($transactions_result && $transactions_result->num_rows > 0): ?>
    <?php $transactions_result->data_seek(0); ?>
    <?php while ($transaction = $transactions_result->fetch_assoc()): ?>
        <?php $type_info = get_transaction_type_info($transaction['type']); ?>
        <div class="modal fade" id="transactionModal<?php echo $transaction['transaction_id']; ?>" tabindex="-1" aria-labelledby="transactionModalLabel<?php echo $transaction['transaction_id']; ?>" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="transactionModalLabel<?php echo $transaction['transaction_id']; ?>">
                            <i class="fa <?php echo $type_info['icon']; ?> me-2"></i>Detail Transaksi #<?php echo $transaction['transaction_id']; ?>
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="transaction-detail-item">
                            <div class="detail-label">ID Transaksi</div>
                            <div class="detail-value">#<?php echo $transaction['transaction_id']; ?></div>
                        </div>
                        <div class="transaction-detail-item">
                            <div class="detail-label">Jenis Transaksi</div>
                            <div class="detail-value">
                                <div class="d-flex align-items-center">
                                    <div class="transaction-icon me-2 <?php echo $type_info['text_class']; ?>">
                                        <i class="fa <?php echo $type_info['icon']; ?>"></i>
                                    </div>
                                    <?php echo $type_info['label']; ?>
                                </div>
                            </div>
                        </div>
                        <div class="transaction-detail-item">
                            <div class="detail-label">Jumlah</div>
                            <div class="detail-value <?php echo ($transaction['type'] == 'deposit' || $transaction['type'] == 'bid_refund') ? 'text-success' : 'text-danger'; ?>">
                                <?php if ($transaction['type'] == 'deposit' || $transaction['type'] == 'bid_refund'): ?>
                                    + Rp <?php echo number_format($transaction['amount'], 0, ',', '.'); ?>
                                <?php else: ?>
                                    - Rp <?php echo number_format($transaction['amount'], 0, ',', '.'); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="transaction-detail-item">
                            <div class="detail-label">Status</div>
                            <div class="detail-value">
                                <?php echo get_transaction_status_badge($transaction['status']); ?>
                            </div>
                        </div>
                        <div class="transaction-detail-item">
                            <div class="detail-label">Tanggal & Waktu</div>
                            <div class="detail-value">
                                <?php echo date('d M Y H:i', strtotime($transaction['created_at'])); ?> WIB
                            </div>
                        </div>
                        <?php if (!empty($transaction['reference_number'])): ?>
                            <div class="transaction-detail-item">
                                <div class="detail-label">Nomor Referensi</div>
                                <div class="detail-value"><?php echo $transaction['reference_number']; ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($transaction['notes'])): ?>
                            <div class="transaction-detail-item">
                                <div class="detail-label">Catatan</div>
                                <div class="detail-value"><?php echo $transaction['notes']; ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($transaction['payment_proof'])): ?>
                            <div class="transaction-detail-item">
                                <div class="detail-label">Bukti Pembayaran</div>
                                <div class="detail-value">
                                    <img src="<?php echo $transaction['payment_proof']; ?>" alt="Bukti Pembayaran" class="img-fluid payment-proof-img">
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <?php if ($transaction['status'] == 'pending' && $transaction['type'] == 'deposit'): ?>
                            <a href="upload-payment.php?id=<?php echo $transaction['transaction_id']; ?>" class="btn btn-success">
                                <i class="fa fa-upload me-2"></i>Upload Bukti Pembayaran
                            </a>
                        <?php endif; ?>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
