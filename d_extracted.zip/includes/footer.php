        </div>
        <!-- content close -->
        <a href="#" id="back-to-top"></a>
        <!-- footer begin -->
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="widget">
                            <h5>Tentang LelangMobil</h5>
                            <p>LelangMobil adalah platform lelang mobil terpercaya di Indonesia yang menghubungkan penjual dan pembeli dalam sistem lelang yang transparan dan aman.</p>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="widget">
                            <h5>Link Cepat</h5>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="auctions.php">Lelang Aktif</a></li>
                                <li><a href="how-it-works.php">Cara Kerja</a></li>
                                <li><a href="contact.php">Kontak</a></li>
                                <li><a href="terms.php">Syarat & Ketentuan</a></li>
                                <li><a href="privacy.php">Kebijakan Privasi</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="widget">
                            <h5>Hubungi Kami</h5>
                            <address class="s1">
                                <span><i class="id-color fa fa-map-marker fa-lg"></i>Jl. Jendral Sudirman No. 123, Jakarta Pusat</span>
                                <span><i class="id-color fa fa-phone fa-lg"></i>+62 21 1234 5678</span>
                                <span><i class="id-color fa fa-envelope-o fa-lg"></i><a href="mailto:info@lelangmobil.com">info@lelangmobil.com</a></span>
                            </address>
                        </div>
                    </div>
                </div>
            </div>
            <div class="subfooter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="de-flex">
                                <div class="de-flex-col">
                                    <a href="index.php">
                                        <img alt="" class="f-logo" src="images/logo.png" style="max-width: 140px;">
                                    </a>
                                </div>
                                <div class="de-flex-col">
                                    <div class="social-icons">
                                        <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-instagram fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-youtube fa-lg"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer close -->
    </div>

    <!-- Javascript Files - Dikelola melalui js-loader.php
    ================================================== -->
    <?php
    // Set default value untuk variabel kontrol JS loader
    $is_dashboard_page = isset($is_dashboard_page) ? $is_dashboard_page : false;
    $use_premium_effects = isset($use_premium_effects) ? $use_premium_effects : false;

    // Include JS loader
    if (file_exists('/home/lelang/public_html/includes/js-loader.php')) {
        include_once '/home/lelang/public_html/includes/js-loader.php';
    } else {
        include_once 'js-loader.php';
    }
    ?>
</body>
</html>
