<?php
// Set page title
$page_title = "Detail Pengguna";

// Include header
include 'includes/header.php';

// Check if user ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: users.php");
    exit;
}

$user_id = intval($_GET['id']);

// Get user information
$user_sql = "SELECT * FROM users WHERE user_id = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();

if ($user_result->num_rows == 0) {
    header("Location: users.php");
    exit;
}

$user = $user_result->fetch_assoc();

// Get user's bid history
$bids_sql = "SELECT b.*, v.title, v.current_bid, v.auction_end, v.status, 
              (v.current_bidder = ?) AS is_winning
              FROM bids b 
              JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
              WHERE b.bidder_id = ? 
              ORDER BY b.bid_time DESC
              LIMIT 10";
$bids_stmt = $conn->prepare($bids_sql);
$bids_stmt->bind_param("ii", $user_id, $user_id);
$bids_stmt->execute();
$bids_result = $bids_stmt->get_result();

// Get user's transaction history
$transactions_sql = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10";
$transactions_stmt = $conn->prepare($transactions_sql);
$transactions_stmt->bind_param("i", $user_id);
$transactions_stmt->execute();
$transactions_result = $transactions_stmt->get_result();

// Get vehicles listed by this user
$vehicles_sql = "SELECT * FROM vehicles WHERE seller_id = ? ORDER BY created_at DESC LIMIT 10";
$vehicles_stmt = $conn->prepare($vehicles_sql);
$vehicles_stmt->bind_param("i", $user_id);
$vehicles_stmt->execute();
$vehicles_result = $vehicles_stmt->get_result();

// Calculate user statistics
$stats_sql = "SELECT 
                (SELECT COUNT(*) FROM bids WHERE bidder_id = ?) as total_bids,
                (SELECT COUNT(*) FROM bids WHERE bidder_id = ? AND is_winning = 1) as winning_bids,
                (SELECT COUNT(*) FROM vehicles WHERE seller_id = ?) as vehicles_listed,
                (SELECT COUNT(*) FROM vehicles WHERE seller_id = ? AND status = 'sold') as vehicles_sold,
                (SELECT SUM(amount) FROM transactions WHERE user_id = ? AND type = 'deposit' AND status = 'completed') as total_deposits,
                (SELECT MAX(amount) FROM transactions WHERE user_id = ? AND type = 'deposit' AND status = 'completed') as max_deposit,
                (SELECT MAX(bid_amount) FROM bids WHERE bidder_id = ?) as highest_bid,
                (SELECT COUNT(*) FROM transactions WHERE user_id = ? AND status = 'pending') as pending_transactions";
$stats_stmt = $conn->prepare($stats_sql);
$stats_stmt->bind_param("iiiiiiii", $user_id, $user_id, $user_id, $user_id, $user_id, $user_id, $user_id, $user_id);
$stats_stmt->execute();
$stats_result = $stats_stmt->get_result();
$stats = $stats_result->fetch_assoc();

// Handle form submission for balance adjustment
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['adjust_balance'])) {
    $amount = floatval($_POST['amount']);
    $notes = clean_input($_POST['notes']);
    $type = clean_input($_POST['type']);
    
    if ($amount <= 0) {
        $error = "Jumlah harus lebih dari 0.";
    } else {
        $conn->begin_transaction();
        
        try {
            // Create transaction record
            $transaction_sql = "INSERT INTO transactions (user_id, amount, type, status, notes, admin_id) 
                               VALUES (?, ?, ?, 'completed', ?, ?)";
            $transaction_stmt = $conn->prepare($transaction_sql);
            $transaction_stmt->bind_param("idssi", $user_id, $amount, $type, $notes, $admin_id);
            $transaction_stmt->execute();
            
            // Update user balance
            if ($type == 'deposit') {
                $new_balance = $user['balance'] + $amount;
            } else {
                if ($user['balance'] < $amount) {
                    throw new Exception("Saldo pengguna tidak mencukupi untuk penarikan.");
                }
                $new_balance = $user['balance'] - $amount;
            }
            
            $balance_sql = "UPDATE users SET balance = ? WHERE user_id = ?";
            $balance_stmt = $conn->prepare($balance_sql);
            $balance_stmt->bind_param("di", $new_balance, $user_id);
            $balance_stmt->execute();
            
            $conn->commit();
            $success = "Saldo berhasil disesuaikan.";
            
            // Refresh user data
            $user_stmt->execute();
            $user_result = $user_stmt->get_result();
            $user = $user_result->fetch_assoc();
            
            // Refresh transaction data
            $transactions_stmt->execute();
            $transactions_result = $transactions_stmt->get_result();
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Terjadi kesalahan: " . $e->getMessage();
        }
    }
}

// Handle user verification
if (isset($_POST['verify_user']) && $user['is_verified'] == 0) {
    $verify_sql = "UPDATE users SET is_verified = 1 WHERE user_id = ?";
    $verify_stmt = $conn->prepare($verify_sql);
    $verify_stmt->bind_param("i", $user_id);
    
    if ($verify_stmt->execute()) {
        $success = "Pengguna berhasil diverifikasi.";
        
        // Refresh user data
        $user_stmt->execute();
        $user_result = $user_stmt->get_result();
        $user = $user_result->fetch_assoc();
    } else {
        $error = "Gagal memverifikasi pengguna.";
    }
}

// Handle admin privilege toggle
if (isset($_POST['toggle_admin'])) {
    $new_admin_status = $user['is_admin'] ? 0 : 1;
    $admin_sql = "UPDATE users SET is_admin = ? WHERE user_id = ?";
    $admin_stmt = $conn->prepare($admin_sql);
    $admin_stmt->bind_param("ii", $new_admin_status, $user_id);
    
    if ($admin_stmt->execute()) {
        $success = $new_admin_status ? "Pengguna berhasil dijadikan admin." : "Hak akses admin berhasil dicabut.";
        
        // Refresh user data
        $user_stmt->execute();
        $user_result = $user_stmt->get_result();
        $user = $user_result->fetch_assoc();
    } else {
        $error = "Gagal mengubah status admin pengguna.";
    }
}

$page_title = "Detail Pengguna: " . $user['username'];
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><?php echo $page_title; ?></h1>
    <div>
        <a href="users.php" class="btn btn-secondary me-2">
            <i class="fa fa-arrow-left"></i> Kembali
        </a>
        <a href="user-form.php?id=<?php echo $user_id; ?>" class="btn btn-primary">
            <i class="fa fa-edit"></i> Edit Pengguna
        </a>
    </div>
</div>

<?php if(isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<?php if(isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <!-- User Info Card -->
        <div class="de-box mb-4">
            <div class="text-center mb-4">
                <img src="https://via.placeholder.com/150" class="rounded-circle mb-3" alt="User Profile">
                <h3><?php echo $user['username']; ?></h3>
                <p class="mb-0"><?php echo $user['email']; ?></p>
                
                <div class="mt-3">
                    <?php if ($user['is_admin']): ?>
                        <span class="badge bg-primary">Admin</span>
                    <?php endif; ?>
                    
                    <?php if ($user['is_verified']): ?>
                        <span class="badge bg-success">Terverifikasi</span>
                    <?php else: ?>
                        <span class="badge bg-warning">Belum Verifikasi</span>
                    <?php endif; ?>
                </div>
                
                <div class="mt-3">
                    <form method="post" class="d-inline">
                        <?php if (!$user['is_verified']): ?>
                            <button type="submit" name="verify_user" class="btn btn-sm btn-success" onclick="return confirm('Yakin ingin memverifikasi pengguna ini?')">
                                <i class="fa fa-check"></i> Verifikasi Pengguna
                            </button>
                        <?php endif; ?>
                        
                        <button type="submit" name="toggle_admin" class="btn btn-sm <?php echo $user['is_admin'] ? 'btn-danger' : 'btn-primary'; ?>" onclick="return confirm('Yakin ingin <?php echo $user['is_admin'] ? 'mencabut hak admin' : 'menjadikan admin'; ?> pengguna ini?')">
                            <i class="fa <?php echo $user['is_admin'] ? 'fa-ban' : 'fa-key'; ?>"></i> 
                            <?php echo $user['is_admin'] ? 'Cabut Admin' : 'Jadikan Admin'; ?>
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="mt-4">
                <h5 class="mb-3">Informasi Personal</h5>
                <table class="table">
                    <tr>
                        <th>Nama Lengkap:</th>
                        <td><?php echo $user['full_name'] ? $user['full_name'] : 'Tidak diisi'; ?></td>
                    </tr>
                    <tr>
                        <th>Telepon:</th>
                        <td><?php echo $user['phone'] ? $user['phone'] : 'Tidak diisi'; ?></td>
                    </tr>
                    <tr>
                        <th>Alamat:</th>
                        <td><?php echo $user['address'] ? $user['address'] : 'Tidak diisi'; ?></td>
                    </tr>
                    <tr>
                        <th>Saldo:</th>
                        <td><?php echo format_currency($user['balance']); ?></td>
                    </tr>
                    <tr>
                        <th>Terdaftar Pada:</th>
                        <td><?php echo date('d M Y H:i', strtotime($user['created_at'])); ?></td>
                    </tr>
                    <tr>
                        <th>Diperbarui Pada:</th>
                        <td><?php echo date('d M Y H:i', strtotime($user['updated_at'])); ?></td>
                    </tr>
                </table>
            </div>
        </div>
        
        <!-- User Statistics Card -->
        <div class="de-box mb-4">
            <h5 class="mb-3">Statistik Pengguna</h5>
            <table class="table">
                <tr>
                    <th>Total Bid:</th>
                    <td><?php echo $stats['total_bids'] ? $stats['total_bids'] : 0; ?></td>
                </tr>
                <tr>
                    <th>Bid Menang:</th>
                    <td><?php echo $stats['winning_bids'] ? $stats['winning_bids'] : 0; ?></td>
                </tr>
                <tr>
                    <th>Kendaraan Terdaftar:</th>
                    <td><?php echo $stats['vehicles_listed'] ? $stats['vehicles_listed'] : 0; ?></td>
                </tr>
                <tr>
                    <th>Kendaraan Terjual:</th>
                    <td><?php echo $stats['vehicles_sold'] ? $stats['vehicles_sold'] : 0; ?></td>
                </tr>
                <tr>
                    <th>Total Deposit:</th>
                    <td><?php echo $stats['total_deposits'] ? format_currency($stats['total_deposits']) : format_currency(0); ?></td>
                </tr>
                <tr>
                    <th>Deposit Terbesar:</th>
                    <td><?php echo $stats['max_deposit'] ? format_currency($stats['max_deposit']) : format_currency(0); ?></td>
                </tr>
                <tr>
                    <th>Bid Tertinggi:</th>
                    <td><?php echo $stats['highest_bid'] ? format_currency($stats['highest_bid']) : format_currency(0); ?></td>
                </tr>
                <tr>
                    <th>Transaksi Pending:</th>
                    <td><?php echo $stats['pending_transactions'] ? $stats['pending_transactions'] : 0; ?></td>
                </tr>
            </table>
        </div>
        
        <!-- Balance Adjustment -->
        <div class="de-box">
            <h5 class="mb-3">Penyesuaian Saldo</h5>
            <form method="post">
                <div class="mb-3">
                    <label for="amount" class="form-label">Jumlah (Rp)</label>
                    <input type="number" class="form-control" id="amount" name="amount" required min="1" step="1000">
                </div>
                <div class="mb-3">
                    <label for="type" class="form-label">Tipe</label>
                    <select class="form-control form-select" id="type" name="type" required>
                        <option value="deposit">Deposit (Tambah Saldo)</option>
                        <option value="withdrawal">Penarikan (Kurangi Saldo)</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="notes" class="form-label">Catatan</label>
                    <textarea class="form-control" id="notes" name="notes" rows="2" required></textarea>
                </div>
                <button type="submit" name="adjust_balance" class="btn btn-primary" onclick="return confirm('Yakin ingin menyesuaikan saldo pengguna?')">
                    Sesuaikan Saldo
                </button>
            </form>
        </div>
    </div>
    
    <div class="col-md-8">
        <!-- Bid History -->
        <div class="de-box mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Riwayat Bid</h5>
                <a href="bids.php?user_id=<?php echo $user_id; ?>" class="btn btn-sm btn-primary">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>Kendaraan</th>
                            <th>Jumlah Bid</th>
                            <th>Waktu Bid</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($bids_result->num_rows > 0): ?>
                            <?php while ($bid = $bids_result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <a href="../vehicle.php?id=<?php echo $bid['vehicle_id']; ?>" target="_blank"><?php echo $bid['title']; ?></a>
                                    </td>
                                    <td><?php echo format_currency($bid['bid_amount']); ?></td>
                                    <td><?php echo date('d M Y H:i', strtotime($bid['bid_time'])); ?></td>
                                    <td>
                                        <?php if ($bid['is_winning']): ?>
                                            <span class="badge bg-success">Leading</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Outbid</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">Belum ada riwayat bid.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Transaction History -->
        <div class="de-box mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Riwayat Transaksi</h5>
                <a href="transactions.php?search=<?php echo $user['username']; ?>" class="btn btn-sm btn-primary">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tanggal</th>
                            <th>Jumlah</th>
                            <th>Tipe</th>
                            <th>Status</th>
                            <th>Catatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($transactions_result->num_rows > 0): ?>
                            <?php while ($transaction = $transactions_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $transaction['transaction_id']; ?></td>
                                    <td><?php echo date('d M Y H:i', strtotime($transaction['created_at'])); ?></td>
                                    <td>
                                        <?php
                                        $class = ($transaction['type'] == 'deposit') ? 'text-success' : 'text-danger';
                                        $prefix = ($transaction['type'] == 'deposit') ? '+' : '-';
                                        echo '<span class="'.$class.'">'.$prefix.' '.format_currency($transaction['amount']).'</span>';
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        switch ($transaction['type']) {
                                            case 'deposit':
                                                echo '<span class="badge bg-success">Top-up</span>';
                                                break;
                                            case 'withdrawal':
                                                echo '<span class="badge bg-warning">Penarikan</span>';
                                                break;
                                            case 'bid_hold':
                                                echo '<span class="badge bg-info">Hold Bid</span>';
                                                break;
                                            case 'bid_release':
                                                echo '<span class="badge bg-secondary">Release Bid</span>';
                                                break;
                                            case 'winning_payment':
                                                echo '<span class="badge bg-primary">Pembayaran Menang</span>';
                                                break;
                                            default:
                                                echo $transaction['type'];
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        switch ($transaction['status']) {
                                            case 'pending':
                                                echo '<span class="badge bg-warning">Pending</span>';
                                                break;
                                            case 'completed':
                                                echo '<span class="badge bg-success">Selesai</span>';
                                                break;
                                            case 'rejected':
                                                echo '<span class="badge bg-danger">Ditolak</span>';
                                                break;
                                            default:
                                                echo $transaction['status'];
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo $transaction['notes']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">Belum ada riwayat transaksi.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Vehicles Listed -->
        <div class="de-box">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Kendaraan Terdaftar</h5>
                <a href="vehicles.php?seller_id=<?php echo $user_id; ?>" class="btn btn-sm btn-primary">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover admin-table">
                    <thead>
                        <tr>
                            <th>Judul</th>
                            <th>Harga Awal</th>
                            <th>Current Bid</th>
                            <th>Status</th>
                            <th>Tanggal Berakhir</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($vehicles_result->num_rows > 0): ?>
                            <?php while ($vehicle = $vehicles_result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <a href="../vehicle.php?id=<?php echo $vehicle['vehicle_id']; ?>" target="_blank">
                                            <?php echo $vehicle['title']; ?>
                                        </a>
                                    </td>
                                    <td><?php echo format_currency($vehicle['starting_price']); ?></td>
                                    <td><?php echo $vehicle['current_bid'] ? format_currency($vehicle['current_bid']) : '-'; ?></td>
                                    <td>
                                        <?php
                                        switch ($vehicle['status']) {
                                            case 'upcoming':
                                                echo '<span class="badge bg-info">Akan Datang</span>';
                                                break;
                                            case 'active':
                                                echo '<span class="badge bg-success">Aktif</span>';
                                                break;
                                            case 'ended':
                                                echo '<span class="badge bg-secondary">Selesai</span>';
                                                break;
                                            case 'sold':
                                                echo '<span class="badge bg-primary">Terjual</span>';
                                                break;
                                            case 'not_sold':
                                                echo '<span class="badge bg-danger">Tidak Terjual</span>';
                                                break;
                                            default:
                                                echo $vehicle['status'];
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo date('d M Y H:i', strtotime($vehicle['auction_end'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">Belum ada kendaraan terdaftar.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
