/**
 * Modern Top-up Form JavaScript
 * Adds interactive functionality to the top-up form
 */
document.addEventListener('DOMContentLoaded', function() {
    // Get elements
    const amountInput = document.getElementById('amount');
    const amountPresets = document.querySelectorAll('.amount-preset');
    const paymentMethods = document.querySelectorAll('.payment-method');
    const paymentInputs = document.querySelectorAll('.payment-method input[type="radio"]');
    const paymentProofInput = document.getElementById('payment_proof');
    const proofPreview = document.getElementById('proof-preview');
    const proofPreviewImg = document.getElementById('proof-preview-img');
    const proofFileInfo = document.getElementById('proof-file-info');
    
    // Summary elements
    const summaryAmount = document.getElementById('summary-amount');
    const summaryBank = document.getElementById('summary-bank');
    const summaryFinalBalance = document.getElementById('summary-final-balance');
    const footerTotal = document.getElementById('footer-total');
    
    // Current user balance
    const currentBalance = parseFloat(document.querySelector('.topup-balance strong').innerText.replace(/[^\d]/g, ''));
    
    // Handle amount preset clicks
    amountPresets.forEach(preset => {
        preset.addEventListener('click', function() {
            // Remove active class from all presets
            amountPresets.forEach(p => p.classList.remove('active'));
            
            // Add active class to clicked preset
            this.classList.add('active');
            
            // Set amount input value
            const amount = this.getAttribute('data-amount');
            amountInput.value = formatPrice(amount);
            
            // Update summary
            updateSummary();
        });
    });
    
    // Handle amount input changes
    if (amountInput) {
        amountInput.addEventListener('input', function() {
            // Remove active class from all presets
            amountPresets.forEach(p => p.classList.remove('active'));
            
            // Format price
            const value = this.value.replace(/\D/g, '');
            if (value.length > 0) {
                this.value = formatPrice(value);
            }
            
            // Update summary
            updateSummary();
        });
    }
    
    // Handle payment method selection
    paymentInputs.forEach(input => {
        input.addEventListener('change', function() {
            // Remove active class from all payment methods
            paymentMethods.forEach(method => method.classList.remove('active'));
            
            // Add active class to selected payment method
            this.closest('.payment-method').classList.add('active');
            
            // Update summary
            updateSummary();
        });
    });
    
    // Handle payment proof upload
    if (paymentProofInput) {
        paymentProofInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const file = this.files[0];
                const fileSize = (file.size / 1024 / 1024).toFixed(2); // Convert to MB
                
                // Check file type
                const fileType = file.type;
                if (!['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'].includes(fileType)) {
                    alert('Format file tidak didukung. Silakan gunakan JPG, PNG, atau PDF.');
                    this.value = '';
                    proofPreview.classList.remove('active');
                    return;
                }
                
                // Check file size (max 2MB)
                if (fileSize > 2) {
                    alert('Ukuran file terlalu besar. Maksimal 2MB.');
                    this.value = '';
                    proofPreview.classList.remove('active');
                    return;
                }
                
                // Show preview for images
                if (fileType.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        proofPreviewImg.src = e.target.result;
                        proofPreviewImg.style.display = 'block';
                        proofFileInfo.innerHTML = `${file.name} (${fileSize} MB)`;
                        proofPreview.classList.add('active');
                    };
                    reader.readAsDataURL(file);
                } else {
                    // For PDF, show icon
                    proofPreviewImg.style.display = 'none';
                    proofFileInfo.innerHTML = `<i class="fa fa-file-pdf fa-2x mb-2"></i><br>${file.name} (${fileSize} MB)`;
                    proofPreview.classList.add('active');
                }
            } else {
                proofPreview.classList.remove('active');
            }
        });
    }
    
    // Handle form submission
    const form = document.getElementById('topup-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            // Get amount value
            const amountValue = amountInput.value ? parseFloat(amountInput.value.replace(/\D/g, '')) : 0;
            
            // Validate amount
            if (amountValue < 50000) {
                e.preventDefault();
                alert('Jumlah top-up minimal Rp 50.000');
                amountInput.focus();
                return;
            }
            
            // Validate payment method
            const selectedPaymentMethod = document.querySelector('.payment-method input[type="radio"]:checked');
            if (!selectedPaymentMethod) {
                e.preventDefault();
                alert('Silakan pilih metode pembayaran');
                return;
            }
            
            // Validate reference number
            const referenceNumber = document.getElementById('reference_number').value.trim();
            if (!referenceNumber) {
                e.preventDefault();
                alert('Silakan masukkan nomor referensi transfer');
                document.getElementById('reference_number').focus();
                return;
            }
            
            // Validate payment proof
            const paymentProof = document.getElementById('payment_proof');
            if (!paymentProof.files || !paymentProof.files[0]) {
                e.preventDefault();
                alert('Silakan upload bukti pembayaran');
                paymentProof.focus();
                return;
            }
        });
    }
    
    // Helper function to update summary
    function updateSummary() {
        // Get amount value
        const amountValue = amountInput.value ? parseFloat(amountInput.value.replace(/\D/g, '')) : 0;
        
        // Update summary amount
        if (summaryAmount) {
            summaryAmount.innerText = `Rp ${formatPrice(amountValue)}`;
        }
        
        // Update final balance
        if (summaryFinalBalance) {
            const finalBalance = currentBalance + amountValue;
            summaryFinalBalance.innerText = `Rp ${formatPrice(finalBalance)}`;
        }
        
        // Update footer total
        if (footerTotal) {
            footerTotal.innerText = `Rp ${formatPrice(amountValue)}`;
        }
        
        // Update bank
        if (summaryBank) {
            const selectedBank = document.querySelector('.payment-method input[type="radio"]:checked');
            if (selectedBank) {
                const bankValue = selectedBank.value.split(':')[0].trim();
                summaryBank.innerText = bankValue;
            } else {
                summaryBank.innerText = '-';
            }
        }
    }
    
    // Helper function to format price
    function formatPrice(price) {
        return parseFloat(price).toLocaleString('id-ID').replace(/\s/g, '.');
    }
});
