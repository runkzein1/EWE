<?php
/**
 * Partial file untuk transaction table yang sudah diperbaiki
 * File ini akan di-include di account.php
 */

// Check if we should use Modern 2025 style
$use_modern_2025 = isset($use_modern_2025) ? $use_modern_2025 : false;

// Pastikan user_id sudah didefinisikan
if (!isset($user_id) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
}

// Inisialisasi variabel transaksi
$total_deposit = 0;
$total_withdrawal = 0;
$hold_amount = 0;

// Fungsi helper sederhana jika yang asli tidak tersedia
if (!function_exists('is_valid_result')) {
    function is_valid_result($result) {
        return ($result && $result instanceof mysqli_result && $result->num_rows > 0);
    }
}

if (!function_exists('get_value')) {
    function get_value($array, $key, $default = '') {
        return isset($array[$key]) ? $array[$key] : $default;
    }
}

// Query untuk mengambil transaksi user dengan error handling yang lebih baik
$transactions_result = null;
try {
    // Set timeout untuk operasi database
    $timeout_start = microtime(true);
    
    // Query yang lebih lengkap dengan informasi yang dibutuhkan untuk UI
    $transactions_sql = "SELECT t.*, 
        CASE 
            WHEN t.status = 'pending' AND t.type = 'deposit' THEN 'Menunggu Pembayaran'
            WHEN t.status = 'verification' THEN 'Verifikasi Admin'
            WHEN t.status = 'approved' THEN 'Disetujui'
            WHEN t.status = 'rejected' THEN 'Ditolak'
            WHEN t.status = 'completed' THEN 'Selesai'
            ELSE t.status
        END as status_display,
        CASE 
            WHEN t.type = 'deposit' THEN 'Top Up'
            WHEN t.type = 'withdrawal' THEN 'Penarikan'
            WHEN t.type = 'bid' THEN 'Penawaran'
            WHEN t.type = 'win' THEN 'Kemenangan Lelang'
            WHEN t.type = 'refund' THEN 'Pengembalian Dana'
            ELSE t.type
        END as type_display
    FROM transactions t 
    WHERE t.user_id = ? 
    ORDER BY t.created_at DESC";
    
    $stmt = $conn->prepare($transactions_sql);
    
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . $conn->error);
    }
    
    $stmt->bind_param("i", $user_id);
    
    // Set timeout untuk mencegah query terlalu lama
    $timeout_start = microtime(true);
    $execute_result = $stmt->execute();
    
    // Cek jika query terlalu lama atau gagal
    if (!$execute_result || (microtime(true) - $timeout_start) > 3) {
        throw new Exception("Query timeout or failed");
    }
    
    $transactions_result = $stmt->get_result();
    $stmt->close();
} catch (Throwable $e) {
    error_log("Error fetching transactions: " . $e->getMessage());
    echo '<div class="alert alert-danger mb-4">
            <i class="fa fa-exclamation-circle"></i>
            Error mengambil data transaksi. Silakan coba lagi nanti.
          </div>';
    // Tetapkan null agar kode berikutnya tidak mencoba mengakses hasil
    $transactions_result = null;
}

// Hitung total deposit, withdrawal, dan hold amount
if ($transactions_result && $transactions_result instanceof mysqli_result && $transactions_result->num_rows > 0) {
    try {
        while ($tx = $transactions_result->fetch_assoc()) {
            if (isset($tx['type']) && isset($tx['status']) && $tx['type'] == 'deposit' && $tx['status'] == 'completed') {
                $total_deposit += (float)(isset($tx['amount']) ? $tx['amount'] : 0);
            } elseif (isset($tx['type']) && isset($tx['status']) && $tx['type'] == 'withdrawal' && $tx['status'] == 'completed') {
                $total_withdrawal += (float)(isset($tx['amount']) ? $tx['amount'] : 0);
            } elseif (isset($tx['type']) && $tx['type'] == 'bid_hold') {
                $hold_amount += (float)(isset($tx['amount']) ? $tx['amount'] : 0);
            }
        }
    } catch (Throwable $e) {
        error_log("Error processing transactions: " . $e->getMessage());
        // Continue with already calculated values
    }
}
?>

<!-- Transactions Table -->
<?php if ($use_modern_2025): ?>
<!-- Transaction Table - Modern 2025 Style -->
<div class="tab-content-2025 mb-4">
    <div class="tab-header-2025">
        <h3 class="tab-title-2025"><i class="fas fa-history"></i> Riwayat Transaksi</h3>
        <div class="tab-actions-2025">
            <button type="button" class="btn btn-sm btn-outline-primary" onclick="exportTransactions()"><i class="fas fa-download me-1"></i> Ekspor</button>
        </div>
    </div>
    <div class="tab-body-2025">
<?php else: ?>
<!-- Legacy Transaction Table -->
<div class="premium-card">
    <div class="card-body p-0">
<?php endif; ?>

        <?php if (!is_valid_result($transactions_result) || $transactions_result->num_rows == 0): ?>
            <?php if ($use_modern_2025): ?>
            <div class="no-transactions-2025">
                <div class="empty-state-icon">
                    <i class="fas fa-receipt"></i>
                </div>
                <h5>Belum Ada Transaksi</h5>
                <p>Belum ada riwayat transaksi yang tercatat.</p>
                <a href="topup.php" class="btn btn-primary mt-3">
                    <i class="fas fa-plus-circle me-2"></i>Top Up Sekarang
                </a>
            </div>
            <?php else: ?>
            <div class="p-4 text-center">
                <div class="empty-state">
                    <i class="fa fa-receipt fa-3x text-muted mb-3"></i>
                    <h5>Belum Ada Transaksi</h5>
                    <p class="text-muted">Belum ada riwayat transaksi yang tercatat.</p>
                    <a href="topup.php" class="btn premium-btn premium-btn-primary mt-3">
                        <i class="fa fa-plus-circle me-2"></i>Top Up Sekarang
                    </a>
                </div>
            </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="table-responsive">
                <?php if ($use_modern_2025): ?>
                <table class="transaction-table-2025">
                <?php else: ?>
                <table class="table premium-table table-hover">
                <?php endif; ?>
                <thead>
                    <tr>
                        <th>ID Transaksi</th>
                        <th>Tanggal</th>
                        <th>Jenis</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Reset result pointer
                    if ($transactions_result instanceof mysqli_result) {
                        $transactions_result->data_seek(0);
                    }
                    
                    while ($transactions_result instanceof mysqli_result && $transaction = $transactions_result->fetch_assoc()): 
                        // Ensure we have all required fields or set defaults
                        $tx_id = isset($transaction['transaction_id']) ? (int)$transaction['transaction_id'] : 0;
                        $tx_type = isset($transaction['type']) ? $transaction['type'] : '';
                        $tx_status = isset($transaction['status']) ? $transaction['status'] : '';
                        $tx_payment_proof = isset($transaction['payment_proof']) ? $transaction['payment_proof'] : '';
                        $tx_amount = isset($transaction['amount']) ? (float)$transaction['amount'] : 0;
                        $tx_date = isset($transaction['created_at']) ? $transaction['created_at'] : '';
                        $tx_notes = isset($transaction['notes']) ? $transaction['notes'] : '';
                        $tx_ref = isset($transaction['reference_number']) ? $transaction['reference_number'] : '';
                        $tx_payment_method = isset($transaction['payment_method']) ? $transaction['payment_method'] : '';
                        
                        // Format display values
                        $type_display = isset($transaction['type_display']) ? $transaction['type_display'] : ucfirst($tx_type);
                        $status_display = isset($transaction['status_display']) ? $transaction['status_display'] : ucfirst($tx_status);
                        
                        // Set badge color berdasarkan status
                        $status_badge = 'badge-secondary';
                        
                        switch($tx_status) {
                            case 'completed':
                            case 'approved':
                                $status_badge = 'badge-success';
                                break;
                            case 'pending':
                                $status_badge = 'badge-warning';
                                break;
                            case 'rejected':
                                $status_badge = 'badge-danger';
                                break;
                            case 'verification':
                                $status_badge = 'badge-info';
                                break;
                            default:
                                $status_badge = 'badge-secondary';
                        }
                    ?>
                    <tr>
                        <td><span class="badge premium-badge premium-badge-dark">#<?php echo get_value($transaction, 'transaction_id', 'N/A'); ?></span></td>
                        <td><?php echo get_formatted_date($transaction, 'created_at', 'd M Y H:i'); ?></td>
                        <td>
                            <?php 
                            // Set icon and label based on transaction type
                            list($type_icon, $type_label) = get_transaction_type_info($transaction);
                            ?>
                            <?php if ($use_modern_2025): ?>
                            <div class="transaction-type-2025">
                                <i class="fas <?php echo str_replace('fa-', '', $type_icon); ?>"></i>
                                <span><?php echo $type_label; ?></span>
                            </div>
                            <?php else: ?>
                            <i class="fa <?php echo $type_icon; ?> me-2"></i> <?php echo $type_label; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $is_income = (get_value($transaction, 'type') == 'deposit' || get_value($transaction, 'type') == 'bid_release' || get_value($transaction, 'type') == 'refund');
                            $amount_display = safe_format_currency(get_value($transaction, 'amount', 0));
                            ?>
                            <?php if ($use_modern_2025): ?>
                            <div class="transaction-amount-2025 <?php echo $is_income ? 'amount-income' : 'amount-expense'; ?>">
                                <span class="amount-prefix"><?php echo $is_income ? '+' : '-'; ?></span>
                                <span class="amount-value">Rp <?php echo $amount_display; ?></span>
                            </div>
                            <?php else: ?>
                            <span class="<?php echo $is_income ? 'text-success' : 'text-danger'; ?>">
                                <?php echo $is_income ? '+' : '-'; ?>
                                Rp <?php echo $amount_display; ?>
                            </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($use_modern_2025): ?>
                            <?php 
                            // Set modern badge class based on status
                            $modern_status_badge = 'status-secondary-2025';
                            
                            switch($tx_status) {
                                case 'completed':
                                case 'approved':
                                    $modern_status_badge = 'status-completed-2025';
                                    break;
                                case 'pending':
                                    $modern_status_badge = 'status-pending-2025';
                                    break;
                                case 'rejected':
                                    $modern_status_badge = 'status-rejected-2025';
                                    break;
                                case 'verification':
                                    $modern_status_badge = 'status-verification-2025';
                                    break;
                            }
                            ?>
                            <span class="transaction-status-2025 <?php echo $modern_status_badge; ?>">
                                <?php if ($tx_status == 'completed' || $tx_status == 'approved'): ?>
                                <i class="fas fa-check-circle"></i>
                                <?php elseif ($tx_status == 'pending'): ?>
                                <i class="fas fa-clock"></i>
                                <?php elseif ($tx_status == 'rejected'): ?>
                                <i class="fas fa-times-circle"></i>
                                <?php elseif ($tx_status == 'verification'): ?>
                                <i class="fas fa-search"></i>
                                <?php else: ?>
                                <i class="fas fa-info-circle"></i>
                                <?php endif; ?>
                                <?php echo $status_display; ?>
                            </span>
                            <?php else: ?>
                            <span class="badge <?php echo $status_badge; ?>"><?php echo $status_display; ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="notes-truncate">
                                <?php echo get_value($transaction, 'notes', '-'); ?>
                            </div>
                        </td>
                        <td>
                            <div class="d-flex">
                                <button type="button" class="btn premium-btn premium-btn-primary btn-sm me-2" data-bs-toggle="modal" data-bs-target="#transactionModal<?php echo get_value($transaction, 'transaction_id'); ?>">
                                    <i class="fa fa-eye"></i>
                                </button>
                                
                                <?php if (get_value($transaction, 'status') == 'pending' && get_value($transaction, 'type') == 'deposit'): ?>
                                <a href="upload-payment.php?id=<?php echo get_value($transaction, 'transaction_id'); ?>" class="btn premium-btn premium-btn-success btn-sm">
                                    <i class="fa fa-upload"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <?php if ($tx_type == 'deposit' && $tx_status == 'pending'): ?>
                                <a href="upload-payment.php?id=<?php echo $tx_id; ?>" class="btn btn-sm btn-primary">
                                    <i class="fa fa-upload"></i> Upload Bukti
                                </a>
                            <?php elseif ($tx_type == 'deposit' && $tx_status == 'verification'): ?>
                                <span class="badge badge-info">Sedang Diverifikasi</span>
                            <?php elseif ($tx_type == 'withdrawal' && $tx_status == 'pending'): ?>
                                <span class="badge badge-warning">Menunggu Proses</span>
                            <?php elseif ($tx_status == 'rejected'): ?>
                                <span class="text-danger"><i class="fa fa-times-circle"></i> Ditolak</span>
                            <?php elseif ($tx_status == 'approved' || $tx_status == 'completed'): ?>
                                <span class="text-success"><i class="fa fa-check-circle"></i> Selesai</span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
        
    <?php if ($use_modern_2025): ?>
    </div>
</div>
    <?php else: ?>
    </div>
</div>
    <?php endif; ?>
