<?php
/**
 * File untuk Wallet Tab yang sudah diperbaiki menggunakan helper functions
 * Untuk menghindari PHP errors dan warnings
 */

// Pastikan user_id sudah didefinisikan
if (!isset($user_id) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
}

// Query saldo user dengan validasi
if (empty($user_id)) {
    echo '<div class="alert alert-danger">User ID tidak valid.</div>';
    exit;
}

// Perbaikan query: menggunakan kolom 'user_id' bukan 'id'
$wallet_query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($wallet_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$wallet_result = $stmt->get_result();

if (!$wallet_result || $wallet_result->num_rows === 0) {
    echo '<div class="alert alert-danger">Data user tidak ditemukan.</div>';
    exit;
}

$wallet = $wallet_result->fetch_assoc();

// Inisialisasi variabel untuk wallet
$total_deposit = 0;
$total_withdrawal = 0;
$hold_amount = 0;
$available_balance = 0;

// Gunakan function_exists untuk mencegah fatal error redeclaration
if (!function_exists('get_transaction_type_info')) {
    function get_transaction_type_info($transaction) {
        $type = get_value($transaction, 'type', '');
        $icon = 'fa-question-circle';
        $label = 'Tidak diketahui';
        
        switch($type) {
            case 'deposit':
                $icon = 'fa-arrow-alt-circle-up';
                $label = 'Top Up';
                break;
            case 'withdrawal':
                $icon = 'fa-arrow-alt-circle-down';
                $label = 'Penarikan';
                break;
            case 'bid_hold':
                $icon = 'fa-lock';
                $label = 'Hold Bid';
                break;
            case 'bid_release':
                $icon = 'fa-unlock';
                $label = 'Release Bid';
                break;
            case 'payment':
                $icon = 'fa-credit-card';
                $label = 'Pembayaran';
                break;
            case 'refund':
                $icon = 'fa-undo';
                $label = 'Refund';
                break;
        }
        
        return array($icon, $label);
    }
}

// Fungsi helper untuk mendapatkan badge status transaksi
if (!function_exists('get_transaction_status_badge')) {
    function get_transaction_status_badge($transaction) {
    $status = get_value($transaction, 'status', '');
    $badge_class = 'premium-badge premium-badge-';
    $status_label = ucfirst($status);
    
    switch($status) {
        case 'completed':
            $badge_class .= 'success';
            $status_label = 'Sukses';
            break;
        case 'pending':
            $badge_class .= 'warning';
            $status_label = 'Pending';
            break;
        case 'failed':
            $badge_class .= 'danger';
            $status_label = 'Gagal';
            break;
        case 'processing':
            $badge_class .= 'info';
            $status_label = 'Diproses';
            break;
        default:
            $badge_class .= 'secondary';
    }
    
    return '<span class="' . $badge_class . '">' . $status_label . '</span>';
    }
}

// Fungsi helper untuk mendapatkan tanggal yang diformat
if (!function_exists('get_formatted_date')) {
    function get_formatted_date($data, $key, $format = 'd M Y H:i') {
        $date_str = get_value($data, $key, '');
        if (empty($date_str)) return '-';
        
        try {
            $date = new DateTime($date_str);
            return $date->format($format);
        } catch (Exception $e) {
            return $date_str;
        }
    }
}

// Ambil data transaksi user untuk daftar dan kalkulasi
$transactions_sql = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($transactions_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$transactions_result = $stmt->get_result();

// Hitung total deposit, withdrawal, hold amount dan available balance
if (is_valid_result($transactions_result)) {
    while ($tx = $transactions_result->fetch_assoc()) {
        if (get_value($tx, 'type') == 'deposit' && get_value($tx, 'status') == 'completed') {
            $total_deposit += (float)get_value($tx, 'amount', 0);
        } elseif (get_value($tx, 'type') == 'withdrawal' && get_value($tx, 'status') == 'completed') {
            $total_withdrawal += (float)get_value($tx, 'amount', 0);
        } elseif (get_value($tx, 'type') == 'bid_hold') {
            $hold_amount += (float)get_value($tx, 'amount', 0);
        }
    }
}

// Hitung saldo tersedia
$available_balance = $total_deposit - $total_withdrawal - $hold_amount;
if ($available_balance < 0) $available_balance = 0;
?>

<!-- Tab Wallet -->
<div class="tab-pane fade" id="wallet" role="tabpanel" aria-labelledby="wallet-tab">
    <h3 class="mb-4 animated-heading"><i class="fa fa-wallet me-2"></i>Dompet Saya</h3>
    
    <!-- Card informasi saldo - Style Modern 2025 tapi minimalis -->
    <div class="card mb-4 wallet-card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-wallet me-2"></i>Informasi Saldo</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-3 mb-md-0">
                    <div class="text-center p-3 border rounded h-100 d-flex flex-column justify-content-center wallet-balance-card">
                        <h6 class="text-muted mb-2">Saldo Tersedia</h6>
                        <h3 class="fw-bold text-primary mb-0"><?php echo format_currency($available_balance); ?></h3>
                        <?php if (isset($hold_amount) && $hold_amount > 0): ?>
                        <div class="small text-muted mt-2">Saldo ditahan: <?php echo format_currency($hold_amount); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4 mb-3 mb-md-0">
                    <div class="text-center p-3 border rounded h-100 d-flex flex-column justify-content-center wallet-deposit-card">
                        <h6 class="text-muted mb-2">Total Deposit</h6>
                        <h3 class="fw-bold text-success mb-0"><?php echo format_currency($total_deposit); ?></h3>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="text-center p-3 border rounded h-100 d-flex flex-column justify-content-center wallet-withdraw-card">
                        <h6 class="text-muted mb-2">Total Penarikan</h6>
                        <h3 class="fw-bold text-danger mb-0"><?php echo format_currency($total_withdrawal); ?></h3>
                    </div>
                </div>
            </div>

            <!-- Action buttons dengan koneksi langsung ke topup.php dan withdraw.php -->
            <div class="d-flex justify-content-end mt-4">
                <a href="topup.php" class="btn btn-primary me-2">
                    <i class="fas fa-plus-circle me-1"></i> Top Up Saldo
                </a>
                <?php if ($available_balance >= 50000): ?>
                <a href="withdraw.php" class="btn btn-outline-primary">
                    <i class="fas fa-money-bill-wave me-1"></i> Tarik Saldo
                </a>
                <?php else: ?>
                <button class="btn btn-outline-secondary" disabled title="Minimal saldo Rp 50.000 untuk melakukan penarikan">
                    <i class="fas fa-money-bill-wave me-1"></i> Tarik Saldo
                </button>
                <?php endif; ?>
            </div>
            
            <!-- Status Transaksi Tertunda -->
            <?php 
            // Cek transaksi deposit tertunda jika ada
            $pending_query = "SELECT COUNT(*) as count FROM transactions WHERE user_id = ? AND type = 'deposit' AND status = 'pending'";
            $pending_stmt = $conn->prepare($pending_query);
            $pending_count = 0;
            
            if ($pending_stmt) {
                $pending_stmt->bind_param("i", $user_id);
                $pending_stmt->execute();
                $pending_result = $pending_stmt->get_result()->fetch_assoc();
                $pending_count = $pending_result['count'] ?? 0;
            }
            
            if ($pending_count > 0): 
            ?>
            <div class="alert alert-warning mt-3 d-flex align-items-center" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <div>
                    Anda memiliki <?php echo $pending_count; ?> transaksi topup yang belum diupload bukti pembayaran.
                    <a href="#transactionsTab" class="alert-link" onclick="document.getElementById('transactionsTab').click();">Lihat detail</a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="wallet-dashboard-container">
        <!-- Premium Wallet Overview Card -->
        <div class="wallet-premium-card fade-in-up js-tilt-card">
            <div class="wallet-premium-header">
                <h5><i class="fa fa-tachometer-alt me-2"></i> Dashboard Keuangan</h5>
                <span class="timestamp"><i class="fa fa-clock me-1"></i><?php echo date('d M Y H:i'); ?></span>
            </div>
            
            <div class="wallet-balance-display">
                <div class="wallet-balance-icon">
                    <i class="fa fa-wallet"></i>
                    <div class="coin coin-1"></div>
                    <div class="coin coin-2"></div>
                    <div class="coin coin-3"></div>
                </div>
                <div class="wallet-balance-text">
                    <span>Saldo Tersedia</span>
                    <strong>Rp <?php echo safe_format_currency($available_balance); ?></strong>
                </div>
            </div>
        </div>
        
        <!-- Financial Stats -->
        <div class="wallet-stats-container">
            <div class="wallet-stat-card scale-in" style="animation-delay: 0.1s;">
                <div class="wallet-stat-icon blue">
                    <i class="fa fa-money-bill-wave"></i>
                </div>
                <div class="wallet-stat-value">Rp <?php echo safe_format_currency($total_deposit - $total_withdrawal); ?></div>
                <div class="wallet-stat-label">Total Saldo</div>
            </div>
            
            <div class="wallet-stat-card scale-in" style="animation-delay: 0.2s;">
                <div class="wallet-stat-icon green">
                    <i class="fa fa-arrow-alt-circle-up"></i>
                </div>
                <div class="wallet-stat-value">Rp <?php echo safe_format_currency($total_deposit); ?></div>
                <div class="wallet-stat-label">Total Deposit</div>
            </div>
            
            <div class="wallet-stat-card scale-in" style="animation-delay: 0.3s;">
                <div class="wallet-stat-icon orange">
                    <i class="fa fa-lock"></i>
                </div>
                <div class="wallet-stat-value">Rp <?php echo safe_format_currency($hold_amount); ?></div>
                <div class="wallet-stat-label">Dana Hold untuk Bid</div>
            </div>
        </div>
    </div>
    
    <!-- Top Up & Withdraw Quick Access -->
    <div class="wallet-quick-access">
        <div class="wallet-action-card fade-in-up" style="animation-delay: 0.1s;">
            <div class="wallet-action-header">
                <i class="fa fa-plus-circle"></i>
                <h5>Top Up Dana</h5>
            </div>
            <div class="wallet-action-body">
                <p>Tambahkan dana ke akun Anda untuk memulai penawaran lelang</p>
                <a href="topup.php" class="btn btn-primary">Top Up Sekarang</a>
                    </div>
                    <div class="benefit-item d-flex align-items-center mb-3">
                        <div class="feature-icon bg-success-light text-success me-3 rounded-circle" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
                            <i class="fa fa-shield-alt"></i>
                        </div>
                        <div class="benefit-info">
                            <h6 class="mb-1">Aman & Terjamin</h6>
                            <p class="small text-muted mb-0">Transaksi dienkripsi dan dijamin aman</p>
                        </div>
                    </div>
                </div>
                
                <div class="preset-amounts mb-3">
                    <a href="topup.php?amount=100000" class="preset-amount-btn">Rp 100.000</a>
                    <a href="topup.php?amount=500000" class="preset-amount-btn">Rp 500.000</a>
                    <a href="topup.php?amount=1000000" class="preset-amount-btn">Rp 1.000.000</a>
                </div>
                
                <a href="topup.php" class="wallet-action-btn">
                    <i class="fa fa-plus-circle me-2"></i>Top Up Sekarang
                </a>
            </div>
        </div>
        <div class="wallet-action-card fade-in-up" style="animation-delay: 0.2s;">
            <div class="wallet-action-header">
                <i class="fa fa-money-bill-wave"></i>
                <h5>Tarik Dana</h5>
            </div>
            <div class="wallet-action-body">
                <p>Tarik dana dari akun Anda ke rekening bank pribadi</p>
                
                <?php if ($available_balance >= 50000): ?>
                <a href="withdraw.php" class="btn btn-outline-primary">
                    <i class="fa fa-money-bill-wave me-2"></i>Tarik Dana Sekarang
                </a>
                <?php else: ?>
                <div class="alert alert-info small">
                    <i class="fa fa-info-circle me-2"></i>
                    Minimal saldo Rp 50.000 untuk melakukan penarikan
                </div>
                <button class="btn btn-outline-secondary" disabled>
                    <i class="fa fa-money-bill-wave me-2"></i>Tarik Dana
                </button>
                <?php endif; ?>
            </div>
            <div class="bank-info mb-3">
                    <div class="bank-info-title">
                        <i class="fa fa-info-circle"></i> Informasi Penarikan
                    </div>
                    
                    <div class="bank-detail">
                        <div class="bank-detail-label">Dana Tersedia:</div>
                        <div class="bank-detail-value">Rp <?php echo safe_format_currency($available_balance); ?></div>
                    </div>
                    
                    <div class="bank-detail">
                        <div class="bank-detail-label">Bank:</div>
                        <div class="bank-detail-value">
                            <?php echo isset($user['bank_name']) && !empty($user['bank_name']) ? htmlspecialchars($user['bank_name']) : '<span class="text-warning">Belum ada rekening</span>'; ?>
                        </div>
                    </div>
                    
                    <div class="bank-detail">
                        <div class="bank-detail-label">No. Rekening:</div>
                        <div class="bank-detail-value">
                            <?php if (isset($user['bank_account']) && !empty($user['bank_account'])): ?>
                                <?php echo htmlspecialchars($user['bank_account']); ?>
                                <button class="bank-copy-btn" onclick="copyToClipboard('<?php echo htmlspecialchars($user['bank_account']); ?>')" title="Salin nomor rekening">
                                    <i class="fa fa-copy"></i>
                                </button>
                            <?php else: ?>
                                <span class="text-warning">Tambahkan di profil</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="withdraw-notice small text-muted mb-3">
                    <i class="fa fa-clock me-1"></i> Dana dapat ditarik ke rekening bank terdaftar selama jam kerja. Proses membutuhkan waktu 1x24 jam kerja.
                </div>
                
                <div class="preset-amounts mb-3">
                    <a href="withdraw.php?amount=100000" class="preset-amount-btn">Rp 100.000</a>
                    <a href="withdraw.php?amount=500000" class="preset-amount-btn">Rp 500.000</a>
                    <a href="withdraw.php?amount=1000000" class="preset-amount-btn">Rp 1.000.000</a>
                </div>
                
                <a href="withdraw.php" class="wallet-action-btn">
                    <i class="fa fa-money-bill-wave me-2"></i>Tarik Dana Sekarang
                </a>
            </div>
        </div>
    </div>
    
    <!-- Recent Transactions -->
    <div class="wallet-transactions-container fade-in-up">
        <div class="wallet-transactions-header">
            <h5><i class="fa fa-history me-2"></i> Transaksi Terakhir</h5>
            <a href="#transactions" class="view-all" data-bs-toggle="tab" data-bs-target="#transactions" role="tab">
                Lihat Semua <i class="fa fa-arrow-right ms-1"></i>
            </a>
        </div>
        
        <div class="wallet-transactions-body">
            <?php if (!is_valid_result($transactions_result) || $transactions_result->num_rows == 0): ?>
            <div class="empty-transactions">
                <i class="fa fa-receipt"></i>
                <p>Belum Ada Transaksi</p>
                <a href="topup.php" class="wallet-action-btn">
                    <i class="fa fa-plus-circle me-2"></i>Mulai dengan Top Up
                </a>
            </div>
            <?php else: ?>
                <?php 
                // Reset pointer and limit to 5 rows dengan validasi
                if (is_valid_result($transactions_result)) {
                    $transactions_result->data_seek(0);
                    $count = 0;
                    $transaction_list = array();
                    
                    // Ambil 5 data teratas dengan aman
                    while ($count < 5 && $row = $transactions_result->fetch_assoc()) {
                        $transaction_list[] = $row;
                        $count++;
                    }
                    
                    // Loop melalui array data yang sudah diambil
                    foreach ($transaction_list as $transaction):
                        // Get transaction type info
                        list($type_icon, $type_label) = get_transaction_type_info($transaction);
                        
                        // Tentukan kelas ikon berdasarkan tipe transaksi
                        $transaction_type = get_value($transaction, 'type', '');
                        $icon_class = 'transaction-icon ';
                        $amount_class = 'transaction-amount ';
                        
                        if ($transaction_type == 'deposit') {
                            $icon_class .= 'deposit';
                            $amount_class .= 'deposit';
                        } elseif ($transaction_type == 'withdrawal') {
                            $icon_class .= 'withdrawal';
                            $amount_class .= 'withdrawal';
                        } elseif ($transaction_type == 'bid_hold') {
                            $icon_class .= 'bid-hold';
                            $amount_class .= 'bid-hold';
                        } elseif ($transaction_type == 'bid_release') {
                            $icon_class .= 'bid-release';
                            $amount_class .= 'bid-release';
                        }
                        
                        $transaction_status = get_value($transaction, 'status', '');
                        $status_class = 'transaction-status ' . $transaction_status;
                ?>
                <div class="wallet-transaction-item">
                    <div class="<?php echo $icon_class; ?>">
                        <i class="fa <?php echo $type_icon; ?>"></i>
                    </div>
                    <div class="transaction-info">
                        <div class="transaction-title"><?php echo $type_label; ?></div>
                        <div class="transaction-meta">
                            <div class="transaction-date">
                                <i class="fa fa-calendar-alt me-1"></i> <?php echo get_formatted_date($transaction, 'created_at', 'd M Y'); ?>
                            </div>
                            <div class="transaction-id">
                                <i class="fa fa-hashtag me-1"></i> <?php echo get_value($transaction, 'transaction_id', 'N/A'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="<?php echo $amount_class; ?>">
                        <?php echo ($transaction_type == 'deposit' || $transaction_type == 'bid_release') ? '+' : '-'; ?>
                        Rp <?php echo safe_format_currency(get_value($transaction, 'amount', 0)); ?>
                    </div>
                    <div class="<?php echo $status_class; ?>">
                        <?php echo ucfirst($transaction_status); ?>
                    </div>
                </div>
                <?php 
                    endforeach;
                }
                ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- JavaScript untuk Copy to Clipboard -->
    <script>
    function copyToClipboard(text) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        
        // Tampilkan notifikasi berhasil disalin
        const tooltip = document.createElement('div');
        tooltip.className = 'copy-tooltip';
        tooltip.textContent = 'Berhasil disalin!';
        document.body.appendChild(tooltip);
        
        setTimeout(() => {
            document.body.removeChild(tooltip);
        }, 2000);
    }
    </script>
</div><!-- Akhir wallet tab -->
<?php
// Tutup tag PHP yang mungkin hilang
?>
