<?php
/**
 * Process Address Form
 * Handles form submissions for adding new addresses or updating existing ones
 */

// Include necessary files
include_once 'includes/config.php';
include_once 'includes/db-connect.php';
include_once 'includes/auth-check.php';
include_once 'includes/functions.php';

// Redirect if user not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?message=' . urlencode('Anda harus login terlebih dahulu'));
    exit;
}

$user_id = $_SESSION['user_id'];
$response = [];
$redirect_url = 'account.php';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Add a new address
    if ($action === 'add_address') {
        // Sanitize and validate inputs
        $address_type = filter_input(INPUT_POST, 'address_type', FILTER_SANITIZE_STRING) ?? 'home';
        $address_label = filter_input(INPUT_POST, 'address_label', FILTER_SANITIZE_STRING) ?? '';
        $recipient_name = filter_input(INPUT_POST, 'recipient_name', FILTER_SANITIZE_STRING) ?? '';
        $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING) ?? '';
        $province = filter_input(INPUT_POST, 'province', FILTER_SANITIZE_STRING) ?? '';
        $city = filter_input(INPUT_POST, 'city', FILTER_SANITIZE_STRING) ?? '';
        $district = filter_input(INPUT_POST, 'district', FILTER_SANITIZE_STRING) ?? '';
        $postal_code = filter_input(INPUT_POST, 'postal_code', FILTER_SANITIZE_STRING) ?? '';
        $full_address = filter_input(INPUT_POST, 'full_address', FILTER_SANITIZE_STRING) ?? '';
        $is_default = isset($_POST['default_address']) ? 1 : 0;
        
        // Validate required fields
        if (empty($recipient_name) || empty($phone) || empty($province) || empty($city) || empty($full_address)) {
            $_SESSION['error_message'] = 'Semua field wajib diisi';
            header('Location: ' . $redirect_url);
            exit;
        }
        
        try {
            // Begin transaction
            $db->beginTransaction();
            
            // If this is the default address, unset any existing default addresses
            if ($is_default) {
                $stmt = $db->prepare("UPDATE user_addresses SET is_default = 0 WHERE user_id = :user_id");
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->execute();
            }
            
            // Insert the new address
            $stmt = $db->prepare("INSERT INTO user_addresses (
                user_id, address_type, address_label, recipient_name, phone, 
                province, city, district, postal_code, full_address, is_default
            ) VALUES (
                :user_id, :address_type, :address_label, :recipient_name, :phone,
                :province, :city, :district, :postal_code, :full_address, :is_default
            )");
            
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':address_type', $address_type, PDO::PARAM_STR);
            $stmt->bindParam(':address_label', $address_label, PDO::PARAM_STR);
            $stmt->bindParam(':recipient_name', $recipient_name, PDO::PARAM_STR);
            $stmt->bindParam(':phone', $phone, PDO::PARAM_STR);
            $stmt->bindParam(':province', $province, PDO::PARAM_STR);
            $stmt->bindParam(':city', $city, PDO::PARAM_STR);
            $stmt->bindParam(':district', $district, PDO::PARAM_STR);
            $stmt->bindParam(':postal_code', $postal_code, PDO::PARAM_STR);
            $stmt->bindParam(':full_address', $full_address, PDO::PARAM_STR);
            $stmt->bindParam(':is_default', $is_default, PDO::PARAM_INT);
            
            $result = $stmt->execute();
            
            // Also update the main user address if this is the default address
            if ($is_default) {
                $formatted_address = "$full_address, $district, $city, $province, $postal_code";
                $stmt = $db->prepare("UPDATE users SET address = :address WHERE id = :user_id");
                $stmt->bindParam(':address', $formatted_address, PDO::PARAM_STR);
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->execute();
            }
            
            // Commit transaction
            $db->commit();
            
            $_SESSION['success_message'] = 'Alamat berhasil ditambahkan';
            
        } catch (PDOException $e) {
            // Rollback transaction on error
            $db->rollBack();
            
            $_SESSION['error_message'] = 'Gagal menambahkan alamat: ' . $e->getMessage();
        }
    }
    
    // Delete an address
    else if ($action === 'delete_address') {
        $address_id = filter_input(INPUT_POST, 'address_id', FILTER_SANITIZE_NUMBER_INT);
        
        if (!empty($address_id)) {
            try {
                // Check if address belongs to the user
                $stmt = $db->prepare("SELECT is_default FROM user_addresses WHERE id = :address_id AND user_id = :user_id");
                $stmt->bindParam(':address_id', $address_id, PDO::PARAM_INT);
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->execute();
                $address = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($address) {
                    $is_default = $address['is_default'];
                    
                    // Delete the address
                    $stmt = $db->prepare("DELETE FROM user_addresses WHERE id = :address_id AND user_id = :user_id");
                    $stmt->bindParam(':address_id', $address_id, PDO::PARAM_INT);
                    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                    $result = $stmt->execute();
                    
                    // If deleted address was default, set another address as default
                    if ($is_default) {
                        $stmt = $db->prepare("SELECT id FROM user_addresses WHERE user_id = :user_id LIMIT 1");
                        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                        $stmt->execute();
                        $new_default = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($new_default) {
                            $stmt = $db->prepare("UPDATE user_addresses SET is_default = 1 WHERE id = :address_id");
                            $stmt->bindParam(':address_id', $new_default['id'], PDO::PARAM_INT);
                            $stmt->execute();
                            
                            // Also update main user address
                            $stmt = $db->prepare("SELECT CONCAT(full_address, ', ', district, ', ', city, ', ', province, ', ', postal_code) as formatted_address FROM user_addresses WHERE id = :address_id");
                            $stmt->bindParam(':address_id', $new_default['id'], PDO::PARAM_INT);
                            $stmt->execute();
                            $address_data = $stmt->fetch(PDO::FETCH_ASSOC);
                            
                            if ($address_data) {
                                $stmt = $db->prepare("UPDATE users SET address = :address WHERE id = :user_id");
                                $stmt->bindParam(':address', $address_data['formatted_address'], PDO::PARAM_STR);
                                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                                $stmt->execute();
                            }
                        } else {
                            // No addresses left, clear main address
                            $stmt = $db->prepare("UPDATE users SET address = NULL WHERE id = :user_id");
                            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                            $stmt->execute();
                        }
                    }
                    
                    $_SESSION['success_message'] = 'Alamat berhasil dihapus';
                } else {
                    $_SESSION['error_message'] = 'Alamat tidak ditemukan';
                }
            } catch (PDOException $e) {
                $_SESSION['error_message'] = 'Gagal menghapus alamat: ' . $e->getMessage();
            }
        } else {
            $_SESSION['error_message'] = 'ID alamat tidak valid';
        }
    }
    
    // Set an address as default
    else if ($action === 'set_default_address') {
        $address_id = filter_input(INPUT_POST, 'address_id', FILTER_SANITIZE_NUMBER_INT);
        
        if (!empty($address_id)) {
            try {
                // Begin transaction
                $db->beginTransaction();
                
                // Check if address belongs to the user
                $stmt = $db->prepare("SELECT * FROM user_addresses WHERE id = :address_id AND user_id = :user_id");
                $stmt->bindParam(':address_id', $address_id, PDO::PARAM_INT);
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->execute();
                $address = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($address) {
                    // Clear all default flags for this user
                    $stmt = $db->prepare("UPDATE user_addresses SET is_default = 0 WHERE user_id = :user_id");
                    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                    $stmt->execute();
                    
                    // Set this address as default
                    $stmt = $db->prepare("UPDATE user_addresses SET is_default = 1 WHERE id = :address_id");
                    $stmt->bindParam(':address_id', $address_id, PDO::PARAM_INT);
                    $stmt->execute();
                    
                    // Update main user address
                    $formatted_address = $address['full_address'] . ', ' . $address['district'] . ', ' . 
                                         $address['city'] . ', ' . $address['province'] . ', ' . $address['postal_code'];
                    
                    $stmt = $db->prepare("UPDATE users SET address = :address WHERE id = :user_id");
                    $stmt->bindParam(':address', $formatted_address, PDO::PARAM_STR);
                    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                    $stmt->execute();
                    
                    // Commit transaction
                    $db->commit();
                    
                    $_SESSION['success_message'] = 'Alamat utama berhasil diubah';
                } else {
                    $db->rollBack();
                    $_SESSION['error_message'] = 'Alamat tidak ditemukan';
                }
            } catch (PDOException $e) {
                $db->rollBack();
                $_SESSION['error_message'] = 'Gagal mengubah alamat utama: ' . $e->getMessage();
            }
        } else {
            $_SESSION['error_message'] = 'ID alamat tidak valid';
        }
    }
}

// Redirect back to account page
header('Location: ' . $redirect_url);
exit;
?>
