<?php
/**
 * Modern Bids History Page
 * LelangMobil Web App - Versi 2025
 */

// Include performance optimizer untuk memastikan loading desktop yang optimal
require_once 'config/performance-optimizer.php';

// Aktifkan output buffering untuk performa optimal
if (!ob_get_level()) {
    ob_start();
}

// Aktifkan error reporting dan logging (debug mode hanya ditampilkan jika diperlukan)
error_reporting(E_ALL);
ini_set('display_errors', isset($_GET['debug']) ? 1 : 0);
ini_set('max_execution_time', 15); // Kurangi timeout yang berlebihan

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';
$user_id = $_SESSION['user_id'];

// Get user information dengan cache untuk performa desktop optimal
try {
    // Gunakan database query cache untuk mempercepat loading
    $user_result = db_get_cached($conn, "SELECT * FROM users WHERE user_id = ?", [$user_id], 'i');
    
    if (!isset($user_result['error']) && isset($user_result['data']) && count($user_result['data']) > 0) {
        $user = $user_result['data'][0];
    } else {
        // Fallback jika cache gagal
        $user_sql = "SELECT * FROM users WHERE user_id = ?";
        $user_stmt = $conn->prepare($user_sql);
        $user_stmt->bind_param("i", $user_id);
        $user_stmt->execute();
        $user_result = $user_stmt->get_result();
        $user = $user_result->fetch_assoc();
        
        if (!$user) {
            throw new Exception("User data not found");
        }
    }
} catch (Throwable $e) {
    error_log("Error in bids-modern.php: " . $e->getMessage());
    $error = "Terjadi kesalahan saat memuat data pengguna. Silakan coba refresh halaman.";
}

// Get Bids with Pagination
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$items_per_page = 10;
$offset = ($page - 1) * $items_per_page;

// Get total count for pagination dengan cache
$cache_enabled = !isset($_GET['nocache']); // Disable cache dengan parameter nocache untuk debugging

if ($cache_enabled) {
    // Gunakan cache untuk mempercepat loading di desktop
    $count_result = db_get_cached($conn, "SELECT COUNT(*) as total FROM bids WHERE bidder_id = ?", [$user_id], 'i', 60); // Cache 1 menit
    
    if (!isset($count_result['error']) && isset($count_result['data']) && count($count_result['data']) > 0) {
        $total_items = $count_result['data'][0]['total'];
    } else {
        // Fallback jika cache gagal
        $count_sql = "SELECT COUNT(*) as total FROM bids WHERE bidder_id = ?";
        $count_stmt = $conn->prepare($count_sql);
        $count_stmt->bind_param("i", $user_id);
        $count_stmt->execute();
        $count_result = $count_stmt->get_result();
        $count_row = $count_result->fetch_assoc();
        $total_items = $count_row['total'];
    }
} else {
    // Tanpa cache untuk debugging
    $count_sql = "SELECT COUNT(*) as total FROM bids WHERE bidder_id = ?";
    $count_stmt = $conn->prepare($count_sql);
    $count_stmt->bind_param("i", $user_id);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $count_row = $count_result->fetch_assoc();
    $total_items = $count_row['total'];
}
$total_pages = ceil($total_items / $items_per_page);

// Get paginated bids with vehicle details menggunakan query langsung dengan struktur database produksi
try {
    $bids_sql = "SELECT bids.bid_id, bids.vehicle_id, bids.bidder_id, bids.bid_amount, bids.bid_time, 
               vehicles.model, vehicles.make, vehicles.image, vehicles.starting_price, 
               vehicles.current_bid, vehicles.auction_end as end_date, vehicles.status
               FROM bids
               LEFT JOIN vehicles ON bids.vehicle_id = vehicles.vehicle_id
               WHERE bids.bidder_id = ?
               ORDER BY bids.bid_time DESC
               LIMIT ? OFFSET ?";
    
    if ($cache_enabled) {
        // Gunakan cache untuk performa desktop yang optimal
        $cache_key = "user_bids_{$user_id}_{$page}";
        $bids_result_cached = db_get_cached($conn, $bids_sql, [$user_id, $items_per_page, $offset], 'iii', 30);
        
        if (!isset($bids_result_cached['error']) && isset($bids_result_cached['data'])) {
            // Buat mysqli_result simulasi untuk kompatibilitas dengan kode lama
            $bids_data = $bids_result_cached['data'];
            
            // Custom class yang berperilaku seperti mysqli_result
            $bids_result = new class($bids_data) {
                private $data;
                private $position = 0;
                public $num_rows;
                
                public function __construct($data) {
                    $this->data = $data;
                    $this->num_rows = count($data);
                }
                
                public function fetch_assoc() {
                    if ($this->position >= $this->num_rows) {
                        return null;
                    }
                    return $this->data[$this->position++];
                }
                
                public function data_seek($position) {
                    $this->position = $position;
                    return true;
                }
            };
        } else {
            // Fallback ke query tanpa cache
            $bids_stmt = $conn->prepare($bids_sql);
            $bids_stmt->bind_param("iii", $user_id, $items_per_page, $offset);
            $bids_stmt->execute();
            $bids_result = $bids_stmt->get_result();
        }
    } else {
        // Eksekusi normal tanpa cache untuk debug
        $bids_stmt = $conn->prepare($bids_sql);
        $bids_stmt->bind_param("iii", $user_id, $items_per_page, $offset);
        $bids_stmt->execute();
        $bids_result = $bids_stmt->get_result();
    }
} catch (Throwable $e) {
    error_log("Error in bids-modern.php query execution: " . $e->getMessage());
    $error = "Terjadi kesalahan saat memuat riwayat bid. Silakan coba refresh halaman."; 
    $bids_result = false;
}

// Aktifkan flag untuk halaman dashboard dan tema modern
$page_title = "Riwayat Bid Saya";
$is_dashboard_page = true;
$use_modern_dashboard = true;

// Set variabel untuk komponen bids
$show_pagination = true;
$current_page = $page;

// Include header
include("includes/header.php");
?>

<!-- Main Content Container -->
<div class="container-fluid py-5">
    <?php if (!empty($success)): ?>
    <div class="modern-alert modern-alert-success mb-4 fade-in">
        <i class="fa fa-check-circle"></i>
        <div><?php echo $success; ?></div>
    </div>
    <?php endif; ?>
    
    <?php if (!empty($error)): ?>
    <div class="modern-alert modern-alert-danger mb-4 fade-in">
        <i class="fa fa-exclamation-circle"></i>
        <div><?php echo $error; ?></div>
    </div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Sidebar Navigation -->
        <div class="col-lg-3">
            <?php include("includes/account-navbar.php"); ?>
        </div>
        
        <!-- Main Content -->
        <div class="col-lg-9">
            <h2 class="mb-4 fade-in"><?php echo $page_title; ?></h2>
            
            <!-- Main Content -->
            <div class="modern-card fade-in">
                <div class="modern-card-header">
                    <h3 class="modern-card-title"><i class="fa fa-gavel"></i> Riwayat Tawaran Lelang</h3>
                    
                    <div class="bid-filters">
                        <select id="filterBidStatus" class="modern-form-control form-select-sm">
                            <option value="">Semua Status</option>
                            <option value="active">Aktif</option>
                            <option value="won">Menang</option>
                            <option value="outbid">Dikalahkan</option>
                            <option value="ended">Selesai</option>
                        </select>
                    </div>
                </div>
                
                <div class="modern-card-body p-0">
                    <?php if (!$bids_result || $bids_result->num_rows == 0): ?>
                        <div class="p-4 text-center">
                            <div class="empty-state">
                                <i class="fa fa-gavel fa-3x text-muted mb-3"></i>
                                <h5>Belum Ada Bid</h5>
                                <p class="text-muted">Belum ada riwayat bid yang Anda lakukan.</p>
                                <a href="auctions.php" class="modern-button modern-button-primary mt-3">
                                    <i class="fa fa-search me-2"></i>Lihat Lelang Aktif
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="modern-table" id="bidsTable">
                                <thead>
                                    <tr>
                                        <th width="15%">Foto</th>
                                        <th width="25%">Kendaraan</th>
                                        <th width="15%">Jumlah Bid</th>
                                        <th width="15%">Waktu Bid</th>
                                        <th width="15%">Status</th>
                                        <th width="15%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    while ($bid = $bids_result->fetch_assoc()): 
                                        // Set status badge
                                        $now = new DateTime();
                                        $end_date = new DateTime($bid['end_date']);
                                        $is_ended = $end_date < $now || $bid['status'] == 'ended';
                                        
                                        $status = 'active';
                                        $status_label = 'Aktif';
                                        $status_badge_color = 'info';
                                        $status_icon = 'fa-clock';
                                        
                                        if ($is_ended) {
                                            $status = 'ended';
                                            $status_label = 'Selesai';
                                            $status_badge_color = 'secondary';
                                            $status_icon = 'fa-check';
                                        }
                                        
                                        // Check if this is the current highest bid
                                        $is_highest = false;
                                        if (isset($bid['current_bid']) && isset($bid['bid_amount']) && $bid['bid_amount'] >= $bid['current_bid']) {
                                            $is_highest = true;
                                            
                                            if ($is_ended) {
                                                $status = 'won';
                                                $status_label = 'Menang';
                                                $status_badge_color = 'success';
                                                $status_icon = 'fa-trophy';
                                            }
                                        } else {
                                            $status = 'outbid';
                                            $status_label = 'Dikalahkan';
                                            $status_badge_color = 'warning';
                                            $status_icon = 'fa-arrow-down';
                                        }
                                    ?>
                                    <tr data-status="<?php echo $status; ?>">
                                        <td>
                                            <img src="<?php echo !empty($bid['image']) ? 'uploads/vehicles/'.$bid['image'] : 'images/no-image.svg'; ?>" 
                                                 alt="<?php echo htmlspecialchars($bid['make'] . ' ' . $bid['model']); ?>" 
                                                 class="img-fluid rounded"
                                                 style="max-height: 60px; width: 100%; object-fit: cover;"
                                                 onerror="this.src='images/no-image.svg';">
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <strong><?php echo htmlspecialchars($bid['make'] . ' ' . $bid['model']); ?></strong>
                                                <small class="text-muted">ID Kendaraan: #<?php echo $bid['vehicle_id']; ?></small>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="fw-bold">Rp<?php echo number_format($bid['bid_amount'], 0, ',', '.'); ?></span>
                                            <?php if ($is_highest && !$is_ended): ?>
                                            <span class="modern-badge modern-badge-success d-block mt-1"><i class="fa fa-check"></i> Tertinggi</span>
                                            <?php elseif (!$is_highest): ?>
                                            <span class="d-block text-muted mt-1"><small>Bid Tertinggi: Rp<?php echo number_format($bid['current_bid'], 0, ',', '.'); ?></small></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo date('d M Y', strtotime($bid['bid_time'])); ?>
                                            <div class="text-muted"><small><?php echo date('H:i', strtotime($bid['bid_time'])); ?></small></div>
                                        </td>
                                        <td>
                                            <span class="modern-badge modern-badge-<?php echo $status_badge_color; ?>">
                                                <i class="fa <?php echo $status_icon; ?>"></i> <?php echo $status_label; ?>
                                            </span>
                                            <?php if (!$is_ended): ?>
                                            <div class="small mt-1">
                                                <i class="fa fa-calendar-alt"></i> Berakhir: <?php echo date('d M Y', strtotime($bid['end_date'])); ?>
                                            </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <a href="vehicle.php?id=<?php echo $bid['vehicle_id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fa fa-eye"></i> Detail
                                                </a>
                                                <?php if ($status == 'active' && !$is_highest): ?>
                                                <a href="vehicle.php?id=<?php echo $bid['vehicle_id']; ?>#bid-form" class="btn btn-sm btn-success">
                                                    <i class="fa fa-gavel"></i> Bid Lagi
                                                </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
                
                <?php if (isset($show_pagination) && $show_pagination): ?>
                <div class="modern-card-footer d-flex justify-content-between align-items-center">
                    <div class="text-muted small">
                        Menampilkan <?php echo $bids_result->num_rows; ?> dari <?php echo $total_items; ?> bid
                    </div>
                    
                    <?php if (isset($total_pages) && $total_pages > 1): ?>
                    <nav>
                        <ul class="pagination pagination-sm mb-0">
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php echo $i == $current_page ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="mt-4">
                <div class="d-flex gap-2 justify-content-end">
                    <a href="account-modern.php" class="modern-button modern-button-outline">
                        <i class="fa fa-arrow-left me-2"></i>Kembali ke Dashboard
                    </a>
                    <a href="auctions.php" class="modern-button modern-button-primary">
                        <i class="fa fa-search me-2"></i>Lihat Lelang Aktif
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Bids filter functionality
    const statusFilter = document.getElementById('filterBidStatus');
    const bidsTable = document.getElementById('bidsTable');
    
    if (statusFilter && bidsTable) {
        statusFilter.addEventListener('change', function() {
            const statusValue = this.value;
            const rows = bidsTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const rowStatus = row.getAttribute('data-status');
                
                if (!statusValue || rowStatus === statusValue) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});
</script>

<?php include("includes/footer.php"); ?>
