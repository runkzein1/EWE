<?php
/**
 * LelangMobil Admin Security Dashboard
 * Version: 1.0 (14 Mei 2025)
 *
 * This dashboard allows administrators to monitor security-related activities
 * and respond to potential threats on the LelangMobil platform.
 */

// Ensure this page is only accessible to administrators
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Include necessary files
require_once '../config/database.php';
require_once '../config/security.php';

// Set page title
$page_title = 'Security Dashboard';

// Get security statistics
function getSecurityStats() {
    global $conn;
    
    $stats = [
        'login_attempts' => 0,
        'failed_logins' => 0,
        'blocked_ips' => 0,
        'security_events' => 0,
        'recent_events' => []
    ];
    
    // Get login statistics (last 24 hours)
    $sql = "SELECT 
                COUNT(*) as total_attempts,
                SUM(CASE WHEN success = 0 THEN 1 ELSE 0 END) as failed_attempts
            FROM login_attempts 
            WHERE attempt_time > DATE_SUB(NOW(), INTERVAL 24 HOUR)";
    $result = $conn->query($sql);
    
    if ($row = $result->fetch_assoc()) {
        $stats['login_attempts'] = $row['total_attempts'];
        $stats['failed_logins'] = $row['failed_attempts'];
    }
    
    // Get count of currently blocked IPs
    $sql = "SELECT COUNT(DISTINCT ip_address) as blocked_count
            FROM login_attempts
            WHERE attempt_time > DATE_SUB(NOW(), INTERVAL 30 MINUTE)
            GROUP BY ip_address
            HAVING COUNT(*) >= 5";
    $result = $conn->query($sql);
    
    if ($row = $result->fetch_assoc()) {
        $stats['blocked_ips'] = $row['blocked_count'];
    }
    
    // Get security events (last 24 hours)
    $sql = "SELECT COUNT(*) as event_count
            FROM security_logs
            WHERE event_time > DATE_SUB(NOW(), INTERVAL 24 HOUR)";
    $result = $conn->query($sql);
    
    if ($row = $result->fetch_assoc()) {
        $stats['security_events'] = $row['event_count'];
    }
    
    // Get recent security events
    $sql = "SELECT sl.*, u.username
            FROM security_logs sl
            LEFT JOIN users u ON sl.user_id = u.user_id
            ORDER BY sl.event_time DESC
            LIMIT 10";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $stats['recent_events'][] = $row;
    }
    
    return $stats;
}

// Get currently blocked IPs
function getBlockedIPs() {
    global $conn;
    
    $blocked_ips = [];
    
    $sql = "SELECT ip_address, 
               COUNT(*) as attempt_count,
               MAX(attempt_time) as last_attempt
            FROM login_attempts
            WHERE attempt_time > DATE_SUB(NOW(), INTERVAL 30 MINUTE)
            GROUP BY ip_address
            HAVING COUNT(*) >= 5";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $blocked_ips[] = $row;
    }
    
    return $blocked_ips;
}

// Get security threat distribution
function getThreatDistribution() {
    global $conn;
    
    $threats = [];
    
    $sql = "SELECT event_type, COUNT(*) as count
            FROM security_logs
            WHERE event_time > DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY event_type
            ORDER BY count DESC
            LIMIT 5";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $threats[] = $row;
    }
    
    return $threats;
}

// Get users with suspicious activity
function getSuspiciousUsers() {
    global $conn;
    
    $users = [];
    
    $sql = "SELECT u.user_id, u.username, u.email, u.account_locked_until,
               COUNT(sl.log_id) as security_events
            FROM users u
            JOIN security_logs sl ON u.user_id = sl.user_id
            WHERE sl.event_time > DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY u.user_id
            HAVING COUNT(sl.log_id) >= 3
            ORDER BY security_events DESC
            LIMIT 10";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    
    return $users;
}

// Handle IP unblock request
if (isset($_POST['unblock_ip']) && isset($_POST['ip_address'])) {
    $ip = $conn->real_escape_string($_POST['ip_address']);
    
    // Delete login attempt records for this IP
    $sql = "DELETE FROM login_attempts WHERE ip_address = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $ip);
    
    if ($stmt->execute()) {
        // Log this action
        logSecurityEvent('admin_unblock_ip', "Administrator unblocked IP: $ip", $_SESSION['user_id'], $_SERVER['REMOTE_ADDR']);
        $success_message = "IP address $ip has been unblocked.";
    } else {
        $error_message = "Failed to unblock IP address.";
    }
}

// Handle lockout removal request
if (isset($_POST['unlock_user']) && isset($_POST['user_id'])) {
    $user_id = intval($_POST['user_id']);
    
    // Update user to remove lockout
    $sql = "UPDATE users SET 
               account_locked_until = NULL,
               failed_login_count = 0
            WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    
    if ($stmt->execute()) {
        // Log this action
        logSecurityEvent('admin_unlock_user', "Administrator unlocked user ID: $user_id", $_SESSION['user_id'], $_SERVER['REMOTE_ADDR']);
        $success_message = "User has been unlocked.";
    } else {
        $error_message = "Failed to unlock user.";
    }
}

// Get security settings
function getSecuritySettings() {
    global $conn;
    
    $settings = [];
    
    $sql = "SELECT setting_key, setting_value, description 
            FROM system_settings 
            WHERE setting_group = 'security'";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $settings[$row['setting_key']] = [
            'value' => $row['setting_value'],
            'description' => $row['description']
        ];
    }
    
    return $settings;
}

// Handle security settings update
if (isset($_POST['update_settings'])) {
    $max_login_attempts = intval($_POST['max_login_attempts']);
    $login_lockout_time = intval($_POST['login_lockout_time']);
    $password_expiry = intval($_POST['password_expiry']);
    $enable_2fa = isset($_POST['enable_2fa']) ? 1 : 0;
    
    // Update settings
    $settings = [
        'max_login_attempts' => $max_login_attempts,
        'login_lockout_time' => $login_lockout_time,
        'password_expiry_days' => $password_expiry,
        'enable_2fa' => $enable_2fa
    ];
    
    $success = true;
    
    foreach ($settings as $key => $value) {
        $sql = "UPDATE system_settings SET 
                   setting_value = ?,
                   updated_at = NOW(),
                   updated_by = ?
                WHERE setting_key = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sis", $value, $_SESSION['user_id'], $key);
        
        if (!$stmt->execute()) {
            $success = false;
            break;
        }
    }
    
    if ($success) {
        logSecurityEvent('admin_update_security_settings', "Administrator updated security settings", $_SESSION['user_id'], $_SERVER['REMOTE_ADDR']);
        $success_message = "Security settings have been updated.";
    } else {
        $error_message = "Failed to update security settings.";
    }
}

// Get 2FA usage statistics
function get2FAStats() {
    global $conn;
    
    $stats = [
        'enabled_count' => 0,
        'total_users' => 0,
        'enabled_percentage' => 0,
        'recent_setups' => []
    ];
    
    // Get total number of active users
    $sql = "SELECT COUNT(*) as total FROM users WHERE is_verified = 1";
    $result = $conn->query($sql);
    
    if ($row = $result->fetch_assoc()) {
        $stats['total_users'] = $row['total'];
    }
    
    // Get count of users with 2FA enabled
    $sql = "SELECT COUNT(*) as enabled_count FROM users WHERE two_factor_enabled = 1";
    $result = $conn->query($sql);
    
    if ($row = $result->fetch_assoc()) {
        $stats['enabled_count'] = $row['enabled_count'];
        
        if ($stats['total_users'] > 0) {
            $stats['enabled_percentage'] = round(($stats['enabled_count'] / $stats['total_users']) * 100, 2);
        }
    }
    
    // Get recent 2FA setups
    $sql = "SELECT u.user_id, u.username, u.two_factor_enabled_at
            FROM users u
            WHERE u.two_factor_enabled = 1
            ORDER BY u.two_factor_enabled_at DESC
            LIMIT 5";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $stats['recent_setups'][] = $row;
    }
    
    return $stats;
}

// Get data for display
$security_stats = getSecurityStats();
$blocked_ips = getBlockedIPs();
$threat_distribution = getThreatDistribution();
$suspicious_users = getSuspiciousUsers();
$security_settings = getSecuritySettings();
$two_fa_stats = get2FAStats();

// Include header
include_once 'includes/header.php';
?>

<div class="security-dashboard-container">
    <!-- Page Header -->
    <div class="dashboard-header">
        <h1><i class="fas fa-shield-alt"></i> <?php echo $page_title; ?></h1>
        <p>Monitor and manage security for the LelangMobil platform.</p>
    </div>
    
    <!-- Alert Messages -->
    <?php if (isset($success_message)): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
    </div>
    <?php endif; ?>
    
    <?php if (isset($error_message)): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
    </div>
    <?php endif; ?>
    
    <!-- Dashboard Summary Cards -->
    <div class="dashboard-summary">
        <div class="summary-card">
            <div class="summary-icon login-icon">
                <i class="fas fa-sign-in-alt"></i>
            </div>
            <div class="summary-details">
                <h3><?php echo number_format($security_stats['login_attempts']); ?></h3>
                <p>Login Attempts (24h)</p>
            </div>
        </div>
        
        <div class="summary-card">
            <div class="summary-icon failed-icon">
                <i class="fas fa-times-circle"></i>
            </div>
            <div class="summary-details">
                <h3><?php echo number_format($security_stats['failed_logins']); ?></h3>
                <p>Failed Logins (24h)</p>
            </div>
        </div>
        
        <div class="summary-card">
            <div class="summary-icon blocked-icon">
                <i class="fas fa-ban"></i>
            </div>
            <div class="summary-details">
                <h3><?php echo number_format($security_stats['blocked_ips']); ?></h3>
                <p>Blocked IPs</p>
            </div>
        </div>
        
        <div class="summary-card">
            <div class="summary-icon events-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="summary-details">
                <h3><?php echo number_format($security_stats['security_events']); ?></h3>
                <p>Security Events (24h)</p>
            </div>
        </div>
    </div>
    
    <!-- Main Dashboard Content -->
    <div class="dashboard-content">
        <!-- Left Column -->
        <div class="dashboard-column">
            <!-- Recent Security Events -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h2><i class="fas fa-history"></i> Recent Security Events</h2>
                </div>
                <div class="card-body scrollable">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Event Type</th>
                                <th>User</th>
                                <th>IP Address</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($security_stats['recent_events'])): ?>
                                <tr>
                                    <td colspan="5" class="text-center">No security events found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($security_stats['recent_events'] as $event): ?>
                                    <tr>
                                        <td><?php echo date('d M H:i', strtotime($event['event_time'])); ?></td>
                                        <td>
                                            <span class="event-type <?php echo strtolower($event['event_type']); ?>">
                                                <?php echo $event['event_type']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo isset($event['username']) ? $event['username'] : 'Guest'; ?></td>
                                        <td><?php echo $event['ip_address']; ?></td>
                                        <td class="event-description"><?php echo $event['description']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <a href="security-logs.php" class="btn-link">View All Security Logs</a>
                </div>
            </div>
            
            <!-- Security Threat Distribution -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h2><i class="fas fa-chart-pie"></i> Threat Distribution (7 Days)</h2>
                </div>
                <div class="card-body">
                    <?php if (empty($threat_distribution)): ?>
                        <p class="text-center">No security threats detected in the past 7 days.</p>
                    <?php else: ?>
                        <div class="threat-chart">
                            <?php foreach ($threat_distribution as $threat): ?>
                                <div class="threat-item">
                                    <div class="threat-label"><?php echo $threat['event_type']; ?></div>
                                    <div class="threat-bar-container">
                                        <div class="threat-bar" style="width: <?php echo min(100, ($threat['count'] / max(array_column($threat_distribution, 'count'))) * 100); ?>%">
                                            <?php echo $threat['count']; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Right Column -->
        <div class="dashboard-column">
            <!-- Currently Blocked IPs -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h2><i class="fas fa-ban"></i> Currently Blocked IPs</h2>
                </div>
                <div class="card-body scrollable">
                    <?php if (empty($blocked_ips)): ?>
                        <p class="text-center">No IPs are currently blocked.</p>
                    <?php else: ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>IP Address</th>
                                    <th>Attempts</th>
                                    <th>Last Attempt</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($blocked_ips as $ip): ?>
                                    <tr>
                                        <td><?php echo $ip['ip_address']; ?></td>
                                        <td><?php echo $ip['attempt_count']; ?></td>
                                        <td><?php echo date('d M H:i', strtotime($ip['last_attempt'])); ?></td>
                                        <td>
                                            <form method="post">
                                                <input type="hidden" name="ip_address" value="<?php echo $ip['ip_address']; ?>">
                                                <button type="submit" name="unblock_ip" class="btn-unblock" onclick="return confirm('Are you sure you want to unblock this IP?');">
                                                    <i class="fas fa-unlock"></i> Unblock
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Suspicious Users -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h2><i class="fas fa-user-secret"></i> Suspicious Users</h2>
                </div>
                <div class="card-body scrollable">
                    <?php if (empty($suspicious_users)): ?>
                        <p class="text-center">No suspicious user activity detected in the past 7 days.</p>
                    <?php else: ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Events</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($suspicious_users as $user): ?>
                                    <tr>
                                        <td>
                                            <a href="user-detail.php?id=<?php echo $user['user_id']; ?>">
                                                <?php echo $user['username']; ?>
                                            </a>
                                        </td>
                                        <td><?php echo $user['email']; ?></td>
                                        <td><?php echo $user['security_events']; ?></td>
                                        <td>
                                            <?php if ($user['account_locked_until'] && strtotime($user['account_locked_until']) > time()): ?>
                                                <span class="status-locked">Locked</span>
                                            <?php else: ?>
                                                <span class="status-active">Active</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($user['account_locked_until'] && strtotime($user['account_locked_until']) > time()): ?>
                                                <form method="post">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                    <button type="submit" name="unlock_user" class="btn-unlock" onclick="return confirm('Are you sure you want to unlock this user?');">
                                                        <i class="fas fa-unlock"></i> Unlock
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <a href="user-detail.php?id=<?php echo $user['user_id']; ?>" class="btn-view">
                                                    <i class="fas fa-eye"></i> View
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Security Settings -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h2><i class="fas fa-cogs"></i> Security Settings</h2>
                </div>
                <div class="card-body">
                    <form method="post" class="settings-form">
                        <div class="form-group">
                            <label for="max_login_attempts">Max Login Attempts:</label>
                            <input type="number" id="max_login_attempts" name="max_login_attempts" min="3" max="10" value="<?php echo $security_settings['max_login_attempts']['value'] ?? 5; ?>" required>
                            <p class="form-hint"><?php echo $security_settings['max_login_attempts']['description'] ?? 'Maximum login attempts before account lockout'; ?></p>
                        </div>
                        
                        <div class="form-group">
                            <label for="login_lockout_time">Login Lockout Time (minutes):</label>
                            <input type="number" id="login_lockout_time" name="login_lockout_time" min="5" max="60" value="<?php echo $security_settings['login_lockout_time']['value'] ?? 15; ?>" required>
                            <p class="form-hint"><?php echo $security_settings['login_lockout_time']['description'] ?? 'Duration of account lockout after failed login attempts'; ?></p>
                        </div>
                        
                        <div class="form-group">
                            <label for="password_expiry">Password Expiry Days:</label>
                            <input type="number" id="password_expiry" name="password_expiry" min="30" max="365" value="<?php echo $security_settings['password_expiry_days']['value'] ?? 90; ?>" required>
                            <p class="form-hint"><?php echo $security_settings['password_expiry_days']['description'] ?? 'Number of days before password must be changed'; ?></p>
                        </div>
                        
                        <div class="form-group checkbox-group">
                            <label class="checkbox-container">
                                <input type="checkbox" id="enable_2fa" name="enable_2fa" <?php echo ($security_settings['enable_2fa']['value'] ?? 0) == 1 ? 'checked' : ''; ?>>
                                <span class="checkmark"></span>
                                Enable Two-Factor Authentication
                            </label>
                            <p class="form-hint"><?php echo $security_settings['enable_2fa']['description'] ?? 'Require 2FA for user login'; ?></p>
                        </div>
                        
                        <div class="form-group form-actions">
                            <button type="submit" name="update_settings" class="btn-primary">
                                <i class="fas fa-save"></i> Save Settings
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- 2FA Usage Statistics -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h2><i class="fas fa-key"></i> Two-Factor Authentication Usage</h2>
                </div>
                <div class="card-body">
                    <div class="two-fa-stats">
                        <div class="stat-item">
                            <div class="stat-label">2FA Enabled Users:</div>
                            <div class="stat-value"><?php echo number_format($two_fa_stats['enabled_count']); ?></div>
                        </div>
                        
                        <div class="stat-item">
                            <div class="stat-label">Total Active Users:</div>
                            <div class="stat-value"><?php echo number_format($two_fa_stats['total_users']); ?></div>
                        </div>
                        
                        <div class="stat-item">
                            <div class="stat-label">2FA Usage Rate:</div>
                            <div class="stat-value"><?php echo $two_fa_stats['enabled_percentage']; ?>%</div>
                        </div>
                    </div>
                    
                    <h3>Recent 2FA Setups</h3>
                    <ul class="recent-setups">
                        <?php if (empty($two_fa_stats['recent_setups'])): ?>
                            <li class="text-center">No recent 2FA setups found.</li>
                        <?php else: ?>
                            <?php foreach ($two_fa_stats['recent_setups'] as $setup): ?>
                                <li>
                                    <strong><?php echo $setup['username']; ?></strong> - <?php echo date('d M Y H:i', strtotime($setup['two_factor_enabled_at'])); ?>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>
