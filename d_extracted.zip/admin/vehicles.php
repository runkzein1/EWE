<?php
// Set page title
$page_title = "Manajemen Kendaraan";

// Include header
include 'includes/header.php';

// Process actions (delete, status change)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $vehicle_id = intval($_GET['id']);
    
    // Validate vehicle exists
    $check_sql = "SELECT * FROM vehicles WHERE vehicle_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $vehicle_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $vehicle = $check_result->fetch_assoc();
        
        switch ($action) {
            case 'delete':
                // Delete vehicle
                $delete_sql = "DELETE FROM vehicles WHERE vehicle_id = ?";
                $delete_stmt = $conn->prepare($delete_sql);
                $delete_stmt->bind_param("i", $vehicle_id);
                
                if ($delete_stmt->execute()) {
                    // Also delete related images, bids, etc.
                    $conn->query("DELETE FROM vehicle_images WHERE vehicle_id = $vehicle_id");
                    $conn->query("DELETE FROM vehicle_specs WHERE vehicle_id = $vehicle_id");
                    $conn->query("DELETE FROM bids WHERE vehicle_id = $vehicle_id");
                    
                    $success = "Kendaraan berhasil dihapus.";
                } else {
                    $error = "Gagal menghapus kendaraan.";
                }
                break;
                
            case 'activate':
                // Set status to active
                $update_sql = "UPDATE vehicles SET status = 'active' WHERE vehicle_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("i", $vehicle_id);
                
                if ($update_stmt->execute()) {
                    $success = "Status kendaraan berhasil diubah menjadi aktif.";
                } else {
                    $error = "Gagal mengubah status kendaraan.";
                }
                break;
                
            case 'deactivate':
                // Set status to ended
                $update_sql = "UPDATE vehicles SET status = 'ended' WHERE vehicle_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("i", $vehicle_id);
                
                if ($update_stmt->execute()) {
                    $success = "Status kendaraan berhasil diubah menjadi berakhir.";
                } else {
                    $error = "Gagal mengubah status kendaraan.";
                }
                break;
                
            case 'sold':
                // Set status to sold
                $update_sql = "UPDATE vehicles SET status = 'sold' WHERE vehicle_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("i", $vehicle_id);
                
                if ($update_stmt->execute()) {
                    $success = "Status kendaraan berhasil diubah menjadi terjual.";
                } else {
                    $error = "Gagal mengubah status kendaraan.";
                }
                break;
                
            case 'not_sold':
                // Set status to not sold
                $update_sql = "UPDATE vehicles SET status = 'not_sold' WHERE vehicle_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("i", $vehicle_id);
                
                if ($update_stmt->execute()) {
                    $success = "Status kendaraan berhasil diubah menjadi tidak terjual.";
                } else {
                    $error = "Gagal mengubah status kendaraan.";
                }
                break;
        }
    } else {
        $error = "Kendaraan tidak ditemukan.";
    }
}

// Pagination
$items_per_page = 10;
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($current_page - 1) * $items_per_page;

// Filtering
$where_clause = "1=1"; // Default to show all vehicles
$params = [];
$param_types = "";

// Search
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = "%" . clean_input($_GET['search']) . "%";
    $where_clause .= " AND (model LIKE ? OR description LIKE ? OR brand_name LIKE ? OR model LIKE ?)";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $param_types .= "ssss";
}

// Status filter
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $status = clean_input($_GET['status']);
    $where_clause .= " AND status = ?";
    $params[] = $status;
    $param_types .= "s";
}

// Count total vehicles matching criteria
$count_sql = "SELECT COUNT(*) as total FROM vehicles WHERE $where_clause";
$count_stmt = $conn->prepare($count_sql);
if (!empty($params)) {
    $count_stmt->bind_param($param_types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$count_row = $count_result->fetch_assoc();
$total_items = $count_row['total'];
$total_pages = ceil($total_items / $items_per_page);

// Get vehicles with pagination menggunakan struktur kolom yang benar
$vehicles_sql = "SELECT v.vehicle_id,
                v.model,
                v.brand_name,
                v.year,
                v.start_price,
                v.current_price,
                v.image,
                v.description,
                v.auction_end,
                v.status,
                v.seller_id,
                v.created_at,
                v.model AS title,
                v.brand_name AS brand,
                v.image AS image_main,
                v.start_price AS starting_price,
                v.current_price AS current_bid,
                v.auction_end AS end_date,
                u.username as seller_username 
                FROM vehicles v 
                LEFT JOIN users u ON v.seller_id = u.user_id 
                WHERE $where_clause 
                ORDER BY v.created_at DESC 
                LIMIT ?, ?";

$params[] = $offset;
$params[] = $items_per_page;
$param_types .= "ii";

$vehicles_stmt = $conn->prepare($vehicles_sql);
$vehicles_stmt->bind_param($param_types, ...$params);
$vehicles_stmt->execute();
$vehicles_result = $vehicles_stmt->get_result();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Manajemen Kendaraan</h1>
    <a href="vehicle-form.php" class="btn btn-primary">
        <i class="fa fa-plus"></i> Tambah Kendaraan
    </a>
</div>

<?php if(isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<?php if(isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<!-- Filter Form -->
<div class="de-box mb-4">
    <form action="" method="get" class="row g-3">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control" placeholder="Cari kendaraan..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        </div>
        <div class="col-md-3">
            <select name="status" class="form-control form-select">
                <option value="">Semua Status</option>
                <option value="upcoming" <?php echo (isset($_GET['status']) && $_GET['status'] == 'upcoming') ? 'selected' : ''; ?>>Akan Datang</option>
                <option value="active" <?php echo (isset($_GET['status']) && $_GET['status'] == 'active') ? 'selected' : ''; ?>>Aktif</option>
                <option value="ended" <?php echo (isset($_GET['status']) && $_GET['status'] == 'ended') ? 'selected' : ''; ?>>Berakhir</option>
                <option value="sold" <?php echo (isset($_GET['status']) && $_GET['status'] == 'sold') ? 'selected' : ''; ?>>Terjual</option>
                <option value="not_sold" <?php echo (isset($_GET['status']) && $_GET['status'] == 'not_sold') ? 'selected' : ''; ?>>Tidak Terjual</option>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">Filter</button>
        </div>
        <div class="col-md-2">
            <a href="vehicles.php" class="btn btn-secondary w-100">Reset</a>
        </div>
    </form>
</div>

<!-- Vehicles Table -->
<div class="de-box">
    <div class="table-responsive">
        <table class="table table-hover admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Penjual</th>
                    <th>Harga Awal</th>
                    <th>Current Bid</th>
                    <th>Status</th>
                    <th>Tanggal Berakhir</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($vehicles_result->num_rows > 0): ?>
                    <?php while ($vehicle = $vehicles_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $vehicle['vehicle_id']; ?></td>
                            <td>
                                <?php echo $vehicle['title']; ?><br>
                                <small><?php echo $vehicle['make'] . ' ' . $vehicle['model'] . ' (' . $vehicle['year'] . ')'; ?></small>
                            </td>
                            <td><?php echo $vehicle['seller_username']; ?></td>
                            <td><?php echo format_currency($vehicle['starting_price']); ?></td>
                            <td>
                                <?php echo $vehicle['current_bid'] ? format_currency($vehicle['current_bid']) : '-'; ?>
                            </td>
                            <td>
                                <?php
                                switch ($vehicle['status']) {
                                    case 'upcoming':
                                        echo '<span class="badge bg-info">Akan Datang</span>';
                                        break;
                                    case 'active':
                                        echo '<span class="badge bg-success">Aktif</span>';
                                        break;
                                    case 'ended':
                                        echo '<span class="badge bg-secondary">Berakhir</span>';
                                        break;
                                    case 'sold':
                                        echo '<span class="badge bg-primary">Terjual</span>';
                                        break;
                                    case 'not_sold':
                                        echo '<span class="badge bg-danger">Tidak Terjual</span>';
                                        break;
                                    default:
                                        echo $vehicle['status'];
                                }
                                ?>
                            </td>
                            <td><?php echo date('d M Y H:i', strtotime($vehicle['auction_end'])); ?></td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton<?php echo $vehicle['vehicle_id']; ?>" data-mdb-toggle="dropdown" aria-expanded="false">
                                        Aksi
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton<?php echo $vehicle['vehicle_id']; ?>">
                                        <li><a class="dropdown-item" href="vehicle-form.php?id=<?php echo $vehicle['vehicle_id']; ?>"><i class="fa fa-edit"></i> Edit</a></li>
                                        <li><a class="dropdown-item" href="../vehicle.php?id=<?php echo $vehicle['vehicle_id']; ?>" target="_blank"><i class="fa fa-eye"></i> Lihat</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="vehicles.php?action=activate&id=<?php echo $vehicle['vehicle_id']; ?>" onclick="return confirm('Yakin ingin mengaktifkan kendaraan ini?')"><i class="fa fa-check"></i> Aktifkan</a></li>
                                        <li><a class="dropdown-item" href="vehicles.php?action=deactivate&id=<?php echo $vehicle['vehicle_id']; ?>" onclick="return confirm('Yakin ingin mengakhiri lelang kendaraan ini?')"><i class="fa fa-ban"></i> Akhiri Lelang</a></li>
                                        <li><a class="dropdown-item" href="vehicles.php?action=sold&id=<?php echo $vehicle['vehicle_id']; ?>" onclick="return confirm('Yakin ingin menandai kendaraan ini sebagai terjual?')"><i class="fa fa-check-circle"></i> Set Terjual</a></li>
                                        <li><a class="dropdown-item" href="vehicles.php?action=not_sold&id=<?php echo $vehicle['vehicle_id']; ?>" onclick="return confirm('Yakin ingin menandai kendaraan ini sebagai tidak terjual?')"><i class="fa fa-times-circle"></i> Set Tidak Terjual</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item text-danger" href="vehicles.php?action=delete&id=<?php echo $vehicle['vehicle_id']; ?>" onclick="return confirm('PERINGATAN: Tindakan ini akan menghapus semua data terkait kendaraan ini. Yakin ingin menghapus?')"><i class="fa fa-trash"></i> Hapus</a></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center">Tidak ada kendaraan yang ditemukan</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center mt-4">
                <?php if ($current_page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo "vehicles.php?" . http_build_query(array_merge($_GET, ['page' => $current_page - 1])); ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                        <a class="page-link" href="<?php echo "vehicles.php?" . http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($current_page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo "vehicles.php?" . http_build_query(array_merge($_GET, ['page' => $current_page + 1])); ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
