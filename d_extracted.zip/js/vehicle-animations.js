/**
 * Premium Vehicle Animations
 * Versi: 1.0 (2025-05-02)
 * 
 * Script untuk memberikan animasi dan efek modern pada halaman detail kendaraan
 */

document.addEventListener("DOMContentLoaded", function() {
    // Aktifkan tema modern
    document.body.classList.add("modern-theme");
    
    // Animasi entrance untuk item-item
    animateElements();
    
    // Interaktivitas hover pada carousel thumbnails
    initThumbnailHover();
    
    // Animasi dan efek hover pada riwayat bid
    initBidHistoryAnimations();
    
    // Efek pada tombol bid dan preset
    initBidButtonEffects();
    
    // Parallax effect pada hero section
    initParallaxEffect();
    
    // Inisialisasi tooltip
    initTooltips();
});

/**
 * Animasi entrance untuk elemen-elemen utama dengan stagger delay
 */
function animateElements() {
    // Ambil semua elemen dengan kelas fade-in dan fade-in-up
    const fadeInElements = document.querySelectorAll('.fade-in');
    const fadeInUpElements = document.querySelectorAll('.fade-in-up');
    
    // Buat observer untuk fade in dengan stagger effect
    const fadeInObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                // Tambahkan delay berdasarkan urutan elemen (stagger effect)
                setTimeout(() => {
                    entry.target.classList.add('animated');
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'none';
                }, index * 150); // 150ms delay antara tiap animasi
                
                fadeInObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.15,
        rootMargin: '0px 0px -50px 0px'
    });
    
    // Buat observer untuk fade in up
    const fadeInUpObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
                fadeInUpObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });
    
    // Observe semua elemen fade-in
    fadeInElements.forEach(element => {
        fadeInObserver.observe(element);
    });
    
    // Observe semua elemen fade-in-up
    fadeInUpElements.forEach(element => {
        fadeInUpObserver.observe(element);
    });
    
    // Animate info boxes
    const infoBoxes = document.querySelectorAll('.info-box');
    infoBoxes.forEach((box, index) => {
        box.style.animationDelay = `${index * 0.1}s`;
        box.classList.add('animate__animated', 'animate__fadeIn');
    });
}

/**
 * Interaktivitas hover pada thumbnail
 */
function initThumbnailHover() {
    const thumbnails = document.querySelectorAll('.thumbnail');
    
    thumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('mouseenter', function() {
            thumbnails.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

/**
 * Animasi dan efek hover pada riwayat bid
 */
function initBidHistoryAnimations() {
    const bidItems = document.querySelectorAll('.bid-history-item');
    
    bidItems.forEach((item, index) => {
        // Add staggered animation delay
        item.style.animationDelay = `${index * 0.1}s`;
        
        // Add hover effects
        item.addEventListener('mouseenter', function() {
            this.classList.add('highlight');
        });
        
        item.addEventListener('mouseleave', function() {
            this.classList.remove('highlight');
        });
    });
}

/**
 * Efek pada tombol bid dan preset dengan ripple effect premium
 */
function initBidButtonEffects() {
    const bidButton = document.querySelector('.ultra-bid-button');
    const presetButtons = document.querySelectorAll('.ultra-preset-button');
    
    // Fungsi untuk membuat efek ripple premium
    function createRippleEffect(event) {
        const button = event.currentTarget;
        
        // Hapus ripple yang sudah ada sebelumnya
        const ripple = button.querySelector('.ripple');
        if (ripple) {
            ripple.remove();
        }
        
        // Buat element ripple baru
        const circle = document.createElement('span');
        circle.classList.add('ripple');
        button.appendChild(circle);
        
        // Dapatkan ukuran tombol dan posisi klik
        const diameter = Math.max(button.clientWidth, button.clientHeight);
        const radius = diameter / 2;
        const rect = button.getBoundingClientRect();
        
        // Atur posisi dan ukuran ripple
        circle.style.width = circle.style.height = `${diameter}px`;
        circle.style.left = `${event.clientX - rect.left - radius}px`;
        circle.style.top = `${event.clientY - rect.top - radius}px`;
        
        // Tambahkan class active untuk animasi
        circle.classList.add('active');
        
        // Hapus ripple setelah animasi selesai
        setTimeout(() => {
            circle.remove();
        }, 600);
    }
    
    if (bidButton) {
        // Tambahkan efek hover glow
        bidButton.addEventListener('mouseenter', function() {
            this.classList.add('pulse');
            this.style.boxShadow = '0 0 25px rgba(79, 133, 229, 0.6)';
        });
        
        bidButton.addEventListener('mouseleave', function() {
            this.classList.remove('pulse');
            this.style.boxShadow = '';
        });
        
        // Tambahkan efek ripple saat klik
        bidButton.addEventListener('click', function(e) {
            this.classList.add('clicked');
            createRippleEffect(e);
            
            setTimeout(() => {
                this.classList.remove('clicked');
            }, 300);
        });
    }
    
    // Tambahkan efek ripple dan active pada preset buttons
    presetButtons.forEach(button => {
        button.addEventListener('click', function() {
            presetButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

/**
 * Parallax effect premium pada hero section dengan tilt 3D effect
 */
function initParallaxEffect() {
    const heroSection = document.querySelector('.ultra-hero');
    const heroImg = document.querySelector('.ultra-hero-img');
    const heroContent = document.querySelector('.ultra-hero-content');
    
    if (heroSection && heroImg) {
        // Efek parallax saat scroll
        window.addEventListener('scroll', function() {
            const scrollTop = window.pageYOffset;
            const sectionTop = heroSection.offsetTop;
            const sectionHeight = heroSection.offsetHeight;
            
            // Hanya jalankan efek jika user scroll di area hero section
            if (scrollTop >= sectionTop && scrollTop <= (sectionTop + sectionHeight)) {
                const translateY = (scrollTop - sectionTop) * 0.4;
                heroImg.style.transform = `translate3d(0, ${translateY}px, 0) scale(1.05)`;
                
                if (heroContent) {
                    // Efek content bergerak ke atas lebih lambat (parallax)
                    heroContent.style.transform = `translate3d(0, ${translateY * 0.2}px, 0)`;
                }
            }
        });
        
        // Efek 3D tilt saat mouse bergerak
        heroSection.addEventListener('mousemove', function(e) {
            if (window.innerWidth < 768) return; // Nonaktifkan pada mobile
            
            const xPos = (e.clientX / window.innerWidth - 0.5) * 20; // -10 hingga +10
            const yPos = (e.clientY / heroSection.clientHeight - 0.5) * 10; // -5 hingga +5
            
            heroImg.style.transform = `translate3d(${xPos * 0.5}px, ${yPos * 0.5}px, 0) scale(1.05)`;
            
            if (heroContent) {
                heroContent.style.transform = `translate3d(${xPos * -0.3}px, ${yPos * -0.3}px, 20px)`;
            }
            
            // Efek bayangan bergerak
            const spotlight = `radial-gradient(circle at ${e.clientX}px ${e.clientY - heroSection.offsetTop}px, rgba(255, 255, 255, 0.1), transparent 100%)`;
            heroSection.style.backgroundImage = spotlight;
        });
        
        // Reset ke posisi normal saat mouse meninggalkan area
        heroSection.addEventListener('mouseleave', function() {
            heroImg.style.transform = '';
            if (heroContent) heroContent.style.transform = '';
            heroSection.style.backgroundImage = '';
        });
    }
}

/**
 * Inisialisasi tooltip untuk penjelasan tambahan
 */
function initTooltips() {
    const tooltipTriggers = document.querySelectorAll('[data-tooltip]');
    
    tooltipTriggers.forEach(trigger => {
        trigger.addEventListener('mouseenter', function() {
            const tooltipText = this.getAttribute('data-tooltip');
            
            const tooltip = document.createElement('div');
            tooltip.className = 'custom-tooltip';
            tooltip.textContent = tooltipText;
            
            document.body.appendChild(tooltip);
            
            const rect = this.getBoundingClientRect();
            tooltip.style.left = `${rect.left + rect.width/2 - tooltip.offsetWidth/2}px`;
            tooltip.style.top = `${rect.top - tooltip.offsetHeight - 10}px`;
            
            this.addEventListener('mouseleave', function() {
                tooltip.remove();
            });
        });
    });
}

/**
 * Update timer countdown
 */
function updateCountdown() {
    const timerContainer = document.getElementById('premium-timer');
    
    if (!timerContainer) return;
    
    const endTime = parseInt(timerContainer.getAttribute('data-end')) * 1000;
    const now = new Date().getTime();
    const timeLeft = endTime - now;
    
    if (timeLeft <= 0) {
        timerContainer.innerHTML = '<div class="auction-ended">Lelang telah berakhir</div>';
        // Reload setelah 3 detik
        setTimeout(() => {
            location.reload();
        }, 3000);
        return;
    }
    
    // Hitung waktu tersisa
    const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
    const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
    
    // Update tampilan
    const daysElement = document.getElementById('days');
    const hoursElement = document.getElementById('hours');
    const minutesElement = document.getElementById('minutes');
    const secondsElement = document.getElementById('seconds');
    
    if (daysElement) daysElement.textContent = days.toString().padStart(2, '0');
    if (hoursElement) hoursElement.textContent = hours.toString().padStart(2, '0');
    if (minutesElement) minutesElement.textContent = minutes.toString().padStart(2, '0');
    if (secondsElement) secondsElement.textContent = seconds.toString().padStart(2, '0');
    
    // Tambahkan efek khusus saat mendekati akhir
    if (timeLeft < 300000) { // 5 menit terakhir
        timerContainer.classList.add('urgent');
    } else if (timeLeft < 3600000) { // 1 jam terakhir
        timerContainer.classList.add('warning');
    }
}

// Update countdown setiap detik
setInterval(updateCountdown, 1000);

// Init countdown on load
updateCountdown();
