<?php
// Set page title
$page_title = "Profil Admin";

// Include header
include 'includes/header.php';

// Handle form submission for profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $username = clean_input($_POST['username']);
    $email = clean_input($_POST['email']);
    $full_name = clean_input($_POST['full_name']);
    $phone = clean_input($_POST['phone']);
    $address = clean_input($_POST['address']);
    
    // Validate inputs
    $errors = [];
    
    if (empty($username)) {
        $errors[] = "Username harus diisi.";
    }
    
    if (empty($email)) {
        $errors[] = "Email harus diisi.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Format email tidak valid.";
    }
    
    // Check if username or email already exists for other users
    $check_sql = "SELECT * FROM users WHERE (username = ? OR email = ?) AND user_id != ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ssi", $username, $email, $admin_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $user_exists = $check_result->fetch_assoc();
        if ($user_exists['username'] == $username) {
            $errors[] = "Username sudah digunakan. Silakan pilih username lain.";
        }
        if ($user_exists['email'] == $email) {
            $errors[] = "Email sudah digunakan. Silakan gunakan email lain.";
        }
    }
    
    // If no errors, update profile
    if (empty($errors)) {
        $update_sql = "UPDATE users SET 
                       username = ?, 
                       email = ?, 
                       full_name = ?, 
                       phone = ?, 
                       address = ?,
                       updated_at = NOW() 
                       WHERE user_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("sssssi", $username, $email, $full_name, $phone, $address, $admin_id);
        
        if ($update_stmt->execute()) {
            $success = "Profil berhasil diperbarui.";
            
            // Refresh admin data
            $admin_stmt->execute();
            $admin_result = $admin_stmt->get_result();
            $admin = $admin_result->fetch_assoc();
            
            // Update session
            $_SESSION['username'] = $username;
        } else {
            $error = "Gagal memperbarui profil: " . $conn->error;
        }
    }
}

// Handle password change
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate inputs
    $errors = [];
    
    if (empty($current_password)) {
        $errors[] = "Password saat ini harus diisi.";
    }
    
    if (empty($new_password)) {
        $errors[] = "Password baru harus diisi.";
    } elseif (strlen($new_password) < 6) {
        $errors[] = "Password baru minimal 6 karakter.";
    }
    
    if ($new_password != $confirm_password) {
        $errors[] = "Konfirmasi password tidak cocok.";
    }
    
    // Verify current password
    if (empty($errors) && !password_verify($current_password, $admin['password'])) {
        $errors[] = "Password saat ini tidak cocok.";
    }
    
    // If no errors, update password
    if (empty($errors)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update_sql = "UPDATE users SET password = ?, updated_at = NOW() WHERE user_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("si", $hashed_password, $admin_id);
        
        if ($update_stmt->execute()) {
            $success = "Password berhasil diubah.";
        } else {
            $error = "Gagal mengubah password: " . $conn->error;
        }
    }
}
?>

<div class="container-fluid content-wrapper">
    <h1 class="mb-4">Profil Admin</h1>
    
    <?php if(isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <?php if(isset($errors) && !empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach($errors as $err): ?>
                    <li><?php echo $err; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-4">
            <div class="de-box mb-4">
                <div class="text-center mb-4">
                    <img src="https://via.placeholder.com/150" class="rounded-circle mb-3" alt="Admin Profile">
                    <h3><?php echo $admin['username']; ?></h3>
                    <p class="mb-0"><?php echo $admin['email']; ?></p>
                    <p class="mt-1">
                        <span class="badge bg-primary">Administrator</span>
                    </p>
                </div>
                
                <div class="mt-3">
                    <table class="table">
                        <tr>
                            <th>ID Pengguna:</th>
                            <td><?php echo $admin['user_id']; ?></td>
                        </tr>
                        <tr>
                            <th>Nama Lengkap:</th>
                            <td><?php echo $admin['full_name'] ? $admin['full_name'] : '-'; ?></td>
                        </tr>
                        <tr>
                            <th>Terdaftar Pada:</th>
                            <td><?php echo date('d M Y H:i', strtotime($admin['created_at'])); ?></td>
                        </tr>
                        <tr>
                            <th>Terakhir Login:</th>
                            <td><?php echo isset($admin['last_login']) ? date('d M Y H:i', strtotime($admin['last_login'])) : 'Tidak ada data'; ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Admin Activity Summary -->
            <div class="de-box">
                <h5 class="mb-3">Ringkasan Aktivitas</h5>
                
                <?php
                // Count admin activities
                $activity_sql = "SELECT 
                                (SELECT COUNT(*) FROM transactions WHERE admin_id = ?) as processed_transactions,
                                (SELECT COUNT(*) FROM vehicles WHERE updated_by = ?) as processed_vehicles";
                $activity_stmt = $conn->prepare($activity_sql);
                $activity_stmt->bind_param("ii", $admin_id, $admin_id);
                $activity_stmt->execute();
                $activity_result = $activity_stmt->get_result();
                $activity = $activity_result->fetch_assoc();
                
                // Get last activities
                $last_activity_sql = "SELECT 'transaction' as type, t.created_at as timestamp, t.amount, t.type as trans_type, u.username
                                     FROM transactions t
                                     JOIN users u ON t.user_id = u.user_id
                                     WHERE t.admin_id = ?
                                     UNION
                                     SELECT 'vehicle' as type, v.updated_at as timestamp, NULL as amount, v.status as trans_type, v.title as username
                                     FROM vehicles v
                                     WHERE v.updated_by = ?
                                     ORDER BY timestamp DESC
                                     LIMIT 5";
                $last_activity_stmt = $conn->prepare($last_activity_sql);
                $last_activity_stmt->bind_param("ii", $admin_id, $admin_id);
                $last_activity_stmt->execute();
                $last_activities = $last_activity_stmt->get_result();
                ?>
                
                <div class="row text-center mb-3">
                    <div class="col-6">
                        <div class="stats-card py-3">
                            <i class="fa fa-money-bill-wave"></i>
                            <h4><?php echo $activity['processed_transactions']; ?></h4>
                            <p>Transaksi Diproses</p>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stats-card py-3">
                            <i class="fa fa-car"></i>
                            <h4><?php echo $activity['processed_vehicles']; ?></h4>
                            <p>Kendaraan Dikelola</p>
                        </div>
                    </div>
                </div>
                
                <h6 class="mb-2">Aktivitas Terakhir</h6>
                <ul class="list-group">
                    <?php if ($last_activities->num_rows > 0): ?>
                        <?php while ($activity = $last_activities->fetch_assoc()): ?>
                            <li class="list-group-item bg-dark">
                                <?php if ($activity['type'] == 'transaction'): ?>
                                    <i class="fa fa-money-check text-info me-2"></i>
                                    Memproses transaksi 
                                    <?php echo $activity['trans_type']; ?> dari 
                                    <strong><?php echo $activity['username']; ?></strong>
                                    <?php if ($activity['amount']): ?>
                                        (<?php echo format_currency($activity['amount']); ?>)
                                    <?php endif; ?>
                                <?php else: ?>
                                    <i class="fa fa-car text-warning me-2"></i>
                                    Mengupdate kendaraan 
                                    <strong><?php echo $activity['username']; ?></strong>
                                    (<?php echo $activity['trans_type']; ?>)
                                <?php endif; ?>
                                <small class="text-muted d-block mt-1">
                                    <?php echo date('d M Y H:i', strtotime($activity['timestamp'])); ?>
                                </small>
                            </li>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <li class="list-group-item bg-dark text-center">Belum ada aktivitas</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        
        <div class="col-md-8">
            <!-- Profile Edit Form -->
            <div class="de-box mb-4">
                <h5 class="mb-3">Edit Profil</h5>
                <form method="post" action="">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo $admin['username']; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo $admin['email']; ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo $admin['full_name']; ?>">
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="phone" class="form-label">Nomor Telepon</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $admin['phone']; ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Alamat</label>
                        <textarea class="form-control" id="address" name="address" rows="2"><?php echo $admin['address']; ?></textarea>
                    </div>
                    <button type="submit" name="update_profile" class="btn btn-primary">
                        <i class="fa fa-save"></i> Simpan Perubahan
                    </button>
                </form>
            </div>
            
            <!-- Change Password Form -->
            <div class="de-box">
                <h5 class="mb-3">Ubah Password</h5>
                <form method="post" action="">
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Password Saat Ini</label>
                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="new_password" class="form-label">Password Baru</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                            <small class="text-muted">Minimal 6 karakter</small>
                        </div>
                        <div class="col-md-6">
                            <label for="confirm_password" class="form-label">Konfirmasi Password Baru</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                    </div>
                    <button type="submit" name="change_password" class="btn btn-warning">
                        <i class="fa fa-lock"></i> Ubah Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
