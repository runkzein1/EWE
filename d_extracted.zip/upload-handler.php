<?php
// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Require login
require_login();

// Initialize response array
$response = array(
    'success' => false,
    'message' => '',
    'file_url' => ''
);

// Check if uploads directory exists, if not create it
$uploads_dir = 'uploads';
$payment_proof_dir = $uploads_dir . '/payment_proof';
$temp_dir = $uploads_dir . '/temp';

if (!file_exists($uploads_dir)) {
    mkdir($uploads_dir, 0755, true);
}

if (!file_exists($payment_proof_dir)) {
    mkdir($payment_proof_dir, 0755, true);
}

if (!file_exists($temp_dir)) {
    mkdir($temp_dir, 0755, true);
}

// Handle payment proof upload
if (isset($_POST['action']) && $_POST['action'] == 'upload_payment_proof') {
    if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] == 0) {
        $file = $_FILES['payment_proof'];
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];
        $file_size = $file['size'];
        $file_error = $file['error'];
        
        // Get file extension
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Allowed file extensions
        $allowed = array('jpg', 'jpeg', 'png', 'pdf');
        
        // Check if file extension is allowed
        if (in_array($file_ext, $allowed)) {
            // Check file size (max 2MB)
            if ($file_size <= 2097152) {
                // Generate unique filename
                $new_file_name = 'payment_' . $_SESSION['user_id'] . '_' . date('YmdHis') . '.' . $file_ext;
                $upload_path = $payment_proof_dir . '/' . $new_file_name;
                
                // Move uploaded file
                if (move_uploaded_file($file_tmp, $upload_path)) {
                    $response['success'] = true;
                    $response['message'] = 'Bukti pembayaran berhasil diunggah.';
                    // Simpan URL relatif tanpa path lengkap untuk keamanan
                    $response['file_url'] = $payment_proof_dir . '/' . $new_file_name;
                } else {
                    $response['message'] = 'Gagal mengunggah file. Silakan coba lagi.';
                }
            } else {
                $response['message'] = 'Ukuran file terlalu besar. Maksimal 2MB.';
            }
        } else {
            $response['message'] = 'Format file tidak diizinkan. Gunakan JPG, PNG, atau PDF.';
        }
    } else {
        $response['message'] = 'Tidak ada file yang diunggah atau terjadi kesalahan.';
    }
} else {
    $response['message'] = 'Aksi tidak valid.';
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
exit;
?>
