<?php
/**
 * Profile Card Component
 * LelangMobil Web App - Versi 2025
 */

// Pastikan user sudah diambil datanya sebelum memanggil komponen ini
if (!isset($user) || !is_array($user)) {
    die("Error: User data not loaded.");
}
?>

<div class="modern-card fade-in">
    <div class="modern-card-header">
        <h2 class="modern-card-title"><i class="fa fa-user-circle"></i> Profil Saya</h2>
        <button type="button" class="modern-button modern-button-outline" data-bs-toggle="modal" data-bs-target="#editProfileModal">
            <i class="fa fa-edit"></i> Edit Profil
        </button>
    </div>
    
    <div class="modern-card-body">
        <div class="modern-profile-card">
            <img src="<?php echo !empty($user['profile_photo']) ? 'uploads/profile/'.$user['profile_photo'] : 'images/avatar-placeholder.jpg'; ?>" 
                 alt="<?php echo htmlspecialchars($user['username']); ?>" 
                 class="modern-profile-avatar"
                 onerror="this.src='images/avatar-placeholder.jpg';">
            
            <h3 class="modern-profile-name"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h3>
            <p class="modern-profile-info">
                <i class="fa fa-envelope me-2"></i><?php echo htmlspecialchars($user['email']); ?>
                <?php if (!empty($user['phone'])): ?>
                <br><i class="fa fa-phone me-2"></i><?php echo htmlspecialchars($user['phone']); ?>
                <?php endif; ?>
            </p>
            
            <div class="modern-profile-stats">
                <div class="modern-profile-stat">
                    <div class="modern-profile-stat-value"><?php echo isset($total_bids) ? $total_bids : 0; ?></div>
                    <div class="modern-profile-stat-label">Total Bid</div>
                </div>
                <div class="modern-profile-stat">
                    <div class="modern-profile-stat-value"><?php echo isset($total_wins) ? $total_wins : 0; ?></div>
                    <div class="modern-profile-stat-label">Menang</div>
                </div>
                <div class="modern-profile-stat">
                    <div class="modern-profile-stat-value"><?php echo isset($user['join_date']) ? date('Y', strtotime($user['join_date'])) : date('Y'); ?></div>
                    <div class="modern-profile-stat-label">Bergabung</div>
                </div>
            </div>
        </div>
        
        <div class="mt-4">
            <h4 class="mb-3"><i class="fa fa-info-circle me-2"></i>Informasi Akun</h4>
            <table class="modern-table">
                <tbody>
                    <tr>
                        <td width="40%"><strong>Username</strong></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Email</strong></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Status Email</strong></td>
                        <td>
                            <?php if (isset($user['email_verified']) && $user['email_verified']): ?>
                                <span class="modern-badge modern-badge-success"><i class="fa fa-check"></i> Terverifikasi</span>
                            <?php else: ?>
                                <span class="modern-badge modern-badge-warning"><i class="fa fa-clock"></i> Belum Terverifikasi</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Nomor Telepon</strong></td>
                        <td><?php echo !empty($user['phone']) ? htmlspecialchars($user['phone']) : '<em>Belum diatur</em>'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tanggal Bergabung</strong></td>
                        <td><?php echo isset($user['join_date']) ? date('d F Y', strtotime($user['join_date'])) : '-'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Status Akun</strong></td>
                        <td>
                            <?php if (isset($user['status']) && $user['status'] == 'active'): ?>
                                <span class="modern-badge modern-badge-success"><i class="fa fa-check-circle"></i> Aktif</span>
                            <?php else: ?>
                                <span class="modern-badge modern-badge-danger"><i class="fa fa-times-circle"></i> Tidak Aktif</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="mt-4">
            <h4 class="mb-3"><i class="fa fa-shield-alt me-2"></i>Keamanan</h4>
            <div class="d-flex gap-3">
                <button type="button" class="modern-button modern-button-primary" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                    <i class="fa fa-key me-2"></i>Ubah Password
                </button>
                
                <?php if (!isset($user['email_verified']) || !$user['email_verified']): ?>
                <a href="resend_verification.php" class="modern-button modern-button-warning">
                    <i class="fa fa-envelope me-2"></i>Verifikasi Email
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
