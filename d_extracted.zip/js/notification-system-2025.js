/**
 * Notification System 2025
 * Implementasi sistem notifikasi real-time untuk LelangMobil
 * dengan pendekatan ultra-minimalis
 */

// Namespace untuk notification system
const NotificationSystem = {
    // Inisialisasi sistem notifikasi
    init: function() {
        this.setupEventListeners();
        this.setupStorageListener();
        this.checkQueuedNotifications();
        console.log('Notification System 2025 initialized');
        return this;
    },

    // Setup event listeners
    setupEventListeners: function() {
        // Listener untuk tombol close pada notifikasi
        document.addEventListener('click', function(e) {
            if (e.target.closest('.notification-close')) {
                const notification = e.target.closest('.notification-item-2025');
                if (notification) {
                    NotificationSystem.dismissNotification(notification);
                }
            }
        });
    },

    // Setup local storage listener untuk komunikasi antar tab/halaman
    setupStorageListener: function() {
        window.addEventListener('storage', function(e) {
            if (e.key === 'lelangmobil_notifications') {
                NotificationSystem.checkQueuedNotifications();
            }
        });
    },

    // Tambahkan notifikasi baru
    addNotification: function(data) {
        // Default values
        const notification = {
            id: 'notification_' + Date.now(),
            type: data.type || 'info',
            title: data.title || 'Notifikasi',
            message: data.message || 'Anda memiliki notifikasi baru',
            link: data.link || null,
            timestamp: Date.now(),
            read: false,
            ...data
        };

        // Simpan di local storage untuk persistensi antar halaman
        const notifications = this.getNotifications();
        notifications.unshift(notification);
        localStorage.setItem('lelangmobil_notifications', JSON.stringify(notifications));
        
        // Tampilkan notifikasi
        this.displayNotification(notification);
        
        // Update counter
        this.updateNotificationCounter();
        
        return notification.id;
    },

    // Ambil semua notifikasi dari storage
    getNotifications: function() {
        const notificationsJson = localStorage.getItem('lelangmobil_notifications');
        return notificationsJson ? JSON.parse(notificationsJson) : [];
    },

    // Tampilkan notifikasi UI
    displayNotification: function(notification) {
        // Periksa apakah notification container sudah ada
        let container = document.querySelector('.notification-container-2025');
        if (!container) {
            container = document.createElement('div');
            container.className = 'notification-container-2025';
            document.body.appendChild(container);
        }

        // Buat element notifikasi
        const notificationElement = document.createElement('div');
        notificationElement.className = `notification-item-2025 notification-${notification.type} fade-in-up`;
        notificationElement.dataset.id = notification.id;
        
        // Icon berdasarkan tipe
        let icon = 'info-circle';
        if (notification.type === 'success') icon = 'check-circle';
        if (notification.type === 'warning') icon = 'exclamation-triangle';
        if (notification.type === 'error') icon = 'times-circle';
        
        // Content HTML
        notificationElement.innerHTML = `
            <div class="notification-icon">
                <i class="fas fa-${icon}"></i>
            </div>
            <div class="notification-content">
                <div class="notification-header">
                    <h4>${notification.title}</h4>
                    <button class="notification-close">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="notification-body">
                    <p>${notification.message}</p>
                    ${notification.link ? `<a href="${notification.link}" class="notification-link">Lihat Detail</a>` : ''}
                </div>
            </div>
        `;
        
        // Tambahkan ke container
        container.appendChild(notificationElement);
        
        // Auto dismiss setelah 5 detik
        setTimeout(() => {
            this.dismissNotification(notificationElement);
        }, 5000);
    },
    
    // Hapus notifikasi dari UI
    dismissNotification: function(notificationElement) {
        if (!notificationElement) return;
        
        // Tambahkan class fade-out
        notificationElement.classList.add('fade-out');
        
        // Hapus dari DOM setelah animasi selesai
        setTimeout(() => {
            if (notificationElement.parentNode) {
                notificationElement.parentNode.removeChild(notificationElement);
            }
        }, 300);
    },
    
    // Update counter notifikasi
    updateNotificationCounter: function() {
        const counter = document.querySelector('.notification-counter');
        if (!counter) return;
        
        const unreadCount = this.getNotifications().filter(n => !n.read).length;
        counter.textContent = unreadCount;
        counter.style.display = unreadCount > 0 ? 'flex' : 'none';
    },
    
    // Periksa notifikasi yang perlu ditampilkan
    checkQueuedNotifications: function() {
        const notifications = this.getNotifications();
        const currentTime = Date.now();
        const recentNotifications = notifications.filter(n => {
            return !n.displayed && (currentTime - n.timestamp < 60000); // Hanya tampilkan yang < 1 menit
        });
        
        // Tandai sebagai sudah ditampilkan dan tampilkan
        recentNotifications.forEach(notification => {
            notification.displayed = true;
            this.displayNotification(notification);
        });
        
        // Update storage
        if (recentNotifications.length > 0) {
            localStorage.setItem('lelangmobil_notifications', JSON.stringify(notifications));
        }
        
        // Update counter
        this.updateNotificationCounter();
    },
    
    // Notifikasi untuk bid berhasil
    notifyBidSuccess: function(vehicleId, vehicleName, bidAmount) {
        return this.addNotification({
            type: 'success',
            title: 'Bid Berhasil',
            message: `Penawaran Rp ${bidAmount} untuk ${vehicleName} berhasil dikirim!`,
            link: `vehicle.php?id=${vehicleId}`,
            category: 'bid'
        });
    },
    
    // Notifikasi untuk transaksi berhasil
    notifyTransactionSuccess: function(transactionId, type, amount) {
        let title, message;
        if (type === 'deposit') {
            title = 'Top Up Berhasil';
            message = `Top up sebesar Rp ${amount} berhasil ditambahkan ke akun Anda.`;
        } else if (type === 'withdrawal') {
            title = 'Penarikan Berhasil';
            message = `Penarikan sebesar Rp ${amount} sedang diproses.`;
        } else {
            title = 'Transaksi Berhasil';
            message = `Transaksi ${type} sebesar Rp ${amount} berhasil.`;
        }
        
        return this.addNotification({
            type: 'success',
            title: title,
            message: message,
            link: `account.php?tab=transactions`,
            category: 'transaction'
        });
    },
    
    // Notifikasi untuk perubahan status lelang
    notifyAuctionStatusChange: function(vehicleId, vehicleName, status) {
        let title, message, type;
        
        if (status === 'ending_soon') {
            title = 'Lelang Segera Berakhir';
            message = `Lelang untuk ${vehicleName} akan berakhir dalam 1 jam!`;
            type = 'warning';
        } else if (status === 'outbid') {
            title = 'Anda Terlampaui';
            message = `Penawaran Anda untuk ${vehicleName} telah dilampaui oleh penawaran yang lebih tinggi.`;
            type = 'info';
        } else if (status === 'won') {
            title = 'Selamat!';
            message = `Anda memenangkan lelang untuk ${vehicleName}! Silakan selesaikan pembayaran.`;
            type = 'success';
        }
        
        return this.addNotification({
            type: type,
            title: title,
            message: message,
            link: `vehicle.php?id=${vehicleId}`,
            category: 'auction'
        });
    }
};

// Init notification system ketika DOM ready
document.addEventListener('DOMContentLoaded', function() {
    // Tambahkan CSS untuk notifikasi jika belum ada
    if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification-container-2025 {
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 9999;
                display: flex;
                flex-direction: column;
                gap: 10px;
                max-width: 350px;
            }
            
            .notification-item-2025 {
                background: white;
                border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                overflow: hidden;
                display: flex;
                border-left: 4px solid #ddd;
                transition: all 0.3s ease;
            }
            
            .notification-success { border-left-color: #28c76f; }
            .notification-error { border-left-color: #ea5455; }
            .notification-warning { border-left-color: #ff9f43; }
            .notification-info { border-left-color: #00cfe8; }
            
            .notification-icon {
                width: 50px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 1.3rem;
            }
            
            .notification-success .notification-icon { color: #28c76f; }
            .notification-error .notification-icon { color: #ea5455; }
            .notification-warning .notification-icon { color: #ff9f43; }
            .notification-info .notification-icon { color: #00cfe8; }
            
            .notification-content {
                flex-grow: 1;
                padding: 12px 15px;
            }
            
            .notification-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 5px;
            }
            
            .notification-header h4 {
                margin: 0;
                font-size: 1rem;
                font-weight: 600;
            }
            
            .notification-close {
                background: none;
                border: none;
                color: #999;
                cursor: pointer;
                font-size: 0.8rem;
                padding: 0;
            }
            
            .notification-close:hover {
                color: #333;
            }
            
            .notification-body p {
                margin: 0 0 5px;
                font-size: 0.9rem;
                color: #666;
            }
            
            .notification-link {
                font-size: 0.85rem;
                font-weight: 600;
                color: #3a7bd5;
                text-decoration: none;
                display: inline-block;
                margin-top: 5px;
            }
            
            .notification-counter {
                position: absolute;
                top: -5px;
                right: -5px;
                background: #ea5455;
                color: white;
                width: 18px;
                height: 18px;
                border-radius: 50%;
                font-size: 0.7rem;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: bold;
            }
            
            .fade-in-up {
                animation: notifyFadeInUp 0.3s ease forwards;
            }
            
            .fade-out {
                animation: notifyFadeOut 0.3s ease forwards;
            }
            
            @keyframes notifyFadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            @keyframes notifyFadeOut {
                from {
                    opacity: 1;
                    transform: translateY(0);
                }
                to {
                    opacity: 0;
                    transform: translateY(-20px);
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Inisialisasi sistem notifikasi
    NotificationSystem.init();
});

// Expose globally
window.NotificationSystem = NotificationSystem;
