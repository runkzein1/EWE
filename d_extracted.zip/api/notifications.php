<?php
/**
 * Notifications API - Backend handler untuk sistem notifikasi real-time
 * LelangMobil - Modern Web App 2025
 */

// Include database connection and functions
require_once '../config/database.php';
require_once '../config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Set content type to JSON
header('Content-Type: application/json');

// Verify user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized. Please login.',
        'notifications' => []
    ]);
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle POST requests - mark notification as read
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get POST data
    $postData = json_decode(file_get_contents('php://input'), true);
    
    if (isset($postData['action']) && $postData['action'] === 'mark_read') {
        if (isset($postData['notification_id'])) {
            $notification_id = intval($postData['notification_id']);
            
            // Update notification status in database
            $stmt = $conn->prepare("UPDATE notifications SET is_read = 1, read_at = NOW() WHERE notification_id = ? AND user_id = ?");
            $stmt->bind_param("ii", $notification_id, $user_id);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Notification marked as read'
                ]);
            } else {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Failed to mark notification as read'
                ]);
            }
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Notification ID is required'
            ]);
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid action'
        ]);
    }
    exit;
}

// Handle GET requests - fetch notifications
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Check if notifications table exists
    $tableCheckResult = $conn->query("SHOW TABLES LIKE 'notifications'");
    $tableExists = $tableCheckResult->num_rows > 0;
    
    // Create table if it doesn't exist
    if (!$tableExists) {
        $createTableSQL = "
        CREATE TABLE notifications (
            notification_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            type VARCHAR(50) NOT NULL,
            message TEXT NOT NULL,
            url VARCHAR(255) DEFAULT NULL,
            is_read TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            read_at TIMESTAMP NULL DEFAULT NULL,
            entity_type VARCHAR(50) DEFAULT NULL,
            entity_id INT DEFAULT NULL,
            INDEX (user_id),
            INDEX (type),
            INDEX (is_read)
        )";
        
        $conn->query($createTableSQL);
    }
    
    // Get notifications for this user
    $stmt = $conn->prepare("
        SELECT 
            notification_id as id,
            type,
            message,
            url,
            is_read as `read`,
            UNIX_TIMESTAMP(created_at) as timestamp
        FROM 
            notifications 
        WHERE 
            user_id = ? 
        ORDER BY 
            created_at DESC 
        LIMIT 10
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $row['read'] = (bool)$row['read'];
        $notifications[] = $row;
    }
    
    // Get unread count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $countResult = $stmt->get_result();
    $unreadCount = $countResult->fetch_assoc()['count'];
    
    echo json_encode([
        'status' => 'success',
        'unread_count' => $unreadCount,
        'notifications' => $notifications
    ]);
    exit;
}

// Invalid method
echo json_encode([
    'status' => 'error',
    'message' => 'Invalid request method'
]);
