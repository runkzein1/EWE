/**
 * Vehicle Auction Modern 2025 JavaScript
 * Menambahkan interaktivitas dan efek modern pada halaman lelang kendaraan
 */
document.addEventListener('DOMContentLoaded', function() {
    // Countdown Timer
    function initCountdown() {
        const countdownElement = document.getElementById('auction-countdown');
        if (!countdownElement) return;
        
        const endTime = new Date(countdownElement.getAttribute('data-end-time')).getTime();
        
        function updateCountdown() {
            const now = new Date().getTime();
            const distance = endTime - now;
            
            if (distance < 0) {
                // Auction has ended
                document.getElementById('days').textContent = '0';
                document.getElementById('hours').textContent = '0';
                document.getElementById('minutes').textContent = '0';
                document.getElementById('seconds').textContent = '0';
                
                // Update status
                const statusElement = document.getElementById('auction-status');
                if (statusElement) {
                    statusElement.textContent = 'Lelang Berakhir';
                    statusElement.classList.remove('auction-status-active', 'auction-status-ending-soon');
                    statusElement.classList.add('auction-status-ended');
                }
                
                // Disable bid form
                const bidForm = document.getElementById('bid-form');
                if (bidForm) {
                    const bidButton = bidForm.querySelector('button[type="submit"]');
                    if (bidButton) {
                        bidButton.disabled = true;
                        bidButton.textContent = 'Lelang Telah Berakhir';
                    }
                }
                
                return;
            }
            
            // Calculate time units
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            // Update countdown blocks
            document.getElementById('days').textContent = days;
            document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
            document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
            document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
            
            // Update auction status
            const statusElement = document.getElementById('auction-status');
            if (statusElement) {
                if (distance < 1000 * 60 * 60 * 24) { // Less than 24 hours
                    statusElement.textContent = 'Segera Berakhir';
                    statusElement.classList.remove('auction-status-active');
                    statusElement.classList.add('auction-status-ending-soon', 'pulse-animation');
                }
            }
        }
        
        // Initial update
        updateCountdown();
        
        // Update every second
        setInterval(updateCountdown, 1000);
    }
    
    // Initialize countdown
    initCountdown();
    
    // Handle Bid Suggestions
    const bidSuggestions = document.querySelectorAll('.bid-suggestion');
    const bidInput = document.getElementById('bid_amount');
    
    if (bidSuggestions.length > 0 && bidInput) {
        bidSuggestions.forEach(suggestion => {
            suggestion.addEventListener('click', function() {
                const amount = this.getAttribute('data-amount');
                bidInput.value = amount;
                
                // Remove active class from all suggestions
                bidSuggestions.forEach(s => s.classList.remove('active'));
                
                // Add active class to clicked suggestion
                this.classList.add('active');
            });
        });
    }
    
    // Format currency input
    if (bidInput) {
        bidInput.addEventListener('input', function() {
            // Remove non-numeric characters
            let value = this.value.replace(/[^0-9]/g, '');
            
            // Format with thousand separator
            if (value) {
                value = parseInt(value).toLocaleString('id-ID');
            }
            
            this.value = value;
        });
    }
    
    // Bid Form with AJAX Submission
    const bidForm = document.getElementById('bid-form');
    if (bidForm) {
        bidForm.addEventListener('submit', function(e) {
            e.preventDefault(); // Always prevent default form submission
            
            const bidAmountInput = document.getElementById('bid_amount');
            if (!bidAmountInput || !bidAmountInput.value) {
                showToast('Masukkan jumlah bid terlebih dahulu', 'warning');
                return false;
            }
            
            // Remove formatting and convert to number
            const bidAmount = parseInt(bidAmountInput.value.replace(/[^0-9]/g, ''));
            const currentPrice = parseInt(document.getElementById('current-price').getAttribute('data-price'));
            const minIncrement = parseInt(document.getElementById('bid-form').getAttribute('data-min-increment')) || 100000;
            const vehicleId = document.getElementById('vehicle-container')?.dataset.vehicleId || '0';
            
            if (bidAmount <= currentPrice) {
                showToast('Jumlah bid harus lebih besar dari harga saat ini', 'warning');
                return false;
            }
            
            if (bidAmount < currentPrice + minIncrement) {
                showToast(`Kenaikan bid minimal Rp ${minIncrement.toLocaleString('id-ID')}`, 'warning');
                return false;
            }
            
            // Simpan data untuk notifikasi
            const vehicleName = document.querySelector('.vehicle-title')?.textContent || 'Kendaraan';
            
            // Disable form & show loading
            const submitButton = bidForm.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.textContent;
            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
            
            // Create form data
            const formData = new FormData();
            formData.append('vehicle_id', vehicleId);
            formData.append('bid_amount', bidAmount);
            
            // Send AJAX request
            fetch('/api/bid-processor.php', {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            })
            .then(response => response.json())
            .then(data => {
                submitButton.disabled = false;
                submitButton.textContent = originalButtonText;
                
                if (data.status === 'success') {
                    // Show success notification
                    showToast(`Bid sebesar Rp ${bidAmount.toLocaleString('id-ID')} berhasil!`, 'success');
                    
                    // Update current price display
                    const currentPriceEl = document.getElementById('current-price');
                    if (currentPriceEl) {
                        currentPriceEl.textContent = `Rp ${bidAmount.toLocaleString('id-ID')}`;
                        currentPriceEl.setAttribute('data-price', bidAmount);
                    }
                    
                    // Clear bid input
                    bidAmountInput.value = '';
                    
                    // Remove active class from suggestions
                    document.querySelectorAll('.bid-suggestion').forEach(s => s.classList.remove('active'));
                    
                    // Send to notification system
                    if (window.NotificationSystem) {
                        window.NotificationSystem.notifyBidSuccess(
                            vehicleId,
                            vehicleName,
                            bidAmount.toLocaleString('id-ID')
                        );
                    }
                    
                    // Refresh bid history
                    refreshBidHistory();
                } else {
                    // Show error message
                    showToast(data.message || 'Terjadi kesalahan saat proses bid', 'error');
                    
                    // If redirect is present, redirect user
                    if (data.redirect) {
                        setTimeout(() => {
                            window.location.href = data.redirect;
                        }, 2000);
                    }
                }
            })
            .catch(error => {
                console.error('Bid error:', error);
                submitButton.disabled = false;
                submitButton.textContent = originalButtonText;
                showToast('Terjadi kesalahan koneksi. Silakan coba lagi.', 'error');
            });
            
            return false;
        });
    }
    
    // Toast Notification
    function showToast(message, type = 'info') {
        const toastContainer = document.querySelector('.toast-container');
        
        if (!toastContainer) {
            // Create toast container if it doesn't exist
            const container = document.createElement('div');
            container.className = 'toast-container';
            document.body.appendChild(container);
        }
        
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        
        document.querySelector('.toast-container').appendChild(toast);
        
        // Show toast with animation
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        // Remove toast after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            
            // Remove from DOM after animation
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 3000);
    }
    
    // Image Gallery
    const galleryItems = document.querySelectorAll('.gallery-item');
    const mainImage = document.querySelector('.vehicle-banner-2025 img');
    
    if (galleryItems.length > 0 && mainImage) {
        galleryItems.forEach(item => {
            item.addEventListener('click', function() {
                const imgSrc = this.querySelector('img').getAttribute('src');
                
                // Update main image with fade effect
                mainImage.style.opacity = 0;
                
                setTimeout(() => {
                    mainImage.setAttribute('src', imgSrc);
                    mainImage.style.opacity = 1;
                }, 300);
                
                // Set active class
                galleryItems.forEach(gi => gi.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }
    
    // Animate sections on scroll
    function animateOnScroll() {
        const elements = document.querySelectorAll('.fade-in-up:not(.visible)');
        
        elements.forEach(el => {
            const rect = el.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            if (rect.top < windowHeight - 100) {
                el.classList.add('visible');
            }
        });
    }
    
    // Run once on load
    animateOnScroll();
    
    // Add scroll event listener
    window.addEventListener('scroll', animateOnScroll);
    
    // Real-time bid updates via polling (in real app, replace with WebSockets)
    function initBidUpdates() {
        const bidHistoryTable = document.querySelector('.bid-history-table tbody');
        const vehicleId = document.getElementById('vehicle-container')?.getAttribute('data-vehicle-id');
        
        if (!bidHistoryTable || !vehicleId) return;
        
        function updateBids() {
            // In a real implementation, this would be an AJAX call to get the latest bids
            // For demo purposes, we'll just simulate it
            
            // Check for new bids every 5 seconds
            setTimeout(updateBids, 5000);
        }
        
        // Start polling
        updateBids();
    }
    
    // Initialize bid updates
    initBidUpdates();
    
    // Bid animation
    function flashLatestBid() {
        const latestBidRow = document.querySelector('.bid-history-table tbody tr:first-child');
        
        if (latestBidRow) {
            latestBidRow.classList.add('flash-bid');
            
            setTimeout(() => {
                latestBidRow.classList.remove('flash-bid');
            }, 1000);
        }
    }
    
    // Call this when a new bid comes in
    // flashLatestBid();
});
