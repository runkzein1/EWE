<?php
/**
 * Active Auctions Widget
 * LelangMobil Web App - Versi 2025
 */

// Query untuk lelang aktif terbaru dengan pendekatan minimalis yang hanya mengambil kolom yang pasti ada
try {
    // Gunakan query minimalis untuk menghindari error Unknown column
    $active_auctions_sql = "SELECT vehicle_id, 
                        model, 
                        make, 
                        /* Hindari gunakan kolom image yang tidak diketahui namanya */ 
                        starting_price, 
                        current_bid, 
                        auction_end,
                        year,
                        description,
                        status,
                        seller_id,
                        created_at
                        FROM vehicles 
                        WHERE status = 'active'
                        ORDER BY auction_end ASC
                        LIMIT 4";
    $active_auctions_result = $conn->query($active_auctions_sql);
    
    if (!$active_auctions_result) {
        error_log("Error querying active auctions: " . $conn->error);
        $active_auctions_result = false;
    }
} catch (Throwable $e) {
    error_log("Exception querying active auctions: " . $e->getMessage());
    $active_auctions_result = false;
}
?>

<?php
// Check if we should use Modern 2025 style
$use_modern_2025 = isset($use_modern_2025) ? $use_modern_2025 : false;
?>

<?php if ($use_modern_2025): ?>
<!-- Modern 2025 Active Auctions Widget -->
<div class="auction-widget-2025 mt-4 fade-in-up">
    <div class="widget-header">
        <h3 class="widget-title"><i class="fas fa-gavel"></i> Lelang Aktif</h3>
        <a href="auctions.php" class="btn btn-sm btn-outline-primary widget-view-all">
            <i class="fas fa-list me-1"></i> Lihat Semua
        </a>
    </div>
<?php else: ?>
<!-- Legacy Active Auctions Widget -->
<div class="modern-card mt-4 fade-in">
    <div class="modern-card-header">
        <h3 class="modern-card-title"><i class="fa fa-car"></i> Lelang Aktif</h3>
        <a href="auctions.php" class="modern-button modern-button-outline btn-sm">
            <i class="fa fa-list me-1"></i> Lihat Semua
        </a>
    </div>
<?php endif; ?>
    
    <?php if ($use_modern_2025): ?>
    <div class="widget-body">
        <?php if (!$active_auctions_result || $active_auctions_result->num_rows == 0): ?>
            <div class="no-auctions-2025">
                <div class="empty-state-icon">
                    <i class="fas fa-car-side"></i>
                </div>
                <h5>Tidak Ada Lelang Aktif</h5>
                <p>Belum ada lelang aktif saat ini. Periksa kembali nanti.</p>
            </div>
        <?php else: ?>
            <div class="auction-cards-grid">
                <?php while ($auction = $active_auctions_result->fetch_assoc()): 
                    // Calculate time remaining
                    $now = new DateTime();
                    
                    // Gunakan auction_end karena end_date tidak ada di database produksi
                    $end_date = new DateTime($auction['auction_end']);
                    $interval = $now->diff($end_date);
                    
                    $days = $interval->days;
                    $hours = $interval->h;
                    $minutes = $interval->i;
                    
                    $time_label = "";
                    if ($days > 0) {
                        $time_label = $days . " hari " . $hours . " jam";
                    } else if ($hours > 0) {
                        $time_label = $hours . " jam " . $minutes . " menit";
                    } else {
                        $time_label = $minutes . " menit";
                    }
                    
                    // Set bid amount
                    $bid_amount = max($auction['current_bid'], $auction['starting_price']);
                ?>
                <div class="auction-card">
                    <div class="auction-card-image">
                        <!-- Selalu gunakan no-image.svg karena kolom image dihilangkan dari query -->
                        <img src="images/no-image.svg" 
                             alt="<?php echo htmlspecialchars($auction['model']); ?>" 
                             class="img-fluid">
                        <div class="auction-time">
                            <i class="fa fa-clock me-1"></i> <?php echo $time_label; ?>
                        </div>
                    </div>
                    <div class="auction-card-content">
                        <h5 class="auction-title"><?php echo htmlspecialchars($auction['model']); ?></h5>
                        <div class="auction-details">
                            <div class="auction-bid">
                                <div class="bid-label">Bid Saat Ini</div>
                                <div class="bid-amount">Rp<?php echo number_format($bid_amount, 0, ',', '.'); ?></div>
                            </div>
                            <div class="auction-bids">
                                <div class="bids-count"><?php echo isset($auction['total_bids']) ? $auction['total_bids'] : '0'; ?></div>
                                <div class="bids-label">Bid</div>
                            </div>
                        </div>
                        <a href="vehicle.php?id=<?php echo $auction['vehicle_id']; ?>" class="modern-button modern-button-primary w-100 mt-2">
                            <i class="fa fa-gavel me-2"></i>Ajukan Bid
                        </a>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="modern-card-body p-0">
        <?php if (!$active_auctions_result || $active_auctions_result->num_rows == 0): ?>
            <div class="p-4 text-center">
                <div class="empty-state">
                    <i class="fa fa-car fa-3x text-muted mb-3"></i>
                    <h5>Tidak Ada Lelang Aktif</h5>
                    <p class="text-muted">Saat ini tidak ada lelang yang aktif.</p>
                </div>
            </div>
        <?php else: ?>
            <div class="auction-cards-grid">
                <?php while ($auction = $active_auctions_result->fetch_assoc()): 
                    // Calculate time remaining
                    $now = new DateTime();
                    
                    // Gunakan auction_end karena end_date tidak ada di database produksi
                    $end_date = new DateTime($auction['auction_end']);
                    $interval = $now->diff($end_date);
                    
                    $days = $interval->days;
                    $hours = $interval->h;
                    $minutes = $interval->i;
                    
                    $time_label = "";
                    if ($days > 0) {
                        $time_label = $days . " hari " . $hours . " jam";
                    } else if ($hours > 0) {
                        $time_label = $hours . " jam " . $minutes . " menit";
                    } else {
                        $time_label = $minutes . " menit";
                    }
                    
                    // Set bid amount
                    $bid_amount = max($auction['current_bid'], $auction['starting_price']);
                ?>
                <div class="auction-card">
                    <div class="auction-card-image">
                        <!-- Selalu gunakan no-image.svg karena kolom image dihilangkan dari query -->
                        <img src="images/no-image.svg" 
                             alt="<?php echo htmlspecialchars($auction['model']); ?>" 
                             class="img-fluid">
                        <div class="auction-time">
                            <i class="fa fa-clock me-1"></i> <?php echo $time_label; ?>
                        </div>
                    </div>
                    <div class="auction-card-content">
                        <h5 class="auction-title"><?php echo htmlspecialchars($auction['model']); ?></h5>
                        <div class="auction-details">
                            <div class="auction-bid">
                                <div class="bid-label">Bid Saat Ini</div>
                                <div class="bid-amount">Rp<?php echo number_format($bid_amount, 0, ',', '.'); ?></div>
                            </div>
                            <div class="auction-bids">
                                <div class="bids-count"><?php echo isset($auction['total_bids']) ? $auction['total_bids'] : '0'; ?></div>
                                <div class="bids-label">Bid</div>
                            </div>
                        </div>
                        <a href="vehicle.php?id=<?php echo $auction['vehicle_id']; ?>" class="modern-button modern-button-primary w-100 mt-2">
                            <i class="fa fa-gavel me-2"></i>Ajukan Bid
                        </a>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.auction-cards-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: 1rem;
    padding: 1rem;
}

.auction-card {
    background: var(--panel-bg);
    border-radius: var(--border-radius);
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    transition: all var(--transition-speed);
}

.auction-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

.auction-card-image {
    position: relative;
    height: 140px;
    overflow: hidden;
}

.auction-card-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.auction-card:hover .auction-card-image img {
    transform: scale(1.05);
}

.auction-time {
    position: absolute;
    bottom: 10px;
    left: 10px;
    background: rgba(0, 0, 0, 0.7);
    color: white;
    padding: 0.25rem 0.5rem;
    border-radius: 20px;
    font-size: 0.75rem;
}

.auction-card-content {
    padding: 1rem;
}

.auction-title {
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 0.75rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.auction-details {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.75rem;
}

.auction-bid, .auction-bids {
    text-align: center;
}

.bid-label, .bids-label {
    font-size: 0.7rem;
    color: var(--gray-color);
}

.bid-amount {
    font-weight: 700;
    color: var(--primary-color);
}

.bids-count {
    font-weight: 700;
}

@media (max-width: 768px) {
    .auction-cards-grid {
        grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    }
    
    .auction-card-image {
        height: 120px;
    }
    
    .auction-title {
        font-size: 0.8rem;
    }
}
</style>
<?php endif; ?>
