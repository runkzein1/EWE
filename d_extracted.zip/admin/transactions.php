<?php
// Set page title
$page_title = "Manajemen Transaksi";

// Include header
include 'includes/header.php';

// Process transaction approval/rejection
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $transaction_id = intval($_GET['id']);
    
    // Validate transaction exists
    $check_sql = "SELECT t.*, u.username, u.balance 
                 FROM transactions t 
                 JOIN users u ON t.user_id = u.user_id 
                 WHERE t.transaction_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $transaction_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $transaction = $check_result->fetch_assoc();
        
        // Check if transaction is still pending
        if ($transaction['status'] == 'pending') {
            $conn->begin_transaction();
            
            try {
                if ($action == 'approve') {
                    // Update transaction status
                    $update_sql = "UPDATE transactions SET status = 'completed', admin_id = ?, updated_at = NOW() WHERE transaction_id = ?";
                    $update_stmt = $conn->prepare($update_sql);
                    $update_stmt->bind_param("ii", $admin_id, $transaction_id);
                    $update_stmt->execute();
                    
                    // Update user balance
                    if ($transaction['type'] == 'deposit') {
                        $new_balance = $transaction['balance'] + $transaction['amount'];
                        $balance_sql = "UPDATE users SET balance = ? WHERE user_id = ?";
                        $balance_stmt = $conn->prepare($balance_sql);
                        $balance_stmt->bind_param("di", $new_balance, $transaction['user_id']);
                        $balance_stmt->execute();
                    }
                    
                    $conn->commit();
                    $success = "Transaksi berhasil disetujui dan saldo pengguna telah diperbarui.";
                } 
                elseif ($action == 'reject') {
                    // Update transaction status
                    $update_sql = "UPDATE transactions SET status = 'rejected', admin_id = ?, updated_at = NOW() WHERE transaction_id = ?";
                    $update_stmt = $conn->prepare($update_sql);
                    $update_stmt->bind_param("ii", $admin_id, $transaction_id);
                    $update_stmt->execute();
                    
                    $conn->commit();
                    $success = "Transaksi berhasil ditolak.";
                }
            } catch (Exception $e) {
                $conn->rollback();
                $error = "Terjadi kesalahan: " . $e->getMessage();
            }
        } else {
            $error = "Transaksi ini sudah diproses sebelumnya.";
        }
    } else {
        $error = "Transaksi tidak ditemukan.";
    }
}

// Pagination
$items_per_page = 15;
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($current_page - 1) * $items_per_page;

// Filtering
$where_clause = "1=1"; // Default to show all transactions
$params = [];
$param_types = "";

// Search by transaction ID or username
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = clean_input($_GET['search']);
    if (is_numeric($search)) {
        // Search by transaction ID
        $where_clause .= " AND t.transaction_id = ?";
        $params[] = intval($search);
        $param_types .= "i";
    } else {
        // Search by username
        $search = "%$search%";
        $where_clause .= " AND u.username LIKE ?";
        $params[] = $search;
        $param_types .= "s";
    }
}

// Filter by transaction type
if (isset($_GET['type']) && !empty($_GET['type'])) {
    $type = clean_input($_GET['type']);
    $where_clause .= " AND t.type = ?";
    $params[] = $type;
    $param_types .= "s";
}

// Filter by transaction status
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $status = clean_input($_GET['status']);
    $where_clause .= " AND t.status = ?";
    $params[] = $status;
    $param_types .= "s";
}

// Handle period filter
if (isset($_GET['period']) && !empty($_GET['period'])) {
    $period = clean_input($_GET['period']);
    
    switch ($period) {
        case 'today':
            $where_clause .= " AND DATE(t.created_at) = CURDATE()";
            break;
        case 'week':
            $where_clause .= " AND YEARWEEK(t.created_at, 1) = YEARWEEK(CURDATE(), 1)";
            break;
        case 'month':
            $where_clause .= " AND YEAR(t.created_at) = YEAR(CURDATE()) AND MONTH(t.created_at) = MONTH(CURDATE())";
            break;
    }
}

// Count total transactions matching criteria
$count_sql = "SELECT COUNT(*) as total 
             FROM transactions t 
             JOIN users u ON t.user_id = u.user_id 
             WHERE $where_clause";
$count_stmt = $conn->prepare($count_sql);
if (!empty($params)) {
    $count_stmt->bind_param($param_types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$count_row = $count_result->fetch_assoc();
$total_items = $count_row['total'];
$total_pages = ceil($total_items / $items_per_page);

// Get transactions with pagination
$transactions_sql = "SELECT t.*, u.username, a.username as admin_username
                    FROM transactions t 
                    JOIN users u ON t.user_id = u.user_id 
                    LEFT JOIN users a ON t.admin_id = a.user_id 
                    WHERE $where_clause 
                    ORDER BY t.created_at DESC 
                    LIMIT ?, ?";
$params[] = $offset;
$params[] = $items_per_page;
$param_types .= "ii";

$transactions_stmt = $conn->prepare($transactions_sql);
$transactions_stmt->bind_param($param_types, ...$params);
$transactions_stmt->execute();
$transactions_result = $transactions_stmt->get_result();
?>

<h1 class="mb-4">Manajemen Transaksi</h1>

<?php if(isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<?php if(isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<!-- Filter Form -->
<div class="de-box mb-4">
    <form action="" method="get" class="row g-3">
        <div class="col-md-3">
            <input type="text" name="search" class="form-control" placeholder="Cari ID transaksi atau username..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        </div>
        <div class="col-md-3">
            <select name="type" class="form-control form-select">
                <option value="">Semua Tipe</option>
                <option value="deposit" <?php echo (isset($_GET['type']) && $_GET['type'] == 'deposit') ? 'selected' : ''; ?>>Top-up</option>
                <option value="withdrawal" <?php echo (isset($_GET['type']) && $_GET['type'] == 'withdrawal') ? 'selected' : ''; ?>>Penarikan</option>
                <option value="bid_hold" <?php echo (isset($_GET['type']) && $_GET['type'] == 'bid_hold') ? 'selected' : ''; ?>>Hold Bid</option>
                <option value="bid_release" <?php echo (isset($_GET['type']) && $_GET['type'] == 'bid_release') ? 'selected' : ''; ?>>Release Bid</option>
                <option value="winning_payment" <?php echo (isset($_GET['type']) && $_GET['type'] == 'winning_payment') ? 'selected' : ''; ?>>Pembayaran Menang</option>
            </select>
        </div>
        <div class="col-md-2">
            <select name="status" class="form-control form-select">
                <option value="">Semua Status</option>
                <option value="pending" <?php echo (isset($_GET['status']) && $_GET['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                <option value="completed" <?php echo (isset($_GET['status']) && $_GET['status'] == 'completed') ? 'selected' : ''; ?>>Selesai</option>
                <option value="rejected" <?php echo (isset($_GET['status']) && $_GET['status'] == 'rejected') ? 'selected' : ''; ?>>Ditolak</option>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">Filter</button>
        </div>
        <div class="col-md-2">
            <a href="transactions.php" class="btn btn-secondary w-100">Reset</a>
        </div>
    </form>
</div>

<!-- Transactions Table -->
<?php
// Get transaction statistics
$stats_sql = "SELECT 
    COUNT(*) as total_count,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_count,
    SUM(CASE WHEN status = 'completed' AND type = 'deposit' THEN amount ELSE 0 END) as total_topup
    FROM transactions
    WHERE type IN ('deposit', 'withdrawal')"
;
$stats_result = $conn->query($stats_sql);
$stats = $stats_result->fetch_assoc();
?>

<!-- Transaction Statistics -->
<div class="transaction-stats mb-4">
    <div class="stat-card total">
        <div class="stat-icon"><i class="fa fa-exchange-alt"></i></div>
        <div class="stat-value"><?php echo number_format($stats['total_count']); ?></div>
        <div class="stat-label">Total Transaksi</div>
    </div>
    
    <div class="stat-card pending">
        <div class="stat-icon"><i class="fa fa-clock"></i></div>
        <div class="stat-value"><?php echo number_format($stats['pending_count']); ?></div>
        <div class="stat-label">Menunggu Persetujuan</div>
    </div>
    
    <div class="stat-card completed">
        <div class="stat-icon"><i class="fa fa-check-circle"></i></div>
        <div class="stat-value"><?php echo number_format($stats['completed_count']); ?></div>
        <div class="stat-label">Selesai</div>
    </div>
    
    <div class="stat-card rejected">
        <div class="stat-icon"><i class="fa fa-times-circle"></i></div>
        <div class="stat-value"><?php echo number_format($stats['rejected_count']); ?></div>
        <div class="stat-label">Ditolak</div>
    </div>
    
    <div class="stat-card completed">
        <div class="stat-icon"><i class="fa fa-wallet"></i></div>
        <div class="stat-value">Rp <?php echo number_format($stats['total_topup'], 0, ',', '.'); ?></div>
        <div class="stat-label">Total Top-up</div>
    </div>
</div>

<!-- Filter Controls -->
<div class="topup-filter-controls mb-4">
    <form method="get" action="">
        <div class="filter-row">
            <div class="filter-group">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="">Semua Status</option>
                    <option value="pending" <?php echo isset($_GET['status']) && $_GET['status'] == 'pending' ? 'selected' : ''; ?>>Menunggu Persetujuan</option>
                    <option value="completed" <?php echo isset($_GET['status']) && $_GET['status'] == 'completed' ? 'selected' : ''; ?>>Selesai</option>
                    <option value="rejected" <?php echo isset($_GET['status']) && $_GET['status'] == 'rejected' ? 'selected' : ''; ?>>Ditolak</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Jenis Transaksi</label>
                <select name="type" class="form-control">
                    <option value="">Semua Jenis</option>
                    <option value="deposit" <?php echo isset($_GET['type']) && $_GET['type'] == 'deposit' ? 'selected' : ''; ?>>Top-up Saldo</option>
                    <option value="withdrawal" <?php echo isset($_GET['type']) && $_GET['type'] == 'withdrawal' ? 'selected' : ''; ?>>Penarikan</option>
                    <option value="bid_hold" <?php echo isset($_GET['type']) && $_GET['type'] == 'bid_hold' ? 'selected' : ''; ?>>Penahanan Bid</option>
                    <option value="bid_release" <?php echo isset($_GET['type']) && $_GET['type'] == 'bid_release' ? 'selected' : ''; ?>>Pelepasan Bid</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Periode</label>
                <select name="period" class="form-control">
                    <option value="">Semua Waktu</option>
                    <option value="today" <?php echo isset($_GET['period']) && $_GET['period'] == 'today' ? 'selected' : ''; ?>>Hari Ini</option>
                    <option value="week" <?php echo isset($_GET['period']) && $_GET['period'] == 'week' ? 'selected' : ''; ?>>Minggu Ini</option>
                    <option value="month" <?php echo isset($_GET['period']) && $_GET['period'] == 'month' ? 'selected' : ''; ?>>Bulan Ini</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Pencarian</label>
                <input type="text" name="search" class="form-control" placeholder="ID, Username, Referensi..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            </div>
        </div>
        
        <div class="filter-actions">
            <button type="submit" class="btn btn-primary"><i class="fa fa-filter"></i> Filter</button>
            <a href="transactions.php" class="btn btn-outline-secondary"><i class="fa fa-sync"></i> Reset</a>
        </div>
    </form>
</div>

<div class="de-box">
    <div class="table-responsive">
        <table class="table table-hover admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Pengguna</th>
                    <th>Tanggal</th>
                    <th>Jumlah</th>
                    <th>Tipe</th>
                    <th>Status</th>
                    <th>Referensi</th>
                    <th>Diproses Oleh</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($transactions_result->num_rows > 0): ?>
                    <?php while ($transaction = $transactions_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $transaction['transaction_id']; ?></td>
                            <td>
                                <a href="user-detail.php?id=<?php echo $transaction['user_id']; ?>" class="text-decoration-none">
                                    <?php echo $transaction['username']; ?>
                                </a>
                            </td>
                            <td><?php echo date('d M Y H:i', strtotime($transaction['created_at'])); ?></td>
                            <td><?php echo format_currency($transaction['amount']); ?></td>
                            <td>
                                <?php
                                switch ($transaction['type']) {
                                    case 'deposit':
                                        echo '<span class="badge bg-success">Top-up</span>';
                                        break;
                                    case 'withdrawal':
                                        echo '<span class="badge bg-warning">Penarikan</span>';
                                        break;
                                    case 'bid_hold':
                                        echo '<span class="badge bg-info">Hold Bid</span>';
                                        break;
                                    case 'bid_release':
                                        echo '<span class="badge bg-secondary">Release Bid</span>';
                                        break;
                                    case 'winning_payment':
                                        echo '<span class="badge bg-primary">Pembayaran Menang</span>';
                                        break;
                                    default:
                                        echo $transaction['type'];
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                if ($transaction['status'] == 'pending') {
                                    echo '<span class="status-badge status-pending">Menunggu</span>';
                                } elseif ($transaction['status'] == 'completed') {
                                    echo '<span class="status-badge status-completed">Selesai</span>';
                                } elseif ($transaction['status'] == 'rejected') {
                                    echo '<span class="status-badge status-rejected">Ditolak</span>';
                                } else {
                                    echo $transaction['status'];
                                }
                                ?>
                            </td>
                            <td><?php echo $transaction['reference_number']; ?></td>
                            <td><?php echo $transaction['admin_username'] ? $transaction['admin_username'] : '-'; ?></td>
                            <td>
                                <?php if ($transaction['status'] == 'pending' && $transaction['type'] == 'deposit'): ?>
                                    <div class="btn-group" role="group" aria-label="Transaction Actions">
                                        <a href="transactions.php?action=approve&id=<?php echo $transaction['transaction_id']; ?>" class="btn btn-sm btn-success" onclick="return confirm('Yakin ingin menyetujui transaksi ini?')">
                                            <i class="fa fa-check"></i> Setujui
                                        </a>
                                        <a href="transactions.php?action=reject&id=<?php echo $transaction['transaction_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menolak transaksi ini?')">
                                            <i class="fa fa-times"></i> Tolak
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <a href="transaction-detail.php?id=<?php echo $transaction['transaction_id']; ?>" class="btn btn-sm btn-primary">
                                        <i class="fa fa-eye"></i> Detail
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center">Tidak ada transaksi yang ditemukan</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center mt-4">
                <?php if ($current_page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo "transactions.php?" . http_build_query(array_merge($_GET, ['page' => $current_page - 1])); ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                        <a class="page-link" href="<?php echo "transactions.php?" . http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($current_page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo "transactions.php?" . http_build_query(array_merge($_GET, ['page' => $current_page + 1])); ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
