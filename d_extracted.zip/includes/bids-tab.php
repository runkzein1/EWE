<?php
/**
 * File untuk Tab Bids yang sudah diperbaiki menggunakan helper functions
 * Untuk menghindari PHP errors dan warnings
 * Update: Tambahan error handling - 2025-05-03
 */

try {
    // Pastikan user_id sudah didefinisikan
    if (!isset($user_id) && isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
    }

    // Inisialisasi variabel bids
    $active_bids_count = 0;
    $winning_bids_count = 0;
    $total_bids_count = 0;

    // Validasi koneksi database
    if (!isset($conn) || !($conn instanceof mysqli)) {
        throw new Exception("Koneksi database tidak tersedia");
    }

    // Query untuk mengambil penawaran user
    $bids_sql = "SELECT b.*, v.make, v.model, v.year, v.auction_end as end_date, v.image_main as image_url, v.starting_price, v.title 
                 FROM bids b 
                 LEFT JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
                 WHERE b.bidder_id = ? 
                 ORDER BY b.bid_time DESC";
    $stmt = $conn->prepare($bids_sql);
    if (!$stmt) {
        throw new Exception("Database error: " . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $bids_result = $stmt->get_result();

// Hitung jumlah bid aktif dan menang
if (is_valid_result($bids_result)) {
    $total_bids_count = $bids_result->num_rows;
    while ($bid = $bids_result->fetch_assoc()) {
        if (is_bid_active($bid)) {
            $active_bids_count++;
            if (get_value($bid, 'is_winning') == 1) {
                $winning_bids_count++;
            }
        }
    }
}
?>

<!-- Tab Bids -->
<div class="tab-pane fade premium-tab" id="bids" role="tabpanel" aria-labelledby="bids-tab">
    <h3 class="mb-4 animated-heading"><i class="fa fa-gavel me-2"></i>Penawaran Saya</h3>
    
    <!-- Filter & Status Cards -->
    <div class="row mb-4">
        <div class="col-lg-8 mb-3 mb-lg-0">
            <div class="premium-card">
                <div class="card-body">
                    <div class="row align-items-end">
                        <div class="col-md-4 mb-3 mb-md-0">
                            <label for="bid-status" class="form-label">Status Bid</label>
                            <select class="form-select" id="bid-status">
                                <option value="">Semua Status</option>
                                <option value="active">Aktif</option>
                                <option value="winning">Tertinggi</option>
                                <option value="ended">Berakhir</option>
                                <option value="won">Menang</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3 mb-md-0">
                            <label for="bid-sort" class="form-label">Urutkan</label>
                            <select class="form-select" id="bid-sort">
                                <option value="newest">Terbaru</option>
                                <option value="highest">Nilai Tertinggi</option>
                                <option value="closing">Segera Berakhir</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <button class="btn premium-btn premium-btn-primary w-100" id="apply-bid-filter">
                                <i class="fa fa-filter me-2"></i>Terapkan Filter
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <!-- Summary Stats Cards with Premium Auto Theme -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card ultra-glass stat-card js-tilt-card">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center tilt-child">
                                <div class="ultra-stat-icon blue">
                                    <i class="fa fa-gavel"></i>
                                </div>
                                <div class="ultra-stat-content ms-3">
                                    <div class="ultra-stat-value count-number" data-target="<?php echo $total_bids_count; ?>">
                                        <?php echo $total_bids_count; ?>
                                    </div>
                                    <div class="ultra-stat-label">Total Bid</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card ultra-glass stat-card js-tilt-card">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center tilt-child">
                                <div class="ultra-stat-icon teal">
                                    <i class="fa fa-spinner fa-pulse"></i>
                                </div>
                                <div class="ultra-stat-content ms-3">
                                    <div class="ultra-stat-value text-gradient"><?php echo $active_bids_count; ?></div>
                                    <div class="ultra-stat-label">Bid Aktif</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card ultra-glass stat-card js-tilt-card">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center tilt-child">
                                <div class="ultra-stat-icon gold">
                                    <i class="fa fa-trophy"></i>
                                </div>
                                <div class="ultra-stat-content ms-3">
                                    <div class="ultra-stat-value"><?php echo $winning_bids_count; ?></div>
                                    <div class="ultra-stat-label">Bid Tertinggi</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bids Grid -->
    <div class="premium-card">
        <div class="card-body">
            <?php if (!is_valid_result($bids_result) || $bids_result->num_rows == 0): ?>
            <div class="text-center p-4">
                <div class="empty-state">
                    <i class="fa fa-gavel fa-3x text-muted mb-3"></i>
                    <h5>Belum Ada Penawaran</h5>
                    <p class="text-muted">Anda belum membuat penawaran apapun.</p>
                    <a href="vehicle-list.php" class="btn premium-btn premium-btn-primary mt-3">
                        <i class="fa fa-search me-2"></i>Lihat Kendaraan
                    </a>
                </div>
            </div>
            <?php else: ?>
            <div class="row mb-4">
                <div class="col-12">
                    <div class="premium-card">
                        <div class="card-body pb-2">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0"><i class="fa fa-car me-2"></i>Daftar Kendaraan Ditawar</h5>
                                <div class="bid-controls">
                                    <span class="text-muted me-2">Total: <span class="badge bg-info"><?php echo $total_bids_count; ?></span></span>
                                    <span class="bid-view-toggle">
                                        <button class="btn btn-sm btn-outline-secondary me-1" id="grid-view"><i class="fa fa-th"></i></button>
                                        <button class="btn btn-sm btn-outline-secondary" id="list-view"><i class="fa fa-list"></i></button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bid-cards-grid bid-cards-container">
                <?php 
                // Reset pointer
                if (is_valid_result($bids_result)) {
                    $bids_result->data_seek(0);
                    while ($bid = $bids_result->fetch_assoc()): 
                        // Tentukan status dan kelas
                        $status_class = "";
                        $status_text = "";
                        
                        // Fungsi helper untuk validasi bid
                        $is_active = is_bid_active($bid);
                        $is_winning = get_value($bid, 'is_winning', 0) == 1;
                        $end_date = get_value($bid, 'end_date', '');
                        
                        // Tentukan status penawaran berdasarkan data yang valid
                        if ($is_active) {
                            if ($is_winning) {
                                $status_class = "winning";
                                $status_text = "Tertinggi";
                            } else {
                                $status_class = "active";
                                $status_text = "Aktif";
                            }
                        } else {
                            if (get_value($bid, 'is_winning') == 1) {
                                $status_class = "won";
                                $status_text = "Menang";
                            } else {
                                $status_class = "ended";
                                $status_text = "Berakhir";
                            }
                        }
                ?>
                <div class="bid-card <?php echo $status_class; ?>" 
                     data-status="<?php echo $status_class; ?>" 
                     data-amount="<?php echo get_value($bid, 'bid_amount', 0); ?>" 
                     data-time="<?php echo get_value($bid, 'bid_time'); ?>" 
                     data-end="<?php echo $end_date; ?>">
                    <div class="bid-card-header">
                        <div class="bid-status-badge <?php echo $status_class; ?>">
                            <?php if ($status_class == 'winning' || $status_class == 'won'): ?>
                                <i class="fa fa-trophy"></i>
                            <?php endif; ?>
                            <?php echo $status_text; ?>
                        </div>
                        <div class="bid-time">
                            <?php echo get_formatted_date($bid, 'bid_time', 'd M Y H:i'); ?>
                        </div>
                    </div>
                    <div class="bid-card-image">
                        <?php 
                        $image_url = get_value($bid, 'image_url', '');
                        // Validasi image_url dan berikan default jika tidak ada
                        if (empty($image_url)) {
                            $image_url = 'img/no-image.jpg';
                        } else {
                            // Pastikan path gambar benar
                            $image_url = 'uploads/vehicles/' . $image_url;
                        }
                        ?>
                        <img src="<?php echo $image_url; ?>" 
                             alt="<?php echo get_value($bid, 'make', '') . ' ' . get_value($bid, 'model', ''); ?>" 
                             onerror="this.src='img/no-image.jpg';" 
                             loading="lazy" 
                             class="vehicle-image">
                        <?php if ($is_winning): ?>
                        <div class="premium-badge winning-badge">
                            <i class="fa fa-trophy"></i>
                            <span>Tertinggi</span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="bid-card-vehicle">
                        <h5><?php echo get_value($bid, 'make', 'Merek') . ' ' . get_value($bid, 'model', 'Model'); ?></h5>
                        <p class="text-muted"><?php echo get_value($bid, 'year', 'Tahun tidak diketahui'); ?></p>
                        <p class="vehicle-title"><?php echo get_value($bid, 'title', ''); ?></p>
                    </div>
                    <div class="bid-card-details">
                        <div class="bid-amount">
                            <span class="label">Bid Anda:</span>
                            <span class="amount">Rp <?php echo safe_format_currency(get_value($bid, 'bid_amount')); ?></span>
                        </div>
                        <div class="starting-price">
                            <span class="label">Harga Awal:</span>
                            <span class="price">Rp <?php echo safe_format_currency(get_value($bid, 'starting_price')); ?></span>
                        </div>
                    </div>
                    <div class="bid-card-footer">
                        <?php if (is_bid_active($bid)): ?>
                        <div class="countdown" data-end="<?php echo get_value($bid, 'end_date'); ?>">
                            <i class="fa fa-clock me-1"></i>
                            Sisa: <?php echo get_bid_remaining_time($bid); ?>
                        </div>
                        <a href="vehicle.php?id=<?php echo get_value($bid, 'vehicle_id'); ?>" class="btn premium-btn premium-btn-sm premium-btn-primary">
                            <i class="fa fa-plus-circle me-1"></i>Naikkan Bid
                        </a>
                        <?php else: ?>
                        <div class="countdown ended">
                            <i class="fa fa-check-circle me-1"></i>
                            Lelang Berakhir
                        </div>
                        <a href="vehicle.php?id=<?php echo get_value($bid, 'vehicle_id'); ?>" class="btn premium-btn premium-btn-sm premium-btn-outline">
                            <i class="fa fa-eye me-1"></i>Detail
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php 
                    endwhile; 
                }
                ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div><!-- Akhir tab bids -->

<?php
} catch (Exception $e) {
    // Log error untuk debugging server-side
    error_log('Error loading bid history: ' . $e->getMessage());
    
    // Tampilkan pesan error yang user-friendly
    echo '<div class="tab-pane fade premium-tab" id="bids" role="tabpanel" aria-labelledby="bids-tab">';
    echo '<h3 class="mb-4 animated-heading"><i class="fa fa-gavel me-2"></i>Penawaran Saya</h3>';
    echo '<div class="premium-card">';
    echo '<div class="card-body">';
    echo '<div class="alert alert-danger">';
    echo '<i class="fa fa-exclamation-triangle me-2"></i>Error pada sistem. Mohon maaf atas ketidaknyamanan ini.';
    echo '</div>';
    echo '<p class="text-muted">Detail error: ' . htmlspecialchars($e->getMessage()) . '</p>';
    echo '<p>Silakan refresh halaman atau hubungi tim support jika masalah berlanjut.</p>';
    echo '<button class="btn premium-btn mt-3" onclick="location.reload()"><i class="fa fa-sync me-2"></i>Refresh Halaman</button>';
    echo '</div></div></div>';
}

