<?php
// Ensure this file is included by account.php and has access to $db, $user_id, $user_transactions, $csrf_token

if (!defined('ROOT_PATH')) {
    die("Direct access not allowed.");
}

// $user_transactions should be an array of the user's transactions, fetched in account.php
// Each transaction item should ideally contain: transaction_date, description, amount, type (e.g., deposit, withdrawal, bid_won, bid_placed, fee, refund), status

// --- Filtering Logic (Optional) ---
$filter_type = sanitize_input($_GET['filter'] ?? 'all'); // e.g., ?tab=transactions&filter=deposits
$allowed_filters = ['all', 'deposits', 'withdrawals', 'bids', 'fees', 'wallet']; // Add more as needed
if (!in_array($filter_type, $allowed_filters)) {
    $filter_type = 'all';
}

$page_number = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$items_per_page = 15; // Number of transactions per page

// Fetch transactions based on filter and pagination - this might be a more complex query in a real app
// For now, we'll filter the $user_transactions array if it's pre-loaded with all recent transactions
$display_transactions = $user_transactions; // Start with all loaded transactions

if ($filter_type !== 'all') {
    $display_transactions = array_filter($user_transactions, function($transaction) use ($filter_type) {
        $type_lower = strtolower($transaction['type']);
        if ($filter_type === 'deposits') return in_array($type_lower, ['deposit', 'topup']);
        if ($filter_type === 'withdrawals') return $type_lower === 'withdrawal';
        if ($filter_type === 'bids') return strpos($type_lower, 'bid') !== false || $type_lower === 'auction_win';
        if ($filter_type === 'fees') return strpos($type_lower, 'fee') !== false;
        if ($filter_type === 'wallet') return in_array($type_lower, ['deposit', 'topup', 'withdrawal', 'refund', 'bonus']);
        return false;
    });
}

// Basic pagination (client-side from the preloaded $user_transactions)
// For server-side pagination, you'd adjust your SQL query with LIMIT and OFFSET
$total_items = count($display_transactions);
$total_pages = ceil($total_items / $items_per_page);
$offset = ($page_number - 1) * $items_per_page;
$paginated_transactions = array_slice($display_transactions, $offset, $items_per_page);

?>

<h4>Transaction History</h4>
<hr>

<!-- Filter UI -->
<div class="btn-group mb-3" role="group" aria-label="Filter transactions">
    <a href="?tab=transactions&filter=all" class="btn btn-outline-secondary <?php echo $filter_type === 'all' ? 'active' : ''; ?>">All</a>
    <a href="?tab=transactions&filter=wallet" class="btn btn-outline-secondary <?php echo $filter_type === 'wallet' ? 'active' : ''; ?>">Wallet</a>
    <a href="?tab=transactions&filter=bids" class="btn btn-outline-secondary <?php echo $filter_type === 'bids' ? 'active' : ''; ?>">Bids</a>
    <a href="?tab=transactions&filter=deposits" class="btn btn-outline-secondary <?php echo $filter_type === 'deposits' ? 'active' : ''; ?>">Deposits</a>
    <a href="?tab=transactions&filter=withdrawals" class="btn btn-outline-secondary <?php echo $filter_type === 'withdrawals' ? 'active' : ''; ?>">Withdrawals</a>
</div>


<?php if (!empty($paginated_transactions)): ?>
    <div class="table-responsive">
        <table class="table table-striped table-hover modern-table">
            <thead class="table-dark">
                <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Type</th>
                    <th class="text-end">Amount</th>
                    <th class="text-center">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($paginated_transactions as $transaction): ?>
                    <tr>
                        <td><?php echo htmlspecialchars(date("d M Y, H:i", strtotime($transaction['transaction_date'] ?? 'N/A'))); ?></td>
                        <td><?php echo htmlspecialchars($transaction['description'] ?? 'N/A'); ?></td>
                        <td><span class="badge bg-info text-dark"><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $transaction['type'] ?? 'N/A'))); ?></span></td>
                        <td class="text-end fw-bold <?php echo (floatval($transaction['amount'] ?? 0) >= 0 && !in_array(strtolower($transaction['type'] ?? ''), ['withdrawal','fee','bid_placed'])) ? 'text-success' : 'text-danger'; ?>">
                            <?php 
                            $amount = floatval($transaction['amount'] ?? 0);
                            // Display positive for deposits/wins, negative for withdrawals/fees/bids
                            // This logic might need adjustment based on how 'amount' is stored for different types
                            // if (in_array(strtolower($transaction['type'] ?? ''), ['withdrawal', 'fee', 'bid_placed']) && $amount > 0) {
                            //    $amount *= -1; 
                            // }
                            echo "Rp " . number_format($amount, 2, ',', '.'); 
                            ?>
                        </td>
                        <td class="text-center">
                            <?php 
                            $status = strtolower($transaction['status'] ?? 'pending');
                            $badge_class = 'bg-secondary'; // Default for pending or unknown
                            if ($status === 'completed' || $status === 'success') $badge_class = 'bg-success';
                            else if ($status === 'failed' || $status === 'cancelled') $badge_class = 'bg-danger';
                            else if ($status === 'pending') $badge_class = 'bg-warning text-dark';
                            echo "<span class=\"badge {$badge_class}\">" . htmlspecialchars(ucfirst($status)) . "</span>";
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination Controls -->
    <?php if ($total_pages > 1): ?>
    <nav aria-label="Transaction pagination">
        <ul class="pagination justify-content-center mt-4">
            <?php if ($page_number > 1): ?>
                <li class="page-item"><a class="page-link" href="?tab=transactions&filter=<?php echo $filter_type; ?>&page=<?php echo $page_number - 1; ?>">Previous</a></li>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo ($i === $page_number) ? 'active' : ''; ?>">
                    <a class="page-link" href="?tab=transactions&filter=<?php echo $filter_type; ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($page_number < $total_pages): ?>
                <li class="page-item"><a class="page-link" href="?tab=transactions&filter=<?php echo $filter_type; ?>&page=<?php echo $page_number + 1; ?>">Next</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <?php endif; ?>

<?php else: ?>
    <div class="alert alert-info" role="alert">
        No transactions found matching your criteria. <?php if ($filter_type !== 'all') echo '<a href="?tab=transactions&filter=all">Show all transactions</a>.'; ?>
    </div>
<?php endif; ?>

<style>
.modern-table th {
    font-weight: 600;
}
.badge {
    font-size: 0.85em;
    padding: 0.4em 0.7em;
}
</style>
