<?php
/**
 * Performance Monitoring for LelangMobil
 * Version: 1.0 (14 Mei 2025)
 * 
 * File ini berisi fungsi-fungsi untuk memonitor dan meningkatkan performa aplikasi
 */

// Mulai menghitung waktu eksekusi
function start_performance_monitoring() {
    // Menyimpan waktu mulai dalam milliseconds
    $_SERVER['PERFORMANCE_START_TIME'] = microtime(true);
    
    // Menyimpan penggunaan memori awal
    $_SERVER['PERFORMANCE_START_MEMORY'] = memory_get_usage();
    
    // Enable output buffering
    ob_start();
}

// Akhiri monitoring dan tampilkan informasi performa (untuk debugging)
function end_performance_monitoring($show_debug = false) {
    // Ambil waktu eksekusi
    $execution_time = round((microtime(true) - $_SERVER['PERFORMANCE_START_TIME']) * 1000);
    
    // Ambil penggunaan memori
    $memory_usage = round((memory_get_usage() - $_SERVER['PERFORMANCE_START_MEMORY']) / (1024 * 1024), 2);
    
    // Siapkan data performa untuk logging
    $performance_data = [
        'execution_time_ms' => $execution_time,
        'memory_usage_mb' => $memory_usage,
        'uri' => $_SERVER['REQUEST_URI'],
        'timestamp' => date('Y-m-d H:i:s'),
        'user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'guest'
    ];
    
    // Log data performa
    log_performance_data($performance_data);
    
    // Jika debug mode aktif, tampilkan informasi performa
    if ($show_debug) {
        return "<div class='performance-debug'>Waktu: {$execution_time}ms | Memori: {$memory_usage}MB</div>";
    }
    
    // Jika lambat, tambahkan komentar HTML untuk monitoring
    $html = ob_get_contents();
    if ($execution_time > 1000) { // lebih dari 1 detik dianggap lambat
        $html .= "\n<!-- Performance Warning: Page load time {$execution_time}ms -->";
    }
    
    return $html;
}

// Log data performa ke tabel database
function log_performance_data($data) {
    global $conn;
    
    // Skip logging untuk file statis atau jika database belum tersedia
    if (!isset($conn) || !$conn || strpos($_SERVER['REQUEST_URI'], '.') !== false) {
        return;
    }
    
    try {
        // Cek apakah tabel performance_logs ada
        $table_check = $conn->query("SHOW TABLES LIKE 'performance_logs'");
        if ($table_check->num_rows == 0) {
            // Tabel tidak ada, skip logging
            return;
        }
        
        $sql = "INSERT INTO performance_logs (uri, execution_time, memory_usage, user_id, timestamp) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sddss", 
            $data['uri'], 
            $data['execution_time_ms'], 
            $data['memory_usage_mb'], 
            $data['user_id'], 
            $data['timestamp']
        );
        $stmt->execute();
    } catch (Exception $e) {
        // Jangan crash halaman jika gagal logging
        error_log("Performance logging error: " . $e->getMessage());
    }
}

// Compress HTML output
function compress_html_output($html) {
    // Skip jika HTML kosong atau tidak valid
    if (empty($html) || !is_string($html)) {
        return $html;
    }
    
    // Kompresi dasar HTML
    $search = [
        '/\>[^\S ]+/s',     // hapus whitespace setelah tag
        '/[^\S ]+\</s',     // hapus whitespace sebelum tag
        '/(\s)+/s',         // gabungkan multiple whitespace jadi 1
        '/<!--(.|\s)*?-->/' // hapus komentar HTML
    ];
    
    $replace = [
        '>',
        '<',
        '\\1',
        ''
    ];
    
    return preg_replace($search, $replace, $html);
}

// Initialize performance monitoring
start_performance_monitoring();
