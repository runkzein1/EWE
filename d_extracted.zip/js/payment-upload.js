/**
 * Payment Upload JS
 * Interaktivitas modern untuk halaman upload bukti pembayaran
 * Version: 2.0
 * Last Updated: May 6, 2025
 */

document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const dropArea = document.getElementById('drop-area');
    const fileInput = document.getElementById('payment_proof');
    const browseBtn = document.getElementById('browse-btn');
    const filePreview = document.getElementById('file-preview');
    const previewContainer = document.querySelector('.preview-container');
    const fileInfoElement = document.querySelector('.file-info');
    const removeFileBtn = document.getElementById('remove-file');
    const submitButton = document.getElementById('submitButton');
    const notesInput = document.getElementById('notes');
    
    // Fungsi untuk mencegah default behavior
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    // Inisialisasi events jika semua elemen ditemukan
    if (dropArea && fileInput) {
        // Browse button click
        if (browseBtn) {
            browseBtn.addEventListener('click', () => {
                fileInput.click();
            });
        }
        
        // Drag & drop events
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, preventDefaults, false);
        });
        
        // Highlight drop area on drag events
        ['dragenter', 'dragover'].forEach(eventName => {
            dropArea.addEventListener(eventName, () => {
                dropArea.classList.add('highlight');
                const uploadMessage = dropArea.querySelector('.upload-message');
                if (uploadMessage) uploadMessage.classList.add('pulse');
            });
        });
        
        // Remove highlight on drag leave/drop
        ['dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, () => {
                dropArea.classList.remove('highlight');
                const uploadMessage = dropArea.querySelector('.upload-message');
                if (uploadMessage) uploadMessage.classList.remove('pulse');
            });
        });
        
        // Handle dropped files
        dropArea.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            
            if (files.length) {
                handleFile(files[0]);
            }
        });
        
        // Handle file selection via input
        fileInput.addEventListener('change', () => {
            if (fileInput.files.length) {
                handleFile(fileInput.files[0]);
            }
        });
        
        // Remove file button
        if (removeFileBtn) {
            removeFileBtn.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent triggering dropArea click
                resetFileUpload();
            });
        }
        
        // Handle file preview and validation
        function handleFile(file) {
            // Validasi tipe file
            const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
            const fileExtension = file.name.split('.').pop().toLowerCase();
            
            if (!validTypes.includes(file.type) && !['jpg', 'jpeg', 'png', 'pdf'].includes(fileExtension)) {
                showError('Format file tidak didukung. Gunakan JPG, JPEG, PNG, atau PDF.');
                return;
            }
            
            // Validasi ukuran file (maks 5MB)
            const maxSize = 5 * 1024 * 1024; // 5MB
            if (file.size > maxSize) {
                showError('Ukuran file terlalu besar. Maksimum 5MB.');
                return;
            }
            
            // Show file preview
            showFilePreview(file);
            
            // Enable submit button
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.classList.add('btn-pulse'); // Tambahkan efek pulse ke button
                setTimeout(() => submitButton.classList.remove('btn-pulse'), 1500);
            }
        }
        
        // Show file preview based on file type
        function showFilePreview(file) {
            // Show preview container
            if (filePreview) {
                filePreview.classList.remove('d-none');
            }
            
            // Display file info
            const fileSize = formatFileSize(file.size);
            if (fileInfoElement) {
                fileInfoElement.innerHTML = `
                    <div class="file-name">${file.name}</div>
                    <div class="file-size">${fileSize}</div>
                `;
            }
            
            // Generate preview
            if (previewContainer) {
                previewContainer.innerHTML = '';
                
                if (file.type.startsWith('image/')) {
                    const img = document.createElement('img');
                    img.classList.add('img-preview');
                    previewContainer.appendChild(img);
                    
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        img.src = e.target.result;
                        img.alt = file.name;
                    };
                    reader.readAsDataURL(file);
                } else if (file.type === 'application/pdf') {
                    const icon = document.createElement('div');
                    icon.classList.add('pdf-preview');
                    icon.innerHTML = '<i class="fas fa-file-pdf"></i>'; 
                    previewContainer.appendChild(icon);
                }
                
                // Animate preview appearance
                setTimeout(() => {
                    previewContainer.classList.add('preview-show');
                }, 50);
            }
        }
        
        // Format file size for display
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
        
        // Reset file upload
        function resetFileUpload() {
            fileInput.value = '';
            if (filePreview) filePreview.classList.add('d-none');
            if (previewContainer) previewContainer.innerHTML = '';
            if (fileInfoElement) fileInfoElement.innerHTML = '';
            
            if (submitButton) {
                submitButton.disabled = true;
            }
        }
        
        // Show error message
        function showError(message) {
            // Create error toast
            const toast = document.createElement('div');
            toast.className = 'payment-error-toast';
            toast.innerHTML = `
                <div class="payment-error-icon">
                    <i class="fas fa-exclamation-circle"></i>
                </div>
                <div class="payment-error-message">${message}</div>
            `;
            
            // Add to document
            document.body.appendChild(toast);
            
            // Show with animation
            setTimeout(() => toast.classList.add('show'), 10);
            
            // Remove after timeout
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }
        
        function showErrorAlert(title, message) {
            const alertContainer = document.getElementById('alert-container');
            
            const alert = document.createElement('div');
            alert.className = 'payment-alert error';
            alert.innerHTML = `
                <div class="alert-icon">
                    <i class="fa fa-exclamation-circle"></i>
                </div>
                <div class="alert-content">
                    <div class="alert-title">${title}</div>
                    <div class="alert-message">${message}</div>
                </div>
            `;
            
            // Clear previous alerts
            alertContainer.innerHTML = '';
            alertContainer.appendChild(alert);
            
            // Auto hide after 5 seconds
            setTimeout(() => {
                alert.style.opacity = '0';
                setTimeout(() => {
                    alert.remove();
                }, 300);
            }, 5000);
        }
        
        // Format file size
        function formatFileSize(bytes) {
            if (bytes < 1024) {
                return bytes + ' bytes';
            } else if (bytes < 1024 * 1024) {
                return (bytes / 1024).toFixed(2) + ' KB';
            } else {
                return (bytes / 1024 / 1024).toFixed(2) + ' MB';
            }
        }
    }
    
    // Copy account number
    const copyButtons = document.querySelectorAll('.copy-button');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const textToCopy = this.getAttribute('data-copy');
            const textarea = document.createElement('textarea');
            textarea.value = textToCopy;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            
            // Show copied notification
            const originalText = this.textContent;
            this.textContent = 'Tersalin!';
            button.classList.add('copied');
            
            setTimeout(() => {
                this.textContent = originalText;
                button.classList.remove('copied');
            }, 2000);
        });
    });
    
    // Form submission confirmation
    const paymentForm = document.getElementById('payment-form');
    if (paymentForm) {
        paymentForm.addEventListener('submit', function(e) {
            if (!fileInput.value) {
                e.preventDefault();
                showErrorAlert('File belum dipilih', 'Silakan pilih bukti pembayaran terlebih dahulu.');
                return;
            }
            
            if (!confirm('Apakah Anda yakin ingin mengirim bukti pembayaran ini?')) {
                e.preventDefault();
            }
        });
    }
});

