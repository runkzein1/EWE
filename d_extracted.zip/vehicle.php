<?php
/**
 * Detail Kendaraan
 */

// Buffer output untuk mencegah headers already sent error
ob_start();

// Include performance optimizer
require_once 'config/performance-optimizer.php';

// Aktifkan error reporting dan logging untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1); // Aktifkan sementara untuk debugging
ini_set('display_startup_errors', 1);
ini_set('display_errors', 0); // Set ke 0 di production

// Set PHP execution time limit yang sangat ketat
set_time_limit(10); // Ditingkatkan sedikit untuk memberikan waktu memuat halaman
ini_set('max_execution_time', 10);

// Pengaturan memori dan koneksi
ini_set('memory_limit', '64M');
ini_set('default_socket_timeout', 5);

// Include configuration, database connection and functions
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Atur timeout untuk mencegah loading berulang
set_time_limit(10);
ini_set('max_execution_time', 10);

// Auto redirect jika loading terlalu lama
header("Refresh: 15;url=error.php?reason=timeout&page=vehicle");

// Flag untuk menggunakan style modern 2025
$use_modern_2025 = true;

// Set error handler tersendiri untuk halaman ini
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    // Log error
    error_log("Error di vehicle.php: [$errno] $errstr in $errfile on line $errline");
    // Redirect ke halaman yang aman
    header("Location: error.php?reason=" . urlencode("Terjadi kesalahan saat memuat data kendaraan"));
    exit();
});

$error = '';
$success = '';
$vehicle = [];

// Check if vehicle ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: auctions.php");
    exit;
}

$vehicle_id = intval($_GET['id']);

try {
    // DISABLE STRICT MODE untuk memastikan query berjalan tanpa error
    $conn->query("SET sql_mode=''");

    // Set timeout sangat singkat untuk query
    $conn->options(MYSQLI_OPT_CONNECT_TIMEOUT, 2);

    // Query untuk dapatkan data kendaraan dengan optimasi untuk desktop
    $vehicle_query = "SELECT v.*, u.username, u.user_id as seller_id, COUNT(b.bid_id) as bid_count,
                       MAX(b.bid_amount) as highest_bid
               FROM vehicles v
               LEFT JOIN users u ON v.seller_id = u.user_id
               LEFT JOIN bids b ON v.vehicle_id = b.vehicle_id
               WHERE v.vehicle_id = ?
               GROUP BY v.vehicle_id";

    // Gunakan cache untuk query vehicle detail (sangat efektif untuk desktop)
    $vehicle_cache_key = 'vehicle_' . $vehicle_id;
    $vehicle_result = db_get_cached($conn, $vehicle_query, [$vehicle_id], 'i');

    // Cek hasil cache
    if (!isset($vehicle_result['error']) && isset($vehicle_result['data']) && count($vehicle_result['data']) > 0) {
        // Gunakan data dari cache
        $vehicle_data = $vehicle_result['data'][0];
        $execution_time = $vehicle_result['execution_time']; // Untuk logging performa

        // Log performa jika ada
        if (isset($_GET['debug'])) {
            error_log("Vehicle query served from cache in {$execution_time}s");
        }
    } else {
        // Fallback ke query langsung jika cache gagal
        // Prepare statement dengan timeout lebih singkat
        $timeout_start = microtime(true);
        $vehicle_stmt = $conn->prepare($vehicle_query);

        if (!$vehicle_stmt) {
            throw new Exception("Prepare statement error: " . $conn->error);
        }

        // Binding parameter
        $vehicle_stmt->bind_param("i", $vehicle_id);

        // Execute dengan timeout check
        try {
            $execute_success = $vehicle_stmt->execute();

            // Cek eksekusi timeout atau gagal
            if (!$execute_success || (microtime(true) - $timeout_start) > 3) {
                throw new Exception("Database operation timeout or failed: " . $vehicle_stmt->error);
            }

            $result = $vehicle_stmt->get_result();
            if (!$result) {
                throw new Exception("Error getting result set: " . $vehicle_stmt->error);
            }

            $vehicle_data = $result->fetch_assoc();
            if (!$vehicle_data) {
                throw new Exception("Vehicle data not found");
            }
        } catch (Exception $e) {
            error_log("Error in vehicle query execution: " . $e->getMessage());
            throw $e; // Re-throw untuk ditangani oleh handler di atas
        }
    }

    if ($vehicle_data) {
        $vehicle = $vehicle_data;
    } else {
        header("Location: auctions.php?error=vehicle_not_found");
        exit;
    }

    // Close statement
    $stmt->close();

} catch (Throwable $e) {
    error_log("Error in vehicle.php: " . $e->getMessage());
    echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="alert alert-danger">
            <h3>Error</h3>
            <p>Maaf, terjadi kesalahan saat memuat detail kendaraan: ' . htmlspecialchars($e->getMessage()) . '</p>
            <a href="index.php" class="btn btn-primary">Kembali ke Beranda</a>
        </div>
    </div>
</body>
</html>';
    exit;
}

// Include header
include_once 'includes/header.php';

// Format harga dan tanggal
$starting_price = isset($vehicle['starting_price']) ? number_format($vehicle['starting_price'], 0, ',', '.') : 0;
$current_bid = isset($vehicle['current_bid']) ? number_format($vehicle['current_bid'], 0, ',', '.') : 0;
$auction_end = isset($vehicle['auction_end']) ? date('Y-m-d H:i:s', strtotime($vehicle['auction_end'])) : date('Y-m-d H:i:s', strtotime('+7 days'));

// Cek apakah lelang sudah berakhir
$auction_ended = false;
if ($auction_end) {
    $auction_ended = strtotime($auction_end) < time();
}

// Hitung waktu tersisa
$days_left = 0;
$hours_left = 0;
$minutes_left = 0;
$seconds_left = 0;
$total_seconds = 0;

if ($auction_end && !$auction_ended) {
    $seconds_remaining = strtotime($auction_end) - time();
    $total_seconds = $seconds_remaining;

    $days_left = floor($seconds_remaining / 86400);
    $seconds_remaining = $seconds_remaining % 86400;

    $hours_left = floor($seconds_remaining / 3600);
    $seconds_remaining = $seconds_remaining % 3600;

    $minutes_left = floor($seconds_remaining / 60);
    $seconds_left = $seconds_remaining % 60;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($vehicle['make'] . ' ' . $vehicle['model']); ?> - LelangMobil</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <?php if ($use_modern_2025): ?>
    <!-- Modern 2025 Styling -->
    <link rel="stylesheet" href="css/modern-2025.css">
    <link rel="stylesheet" href="css/vehicle-modern-2025.css">
    <?php endif; ?>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include_once 'includes/header.php'; ?>

    <div class="container mt-4" id="vehicle-container" data-vehicle-id="<?php echo htmlspecialchars($vehicle['id']); ?>">
        <div class="row">
            <div class="col-12">
                <!-- Vehicle Detail Container - Modern 2025 Version -->
                <div class="card shadow-sm modern-card-2025">
                <div class="card-header">
                    <h2 class="card-title"><?php echo htmlspecialchars($vehicle['make'] . ' ' . $vehicle['model']); ?></h2>
                    <div class="badge bg-<?php echo ($vehicle['status'] == 'active') ? 'success' : 'secondary'; ?>">
                        <?php echo htmlspecialchars(ucfirst($vehicle['status'])); ?>
                    </div>
                </div>

                <div class="card-body">
                    <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-6">
                            <!-- Vehicle Images - Modern 2025 Gallery -->
                            <div class="vehicle-gallery-container-2025 fade-in-up">
                                <div class="vehicle-banner-2025">
                                    <img src="<?php echo isset($vehicle['image']) && !empty($vehicle['image']) ? htmlspecialchars('uploads/vehicles/' . $vehicle['image']) : 'assets/img/no-image.svg'; ?>"
                                         class="img-fluid"
                                         alt="<?php echo htmlspecialchars($vehicle['make'] . ' ' . $vehicle['model']); ?>"
                                         onerror="this.src='assets/img/no-image.svg';">

                                    <?php if ($vehicle['status'] == 'active' && !$auction_ended): ?>
                                    <div class="banner-auction-status active">
                                        <i class="fas fa-gavel"></i> Lelang Aktif
                                    </div>
                                    <?php elseif ($auction_ended): ?>
                                    <div class="banner-auction-status ended">
                                        <i class="fas fa-flag-checkered"></i> Lelang Selesai
                                    </div>
                                    <?php else: ?>
                                    <div class="banner-auction-status inactive">
                                        <i class="fas fa-pause-circle"></i> Lelang Tidak Aktif
                                    </div>
                                    <?php endif; ?>
                                </div>

                                <div class="vehicle-thumbnails-2025">
                                    <!-- Main Image as First Thumbnail -->
                                    <div class="gallery-item active">
                                        <img src="<?php echo isset($vehicle['image']) && !empty($vehicle['image']) ? htmlspecialchars('uploads/vehicles/' . $vehicle['image']) : 'assets/img/no-image-thumb.svg'; ?>"
                                             alt="Thumbnail 1"
                                             onerror="this.src='assets/img/no-image-thumb.svg';">
                                    </div>

                                    <?php
                                    // Additional images would be here
                                    // For example, loop through additional images if they exist
                                    for ($i = 2; $i <= 4; $i++):
                                        // This is just a placeholder, in a real app you'd query additional images
                                        $additionalImageField = 'additional_image_' . ($i-1);
                                        $hasAdditionalImage = isset($vehicle[$additionalImageField]) && !empty($vehicle[$additionalImageField]);
                                    ?>
                                    <div class="gallery-item">
                                        <img src="<?php echo $hasAdditionalImage ? htmlspecialchars('uploads/vehicles/' . $vehicle[$additionalImageField]) : 'assets/img/no-image-thumb.svg'; ?>"
                                             alt="Thumbnail <?php echo $i; ?>"
                                             onerror="this.src='assets/img/no-image-thumb.svg';">
                                    </div>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <div class="specifications-card-2025 mb-4 fade-in-up">
                                <div class="specifications-header">
                                    <h3><i class="fas fa-car-side"></i> Spesifikasi Kendaraan</h3>
                                </div>
                                <div class="specifications-body">
                                    <div class="spec-items-grid">
                                        <div class="spec-item">
                                            <div class="spec-icon"><i class="fas fa-tag"></i></div>
                                            <div class="spec-details">
                                                <span class="spec-label">Merk</span>
                                                <span class="spec-value"><?php echo htmlspecialchars($vehicle['make']); ?></span>
                                            </div>
                                        </div>

                                        <div class="spec-item">
                                            <div class="spec-icon"><i class="fas fa-car"></i></div>
                                            <div class="spec-details">
                                                <span class="spec-label">Model</span>
                                                <span class="spec-value"><?php echo htmlspecialchars($vehicle['model']); ?></span>
                                            </div>
                                        </div>

                                        <div class="spec-item">
                                            <div class="spec-icon"><i class="fas fa-calendar-alt"></i></div>
                                            <div class="spec-details">
                                                <span class="spec-label">Tahun</span>
                                                <span class="spec-value"><?php echo htmlspecialchars($vehicle['year']); ?></span>
                                            </div>
                                        </div>

                                        <div class="spec-item">
                                            <div class="spec-icon"><i class="fas fa-tachometer-alt"></i></div>
                                            <div class="spec-details">
                                                <span class="spec-label">Kilometer</span>
                                                <span class="spec-value"><?php echo isset($vehicle['mileage']) ? htmlspecialchars(number_format($vehicle['mileage'], 0, ',', '.')) . ' km' : 'Tidak tersedia'; ?></span>
                                            </div>
                                        </div>

                                        <div class="spec-item">
                                            <div class="spec-icon"><i class="fas fa-cogs"></i></div>
                                            <div class="spec-details">
                                                <span class="spec-label">Transmisi</span>
                                                <span class="spec-value"><?php echo isset($vehicle['transmission']) ? htmlspecialchars(ucfirst($vehicle['transmission'])) : 'Tidak tersedia'; ?></span>
                                            </div>
                                        </div>

                                        <div class="spec-item">
                                            <div class="spec-icon"><i class="fas fa-gas-pump"></i></div>
                                            <div class="spec-details">
                                                <span class="spec-label">Bahan Bakar</span>
                                                <span class="spec-value"><?php echo isset($vehicle['fuel_type']) ? htmlspecialchars(ucfirst($vehicle['fuel_type'])) : 'Tidak tersedia'; ?></span>
                                            </div>
                                        </div>

                                        <div class="spec-item">
                                            <div class="spec-icon"><i class="fas fa-palette"></i></div>
                                            <div class="spec-details">
                                                <span class="spec-label">Warna</span>
                                                <span class="spec-value"><?php echo isset($vehicle['color']) ? htmlspecialchars(ucfirst($vehicle['color'])) : 'Tidak tersedia'; ?></span>
                                            </div>
                                        </div>

                                        <?php if (isset($vehicle['engine_size']) && !empty($vehicle['engine_size'])): ?>
                                        <div class="spec-item">
                                            <div class="spec-icon"><i class="fas fa-bolt"></i></div>
                                            <div class="spec-details">
                                                <span class="spec-label">Kapasitas Mesin</span>
                                                <span class="spec-value"><?php echo htmlspecialchars($vehicle['engine_size']); ?> cc</span>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <!-- Info Lelang -->
                            <div class="card mb-3">
                                <div class="card-header">Detail Lelang</div>
                                <div class="card-body">
                                    <p><strong>Harga Awal:</strong> Rp <?php echo $starting_price; ?></p>
                                    <p><strong>Penawaran Tertinggi:</strong> Rp <?php echo $current_bid; ?></p>

                                    <?php if ($vehicle['status'] == 'active' && !$auction_ended): ?>
                                        <!-- Countdown Timer - Modern 2025 Style -->
                                        <div class="mb-4">
                                            <div class="auction-status-wrapper">
                                                <span id="auction-status" class="auction-status auction-status-active">
                                                    <?php echo ($total_seconds < 86400) ? 'Segera Berakhir' : 'Lelang Aktif'; ?>
                                                </span>
                                            </div>
                                            <div id="auction-countdown" class="countdown-timer-2025" data-end-time="<?php echo htmlspecialchars($auction_end); ?>">
                                                <div class="countdown-block">
                                                    <span id="days" class="countdown-value"><?php echo str_pad($days_left, 2, '0', STR_PAD_LEFT); ?></span>
                                                    <span class="countdown-label">Hari</span>
                                                </div>
                                                <div class="countdown-block">
                                                    <span id="hours" class="countdown-value"><?php echo str_pad($hours_left, 2, '0', STR_PAD_LEFT); ?></span>
                                                    <span class="countdown-label">Jam</span>
                                                </div>
                                                <div class="countdown-block">
                                                    <span id="minutes" class="countdown-value"><?php echo str_pad($minutes_left, 2, '0', STR_PAD_LEFT); ?></span>
                                                    <span class="countdown-label">Menit</span>
                                                </div>
                                                <div class="countdown-block">
                                                    <span id="seconds" class="countdown-value"><?php echo str_pad($seconds_left, 2, '0', STR_PAD_LEFT); ?></span>
                                                    <span class="countdown-label">Detik</span>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Form Bid - Modern 2025 Style -->
                                        <?php if (isset($_SESSION['user_id'])): ?>
                                            <div class="bid-form-wrapper-2025 fade-in-up">
                                                <h3 class="bid-form-title">Pasang Bid</h3>
                                                <form action="" method="post" id="bid-form" data-min-increment="100000">
                                                    <div class="mb-4">
                                                        <div class="current-price-wrapper">
                                                            <h4>Harga Saat Ini</h4>
                                                            <div id="current-price" class="current-price" data-price="<?php echo htmlspecialchars(str_replace('.', '', $current_bid)); ?>">
                                                                Rp <?php echo htmlspecialchars($current_bid); ?>
                                                            </div>
                                                        </div>

                                                        <div class="bid-suggestions-wrapper">
                                                            <div class="bid-suggestions-label">Bid Cepat</div>
                                                            <div class="bid-suggestions">
                                                                <?php
                                                                // Parse current bid to integer
                                                                $current_bid_int = (int) str_replace('.', '', $current_bid);
                                                                $suggestions = [
                                                                    $current_bid_int + 100000,
                                                                    $current_bid_int + 500000,
                                                                    $current_bid_int + 1000000
                                                                ];

                                                                foreach ($suggestions as $index => $suggestion):
                                                                ?>
                                                                <div class="bid-suggestion" data-amount="<?php echo number_format($suggestion, 0, ',', '.'); ?>">
                                                                    <span class="suggestion-label">+<?php echo ($index === 0) ? '100rb' : (($index === 1) ? '500rb' : '1jt'); ?></span>
                                                                    <span class="suggestion-amount">Rp <?php echo number_format($suggestion, 0, ',', '.'); ?></span>
                                                                </div>
                                                                <?php endforeach; ?>
                                                            </div>
                                                        </div>

                                                        <label for="bid_amount" class="form-label bid-label">Masukkan Jumlah Bid</label>
                                                        <div class="input-group bid-input-group">
                                                            <span class="input-group-text">Rp</span>
                                                            <input type="text" name="bid_amount" id="bid_amount"
                                                                   class="form-control bid-input"
                                                                   placeholder="0"
                                                                   required>
                                                        </div>
                                                        <small class="text-muted bid-hint">Kenaikan minimal Rp 100.000</small>
                                                    </div>
                                                    <button type="submit" name="place_bid" class="btn btn-primary btn-bid w-100">Pasang Bid</button>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <div class="login-prompt-2025 fade-in-up">
                                                <div class="login-prompt-icon">
                                                    <i class="fa-solid fa-lock"></i>
                                                </div>
                                                <div class="login-prompt-text">
                                                    <h4>Masuk untuk Lelang</h4>
                                                    <p>Silakan <a href="login.php" class="login-link">login</a> untuk memasang bid pada kendaraan ini.</p>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <div class="auction-ended-notice-2025 fade-in-up">
                                            <div class="notice-icon">
                                                <i class="fas fa-flag-checkered"></i>
                                            </div>
                                            <div class="notice-text">
                                                <h4>Lelang Telah Berakhir</h4>
                                                <p>Lelang untuk kendaraan ini telah berakhir atau tidak aktif.</p>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-6">
                            <!-- Vehicle Description - Modern 2025 Style -->
                            <div class="description-card-2025 mb-4 fade-in-up">
                                <div class="description-header">
                                    <h3><i class="fas fa-align-left"></i> Deskripsi Kendaraan</h3>
                                </div>
                                <div class="description-body">
                                    <?php if (isset($vehicle['description']) && !empty($vehicle['description'])): ?>
                                        <div class="vehicle-description">
                                            <?php echo nl2br(htmlspecialchars($vehicle['description'])); ?>
                                        </div>
                                    <?php else: ?>
                                        <p class="no-description">Tidak ada deskripsi untuk kendaraan ini.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <!-- Bid History - Modern 2025 Style -->
                            <div class="bid-history-card-2025 mb-4 fade-in-up">
                                <div class="bid-history-header">
                                    <h3><i class="fas fa-history"></i> Riwayat Bid</h3>
                                </div>
                                <div class="bid-history-body">
                                    <?php
                                    // Get bid history
                                    try {
                                        $bid_query = "SELECT b.*, u.username
                                                    FROM bids b
                                                    JOIN users u ON b.user_id = u.id
                                                    WHERE b.vehicle_id = ?
                                                    ORDER BY b.created_at DESC
                                                    LIMIT 10";
                                        $bid_stmt = $mysqli->prepare($bid_query);
                                        $bid_stmt->bind_param("i", $_GET['id']);
                                        $bid_stmt->execute();
                                        $bid_result = $bid_stmt->get_result();

                                        if ($bid_result && $bid_result->num_rows > 0) {
                                            // Display bid history
                                            echo '<div class="table-responsive">';
                                            echo '<table class="table bid-history-table">';
                                            echo '<thead><tr><th>Bidder</th><th>Jumlah Bid</th><th>Tanggal</th></tr></thead>';
                                            echo '<tbody>';

                                            while ($bid = $bid_result->fetch_assoc()) {
                                                echo '<tr>';
                                                echo '<td>' . htmlspecialchars($bid['username']) . '</td>';
                                                echo '<td>Rp ' . number_format($bid['amount'], 0, ',', '.') . '</td>';
                                                echo '<td>' . date('d/m/Y H:i', strtotime($bid['created_at'])) . '</td>';
                                                echo '</tr>';
                                            }

                                            echo '</tbody>';
                                            echo '</table>';
                                            echo '</div>';
                                        } else {
                                            echo '<div class="no-bids-message">';
                                            echo '<i class="fas fa-info-circle"></i>';
                                            echo '<p>Belum ada bid untuk kendaraan ini</p>';
                                            echo '</div>';
                                        }

                                        $bid_stmt->close();
                                    } catch (Exception $e) {
                                        error_log("Error getting bid history: " . $e->getMessage());
                                        echo '<div class="alert alert-warning">Gagal memuat riwayat bid</div>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Toast Container for notifications -->
<div class="toast-container"></div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

<?php if ($use_modern_2025): ?>
<!-- Modern 2025 JS -->
<script src="js/modern-2025.js"></script>
<script src="js/notification-system-2025.js"></script>
<script src="js/vehicle-auction-2025.js"></script>
<?php else: ?>
<!-- Legacy countdown script for non-modern view -->
<script>
// Simple countdown script
var totalSeconds = <?php echo $total_seconds; ?>;
var auctionEnded = <?php echo $auction_ended ? 'true' : 'false'; ?>;

if (!auctionEnded && totalSeconds > 0) {
    var countdownInterval = setInterval(function() {
        if (totalSeconds <= 0) {
            clearInterval(countdownInterval);
            document.getElementById('days').textContent = '00';
            document.getElementById('hours').textContent = '00';
            document.getElementById('minutes').textContent = '00';
            document.getElementById('seconds').textContent = '00';
            return;
        }

        totalSeconds--;

        var days = Math.floor(totalSeconds / 86400);
        var remainder = totalSeconds % 86400;

        var hours = Math.floor(remainder / 3600);
        remainder = remainder % 3600;

        var minutes = Math.floor(remainder / 60);
        var seconds = remainder % 60;

        document.getElementById('days').textContent = String(days).padStart(2, '0');
        document.getElementById('hours').textContent = String(hours).padStart(2, '0');
        document.getElementById('minutes').textContent = String(minutes).padStart(2, '0');
        document.getElementById('seconds').textContent = String(seconds).padStart(2, '0');
    }, 1000);
}
</script>
<?php endif; ?>

<?php include_once 'includes/footer.php'; ?>
<?php
// Flush output buffer untuk menyelesaikan proses
if (ob_get_length()) ob_end_flush();
?>
