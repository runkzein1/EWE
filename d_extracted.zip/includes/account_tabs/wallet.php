<?php
// Ensure this file is included by account.php and has access to $db, $user_id, $user_wallet, $csrf_token

if (!defined('ROOT_PATH')) {
    die("Direct access not allowed.");
}

// Example: Fetch detailed wallet information if $user_wallet is just a summary
// $detailed_wallet_info = get_detailed_wallet_info($db, $user_id);

?>

<h4>My Wallet</h4>
<hr>

<div class="card bg-light mb-4">
    <div class="card-body">
        <h5 class="card-title">Current Balance</h5>
        <p class="card-text fs-3 fw-bold">
            <?php 
            // Assuming $user_wallet is an array or object with a 'balance' key
            // Format as currency - ensure you have a function for this or use number_format
            echo "Rp " . number_format($user_wallet['balance'] ?? 0, 2, ',', '.'); 
            ?>
        </p>
        <!-- Add last updated date if available -->
        <!-- <small class="text-muted">Last updated: <?php echo htmlspecialchars($user_wallet['last_updated'] ?? 'N/A'); ?></small> -->
    </div>
</div>

<div class="actions mb-4">
    <a href="<?php echo htmlspecialchars(BASE_URL . 'topup.php'); ?>" class="btn btn-success me-2">Top Up Balance</a>
    <a href="<?php echo htmlspecialchars(BASE_URL . 'withdraw.php'); ?>" class="btn btn-warning">Withdraw Funds</a>
    <!-- Add more actions as needed, e.g., transaction history specific to wallet -->
</div>

<h5>Wallet Activity</h5>
<p class="text-muted">Recent transactions related to your wallet.</p>
<?php
// You would typically fetch and display wallet-specific transactions here
// For example, using a function like: get_wallet_transactions($db, $user_id, 5);
// For now, we filter the general $user_transactions array if it exists.
$wallet_transactions_found = false;
if (isset($user_transactions) && !empty($user_transactions)):
?>
<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Amount</th>
                <th>Type</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($user_transactions as $transaction): ?>
                <?php 
                // Define wallet-related transaction types
                $wallet_related_types = ['deposit', 'withdrawal', 'topup', 'refund', 'bonus']; // Add more as needed
                if (in_array(strtolower($transaction['type']), $wallet_related_types)): 
                    $wallet_transactions_found = true;
                ?>
                <tr>
                    <td><?php echo htmlspecialchars(date("d M Y, H:i", strtotime($transaction['transaction_date']))); ?></td>
                    <td><?php echo htmlspecialchars($transaction['description']); ?></td>
                    <td class="<?php echo (in_array(strtolower($transaction['type']), ['deposit', 'topup', 'refund', 'bonus'])) ? 'text-success' : 'text-danger'; ?>">
                        <?php echo "Rp " . number_format($transaction['amount'], 2, ',', '.'); ?>
                    </td>
                    <td><?php echo htmlspecialchars(ucfirst($transaction['type'])); ?></td>
                </tr>
                <?php endif; ?>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php 
    if (!$wallet_transactions_found) {
        echo "<p>No recent wallet-specific activity found in your general transactions.</p>";
    }
?>
<?php else: ?>
<p>No transaction data available to display wallet activity.</p>
<?php endif; ?>

<!-- You might want to link to a full wallet transaction history page -->
<div class="mt-3">
    <a href="<?php echo htmlspecialchars(BASE_URL . 'account.php?tab=transactions&filter=wallet'); ?>">View All Wallet Transactions</a>
</div>
