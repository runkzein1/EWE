<?php
/**
 * Session Helper Utility
 * LelangMobil Web App - Versi 2025
 * 
 * This file contains functions for reliable session management
 * Version: 1.0
 */

/**
 * Safely starts a session with proper configuration
 * @return bool True if session started successfully
 */
function ensure_session_started() {
    if (session_status() == PHP_SESSION_NONE && !headers_sent()) {
        // Configure session for better security
        $currentCookieParams = session_get_cookie_params();        session_set_cookie_params([
            'lifetime' => 86400,  // 24 hours
            'path' => '/',
            'domain' => '',
            'secure' => true, // Enforce HTTPS in production
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        
        // Start the session
        return session_start();
    }
    
    return (session_status() == PHP_SESSION_ACTIVE);
}

/**
 * Regenerates the session ID to prevent session fixation
 * @param bool $delete_old_session Whether to delete the old session data
 * @return bool True if session ID was regenerated
 */
function regenerate_session_safely($delete_old_session = true) {
    if (session_status() == PHP_SESSION_ACTIVE) {
        // Only regenerate if headers haven't been sent
        if (!headers_sent()) {
            return session_regenerate_id($delete_old_session);
        } else {
            // Log inability to regenerate session due to headers already sent
            error_log('Cannot regenerate session ID - headers already sent');
            return false;
        }
    }
    return false;
}

/**
 * Validates if the current session is still valid
 * @param int $max_lifetime Maximum session lifetime in seconds (default 24 hours)
 * @return bool True if session is valid
 */
function is_session_valid($max_lifetime = 86400) {
    if (session_status() != PHP_SESSION_ACTIVE || !isset($_SESSION['last_activity'])) {
        return false;
    }
    
    // Check if the session has expired
    if (time() - $_SESSION['last_activity'] > $max_lifetime) {
        return false;
    }
    
    // Update last activity time
    $_SESSION['last_activity'] = time();
    return true;
}

/**
 * Safely destroys the current session
 * @return bool True if session was destroyed
 */
function destroy_session_safely() {
    if (session_status() == PHP_SESSION_ACTIVE) {
        // Clear session data
        $_SESSION = array();
        
        // If a session cookie is used, delete it
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        // Destroy the session
        return session_destroy();
    }
    return true;
}

/**
 * Creates a new secure CSRF token and stores it in the session
 * @return string The generated CSRF token
 */
function generate_secure_csrf_token() {
    // Ensure session is started
    ensure_session_started();
    
    try {
        // Generate a new token using cryptographically secure function
        $token = bin2hex(random_bytes(32));
    } catch (Exception $e) {
        // Fallback if random_bytes fails
        $token = md5(uniqid(mt_rand(), true) . session_id() . time());
        error_log("CSRF token generation used fallback method: " . $e->getMessage());
    }
    
    // Store the token in session
    $_SESSION['csrf_token'] = $token;
    $_SESSION['csrf_token_time'] = time();
    
    return $token;
}

/**
 * Verifies if a given token matches the stored CSRF token
 * @param string $token The token to verify
 * @param bool $regenerate Whether to regenerate token after verification
 * @return bool True if token is valid
 */
function verify_secure_csrf_token($token, $regenerate = false) {
    // Ensure session is started
    ensure_session_started();
    
    // Basic validation
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    
    // Compare tokens
    $valid = hash_equals($_SESSION['csrf_token'], $token);
    
    // Regenerate token if requested and valid
    if ($valid && $regenerate) {
        generate_secure_csrf_token();
    }
    
    return $valid;
}

/**
 * Gets the current stored CSRF token or generates a new one
 * @return string The CSRF token
 */
function get_csrf_token() {
    // Ensure session is started
    ensure_session_started();
    
    // Generate token if it doesn't exist or is expired (1 hour)
    if (!isset($_SESSION['csrf_token']) || 
        !isset($_SESSION['csrf_token_time']) || 
        (time() - $_SESSION['csrf_token_time'] > 3600)) {
        return generate_secure_csrf_token();
    }
    
    return $_SESSION['csrf_token'];
}

/**
 * Generates an HTML hidden input field with CSRF token
 * @return string HTML for CSRF token input field
 */
function csrf_token_input_field() {
    $token = get_csrf_token();
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token) . '">';
}
