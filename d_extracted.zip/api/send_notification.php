<?php
/**
 * Send Notification API
 * Digunakan untuk mengirim notifikasi ke pengguna tertentu
 * LelangMobil - Modern Web App 2025
 */

// Include database connection
require_once '../config/database.php';

// Set content type to JSON
header('Content-Type: application/json');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
    exit;
}

// Get POST data
$postData = json_decode(file_get_contents('php://input'), true);

// Verify required fields
if (!isset($postData['user_id']) || !isset($postData['type']) || !isset($postData['message'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Missing required fields'
    ]);
    exit;
}

// Extract data
$user_id = intval($postData['user_id']);
$type = $postData['type'];
$message = $postData['message'];
$url = isset($postData['url']) ? $postData['url'] : null;
$entity_type = isset($postData['entity_type']) ? $postData['entity_type'] : null;
$entity_id = isset($postData['entity_id']) ? intval($postData['entity_id']) : null;

// Check if the notifications table exists
$tableCheckResult = $conn->query("SHOW TABLES LIKE 'notifications'");
$tableExists = $tableCheckResult->num_rows > 0;

// Create table if it doesn't exist
if (!$tableExists) {
    $createTableSQL = "
    CREATE TABLE notifications (
        notification_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        type VARCHAR(50) NOT NULL,
        message TEXT NOT NULL,
        url VARCHAR(255) DEFAULT NULL,
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        read_at TIMESTAMP NULL DEFAULT NULL,
        entity_type VARCHAR(50) DEFAULT NULL,
        entity_id INT DEFAULT NULL,
        INDEX (user_id),
        INDEX (type),
        INDEX (is_read)
    )";
    
    if (!$conn->query($createTableSQL)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Failed to create notifications table: ' . $conn->error
        ]);
        exit;
    }
}

// Insert notification
$stmt = $conn->prepare("
    INSERT INTO notifications 
    (user_id, type, message, url, entity_type, entity_id) 
    VALUES (?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Preparation failed: ' . $conn->error
    ]);
    exit;
}

$stmt->bind_param("issssi", 
    $user_id, 
    $type, 
    $message, 
    $url, 
    $entity_type, 
    $entity_id
);

if ($stmt->execute()) {
    $notification_id = $stmt->insert_id;
    echo json_encode([
        'status' => 'success',
        'message' => 'Notification sent successfully',
        'notification_id' => $notification_id
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Failed to send notification: ' . $stmt->error
    ]);
}
?>
