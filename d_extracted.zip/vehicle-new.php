<?php
// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$error = '';
$success = '';

// Check if vehicle ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: auctions.php");
    exit;
}

$vehicle_id = intval($_GET['id']);

// Get vehicle information
$sql = "SELECT v.*, u.username as seller_username 
        FROM vehicles v 
        LEFT JOIN users u ON v.seller_id = u.user_id 
        WHERE v.vehicle_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $vehicle_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    header("Location: auctions.php");
    exit;
}

$vehicle = $result->fetch_assoc();

// Get vehicle images
$images_sql = "SELECT * FROM vehicle_images WHERE vehicle_id = ? ORDER BY is_main DESC";
$images_stmt = $conn->prepare($images_sql);
$images_stmt->bind_param("i", $vehicle_id);
$images_stmt->execute();
$images_result = $images_stmt->get_result();

// Get vehicle specifications
$specs_sql = "SELECT * FROM vehicle_specs WHERE vehicle_id = ? ORDER BY spec_id";
$specs_stmt = $conn->prepare($specs_sql);
$specs_stmt->bind_param("i", $vehicle_id);
$specs_stmt->execute();
$specs_result = $specs_stmt->get_result();

// Get bid history
$bids_sql = "SELECT b.*, u.username 
            FROM bids b
            LEFT JOIN users u ON b.bidder_id = u.user_id
            WHERE b.vehicle_id = ?
            ORDER BY b.bid_time DESC";
$bids_stmt = $conn->prepare($bids_sql);
$bids_stmt->bind_param("i", $vehicle_id);
$bids_stmt->execute();
$bids_result = $bids_stmt->get_result();

// Process bid submit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_bid'])) {
    if (!is_logged_in()) {
        $error = "Anda harus login untuk melakukan bid.";
    } else {
        $user_id = $_SESSION['user_id'];
        $bid_amount = isset($_POST['bid_amount']) ? filter_var($_POST['bid_amount'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION) : 0;
        
        if ($bid_amount <= 0) {
            $error = "Jumlah bid tidak valid.";
        } else if ($bid_amount <= $vehicle['current_bid']) {
            $error = "Bid Anda harus lebih tinggi dari bid tertinggi saat ini.";
        } else if ($bid_amount < $vehicle['starting_price']) {
            $error = "Bid Anda harus lebih tinggi dari harga awal.";
        } else {
            // Check if auction is still active
            if ($vehicle['status'] !== 'active') {
                $error = "Lelang sudah tidak aktif.";
            } else {
                // Check user balance
                $user_sql = "SELECT balance FROM users WHERE user_id = ?";
                $user_stmt = $conn->prepare($user_sql);
                $user_stmt->bind_param("i", $user_id);
                $user_stmt->execute();
                $user_result = $user_stmt->get_result();
                $user_data = $user_result->fetch_assoc();
                
                if ($user_data['balance'] < $bid_amount) {
                    $error = "Saldo Anda tidak mencukupi untuk melakukan bid ini.";
                } else {
                    // Place bid
                    $bid_sql = "INSERT INTO bids (vehicle_id, bidder_id, bid_amount, bid_time) VALUES (?, ?, ?, NOW())";
                    $bid_stmt = $conn->prepare($bid_sql);
                    $bid_stmt->bind_param("iid", $vehicle_id, $user_id, $bid_amount);
                    
                    if ($bid_stmt->execute()) {
                        // Update current bid for vehicle
                        $update_sql = "UPDATE vehicles SET current_bid = ? WHERE vehicle_id = ?";
                        $update_stmt = $conn->prepare($update_sql);
                        $update_stmt->bind_param("di", $bid_amount, $vehicle_id);
                        $update_stmt->execute();
                        
                        // Create transaction for bid hold
                        $transaction_sql = "INSERT INTO transactions (user_id, amount, type, status, notes, created_at) 
                                           VALUES (?, ?, 'bid_hold', 'completed', ?, NOW())";
                        $transaction_stmt = $conn->prepare($transaction_sql);
                        $notes = "Bid hold untuk kendaraan ID #" . $vehicle_id;
                        $transaction_stmt->bind_param("ids", $user_id, $bid_amount, $notes);
                        $transaction_stmt->execute();
                        
                        $success = "Bid Anda berhasil diajukan!";
                        
                        // Refresh page to show updated bid
                        header("Location: vehicle.php?id=" . $vehicle_id . "&success=bid_placed");
                        exit;
                    } else {
                        $error = "Terjadi kesalahan saat mengajukan bid.";
                    }
                }
            }
        }
    }
}

// Get success message from URL if exists
if (isset($_GET['success']) && $_GET['success'] === 'bid_placed') {
    $success = "Bid Anda berhasil diajukan!";
}

// Determine auction status
if (!isset($vehicle['status']) || empty($vehicle['status'])) {
    if (strtotime($vehicle['auction_end']) < time()) {
        $vehicle['status'] = 'ended';
    } else {
        $vehicle['status'] = 'active';
    }
}

// Calculate time left
$now = new DateTime();
$end_date = new DateTime($vehicle['auction_end']);
$interval = $now->diff($end_date);
$days_left = $interval->days;
$hours_left = $interval->h;
$minutes_left = $interval->i;
$seconds_left = $interval->s;
$total_seconds = $days_left * 86400 + $hours_left * 3600 + $minutes_left * 60 + $seconds_left;
$auction_ended = $now > $end_date;

// Calculate auction progress
$start_date = new DateTime($vehicle['auction_start']);
$total_duration = $start_date->diff($end_date);
$total_seconds_duration = $total_duration->days * 86400 + $total_duration->h * 3600 + $total_duration->i * 60 + $total_duration->s;
$elapsed_seconds = $total_seconds_duration - $total_seconds;
$progress_percentage = min(100, max(0, ($elapsed_seconds / $total_seconds_duration) * 100));

$page_title = $vehicle['title'] . " - LelangMobil";
?>

<?php include 'includes/header.php'; ?>

<!-- Link stylesheet vehicle ultra modern -->
<link rel="stylesheet" href="css/modern-vehicle.css">
<link rel="stylesheet" href="css/vehicle-animations.css">
<link rel="stylesheet" href="css/ultra-modern-vehicle.css">

<!-- Script vehicle-animations.js sudah menangani aktivasi tema modern -->

<div id="top"></div>
<!-- Ultra Hero Vehicle Section -->
<section id="vehicle-hero" class="ultra-hero fade-in">
    <img src="<?php echo !empty($vehicle['image_main']) ? 'uploads/vehicles/'.$vehicle['image_main'] : 'images/background/2.jpg'; ?>" class="ultra-hero-img" alt="<?php echo $vehicle['title']; ?>">
    <div class="ultra-hero-content">
        <div class="ultra-container">
            <div class="ultra-badge-container">
                <div class="ultra-badge ultra-badge-primary"><i class="fa fa-tag"></i> Lot #<?php echo str_pad($vehicle['vehicle_id'], 5, '0', STR_PAD_LEFT); ?></div>
                <?php if ($vehicle['status'] == 'active'): ?>
                    <div class="ultra-badge ultra-badge-active"><i class="fa fa-gavel"></i> Sedang Berlangsung</div>
                <?php elseif ($vehicle['status'] == 'upcoming'): ?>
                    <div class="ultra-badge ultra-badge-upcoming"><i class="fa fa-clock"></i> Akan Datang</div>
                <?php elseif ($vehicle['status'] == 'ended' || $vehicle['status'] == 'sold'): ?>
                    <div class="ultra-badge ultra-badge-ended"><i class="fa fa-flag-checkered"></i> Selesai</div>
                <?php endif; ?>
            </div>
            
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <h1 class="ultra-vehicle-title"><?php echo $vehicle['title']; ?></h1>
                    <h3 class="ultra-vehicle-subtitle"><?php echo $vehicle['make'] . ' ' . $vehicle['model'] . ' ' . $vehicle['year']; ?></h3>
                </div>
                <div class="col-lg-4">
                    <?php if ($vehicle['status'] == 'active'): ?>
                        <div class="ultra-price-badge">
                            <div class="ultra-price-label">Penawaran Tertinggi</div>
                            <div class="ultra-price-value"><?php echo format_currency($vehicle['current_bid'] ?: $vehicle['starting_price']); ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ultra-section">
    <div class="ultra-container">
        <?php if(!empty($error)): ?>
            <div class="alert alert-danger fade-in-up"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if(!empty($success)): ?>
            <div class="alert alert-success fade-in-up"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <div class="ultra-grid">
            <div class="ultra-col-8">
                <!-- Main Image & Gallery -->
                <div class="ultra-gallery-container fade-in">
                    <div id="carouselGallery" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner ultra-main-image">
                            <?php if (!empty($vehicle['image_main'])): ?>
                                <div class="carousel-item active">
                                    <img src="uploads/vehicles/<?php echo $vehicle['image_main']; ?>" class="d-block w-100" alt="<?php echo $vehicle['title']; ?>" loading="lazy">
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($images_result && $images_result->num_rows > 0): ?>
                                <?php $images_result->data_seek(0); ?>
                                <?php while ($image = $images_result->fetch_assoc()): ?>
                                    <div class="carousel-item">
                                        <img src="uploads/vehicles/<?php echo $image['image_url']; ?>" class="d-block w-100" alt="<?php echo $vehicle['title']; ?>" loading="lazy">
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselGallery" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselGallery" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                    <div class="ultra-thumbnails">
                        <?php if (!empty($vehicle['image_main'])): ?>
                            <div class="ultra-thumbnail active" data-bs-target="#carouselGallery" data-bs-slide-to="0">
                                <img src="uploads/vehicles/<?php echo $vehicle['image_main']; ?>" alt="Thumbnail 1" loading="lazy">
                            </div>
                        <?php endif; ?>
                        <?php if ($images_result && $images_result->num_rows > 0): ?>
                            <?php $counter = 1; ?>
                            <?php $images_result->data_seek(0); ?>
                            <?php while ($image = $images_result->fetch_assoc()): ?>
                                <div class="ultra-thumbnail" data-bs-target="#carouselGallery" data-bs-slide-to="<?php echo $counter; ?>">
                                    <img src="uploads/vehicles/<?php echo $image['image_url']; ?>" alt="Thumbnail <?php echo $counter + 1; ?>" loading="lazy">
                                </div>
                                <?php $counter++; ?>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Vehicle Description -->
                <div class="ultra-info-section fade-in-up">
                    <h3><i class="fa fa-info-circle"></i> Deskripsi Kendaraan</h3>
                    <div class="ultra-description">
                        <?php echo nl2br($vehicle['description']); ?>
                    </div>
                </div>
                
                <!-- Vehicle Specifications -->
                <div class="ultra-info-section fade-in-up">
                    <h3><i class="fa fa-cogs"></i> Spesifikasi</h3>
                    <div class="ultra-info-grid">
                        <div class="ultra-info-box">
                            <div class="ultra-info-label">Merek</div>
                            <div class="ultra-info-value"><?php echo $vehicle['make']; ?></div>
                        </div>
                        <div class="ultra-info-box">
                            <div class="ultra-info-label">Model</div>
                            <div class="ultra-info-value"><?php echo $vehicle['model']; ?></div>
                        </div>
                        <div class="ultra-info-box">
                            <div class="ultra-info-label">Tahun</div>
                            <div class="ultra-info-value"><?php echo $vehicle['year']; ?></div>
                        </div>
                        <div class="ultra-info-box">
                            <div class="ultra-info-label">Kilometer</div>
                            <div class="ultra-info-value"><?php echo number_format($vehicle['mileage']); ?> KM</div>
                        </div>
                        <div class="ultra-info-box">
                            <div class="ultra-info-label">Transmisi</div>
                            <div class="ultra-info-value"><?php echo $vehicle['transmission']; ?></div>
                        </div>
                        <div class="ultra-info-box">
                            <div class="ultra-info-label">Bahan Bakar</div>
                            <div class="ultra-info-value"><?php echo $vehicle['fuel_type']; ?></div>
                        </div>
                        
                        <?php if ($specs_result && $specs_result->num_rows > 0): ?>
                            <?php while ($spec = $specs_result->fetch_assoc()): ?>
                                <div class="ultra-info-box">
                                    <div class="ultra-info-label"><?php echo $spec['spec_name']; ?></div>
                                    <div class="ultra-info-value"><?php echo $spec['spec_value']; ?></div>
                                </div>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Additional Vehicle Features -->
                <div class="ultra-info-section fade-in-up">
                    <h3><i class="fa fa-list-check"></i> Fitur Tambahan</h3>
                    <div class="ultra-description">
                        <?php echo nl2br($vehicle['features']); ?>
                    </div>
                </div>
            </div>
            
            <div class="ultra-col-4">
                <!-- Auction Sidebar Card -->
                <div class="ultra-auction-card fade-in">
                    <div class="ultra-auction-status">
                        <div class="ultra-status-title">Status Lelang</div>
                        <div class="ultra-status-value <?php echo $vehicle['status']; ?>">
                            <?php 
                                switch($vehicle['status']) {
                                    case 'upcoming':
                                        echo '<i class="fa fa-clock"></i> Akan Datang';
                                        break;
                                    case 'active':
                                        echo '<i class="fa fa-gavel"></i> Sedang Berlangsung';
                                        break;
                                    case 'ended':
                                        echo '<i class="fa fa-flag-checkered"></i> Selesai';
                                        break;
                                    case 'sold':
                                        echo '<i class="fa fa-check-circle"></i> Terjual';
                                        break;
                                    default:
                                        echo '<i class="fa fa-info-circle"></i> ' . ucfirst($vehicle['status']);
                                }
                            ?>
                        </div>
                    </div>
                    
                    <?php if ($vehicle['status'] == 'active'): ?>
                        <!-- Countdown Timer -->
                        <div class="ultra-countdown" id="premium-timer" data-end="<?php echo strtotime($vehicle['auction_end']); ?>">
                            <div class="ultra-countdown-title">Sisa Waktu Lelang</div>
                            <div class="ultra-timer-grid">
                                <div class="ultra-timer-block">
                                    <div class="ultra-timer-number"><span id="days"><?php echo str_pad($days_left, 2, '0', STR_PAD_LEFT); ?></span></div>
                                    <div class="ultra-timer-label">Hari</div>
                                </div>
                                <div class="ultra-timer-block">
                                    <div class="ultra-timer-number"><span id="hours"><?php echo str_pad($hours_left, 2, '0', STR_PAD_LEFT); ?></span></div>
                                    <div class="ultra-timer-label">Jam</div>
                                </div>
                                <div class="ultra-timer-block">
                                    <div class="ultra-timer-number"><span id="minutes"><?php echo str_pad($minutes_left, 2, '0', STR_PAD_LEFT); ?></span></div>
                                    <div class="ultra-timer-label">Menit</div>
                                </div>
                                <div class="ultra-timer-block">
                                    <div class="ultra-timer-number"><span id="seconds"><?php echo str_pad($seconds_left, 2, '0', STR_PAD_LEFT); ?></span></div>
                                    <div class="ultra-timer-label">Detik</div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Progress Bar -->
                        <div class="ultra-progress-container">
                            <div class="ultra-progress-info">
                                <div class="ultra-progress-start"><?php echo date('j M Y', strtotime($vehicle['auction_start'])); ?></div>
                                <div class="ultra-progress-end"><?php echo date('j M Y', strtotime($vehicle['auction_end'])); ?></div>
                            </div>
                            <div class="ultra-progress-bar">
                                <div class="ultra-progress-fill" style="width: <?php echo $progress_percentage; ?>%"></div>
                            </div>
                        </div>
                        
                        <!-- Bid Form -->
                        <?php if (is_logged_in()): ?>
                            <div class="ultra-bid-form">
                                <form action="" method="post">
                                    <div class="ultra-form-group">
                                        <label class="ultra-form-label">Masukkan Jumlah Bid</label>
                                        <div class="ultra-bid-presets">
                                            <?php 
                                                $current_amount = max($vehicle['current_bid'], $vehicle['starting_price']);
                                                $increments = [500000, 1000000, 2000000];
                                                foreach ($increments as $increment) {
                                                    $preset_amount = $current_amount + $increment;
                                                    echo '<button type="button" class="ultra-preset-btn" data-amount="'.$preset_amount.'">+'.format_currency($increment).'</button>';
                                                }
                                            ?>
                                        </div>
                                        <input type="text" name="bid_amount" id="bidAmount" class="ultra-form-control" placeholder="Rp 0" required>
                                    </div>
                                    <button type="submit" name="place_bid" id="bidButton" class="ultra-btn ultra-btn-primary">
                                        <i class="fa fa-gavel"></i> Ajukan Bid
                                    </button>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="ultra-bid-form">
                                <div class="text-center p-3">
                                    <p>Anda harus login untuk mengajukan bid</p>
                                    <a href="login.php?redirect=vehicle.php?id=<?php echo $vehicle_id; ?>" class="ultra-btn ultra-btn-primary">
                                        <i class="fa fa-sign-in-alt"></i> Login Untuk Bid
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <!-- Bid History -->
                    <div class="ultra-history-section">
                        <div class="ultra-history-title">
                            <i class="fa fa-history"></i> Riwayat Bid
                        </div>
                        <?php if ($bids_result && $bids_result->num_rows > 0): ?>
                            <div class="ultra-history-list">
                                <?php while ($bid = $bids_result->fetch_assoc()): ?>
                                    <?php 
                                        $is_highest = ($bid['bid_amount'] == $vehicle['current_bid']);
                                        $is_you = is_logged_in() && $bid['bidder_id'] == $_SESSION['user_id'];
                                        $bidder_name = $is_you ? 'Anda' : mask_username($bid['username']);
                                        $bid_class = $is_highest ? 'highest' : ($is_you ? 'you' : '');
                                    ?>
                                    <div class="ultra-history-item <?php echo $bid_class; ?>">
                                        <div class="ultra-bidder-info">
                                            <div class="ultra-bidder-avatar">
                                                <?php echo substr($bidder_name, 0, 1); ?>
                                            </div>
                                            <div>
                                                <div class="ultra-bidder-name">
                                                    <?php echo $bidder_name; ?>
                                                    <?php if ($is_highest): ?>
                                                        <span class="badge bg-success">Tertinggi</span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="ultra-bidder-time">
                                                    <?php echo date('d M Y, H:i', strtotime($bid['bid_time'])); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ultra-bid-amount">
                                            <?php echo format_currency($bid['bid_amount']); ?>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div class="ultra-history-empty">
                                <div class="ultra-history-icon">
                                    <i class="fa fa-gavel"></i>
                                </div>
                                <p>Belum ada bid untuk kendaraan ini</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modernized Auction Scripts -->
<script src="js/premium-auction.js"></script>
<script src="js/vehicle-animations.js"></script>
<script src="js/vehicle-performance.js"></script>

<!-- Fallback Countdown Script for browsers without modern JS support -->
<?php if ($vehicle['status'] == 'active'): ?>
<script>
function countdownFallback() {
    const endTime = <?php echo strtotime($vehicle['auction_end']) ?> * 1000;
    const now = new Date().getTime();
    const diff = endTime - now;
    
    if (diff <= 0) {
        document.getElementById('premium-timer').innerHTML = '<div class="auction-ended">Lelang telah berakhir</div>';
        setTimeout(() => { location.reload(); }, 3000);
        return;
    }
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    
    document.getElementById('days').textContent = days.toString().padStart(2, '0');
    document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
    document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
    document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
}

// Run countdown immediately and every second
countdownFallback();
setInterval(countdownFallback, 1000);
</script>
<?php endif; ?>

<!-- Bid Amount Handling -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Preset Buttons
    const presetButtons = document.querySelectorAll('.ultra-preset-btn');
    const bidInput = document.getElementById('bidAmount');
    
    if (presetButtons.length > 0 && bidInput) {
        presetButtons.forEach(button => {
            button.addEventListener('click', function() {
                const amount = this.getAttribute('data-amount');
                bidInput.value = amount;
                
                // Remove active class from all buttons
                presetButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
            });
        });
    }
    
    // Format currency in input
    if (bidInput) {
        bidInput.addEventListener('input', function() {
            // Remove non-numeric characters
            let value = this.value.replace(/\D/g, '');
            
            // Format with thousand separator
            if (value) {
                this.value = new Intl.NumberFormat('id-ID', {
                    style: 'currency',
                    currency: 'IDR',
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0
                }).format(value);
            }
        });
        
        // On form submit, clean the value
        const bidForm = bidInput.closest('form');
        if (bidForm) {
            bidForm.addEventListener('submit', function() {
                bidInput.value = bidInput.value.replace(/\D/g, '');
            });
        }
    }
});
</script>

<?php include 'includes/footer.php'; ?>
