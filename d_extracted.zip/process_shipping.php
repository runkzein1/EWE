<?php
// Memulai session
session_start();

// Koneksi ke database
require_once 'includes/db_connect.php';

// Cek login status
if (!isset($_SESSION['user_id'])) {
    // Redirect ke halaman login jika belum login
    header('Location: login.php');
    exit;
}

// Ambil data user
$user_id = $_SESSION['user_id'];

// Tangani tambah alamat baru
if (isset($_POST['add_address'])) {
    // Ambil data form
    $recipient_name = $_POST['recipient_name'];
    $phone = $_POST['phone'];
    $address_line1 = $_POST['address_line1'];
    $address_line2 = isset($_POST['address_line2']) ? $_POST['address_line2'] : '';
    $city = $_POST['city'];
    $province = $_POST['province'];
    $postal_code = $_POST['postal_code'];
    $is_primary = isset($_POST['is_primary']) ? 1 : 0;
    
    // Validasi 
    $errors = [];
    
    if (empty($recipient_name)) {
        $errors[] = "Nama penerima harus diisi";
    }
    
    if (empty($phone)) {
        $errors[] = "Nomor telepon harus diisi";
    }
    
    if (empty($address_line1)) {
        $errors[] = "Alamat harus diisi";
    }
    
    if (empty($city)) {
        $errors[] = "Kota harus diisi";
    }
    
    if (empty($province)) {
        $errors[] = "Provinsi harus diisi";
    }
    
    if (empty($postal_code)) {
        $errors[] = "Kode pos harus diisi";
    }
    
    // Jika tidak ada error, proses penyimpanan
    if (empty($errors)) {
        try {
            // Mulai transaksi
            $conn->begin_transaction();
            
            // Jika alamat ini akan dijadikan utama, reset semua alamat lain
            if ($is_primary) {
                $reset_sql = "UPDATE shipping_addresses SET is_primary = 0 WHERE user_id = ?";
                $reset_stmt = $conn->prepare($reset_sql);
                $reset_stmt->bind_param("i", $user_id);
                $reset_stmt->execute();
            }
            
            // Tambahkan alamat baru
            $add_sql = "INSERT INTO shipping_addresses (user_id, recipient_name, phone, address_line1, address_line2, city, province, postal_code, is_primary) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $add_stmt = $conn->prepare($add_sql);
            $add_stmt->bind_param("isssssssi", $user_id, $recipient_name, $phone, $address_line1, $address_line2, $city, $province, $postal_code, $is_primary);
            $add_stmt->execute();
            
            // Jika ini adalah alamat pertama user, jadikan sebagai primary
            if ($add_stmt->affected_rows > 0 && $conn->insert_id > 0) {
                $check_sql = "SELECT COUNT(*) as count FROM shipping_addresses WHERE user_id = ?";
                $check_stmt = $conn->prepare($check_sql);
                $check_stmt->bind_param("i", $user_id);
                $check_stmt->execute();
                $result = $check_stmt->get_result();
                $count = $result->fetch_assoc()['count'];
                
                if ($count == 1) {
                    $update_sql = "UPDATE shipping_addresses SET is_primary = 1 WHERE user_id = ? AND id = ?";
                    $update_stmt = $conn->prepare($update_sql);
                    $update_stmt->bind_param("ii", $user_id, $conn->insert_id);
                    $update_stmt->execute();
                }
            }
            
            // Commit transaksi
            $conn->commit();
            
            // Set success message
            $_SESSION['success_message'] = "Alamat pengiriman berhasil ditambahkan";
            
        } catch (Exception $e) {
            // Rollback jika terjadi error
            $conn->rollback();
            $errors[] = "Terjadi kesalahan: " . $e->getMessage();
        }
    }
    
    // Jika ada error, simpan untuk ditampilkan
    if (!empty($errors)) {
        $_SESSION['error_messages'] = $errors;
    }
}

// Tangani set alamat utama
if (isset($_POST['set_primary_address'])) {
    $address_id = $_POST['address_id'];
    
    try {
        // Mulai transaksi
        $conn->begin_transaction();
        
        // Reset semua alamat menjadi non-primary
        $reset_sql = "UPDATE shipping_addresses SET is_primary = 0 WHERE user_id = ?";
        $reset_stmt = $conn->prepare($reset_sql);
        $reset_stmt->bind_param("i", $user_id);
        $reset_stmt->execute();
        
        // Set alamat yang dipilih menjadi primary
        $update_sql = "UPDATE shipping_addresses SET is_primary = 1 WHERE id = ? AND user_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ii", $address_id, $user_id);
        $update_stmt->execute();
        
        // Commit transaksi
        $conn->commit();
        
        // Set success message
        $_SESSION['success_message'] = "Alamat utama berhasil diperbarui";
        
    } catch (Exception $e) {
        // Rollback jika terjadi error
        $conn->rollback();
        $_SESSION['error_messages'] = ["Terjadi kesalahan: " . $e->getMessage()];
    }
}

// Tangani hapus alamat
if (isset($_POST['delete_address'])) {
    $address_id = $_POST['address_id'];
    
    try {
        // Hapus alamat
        $delete_sql = "DELETE FROM shipping_addresses WHERE id = ? AND user_id = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("ii", $address_id, $user_id);
        $delete_stmt->execute();
        
        // Jika sukses dihapus
        if ($delete_stmt->affected_rows > 0) {
            // Cek apakah masih ada alamat lain
            $check_sql = "SELECT id FROM shipping_addresses WHERE user_id = ? LIMIT 1";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $user_id);
            $check_stmt->execute();
            $result = $check_stmt->get_result();
            
            // Jika masih ada alamat lain & yang dihapus adalah primary, set alamat pertama menjadi primary
            if ($result->num_rows > 0) {
                $first_address = $result->fetch_assoc();
                $update_sql = "UPDATE shipping_addresses SET is_primary = 1 WHERE id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("i", $first_address['id']);
                $update_stmt->execute();
            }
            
            // Set success message
            $_SESSION['success_message'] = "Alamat berhasil dihapus";
        } else {
            $_SESSION['error_messages'] = ["Alamat tidak ditemukan"];
        }
        
    } catch (Exception $e) {
        $_SESSION['error_messages'] = ["Terjadi kesalahan: " . $e->getMessage()];
    }
}

// Tangani update alamat
if (isset($_POST['update_address'])) {
    // Ambil data form
    $address_id = $_POST['address_id'];
    $recipient_name = $_POST['recipient_name'];
    $phone = $_POST['phone'];
    $address_line1 = $_POST['address_line1'];
    $address_line2 = isset($_POST['address_line2']) ? $_POST['address_line2'] : '';
    $city = $_POST['city'];
    $province = $_POST['province'];
    $postal_code = $_POST['postal_code'];
    
    // Validasi sama seperti pada add
    $errors = [];
    
    if (empty($recipient_name) || empty($phone) || empty($address_line1) || 
        empty($city) || empty($province) || empty($postal_code)) {
        $errors[] = "Semua field wajib harus diisi";
    }
    
    // Jika tidak ada error, update alamat
    if (empty($errors)) {
        try {
            $update_sql = "UPDATE shipping_addresses SET 
                           recipient_name = ?, 
                           phone = ?, 
                           address_line1 = ?, 
                           address_line2 = ?, 
                           city = ?, 
                           province = ?, 
                           postal_code = ? 
                           WHERE id = ? AND user_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("sssssssii", $recipient_name, $phone, $address_line1, $address_line2, $city, $province, $postal_code, $address_id, $user_id);
            $update_stmt->execute();
            
            if ($update_stmt->affected_rows > 0) {
                $_SESSION['success_message'] = "Alamat berhasil diperbarui";
            } else {
                $_SESSION['error_messages'] = ["Tidak ada perubahan pada alamat"];
            }
            
        } catch (Exception $e) {
            $_SESSION['error_messages'] = ["Terjadi kesalahan: " . $e->getMessage()];
        }
    } else {
        $_SESSION['error_messages'] = $errors;
    }
}

// Redirect kembali ke halaman account
header('Location: account.php');
exit;
?>
