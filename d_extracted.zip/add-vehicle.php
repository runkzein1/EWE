<?php
// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=add-vehicle.php");
    exit;
}

// Check if user has appropriate privileges
$user_id = $_SESSION['user_id'];

// Cek apakah kolom role sudah ada di tabel
$check_role_exists = $conn->query("SHOW COLUMNS FROM users LIKE 'role'");

if ($check_role_exists->num_rows > 0) {
    // Kolom role sudah ada, gunakan role untuk otorisasi
    $check_privileges = "SELECT role, is_admin FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($check_privileges);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    // Cek role pengguna
    if ($user['role'] != 'admin' && $user['role'] != 'seller') {
        $_SESSION['alert'] = [
            'type' => 'danger',
            'message' => 'Anda tidak memiliki izin untuk menambahkan lelang. Silakan hubungi admin untuk upgrade akun Anda menjadi seller.'
        ];
        header("Location: account.php");
        exit;
    }
} else {
    // Kolom role belum ada, gunakan is_admin
    $check_privileges = "SELECT is_admin FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($check_privileges);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if (!$user['is_admin']) {
        $_SESSION['alert'] = [
            'type' => 'danger',
            'message' => 'Anda tidak memiliki izin untuk menambahkan lelang. Silakan hubungi admin untuk upgrade akun Anda.'
        ];
        header("Location: account.php");
        exit;
    }
}

// Load dropdown data
$fuel_types = ['Bensin', 'Solar', 'Listrik', 'Hybrid', 'Gas (CNG)', 'Lainnya'];
$body_types = ['Sedan', 'SUV', 'MPV', 'Hatchback', 'Coupe', 'Convertible', 'Wagon', 'Van', 'Pickup', 'Truk', 'Lainnya'];
$transmission_types = ['Manual', 'Otomatis', 'CVT', 'Dual-Clutch', 'Semi-Otomatis', 'Lainnya'];
$condition_ratings = [
    '10' => 'Sempurna - Seperti baru (10/10)',
    '9' => 'Sangat Baik - Nyaris tidak ada cacat (9/10)',
    '8' => 'Baik - Sedikit cacat kosmetik (8/10)',
    '7' => 'Cukup Baik - Beberapa cacat kosmetik (7/10)',
    '6' => 'Rata-rata - Beberapa masalah minor (6/10)',
    '5' => 'Sedang - Beberapa masalah serius (5/10)',
    '4' => 'Di bawah rata-rata - Membutuhkan perbaikan (4/10)',
    '3' => 'Buruk - Membutuhkan perbaikan besar (3/10)',
    '2' => 'Sangat buruk - Mungkin tidak layak jalan (2/10)',
    '1' => 'Rusak parah - Untuk dijual sebagai suku cadang (1/10)'
];

// Lokasi
$locations = [
    'Jakarta', 'Surabaya', 'Bandung', 'Medan', 'Semarang', 'Makassar', 'Palembang',
    'Tangerang', 'Depok', 'Bekasi', 'Yogyakarta', 'Malang', 'Bali', 'Batam',
    'Lainnya'
];

// Fitur kendaraan umum untuk sugesti
$common_features = [
    ['AC (Air Conditioner)', 'fa-snowflake'], 
    ['Power Steering', 'fa-steering-wheel'],
    ['Power Window', 'fa-window-maximize'],
    ['Central Lock', 'fa-lock'],
    ['Audio System', 'fa-music'],
    ['Airbag', 'fa-shield-alt'],
    ['ABS (Anti-lock Braking System)', 'fa-car-crash'],
    ['Electric Mirror', 'fa-mirror'],
    ['Fog Lamp', 'fa-lightbulb'],
    ['Parking Camera', 'fa-camera'],
    ['Parking Sensor', 'fa-parking'],
    ['Keyless Entry', 'fa-key'],
    ['Push Start Button', 'fa-power-off'],
    ['Navigation System', 'fa-map-marked'],
    ['Bluetooth Connection', 'fa-bluetooth']
];

// Process form submission
$errors = [];
$success = false;
$vehicle_id = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required_fields = [
        'title' => 'Judul lelang',
        'description' => 'Deskripsi',
        'make' => 'Merek',
        'model' => 'Model',
        'year' => 'Tahun',
        'body_type' => 'Tipe Bodi',
        'mileage' => 'Kilometrage',
        'fuel_type' => 'Jenis Bahan Bakar',
        'transmission' => 'Transmisi',
        'color' => 'Warna',
        'condition_rating' => 'Rating Kondisi',
        'starting_price' => 'Harga Awal',
        'auction_end' => 'Tanggal Akhir Lelang',
        'location' => 'Lokasi'
    ];

    foreach ($required_fields as $field => $label) {
        if (empty($_POST[$field])) {
            $errors[] = "$label harus diisi";
        }
    }

    // Validate numeric fields
    $numeric_fields = [
        'year' => 'Tahun',
        'mileage' => 'Kilometrage',
        'condition_rating' => 'Rating Kondisi',
        'starting_price' => 'Harga Awal'
    ];

    // Validate optional numeric fields if provided
    $optional_numeric_fields = [
        'reserve_price' => 'Harga Minimum',
        'buy_now_price' => 'Harga Beli Langsung',
        'engine_size' => 'Kapasitas Mesin'
    ];

    foreach ($numeric_fields as $field => $label) {
        if (!empty($_POST[$field]) && !is_numeric(str_replace(['.', ','], '', $_POST[$field]))) {
            $errors[] = "$label harus berupa angka";
        }
    }

    foreach ($optional_numeric_fields as $field => $label) {
        if (!empty($_POST[$field]) && !is_numeric(str_replace(['.', ','], '', $_POST[$field]))) {
            $errors[] = "$label harus berupa angka";
        }
    }

    // Validate date field
    $auction_end = $_POST['auction_end'] ?? '';
    $end_date = new DateTime($auction_end);
    $now = new DateTime();
    
    if ($end_date <= $now) {
        $errors[] = "Tanggal akhir lelang harus di masa depan";
    }

    // Validate price relationships
    $starting_price = str_replace(['.', ','], '', $_POST['starting_price']);
    
    if (!empty($_POST['reserve_price'])) {
        $reserve_price = str_replace(['.', ','], '', $_POST['reserve_price']);
        if ($reserve_price < $starting_price) {
            $errors[] = "Harga minimum tidak boleh lebih rendah dari harga awal";
        }
    }
    
    if (!empty($_POST['buy_now_price']) && !empty($_POST['reserve_price'])) {
        $buy_now_price = str_replace(['.', ','], '', $_POST['buy_now_price']);
        $reserve_price = str_replace(['.', ','], '', $_POST['reserve_price']);
        if ($buy_now_price <= $reserve_price) {
            $errors[] = "Harga beli langsung harus lebih tinggi dari harga minimum";
        }
    } elseif (!empty($_POST['buy_now_price'])) {
        $buy_now_price = str_replace(['.', ','], '', $_POST['buy_now_price']);
        if ($buy_now_price <= $starting_price) {
            $errors[] = "Harga beli langsung harus lebih tinggi dari harga awal";
        }
    }

    // Process if no errors
    if (empty($errors)) {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Cek apakah kolom-kolom baru sudah ada di tabel
            $check_body_type = $conn->query("SHOW COLUMNS FROM vehicles LIKE 'body_type'");
            $has_new_columns = $check_body_type->num_rows > 0;
            
            if ($has_new_columns) {
                // Prepare vehicle insert statement dengan kolom tambahan
                $insert_vehicle = "INSERT INTO vehicles (
                    seller_id, title, description, make, model, body_type, year, 
                    mileage, fuel_type, transmission, color, engine_size,
                    license_plate, vin, condition_rating, starting_price, 
                    reserve_price, buy_now_price, status, featured, location,
                    auction_start, auction_end, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'upcoming', ?, ?, NOW(), ?, NOW())";
                
                $stmt = $conn->prepare($insert_vehicle);
                
                // Convert prices to decimal
                $starting_price = str_replace(['.', ','], '', $_POST['starting_price']);
                $reserve_price = !empty($_POST['reserve_price']) ? str_replace(['.', ','], '', $_POST['reserve_price']) : null;
                $buy_now_price = !empty($_POST['buy_now_price']) ? str_replace(['.', ','], '', $_POST['buy_now_price']) : null;
                $featured = isset($_POST['featured']) ? 1 : 0;
                
                // Set values
                $stmt->bind_param(
                    "isssssisssssssiddidss",
                    $user_id,
                    $_POST['title'],
                    $_POST['description'],
                    $_POST['make'],
                    $_POST['model'],
                    $_POST['body_type'],
                    $_POST['year'],
                    $_POST['mileage'],
                    $_POST['fuel_type'],
                    $_POST['transmission'],
                    $_POST['color'],
                    $_POST['engine_size'],
                    $_POST['license_plate'],
                    $_POST['vin'],
                    $_POST['condition_rating'],
                    $starting_price,
                    $reserve_price,
                    $buy_now_price,
                    $featured,
                    $_POST['location'],
                    $_POST['auction_end']
                );
            } else {
                // Fallback to original schema if new columns don't exist
                $insert_vehicle = "INSERT INTO vehicles (
                    seller_id, title, description, make, model, year, 
                    mileage, condition_rating, starting_price, 
                    status, auction_start, auction_end, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'upcoming', NOW(), ?, NOW())";
                
                $stmt = $conn->prepare($insert_vehicle);
                
                // Convert price to decimal
                $starting_price = str_replace(['.', ','], '', $_POST['starting_price']);
                
                // Set values
                $stmt->bind_param(
                    "issssiidss",
                    $user_id,
                    $_POST['title'],
                    $_POST['description'],
                    $_POST['make'],
                    $_POST['model'],
                    $_POST['year'],
                    $_POST['mileage'],
                    $_POST['condition_rating'],
                    $starting_price,
                    $_POST['auction_end']
                );
            }
            
            // Execute the query
            $stmt->execute();
            $vehicle_id = $conn->insert_id;
            
            // Process specifications if provided
            if (!empty($_POST['spec_name']) && !empty($_POST['spec_value'])) {
                $spec_names = $_POST['spec_name'];
                $spec_values = $_POST['spec_value'];
                
                // Insert each specification
                $insert_spec = "INSERT INTO vehicle_specs (vehicle_id, spec_name, spec_value) VALUES (?, ?, ?)";
                $spec_stmt = $conn->prepare($insert_spec);
                
                for ($i = 0; $i < count($spec_names); $i++) {
                    if (!empty($spec_names[$i]) && !empty($spec_values[$i])) {
                        $spec_stmt->bind_param("iss", $vehicle_id, $spec_names[$i], $spec_values[$i]);
                        $spec_stmt->execute();
                    }
                }
            }
            
            // Process features if provided
            $check_features_table = $conn->query("SHOW TABLES LIKE 'vehicle_features'");
            if ($check_features_table->num_rows > 0 && !empty($_POST['features'])) {
                $features = $_POST['features'];
                $feature_icons = $_POST['feature_icons'];
                
                // Insert each feature
                $insert_feature = "INSERT INTO vehicle_features (vehicle_id, feature_name, feature_icon, is_highlighted) VALUES (?, ?, ?, ?)";
                $feature_stmt = $conn->prepare($insert_feature);
                
                for ($i = 0; $i < count($features); $i++) {
                    if (!empty($features[$i])) {
                        $icon = !empty($feature_icons[$i]) ? $feature_icons[$i] : 'fa-check';
                        $is_highlighted = isset($_POST['feature_highlighted'][$i]) ? 1 : 0;
                        
                        $feature_stmt->bind_param("issi", $vehicle_id, $features[$i], $icon, $is_highlighted);
                        $feature_stmt->execute();
                    }
                }
            }
            
            // Process inspection report if provided
            $check_inspection_table = $conn->query("SHOW TABLES LIKE 'inspection_reports'");
            if ($check_inspection_table->num_rows > 0 && !empty($_POST['inspector_name'])) {
                $insert_inspection = "INSERT INTO inspection_reports (
                    vehicle_id, inspector_name, inspection_date, 
                    overall_condition, engine_condition, exterior_condition, 
                    interior_condition, transmission_condition, electrical_condition, 
                    notes, is_verified
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; 
                
                $inspection_stmt = $conn->prepare($insert_inspection);
                $inspection_date = !empty($_POST['inspection_date']) ? $_POST['inspection_date'] : date('Y-m-d');
                $is_verified = isset($_POST['inspection_verified']) ? 1 : 0;
                
                $inspection_stmt->bind_param(
                    "isssssssssi",
                    $vehicle_id,
                    $_POST['inspector_name'],
                    $inspection_date,
                    $_POST['overall_condition'],
                    $_POST['engine_condition'],
                    $_POST['exterior_condition'],
                    $_POST['interior_condition'],
                    $_POST['transmission_condition'],
                    $_POST['electrical_condition'],
                    $_POST['inspection_notes'],
                    $is_verified
                );
                
                $inspection_stmt->execute();
            }
            
            // Process images upload
            $base_upload_dir = 'uploads/vehicles/';
            if (!file_exists($base_upload_dir)) {
                mkdir($base_upload_dir, 0777, true);
            }
            
            // Create make-specific directory
            $make_safe = preg_replace('/[^a-z0-9]+/', '-', strtolower($make));
            $model_safe = preg_replace('/[^a-z0-9]+/', '-', strtolower($model));
            $upload_dir = $base_upload_dir . $make_safe . '/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // Check if images were uploaded
            if (!empty($_FILES['images']['name'][0])) {
                $allowed_types = ['image/jpeg', 'image/jpg', 'image/png'];
                $max_size = 20 * 1024 * 1024; // 20MB
                $max_images = 20; // Maximum number of images allowed
                
                // Determine which image is set as main
                $main_image_index = isset($_POST['main_image_index']) ? intval($_POST['main_image_index']) : 0;
                
                // Prepare image insert statement
                $insert_image = "INSERT INTO vehicle_images (vehicle_id, image_url, is_main, caption) VALUES (?, ?, ?, ?)";
                $image_stmt = $conn->prepare($insert_image);
                
                // Count how many files were uploaded
                $file_count = count($_FILES['images']['name']);
                
                // Limit to max images
                if ($file_count > $max_images) {
                    $file_count = $max_images;
                }
                
                // Process each uploaded image
                for ($i = 0; $i < $file_count; $i++) {
                    // Check file type
                    if (!in_array($_FILES['images']['type'][$i], $allowed_types)) {
                        throw new Exception("File " . $_FILES['images']['name'][$i] . " bukan file gambar yang valid");
                    }
                    
                    // Check file size
                    if ($_FILES['images']['size'][$i] > $max_size) {
                        throw new Exception("File " . $_FILES['images']['name'][$i] . " terlalu besar (maks. 20MB)");
                    }
                    
                    // Get file extension and sanitize it
                    $file_extension = strtolower(pathinfo($_FILES['images']['name'][$i], PATHINFO_EXTENSION));
                    
                    // Generate a more unique filename with timestamp
                    $timestamp = time();
                    $random = mt_rand(1000, 9999);
                    $filename = $make_safe . '_' . $model_safe . '_' . $vehicle_id . '_' . $timestamp . '_' . $random . '_' . $i . '.' . $file_extension;
                    $target_file = $upload_dir . $filename;
                    
                    // Move uploaded file
                    if (move_uploaded_file($_FILES['images']['tmp_name'][$i], $target_file)) {
                        // Set main image based on the selected index
                        $is_main = ($i === $main_image_index) ? 1 : 0;
                        $image_url = $target_file;
                        
                        // Get caption if provided
                        $caption = isset($_POST['image_captions'][$i]) ? $_POST['image_captions'][$i] : '';
                        
                        // Insert image info into database
                        $image_stmt->bind_param("isis", $vehicle_id, $image_url, $is_main, $caption);
                        $image_stmt->execute();
                        
                        // Log success
                        error_log("Uploaded image: $image_url, Main: $is_main");
                    } else {
                        throw new Exception("Gagal mengupload gambar " . $_FILES['images']['name'][$i]);
                    }
                }
                
                // After all images are uploaded, make sure there's only one main image
                $update_main_sql = "UPDATE vehicle_images SET is_main = CASE 
                                    WHEN (SELECT COUNT(*) FROM (SELECT * FROM vehicle_images WHERE vehicle_id = ? AND is_main = 1) as subq) = 0 
                                    AND image_id = (SELECT MIN(image_id) FROM (SELECT * FROM vehicle_images WHERE vehicle_id = ?) as subq2) 
                                    THEN 1 ELSE is_main END 
                                    WHERE vehicle_id = ?";
                $update_main_stmt = $conn->prepare($update_main_sql);
                $update_main_stmt->bind_param("iii", $vehicle_id, $vehicle_id, $vehicle_id);
                $update_main_stmt->execute();
                $update_main_stmt->close();
            }
            
            // Commit transaction
            $conn->commit();
            $success = true;
            
            // Set success message
            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Kendaraan berhasil ditambahkan ke lelang! Admin akan mereview dan mengaktifkan lelang Anda.'
            ];
            
            // Redirect to vehicle page
            header("Location: vehicle.php?id=" . $vehicle_id);
            exit;
            
        } catch (Exception $e) {
            // Rollback on error
            $conn->rollback();
            $errors[] = "Error: " . $e->getMessage();
        }
    }
}

// Definisikan locations untuk dropdown jika belum ada
if (!isset($locations)) {
    $locations = [
        'Jakarta', 'Surabaya', 'Bandung', 'Medan', 'Semarang', 'Makassar',
        'Palembang', 'Yogyakarta', 'Tangerang', 'Bekasi', 'Depok', 'Bogor',
        'Bali', 'Malang', 'Balikpapan', 'Padang', 'Manado', 'Batam'
    ];
}

// Page title
$page_title = "Tambah Kendaraan Lelang Baru - LelangMobil";
?>

<?php include 'includes/header.php'; ?>
<!-- Enhanced Image Uploader CSS -->
<link rel="stylesheet" href="css/image-upload.css">
<!-- CSS for multi-step form -->
<link rel="stylesheet" href="css/multi-step-form.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<div class="no-bottom no-top" id="content">
    <div id="top"></div>
    
    <section id="subheader" class="jarallax">
        <img src="images/background/subheader.jpg" class="jarallax-img" alt="">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3 text-center">
                    <h1>Tambah Kendaraan Lelang</h1>
                    <p class="lead">Isi formulir berikut dengan lengkap dan akurat untuk mendaftarkan kendaraan Anda ke sistem lelang.</p>
                    <div class="de-separator"></div>
                </div>
            </div>
        </div>
    </section>
    
    <style>
        .form-step {
            display: none;
        }
        .form-step.active {
            display: block;
        }
        .step-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
        }
        .step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #f5f5f5;
            color: #666;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 15px;
            position: relative;
            font-weight: bold;
            border: 2px solid #ddd;
        }
        .step.active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        .step.completed {
            background: #28a745;
            color: white;
            border-color: #28a745;
        }
        .step::after {
            content: '';
            position: absolute;
            width: 30px;
            height: 2px;
            background-color: #ddd;
            top: 50%;
            left: 100%;
            transform: translateY(-50%);
        }
        .step:last-child::after {
            display: none;
        }
        .step.completed::after {
            background-color: #28a745;
        }
        .tab-title {
            font-size: 18px;
            margin-bottom: 15px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            color: var(--primary-color);
        }
        .custom-file-preview {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        .preview-image-container {
            position: relative;
            width: 120px;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .preview-image {
            width: 100%;
            height: 100px;
            object-fit: cover;
            border-radius: 4px;
        }
        .image-caption-input {
            margin-top: 5px;
            font-size: 12px;
            width: 100%;
        }
        .remove-image {
            position: absolute;
            top: -10px;
            right: -10px;
            background: #dc3545;
            color: white;
            border-radius: 50%;
            width: 25px;
            height: 25px;
            line-height: 25px;
            text-align: center;
            cursor: pointer;
        }
        .main-image-badge {
            position: absolute;
            top: 5px;
            left: 5px;
            background: var(--primary-color);
            color: white;
            font-size: 10px;
            padding: 2px 5px;
            border-radius: 3px;
        }
        .feature-item {
            margin-bottom: 10px;
            border: 1px solid #eee;
            padding: 10px;
            border-radius: 5px;
            position: relative;
        }
        .feature-remove {
            position: absolute;
            right: 10px;
            top: 10px;
            cursor: pointer;
            color: #dc3545;
        }
        .format-price {
            text-align: right;
        }
        .btn-main-outline {
            background: transparent;
            border: 2px solid var(--primary-color);
            color: var(--primary-color);
        }
        .btn-main-outline:hover {
            background: var(--primary-color);
            color: white;
        }
        .form-navigation {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .form-required-note {
            font-size: 13px;
            margin-bottom: 20px;
            color: #dc3545;
        }
        .info-tooltip {
            color: var(--primary-color);
            margin-left: 5px;
            cursor: help;
        }
    </style>

    <section id="section-main" class="pt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo $error; ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <div class="de-box">
                        <form action="" method="post" enctype="multipart/form-data" id="add-vehicle-form">
                            
                            <!-- Step Indicators -->
                            <div class="step-indicator">
                                <div class="step active" data-step="1">1</div>
                                <div class="step" data-step="2">2</div>
                                <div class="step" data-step="3">3</div>
                                <div class="step" data-step="4">4</div>
                                <div class="step" data-step="5">5</div>
                            </div>
                            
                            <div class="form-required-note">
                                <i class="fa fa-info-circle"></i> Kolom dengan tanda * wajib diisi
                            </div>
                            
                            <!-- Step 1: Informasi Dasar Kendaraan -->
                            <div class="form-step active" id="step1">
                                <h3 class="tab-title"><i class="fa fa-car"></i> Informasi Dasar Kendaraan</h3>
                                <div class="row g-3">
                                    <div class="col-12">
                                        <div class="field-set mb-3">
                                            <label for="title">Judul Lelang *</label>
                                            <input type="text" name="title" id="title" class="form-control" required value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>">
                                            <small class="text-muted">Contoh: Toyota Avanza G 2019 Hitam Metalik - KM Rendah</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="make">Merek *</label>
                                            <input type="text" name="make" id="make" class="form-control" required placeholder="Toyota, Honda, BMW, dll" value="<?php echo isset($_POST['make']) ? htmlspecialchars($_POST['make']) : ''; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="model">Model *</label>
                                            <input type="text" name="model" id="model" class="form-control" required placeholder="Avanza, Civic, X5, dll" value="<?php echo isset($_POST['model']) ? htmlspecialchars($_POST['model']) : ''; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="body_type">Tipe Bodi *</label>
                                            <select name="body_type" id="body_type" class="form-control" required>
                                                <option value="">-- Pilih Tipe Bodi --</option>
                                                <?php foreach ($body_types as $type): ?>
                                                    <option value="<?php echo $type; ?>" <?php echo (isset($_POST['body_type']) && $_POST['body_type'] == $type) ? 'selected' : ''; ?>>
                                                        <?php echo $type; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="year">Tahun *</label>
                                            <input type="number" name="year" id="year" class="form-control" required min="1900" max="<?php echo date('Y') + 1; ?>" value="<?php echo isset($_POST['year']) ? htmlspecialchars($_POST['year']) : date('Y'); ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="color">Warna *</label>
                                            <input type="text" name="color" id="color" class="form-control" required placeholder="Hitam, Putih, Silver, dll" value="<?php echo isset($_POST['color']) ? htmlspecialchars($_POST['color']) : ''; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="location">Lokasi *</label>
                                            <select name="location" id="location" class="form-control" required>
                                                <option value="">-- Pilih Lokasi --</option>
                                                <?php foreach ($locations as $location): ?>
                                                    <option value="<?php echo $location; ?>" <?php echo (isset($_POST['location']) && $_POST['location'] == $location) ? 'selected' : ''; ?>>
                                                        <?php echo $location; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="mileage">Kilometrage (KM) *</label>
                                            <input type="text" name="mileage" id="mileage" class="form-control format-number" required placeholder="12.000" value="<?php echo isset($_POST['mileage']) ? htmlspecialchars($_POST['mileage']) : ''; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="fuel_type">Jenis Bahan Bakar *</label>
                                            <select name="fuel_type" id="fuel_type" class="form-control" required>
                                                <option value="">-- Pilih Jenis Bahan Bakar --</option>
                                                <?php foreach ($fuel_types as $type): ?>
                                                    <option value="<?php echo $type; ?>" <?php echo (isset($_POST['fuel_type']) && $_POST['fuel_type'] == $type) ? 'selected' : ''; ?>>
                                                        <?php echo $type; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="transmission">Transmisi *</label>
                                            <select name="transmission" id="transmission" class="form-control" required>
                                                <option value="">-- Pilih Jenis Transmisi --</option>
                                                <?php foreach ($transmission_types as $type): ?>
                                                    <option value="<?php echo $type; ?>" <?php echo (isset($_POST['transmission']) && $_POST['transmission'] == $type) ? 'selected' : ''; ?>>
                                                        <?php echo $type; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="engine_size">Kapasitas Mesin (CC)</label>
                                            <input type="text" name="engine_size" id="engine_size" class="form-control format-number" placeholder="1.500" value="<?php echo isset($_POST['engine_size']) ? htmlspecialchars($_POST['engine_size']) : ''; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="license_plate">Nomor Polisi</label>
                                            <input type="text" name="license_plate" id="license_plate" class="form-control" placeholder="B 1234 XYZ" value="<?php echo isset($_POST['license_plate']) ? htmlspecialchars($_POST['license_plate']) : ''; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="field-set mb-3">
                                            <label for="vin">Nomor Rangka/VIN</label>
                                            <input type="text" name="vin" id="vin" class="form-control" placeholder="MHRZBC4ASL" value="<?php echo isset($_POST['vin']) ? htmlspecialchars($_POST['vin']) : ''; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="field-set mb-3">
                                            <label for="condition_rating">Kondisi Kendaraan *</label>
                                            <select name="condition_rating" id="condition_rating" class="form-control" required>
                                                <option value="">-- Pilih Rating Kondisi --</option>
                                                <?php foreach ($condition_ratings as $rating => $desc): ?>
                                                    <option value="<?php echo $rating; ?>" <?php echo (isset($_POST['condition_rating']) && $_POST['condition_rating'] == $rating) ? 'selected' : ''; ?>>
                                                        <?php echo $desc; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-12">
                                        <div class="field-set mb-3">
                                            <label for="description">Deskripsi Kendaraan *</label>
                                            <textarea name="description" id="description" rows="5" class="form-control" required placeholder="Jelaskan kondisi kendaraan secara detail, sejarah perawatan, bekas kecelakaan/banjir (jika ada), fitur-fitur khusus, alasan penjualan, dll."><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                                            <small class="text-muted">Deskripsi yang jelas dan jujur akan meningkatkan kepercayaan penawar.</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-navigation">
                                    <div></div>
                                    <button type="button" class="btn-main next-step">Lanjutkan <i class="fa fa-arrow-right"></i></button>
                                </div>
                            </div>
                            
                            <!-- Step 2: Informasi Harga dan Detail Lelang -->
                            <div class="form-step" id="step2">
                                <h3 class="tab-title"><i class="fa fa-tag"></i> Informasi Harga dan Detail Lelang</h3>
                                
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <div class="field-set mb-3">
                                            <label for="starting_price">Harga Awal Lelang (Rp) * <i class="fa fa-info-circle info-tooltip" title="Harga terendah untuk memulai penawaran"></i></label>
                                            <div class="input-group">
                                                <span class="input-group-text">Rp</span>
                                                <input type="text" name="starting_price" id="starting_price" class="form-control format-price" required placeholder="50.000.000" value="<?php echo isset($_POST['starting_price']) ? htmlspecialchars($_POST['starting_price']) : ''; ?>">
                                            </div>
                                            <small class="text-muted">Harga di mana lelang akan dimulai</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="field-set mb-3">
                                            <label for="reserve_price">Harga Minimum (Reserve Price) <i class="fa fa-info-circle info-tooltip" title="Harga minimum yang harus dicapai agar kendaraan terjual"></i></label>
                                            <div class="input-group">
                                                <span class="input-group-text">Rp</span>
                                                <input type="text" name="reserve_price" id="reserve_price" class="form-control format-price" placeholder="55.000.000" value="<?php echo isset($_POST['reserve_price']) ? htmlspecialchars($_POST['reserve_price']) : ''; ?>">
                                            </div>
                                            <small class="text-muted">Jika tidak ada penawaran yang mencapai harga ini, kendaraan tidak akan terjual</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="field-set mb-3">
                                            <label for="buy_now_price">Harga Beli Langsung <i class="fa fa-info-circle info-tooltip" title="Harga di mana pembeli dapat membeli langsung tanpa lelang"></i></label>
                                            <div class="input-group">
                                                <span class="input-group-text">Rp</span>
                                                <input type="text" name="buy_now_price" id="buy_now_price" class="form-control format-price" placeholder="75.000.000" value="<?php echo isset($_POST['buy_now_price']) ? htmlspecialchars($_POST['buy_now_price']) : ''; ?>">
                                            </div>
                                            <small class="text-muted">Opsional - Harga yang memungkinkan pembeli membeli langsung tanpa proses lelang</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="field-set mb-3">
                                            <label for="auction_end">Tanggal & Waktu Akhir Lelang *</label>
                                            <input type="datetime-local" name="auction_end" id="auction_end" class="form-control" required min="<?php echo date('Y-m-d\TH:i', strtotime('+1 day')); ?>" value="<?php echo isset($_POST['auction_end']) ? htmlspecialchars($_POST['auction_end']) : date('Y-m-d\TH:i', strtotime('+7 days')); ?>">
                                            <small class="text-muted">Lelang akan berakhir pada waktu yang ditentukan</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-12">
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="checkbox" id="featured" name="featured" value="1" <?php echo (isset($_POST['featured']) && $_POST['featured'] == '1') ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="featured">
                                                Jadikan sebagai Lelang Unggulan <i class="fa fa-info-circle info-tooltip" title="Lelang unggulan akan ditampilkan di bagian atas halaman dan akan mendapat perhatian lebih"></i>
                                            </label>
                                            <small class="d-block text-muted">Lelang unggulan akan mendapatkan posisi utama di halaman beranda</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mt-4">
                                    <h4 class="tab-subtitle"><i class="fa fa-list-ul"></i> Fitur Kendaraan</h4>
                                    <p class="small text-muted mb-3">Pilih fitur-fitur yang ada pada kendaraan ini untuk menarik perhatian pembeli potensial.</p>
                                    
                                    <div id="features-container">
                                        <?php $existing_features = isset($_POST['features']) ? $_POST['features'] : []; ?>
                                        <?php $feature_icons = isset($_POST['feature_icons']) ? $_POST['feature_icons'] : []; ?>
                                        <?php $feature_highlighted = isset($_POST['feature_highlighted']) ? $_POST['feature_highlighted'] : []; ?>
                                        
                                        <?php if (!empty($existing_features)): ?>
                                            <?php foreach($existing_features as $index => $feature): ?>
                                                <div class="feature-item">
                                                    <div class="row">
                                                        <div class="col-md-5">
                                                            <div class="form-group">
                                                                <input type="text" name="features[]" class="form-control" placeholder="Nama Fitur" value="<?php echo htmlspecialchars($feature); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <input type="text" name="feature_icons[]" class="form-control" placeholder="Icon (fa-car)" value="<?php echo isset($feature_icons[$index]) ? htmlspecialchars($feature_icons[$index]) : 'fa-check'; ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" name="feature_highlighted[<?php echo $index; ?>]" value="1" <?php echo (isset($feature_highlighted[$index]) && $feature_highlighted[$index] == '1') ? 'checked' : ''; ?>>
                                                                <label class="form-check-label small">Highlight</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-1">
                                                            <span class="feature-remove"><i class="fa fa-times"></i></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <div class="feature-item">
                                                <div class="row">
                                                    <div class="col-md-5">
                                                        <div class="form-group">
                                                            <input type="text" name="features[]" class="form-control" placeholder="Nama Fitur">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <input type="text" name="feature_icons[]" class="form-control" placeholder="Icon (fa-car)" value="fa-check">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" name="feature_highlighted[0]" value="1">
                                                            <label class="form-check-label small">Highlight</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-1">
                                                        <span class="feature-remove"><i class="fa fa-times"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="mb-4 mt-2">
                                        <button type="button" id="add-feature" class="btn btn-sm btn-secondary"><i class="fa fa-plus"></i> Tambah Fitur</button>
                                        <button type="button" id="add-common-features" class="btn btn-sm btn-outline-primary ms-2"><i class="fa fa-list-check"></i> Tambah Fitur Umum</button>
                                    </div>
                                </div>
                                
                                <div class="form-navigation">
                                    <button type="button" class="btn-main-outline prev-step"><i class="fa fa-arrow-left"></i> Kembali</button>
                                    <button type="button" class="btn-main next-step">Lanjutkan <i class="fa fa-arrow-right"></i></button>
                                </div>
                            </div>
                            
                            <!-- Step 3: Spesifikasi Teknis -->
                            <div class="form-step" id="step3">
                                <h3 class="tab-title"><i class="fa fa-cogs"></i> Spesifikasi Teknis</h3>
                                <p class="text-muted">Tambahkan spesifikasi teknis detail untuk memberikan informasi komprehensif kepada calon pembeli.</p>
                                
                                <div id="specifications-container">
                                    <?php $spec_names = isset($_POST['spec_name']) ? $_POST['spec_name'] : []; ?>
                                    <?php $spec_values = isset($_POST['spec_value']) ? $_POST['spec_value'] : []; ?>
                                    
                                    <?php if (!empty($spec_names) && !empty($spec_values)): ?>
                                        <?php foreach($spec_names as $index => $name): ?>
                                            <?php if(!empty($name) && !empty($spec_values[$index])): ?>
                                                <div class="row g-2 mb-2 specification-row">
                                                    <div class="col-md-5">
                                                        <input type="text" name="spec_name[]" class="form-control" placeholder="Nama Spesifikasi" value="<?php echo htmlspecialchars($name); ?>">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <input type="text" name="spec_value[]" class="form-control" placeholder="Nilai" value="<?php echo htmlspecialchars($spec_values[$index]); ?>">
                                                    </div>
                                                    <div class="col-md-2">
                                                        <button type="button" class="btn btn-danger remove-spec"><i class="fa fa-times"></i></button>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                    
                                    <div class="row g-2 mb-2 specification-row">
                                        <div class="col-md-5">
                                            <input type="text" name="spec_name[]" class="form-control" placeholder="Nama Spesifikasi (mis. Transmisi)">
                                        </div>
                                        <div class="col-md-5">
                                            <input type="text" name="spec_value[]" class="form-control" placeholder="Nilai (mis. Otomatis)">
                                        </div>
                                        <div class="col-md-2">
                                            <button type="button" class="btn btn-danger remove-spec" style="display:none;"><i class="fa fa-times"></i></button>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row mb-4">
                                    <div class="col-12">
                                        <button type="button" id="add-spec" class="btn btn-sm btn-secondary"><i class="fa fa-plus"></i> Tambah Spesifikasi</button>
                                        <button type="button" id="add-common-specs" class="btn btn-sm btn-outline-primary ms-2"><i class="fa fa-list-check"></i> Tambah Spesifikasi Umum</button>
                                    </div>
                                </div>
                                
                                <div class="form-navigation">
                                    <button type="button" class="btn-main-outline prev-step"><i class="fa fa-arrow-left"></i> Kembali</button>
                                    <button type="button" class="btn-main next-step">Lanjutkan <i class="fa fa-arrow-right"></i></button>
                                </div>
                            </div>
                            
                            <!-- Step 4: Foto Kendaraan -->
                            <div class="form-step" id="step4">
                                <h3 class="tab-title"><i class="fa fa-camera"></i> Foto Kendaraan</h3>
                                <p class="text-muted">Unggah foto kendaraan berkualitas tinggi dari berbagai sudut. Foto berkualitas dapat meningkatkan minat dan penawaran.</p>
                                
                                <div class="lelang-image-uploader" id="vehicle-image-uploader">
                                    <h4 class="mb-3">Foto Kendaraan</h4>
                                    
                                    <div class="upload-area">
                                        <input type="file" name="images[]" id="vehicle-images" accept="image/jpeg,image/jpg,image/png" multiple required>
                                        <div class="icon"><i class="fa fa-cloud-upload-alt"></i></div>
                                        <p class="upload-text">Klik atau seret foto kendaraan ke sini</p>
                                        <p class="upload-info">Format JPG, JPEG, PNG (maksimal 20MB per file)</p>
                                    </div>
                                    
                                    <div class="file-size-warning"></div>
                                    <div class="file-type-error"></div>
                                    
                                    <div class="upload-limit-info">
                                        <span><i class="fa fa-info-circle"></i> Foto pertama otomatis dijadikan sebagai foto utama</span>
                                        <span>Jumlah Foto: <span class="current-image-count">0</span>/20</span>
                                    </div>
                                    
                                    <div class="upload-progress-bar">
                                        <div class="upload-progress-value"></div>
                                    </div>
                                    
                                    <div class="image-preview-container">
                                        <div class="image-preview-list">
                                            <!-- Image previews will be added here by JavaScript -->
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-12">
                                            <div class="tips-box mt-3">
                                                <h5><i class="fa fa-lightbulb"></i> Tips untuk foto kendaraan yang baik:</h5>
                                                <ul class="small text-muted">
                                                    <li>Foto kendaraan dari beberapa sudut: depan, belakang, samping, interior, dan mesin</li>
                                                    <li>Pastikan cahaya cukup terang namun tidak menyilaukan (hindari cahaya matahari langsung)</li>
                                                    <li>Tunjukkan bagian penting seperti dashboard, kursi, mesin, bagasi, dan fitur khusus</li>
                                                    <li>Jika ada kerusakan, dokumentasikan dengan jelas untuk transparansi</li>
                                                    <li>Bersihkan kendaraan sebelum difoto untuk hasil yang lebih menarik</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-12">
                                            <div id="image-preview" class="row g-3">
                                                <!-- Image preview will be displayed here -->
                                                <div class="col-12 empty-preview-message">
                                                    <div class="alert alert-secondary text-center">
                                                        <i class="fa fa-image fa-2x mb-2"></i>
                                                        <p>Pratinjau foto akan muncul di sini setelah Anda memilih file.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="image-tips mb-4">
                                    <h5><i class="fa fa-lightbulb"></i> Tips Foto Lelang</h5>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <ul class="image-tips-list">
                                                <li><i class="fa fa-check-circle text-success"></i> Gunakan pencahayaan alami yang baik</li>
                                                <li><i class="fa fa-check-circle text-success"></i> Ambil foto dari berbagai sudut (eksternal dan internal)</li>
                                                <li><i class="fa fa-check-circle text-success"></i> Fokus pada fitur penting dan detil unik kendaraan</li>
                                            </ul>
                                        </div>
                                        <div class="col-md-6">
                                            <ul class="image-tips-list">
                                                <li><i class="fa fa-times-circle text-danger"></i> Hindari terlalu banyak editing atau filter</li>
                                                <li><i class="fa fa-times-circle text-danger"></i> Hindari foto gelap atau tidak fokus</li>
                                                <li><i class="fa fa-times-circle text-danger"></i> Hindari foto dengan plat nomor atau wajah orang terlihat jelas</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-navigation">
                                    <button type="button" class="btn-main-outline prev-step"><i class="fa fa-arrow-left"></i> Kembali</button>
                                    <button type="button" class="btn-main next-step">Lanjutkan <i class="fa fa-arrow-right"></i></button>
                                </div>
                            </div>
                            
                            <!-- Step 5: Laporan Inspeksi (Opsional) & Summary -->
                            <div class="form-step" id="step5">
                                <h3 class="tab-title"><i class="fa fa-clipboard-check"></i> Laporan Inspeksi & Ringkasan</h3>
                                
                                <div class="inspection-report-container mb-4">
                                    <div class="inspection-header d-flex align-items-center justify-content-between mb-3">
                                        <h4 class="tab-subtitle mb-0"><i class="fa fa-car-mechanic"></i> Laporan Inspeksi (Opsional)</h4>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="has_inspection" name="has_inspection" value="1" <?php echo (isset($_POST['has_inspection']) && $_POST['has_inspection'] == '1') ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="has_inspection">Tambahkan Laporan Inspeksi</label>
                                        </div>
                                    </div>
                                    
                                    <div id="inspection-details" <?php echo (!isset($_POST['has_inspection']) || $_POST['has_inspection'] != '1') ? 'style="display:none;"' : ''; ?>>
                                        <div class="alert alert-info mb-3">
                                            <p class="mb-1"><i class="fa fa-info-circle"></i> Laporan inspeksi meningkatkan kepercayaan pembeli dan biasanya meningkatkan nilai jual kendaraan.</p>
                                        </div>
                                        
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <div class="field-set mb-3">
                                                    <label for="inspector_name">Nama Inspektor/Bengkel</label>
                                                    <input type="text" name="inspector_name" id="inspector_name" class="form-control" placeholder="Nama bengkel atau mekanik" value="<?php echo isset($_POST['inspector_name']) ? htmlspecialchars($_POST['inspector_name']) : ''; ?>">
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <div class="field-set mb-3">
                                                    <label for="inspection_date">Tanggal Inspeksi</label>
                                                    <input type="date" name="inspection_date" id="inspection_date" class="form-control" max="<?php echo date('Y-m-d'); ?>" value="<?php echo isset($_POST['inspection_date']) ? htmlspecialchars($_POST['inspection_date']) : date('Y-m-d'); ?>">
                                                </div>
                                            </div>
                                            
                                            <div class="col-12">
                                                <div class="field-set mb-3">
                                                    <label for="inspection_details">Ringkasan Inspeksi</label>
                                                    <textarea name="inspection_details" id="inspection_details_text" rows="4" class="form-control" placeholder="Masukkan ringkasan hasil inspeksi kendaraan..."><?php echo isset($_POST['inspection_details']) ? htmlspecialchars($_POST['inspection_details']) : ''; ?></textarea>
                                                </div>
                                            </div>
                                            
                                            <div class="col-12">
                                                <div class="field-set mb-3">
                                                    <label for="inspection_file">Upload Dokumen Inspeksi (Opsional)</label>
                                                    <input type="file" name="inspection_file" id="inspection_file" class="form-control" accept="application/pdf,image/jpeg,image/jpg,image/png">
                                                    <small class="text-muted">Format: PDF, JPG, PNG (Maks. 5MB)</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="summary-container mb-4">
                                    <h4 class="tab-subtitle mb-3"><i class="fa fa-check-double"></i> Ringkasan Kendaraan</h4>
                                    <div class="alert alert-success">
                                        <p class="mb-0"><i class="fa fa-info-circle"></i> Periksa kembali semua data yang telah Anda masukkan sebelum menambahkan kendaraan ke lelang.</p>
                                    </div>
                                    
                                    <div id="vehicle-summary" class="summary-content">
                                        <!-- Summary will be generated by JavaScript -->
                                        <p class="text-muted text-center">Detail kendaraan akan ditampilkan di sini...</p>
                                    </div>
                                </div>
                                
                                <div class="form-check mb-4">
                                    <input class="form-check-input" type="checkbox" id="terms-agreement" required>
                                    <label class="form-check-label" for="terms-agreement">
                                        Saya setuju bahwa informasi yang saya berikan adalah akurat dan lengkap. Saya telah membaca dan menyetujui <a href="terms.php" target="_blank">Syarat dan Ketentuan</a> LelangMobil.
                                    </label>
                                </div>
                                
                                <div class="row mb-4">
                                    <div class="col-12 d-flex justify-content-between">
                                        <button type="button" class="btn-main-outline prev-step"><i class="fa fa-arrow-left"></i> Kembali</button>
                                        <button type="submit" name="add_vehicle" class="btn-main">Tambahkan Kendaraan <i class="fa fa-check"></i></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php include 'includes/footer.php'; ?>

<!-- Enhanced Image Uploader JavaScript -->
<script src="js/image-uploader.js"></script>

<!-- JavaScript para multi-step form -->
<script src="js/multi-step-form.js"></script>

<script>
// Este script proporciona funcionalidad adicional específica al formulario add-vehicle.php
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar tooltips de Bootstrap si están disponibles
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
    
    // Inicializar select2 para mejorar los dropdowns si está disponible
    if (typeof $.fn !== 'undefined' && $.fn.select2) {
        $('#body_type, #location, #fuel_type, #transmission, #condition_rating').select2({
            theme: 'bootstrap4',
            width: '100%',
            placeholder: 'Pilih opsi...',
            allowClear: true
        });
    }
    
    // Validación adicional específica para campos de precio
    const startingPrice = document.getElementById('starting_price');
    const reservePrice = document.getElementById('reserve_price');
    const buyNowPrice = document.getElementById('buy_now_price');
    
    if (startingPrice && reservePrice && buyNowPrice) {
        const validatePrices = function() {
            const startValue = startingPrice.value ? parseFloat(startingPrice.value.replace(/\./g, '').replace(',', '.')) : 0;
            const reserveValue = reservePrice.value ? parseFloat(reservePrice.value.replace(/\./g, '').replace(',', '.')) : 0;
            const buyNowValue = buyNowPrice.value ? parseFloat(buyNowPrice.value.replace(/\./g, '').replace(',', '.')) : 0;
            
            // Solo validamos si hay valores
            if (reserveValue > 0 && reserveValue < startValue) {
                reservePrice.setCustomValidity('Harga minimum harus lebih besar dari atau sama dengan harga awal');
            } else {
                reservePrice.setCustomValidity('');
            }
            
            if (buyNowValue > 0 && buyNowValue <= startValue) {
                buyNowPrice.setCustomValidity('Harga beli langsung harus lebih besar dari harga awal');
            } else if (reserveValue > 0 && buyNowValue > 0 && buyNowValue <= reserveValue) {
                buyNowPrice.setCustomValidity('Harga beli langsung harus lebih besar dari harga minimum');
            } else {
                buyNowPrice.setCustomValidity('');
            }
        };
        
        startingPrice.addEventListener('change', validatePrices);
        reservePrice.addEventListener('change', validatePrices);
        buyNowPrice.addEventListener('change', validatePrices);
    }
    
    // Toggle para detalles de inspección
    const hasInspection = document.getElementById('has_inspection');
    const inspectionDetails = document.getElementById('inspection-details');
    
    if (hasInspection && inspectionDetails) {
        hasInspection.addEventListener('change', function() {
            inspectionDetails.style.display = this.checked ? 'block' : 'none';
        });
    }
    
    // Form validation final
    const form = document.getElementById('add-vehicle-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            // Validate terms agreement
            const termsCheckbox = document.getElementById('terms-agreement');
            if (termsCheckbox && !termsCheckbox.checked) {
                e.preventDefault();
                alert('Anda harus menyetujui syarat dan ketentuan untuk melanjutkan.');
                termsCheckbox.focus();
            }
        });
    }
});
</script>
