<?php
/**
 * Modern Transactions Table
 * LelangMobil Web App - Versi 2025
 */

// Pastikan transactions_result (query result) sudah diambil datanya sebelum memanggil komponen ini
if (!isset($transactions_result)) {
    die("Error: Transactions data not loaded.");
}
?>

<div class="modern-card fade-in">
    <div class="modern-card-header">
        <h2 class="modern-card-title"><i class="fa fa-history"></i> Riwayat Transaksi</h2>
        
        <div class="transaction-filters">
            <select id="filterTransactionType" class="modern-form-control form-select-sm">
                <option value="">Semua Jenis</option>
                <option value="deposit">Top Up</option>
                <option value="withdrawal">Penarikan</option>
                <option value="bid_hold">Bid Hold</option>
                <option value="bid_release">Bid Release</option>
                <option value="bid_win">Menang Lelang</option>
                <option value="refund">Pengembalian Dana</option>
            </select>
            
            <select id="filterTransactionStatus" class="modern-form-control form-select-sm ms-2">
                <option value="">Semua Status</option>
                <option value="completed">Completed</option>
                <option value="pending">Pending</option>
                <option value="processing">Processing</option>
                <option value="rejected">Rejected</option>
            </select>
        </div>
    </div>
    
    <div class="modern-card-body p-0">
        <?php if (!$transactions_result || $transactions_result->num_rows == 0): ?>
            <div class="p-4 text-center">
                <div class="empty-state">
                    <i class="fa fa-receipt fa-3x text-muted mb-3"></i>
                    <h5>Belum Ada Transaksi</h5>
                    <p class="text-muted">Transaksi Anda akan muncul di sini.</p>
                    <a href="topup-menu.php" class="modern-button modern-button-primary mt-3">
                        <i class="fa fa-plus-circle me-2"></i>Mulai dengan Top Up
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="modern-table" id="transactionsTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Jenis</th>
                            <th>Jumlah</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Reset pointer ke awal data
                        if ($transactions_result && $transactions_result->num_rows > 0) {
                            $transactions_result->data_seek(0);
                        }
                        
                        while ($transaction = $transactions_result->fetch_assoc()): 
                            // Set type badge color and icon
                            $type_badge_color = 'primary';
                            $type_icon = 'fa-exchange-alt';
                            $type_label = 'Transaksi';
                            
                            switch($transaction['type']) {
                                case 'deposit':
                                    $type_badge_color = 'success';
                                    $type_icon = 'fa-arrow-down';
                                    $type_label = 'Top Up';
                                    break;
                                case 'withdrawal':
                                    $type_badge_color = 'info';
                                    $type_icon = 'fa-arrow-up';
                                    $type_label = 'Penarikan';
                                    break;
                                case 'bid_hold':
                                    $type_badge_color = 'warning';
                                    $type_icon = 'fa-gavel';
                                    $type_label = 'Bid Hold';
                                    break;
                                case 'bid_release':
                                    $type_badge_color = 'secondary';
                                    $type_icon = 'fa-undo';
                                    $type_label = 'Bid Release';
                                    break;
                                case 'bid_win':
                                    $type_badge_color = 'primary';
                                    $type_icon = 'fa-trophy';
                                    $type_label = 'Menang Lelang';
                                    break;
                                case 'refund':
                                    $type_badge_color = 'info';
                                    $type_icon = 'fa-hand-holding-usd';
                                    $type_label = 'Refund';
                                    break;
                            }
                            
                            // Set status badge color
                            $status_badge_color = 'secondary';
                            $status_icon = 'fa-clock';
                            
                            switch($transaction['status']) {
                                case 'completed':
                                    $status_badge_color = 'success';
                                    $status_icon = 'fa-check-circle';
                                    break;
                                case 'pending':
                                    $status_badge_color = 'warning';
                                    $status_icon = 'fa-clock';
                                    break;
                                case 'processing':
                                    $status_badge_color = 'info';
                                    $status_icon = 'fa-spinner fa-spin';
                                    break;
                                case 'rejected':
                                    $status_badge_color = 'danger';
                                    $status_icon = 'fa-times-circle';
                                    break;
                            }
                        ?>
                        <tr data-type="<?php echo $transaction['type']; ?>" data-status="<?php echo $transaction['status']; ?>">
                            <td><span class="modern-badge modern-badge-dark">#<?php echo $transaction['transaction_id']; ?></span></td>
                            <td>
                                <span class="modern-badge modern-badge-<?php echo $type_badge_color; ?>">
                                    <i class="fa <?php echo $type_icon; ?>"></i> <?php echo $type_label; ?>
                                </span>
                            </td>
                            <td>
                                <span class="<?php echo ($transaction['type'] == 'deposit' || $transaction['type'] == 'bid_release' || $transaction['type'] == 'refund') ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo ($transaction['type'] == 'deposit' || $transaction['type'] == 'bid_release' || $transaction['type'] == 'refund') ? '+' : '-'; ?>
                                    Rp<?php echo number_format($transaction['amount'], 0, ',', '.'); ?>
                                </span>
                            </td>
                            <td><?php echo date('d M Y, H:i', strtotime($transaction['created_at'])); ?></td>
                            <td>
                                <span class="modern-badge modern-badge-<?php echo $status_badge_color; ?>">
                                    <i class="fa <?php echo $status_icon; ?>"></i> <?php echo ucfirst($transaction['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="d-flex gap-2">
                                    <button type="button" class="btn btn-sm btn-primary" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#transactionModal<?php echo $transaction['transaction_id']; ?>">
                                        <i class="fa fa-eye"></i>
                                    </button>
                                    
                                    <?php if ($transaction['status'] == 'pending' && $transaction['type'] == 'deposit'): ?>
                                    <a href="upload-payment.php?id=<?php echo $transaction['transaction_id']; ?>" class="btn btn-sm btn-success">
                                        <i class="fa fa-upload"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    
    <?php if (isset($show_pagination) && $show_pagination): ?>
    <div class="modern-card-footer d-flex justify-content-between align-items-center">
        <div class="text-muted small">
            Menampilkan <?php echo $transactions_result->num_rows; ?> transaksi
        </div>
        
        <?php if (isset($total_pages) && $total_pages > 1): ?>
        <nav>
            <ul class="pagination pagination-sm mb-0">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $i == $current_page ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<!-- Transaction Detail Modals -->
<?php 
if ($transactions_result && $transactions_result->num_rows > 0) {
    // Reset pointer ke awal data
    $transactions_result->data_seek(0);
    
    while ($transaction = $transactions_result->fetch_assoc()): 
?>
<div class="modal fade" id="transactionModal<?php echo $transaction['transaction_id']; ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fa fa-receipt me-2"></i>Detail Transaksi #<?php echo $transaction['transaction_id']; ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-borderless">
                    <tr>
                        <td width="40%"><strong>ID Transaksi</strong></td>
                        <td>#<?php echo $transaction['transaction_id']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Jenis Transaksi</strong></td>
                        <td>
                            <?php 
                            $type_label = 'Transaksi';
                            
                            switch($transaction['type']) {
                                case 'deposit': $type_label = 'Top Up'; break;
                                case 'withdrawal': $type_label = 'Penarikan'; break;
                                case 'bid_hold': $type_label = 'Bid Hold'; break;
                                case 'bid_release': $type_label = 'Bid Release'; break;
                                case 'bid_win': $type_label = 'Menang Lelang'; break;
                                case 'refund': $type_label = 'Refund'; break;
                            }
                            
                            echo $type_label;
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Jumlah</strong></td>
                        <td class="<?php echo ($transaction['type'] == 'deposit' || $transaction['type'] == 'bid_release' || $transaction['type'] == 'refund') ? 'text-success' : 'text-danger'; ?>">
                            <strong>
                                <?php echo ($transaction['type'] == 'deposit' || $transaction['type'] == 'bid_release' || $transaction['type'] == 'refund') ? '+' : '-'; ?>
                                Rp<?php echo number_format($transaction['amount'], 0, ',', '.'); ?>
                            </strong>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Tanggal</strong></td>
                        <td><?php echo date('d F Y, H:i', strtotime($transaction['created_at'])); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Status</strong></td>
                        <td>
                            <?php 
                            $status_class = 'secondary';
                            
                            switch($transaction['status']) {
                                case 'completed': $status_class = 'success'; break;
                                case 'pending': $status_class = 'warning'; break;
                                case 'processing': $status_class = 'info'; break;
                                case 'rejected': $status_class = 'danger'; break;
                            }
                            ?>
                            <span class="badge bg-<?php echo $status_class; ?>"><?php echo ucfirst($transaction['status']); ?></span>
                        </td>
                    </tr>
                    <?php if (!empty($transaction['notes'])): ?>
                    <tr>
                        <td><strong>Catatan</strong></td>
                        <td><?php echo htmlspecialchars($transaction['notes']); ?></td>
                    </tr>
                    <?php endif; ?>
                    
                    <?php if (!empty($transaction['payment_proof'])): ?>
                    <tr>
                        <td><strong>Bukti Pembayaran</strong></td>
                        <td>
                            <a href="uploads/payments/<?php echo $transaction['payment_proof']; ?>" target="_blank" class="btn btn-sm btn-primary">
                                <i class="fa fa-image me-2"></i>Lihat Bukti
                            </a>
                        </td>
                    </tr>
                    <?php endif; ?>
                    
                    <?php if (!empty($transaction['reference_number'])): ?>
                    <tr>
                        <td><strong>Nomor Referensi</strong></td>
                        <td><?php echo $transaction['reference_number']; ?></td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
            <div class="modal-footer">
                <?php if ($transaction['status'] == 'pending' && $transaction['type'] == 'deposit'): ?>
                <a href="upload-payment.php?id=<?php echo $transaction['transaction_id']; ?>" class="btn btn-success">
                    <i class="fa fa-upload me-2"></i>Upload Bukti
                </a>
                <?php endif; ?>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php 
    endwhile;
}
?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Transaction filter functionality
    const typeFilter = document.getElementById('filterTransactionType');
    const statusFilter = document.getElementById('filterTransactionStatus');
    const transactionsTable = document.getElementById('transactionsTable');
    
    if (typeFilter && statusFilter && transactionsTable) {
        const filterTransactions = function() {
            const typeValue = typeFilter.value;
            const statusValue = statusFilter.value;
            const rows = transactionsTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const rowType = row.getAttribute('data-type');
                const rowStatus = row.getAttribute('data-status');
                const typeMatch = !typeValue || rowType === typeValue;
                const statusMatch = !statusValue || rowStatus === statusValue;
                
                if (typeMatch && statusMatch) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        };
        
        typeFilter.addEventListener('change', filterTransactions);
        statusFilter.addEventListener('change', filterTransactions);
    }
});
</script>
