<?php
// Ini adalah konten tab alamat pengiriman yang akan dimasukkan ke account.php
// Untuk membuatnya modular dan mempermudah maintenance

// Ambil alamat pengiriman dari database
$shipping_sql = "SELECT * FROM shipping_addresses WHERE user_id = ? ORDER BY is_primary DESC, id ASC";
$shipping_stmt = $conn->prepare($shipping_sql);
$shipping_stmt->bind_param("i", $user_id);
$shipping_stmt->execute();
$shipping_result = $shipping_stmt->get_result();

// Kabupaten/kota di Indonesia untuk dropdown
$locations = [
    "Jakarta Pusat", "Jakarta Barat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Utara",
    "Bandung", "Surabaya", "Medan", "Semarang", "Makassar", "Palembang", "Tangerang",
    "Depok", "Bekasi", "Bogor", "Yogyakarta", "Malang", "Denpasar", "Balikpapan", "Batam"
];

// Provinsi di Indonesia
$provinces = [
    "Aceh", "Sumatera Utara", "Sumatera Barat", "Riau", "Jambi", "Sumatera Selatan", 
    "Bengkulu", "Lampung", "Kepulauan Bangka Belitung", "Kepulauan Riau", "DKI Jakarta", 
    "Jawa Barat", "Jawa Tengah", "DI Yogyakarta", "Jawa Timur", "Banten", "Bali", 
    "Nusa Tenggara Barat", "Nusa Tenggara Timur", "Kalimantan Barat", "Kalimantan Tengah", 
    "Kalimantan Selatan", "Kalimantan Timur", "Kalimantan Utara", "Sulawesi Utara", 
    "Sulawesi Tengah", "Sulawesi Selatan", "Sulawesi Tenggara", "Gorontalo", 
    "Sulawesi Barat", "Maluku", "Maluku Utara", "Papua", "Papua Barat"
];
?>

<div class="tab-pane" id="shipping">
    <div class="card mb-4 premium-card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0 fade-in"><i class="fa fa-truck me-2 float"></i>Alamat Pengiriman</h5>
            <button type="button" class="btn-primary add-address-btn premium-button ripple-effect" data-bs-toggle="modal" data-bs-target="#addAddressModal">
                <i class="fas fa-plus-circle float"></i> Tambah Alamat Baru
            </button>
        </div>
        <div class="card-body">
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error_messages'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <ul class="mb-0">
                        <?php foreach ($_SESSION['error_messages'] as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['error_messages']); ?>
            <?php endif; ?>
            <p class="address-info">
                Tambahkan alamat pengiriman untuk memudahkan pengiriman mobil yang Anda menangkan dalam lelang.
            </p>
            
            <?php if (!$shipping_result || $shipping_result->num_rows == 0): ?>
                <div class="empty-state">
                    <i class="fas fa-map-marker-alt empty-icon"></i>
                    <p>Anda belum memiliki alamat pengiriman</p>
                    <button type="button" class="btn-add-first" data-bs-toggle="modal" data-bs-target="#addAddressModal">
                        Tambah Alamat Baru
                    </button>
                </div>
            <?php else: ?>
                <div class="address-list">
                    <?php while ($address = $shipping_result->fetch_assoc()): ?>
                        <div class="address-card fade-in <?php echo $address['is_primary'] ? 'primary' : ''; ?>">
                            <?php if ($address['is_primary']): ?>
                                <div class="address-type">Utama</div>
                            <?php endif; ?>
                            
                            <div class="address-name"><?php echo htmlspecialchars($address['recipient_name']); ?></div>
                            <div class="address-phone"><?php echo htmlspecialchars($address['phone']); ?></div>
                            <div class="address-details">
                                <?php echo htmlspecialchars($address['address_line1']); ?>
                                <?php if (!empty($address['address_line2'])): ?>, <?php echo htmlspecialchars($address['address_line2']); ?><?php endif; ?><br>
                                <?php echo htmlspecialchars($address['city']); ?>, <?php echo htmlspecialchars($address['province']); ?> <?php echo htmlspecialchars($address['postal_code']); ?>
                            </div>
                            
                            <div class="address-actions">
                                <?php if (!$address['is_primary']): ?>
                                    <form method="post" action="process_shipping.php" class="d-inline">
                                        <input type="hidden" name="address_id" value="<?php echo $address['id']; ?>">
                                        <button type="submit" name="set_primary_address" class="btn-address btn-primary-address">
                                            <i class="fas fa-check-circle"></i> Jadikan Utama
                                        </button>
                                    </form>
                                <?php endif; ?>
                                
                                <button type="button" class="btn-address btn-edit" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#editAddressModal" 
                                    data-id="<?php echo $address['id']; ?>"
                                    data-name="<?php echo htmlspecialchars($address['recipient_name']); ?>"
                                    data-phone="<?php echo htmlspecialchars($address['phone']); ?>"
                                    data-line1="<?php echo htmlspecialchars($address['address_line1']); ?>"
                                    data-line2="<?php echo htmlspecialchars($address['address_line2']); ?>"
                                    data-city="<?php echo htmlspecialchars($address['city']); ?>"
                                    data-province="<?php echo htmlspecialchars($address['province']); ?>"
                                    data-postal="<?php echo htmlspecialchars($address['postal_code']); ?>">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                
                                <form method="post" action="process_shipping.php" class="d-inline delete-address-form">
                                    <input type="hidden" name="address_id" value="<?php echo $address['id']; ?>">
                                    <button type="submit" name="delete_address" class="btn-address btn-delete">
                                        <i class="fas fa-trash"></i> Hapus
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add Address Modal -->
<div class="modal fade" id="addAddressModal" tabindex="-1" aria-labelledby="addAddressModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addAddressModalLabel">Tambah Alamat Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="process_shipping.php" method="post">
                <div class="modal-body">
                    <div class="form-group mb-3">
                        <label class="form-label" for="recipientName">Nama Penerima*</label>
                        <input type="text" class="form-control" id="recipientName" name="recipient_name" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label class="form-label" for="phoneNumber">Nomor Telepon*</label>
                        <input type="text" class="form-control" id="phoneNumber" name="phone" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label class="form-label" for="addressLine1">Alamat Baris 1*</label>
                        <input type="text" class="form-control" id="addressLine1" name="address_line1" placeholder="Nama jalan, nomor rumah" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label class="form-label" for="addressLine2">Alamat Baris 2</label>
                        <input type="text" class="form-control" id="addressLine2" name="address_line2" placeholder="Apartemen, suite, unit, dll. (opsional)">
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="province">Provinsi*</label>
                                <select class="form-select" id="province" name="province" required>
                                    <option value="">Pilih Provinsi</option>
                                    <?php foreach ($provinces as $province): ?>
                                        <option value="<?php echo $province; ?>"><?php echo $province; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="city">Kota*</label>
                                <select class="form-select" id="city" name="city" required>
                                    <option value="">Pilih Kota</option>
                                    <?php foreach ($locations as $location): ?>
                                        <option value="<?php echo $location; ?>"><?php echo $location; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label class="form-label" for="postalCode">Kode Pos*</label>
                        <input type="text" class="form-control" id="postalCode" name="postal_code" required>
                    </div>
                    
                    <div class="form-check mb-3">
                        <input type="checkbox" class="form-check-input" id="isPrimary" name="is_primary" value="1">
                        <label class="form-check-label" for="isPrimary">Jadikan sebagai alamat utama</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="add_address" class="btn btn-primary">Simpan Alamat</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Address Modal -->
<div class="modal fade" id="editAddressModal" tabindex="-1" aria-labelledby="editAddressModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editAddressModalLabel">Edit Alamat</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="process_shipping.php" method="post">
                <input type="hidden" id="editAddressId" name="address_id">
                <div class="modal-body">
                    <div class="form-group mb-3">
                        <label class="form-label" for="editRecipientName">Nama Penerima*</label>
                        <input type="text" class="form-control" id="editRecipientName" name="recipient_name" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label class="form-label" for="editPhoneNumber">Nomor Telepon*</label>
                        <input type="text" class="form-control" id="editPhoneNumber" name="phone" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label class="form-label" for="editAddressLine1">Alamat Baris 1*</label>
                        <input type="text" class="form-control" id="editAddressLine1" name="address_line1" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label class="form-label" for="editAddressLine2">Alamat Baris 2</label>
                        <input type="text" class="form-control" id="editAddressLine2" name="address_line2">
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="editProvince">Provinsi*</label>
                                <select class="form-select" id="editProvince" name="province" required>
                                    <option value="">Pilih Provinsi</option>
                                    <?php foreach ($provinces as $province): ?>
                                        <option value="<?php echo $province; ?>"><?php echo $province; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="editCity">Kota*</label>
                                <select class="form-select" id="editCity" name="city" required>
                                    <option value="">Pilih Kota</option>
                                    <?php foreach ($locations as $location): ?>
                                        <option value="<?php echo $location; ?>"><?php echo $location; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label class="form-label" for="editPostalCode">Kode Pos*</label>
                        <input type="text" class="form-control" id="editPostalCode" name="postal_code" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="update_address" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Edit Address Modal
    const editAddressModal = document.getElementById('editAddressModal');
    if (editAddressModal) {
        editAddressModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            
            // Extract address data from data attributes
            const id = button.getAttribute('data-id');
            const name = button.getAttribute('data-name');
            const phone = button.getAttribute('data-phone');
            const line1 = button.getAttribute('data-line1');
            const line2 = button.getAttribute('data-line2');
            const city = button.getAttribute('data-city');
            const province = button.getAttribute('data-province');
            const postal = button.getAttribute('data-postal');
            
            // Populate form fields
            document.getElementById('editAddressId').value = id;
            document.getElementById('editRecipientName').value = name;
            document.getElementById('editPhoneNumber').value = phone;
            document.getElementById('editAddressLine1').value = line1;
            document.getElementById('editAddressLine2').value = line2 || '';
            document.getElementById('editCity').value = city;
            document.getElementById('editProvince').value = province;
            document.getElementById('editPostalCode').value = postal;
        });
    }
    
    // Delete Address Confirmation
    const deleteAddressForms = document.querySelectorAll('.delete-address-form');
    deleteAddressForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!confirm('Apakah Anda yakin ingin menghapus alamat ini?')) {
                e.preventDefault();
            }
        });
    });
});
</script>
