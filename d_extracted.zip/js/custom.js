/**
 * LelangMobil Custom JavaScript
 * Versi: 2.0 (2025-05-02)
 * 
 * File ini berisi fungsi-fungsi custom untuk website LelangMobil
 * yang tidak termasuk dalam plugin atau library lain
 */

document.addEventListener('DOMContentLoaded', function() {
    // Aktifkan dark mode premium
    activatePremiumDarkMode();
    
    // Aktifkan animasi dan efek premium lainnya
    initPremiumEffects();
    
    // Init tooltips dan popovers
    initTooltipsAndPopovers();
    
    // Deteksi perangkat untuk penyesuaian UI
    checkDeviceAndAdjustUI();
});

/**
 * Aktifkan dark mode premium dengan efek visual tingkat tinggi
 */
function activatePremiumDarkMode() {
    // Tambahkan class untuk dark mode
    document.body.classList.add('dark-scheme', 'premium-theme');
    
    // Aktifkan efek glassmorphism pada card dan container
    const glassElements = document.querySelectorAll('.card, .ultra-card, .stats-box, .filter-container');
    glassElements.forEach(el => {
        el.classList.add('ultra-glass');
    });
}

/**
 * Inisialisasi efek premium untuk meningkatkan UX
 */
function initPremiumEffects() {
    // Efek ripple pada button dan card
    const rippleElements = document.querySelectorAll('.btn, .ultra-btn, .nav-link, .ultra-tab');
    rippleElements.forEach(el => {
        el.addEventListener('click', function(e) {
            let x = e.clientX - e.target.getBoundingClientRect().left;
            let y = e.clientY - e.target.getBoundingClientRect().top;
            
            let ripple = document.createElement('span');
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple-effect');
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
    
    // Smooth scroll untuk anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Animated counters for statistics
    const animateCounter = (el) => {
        const target = parseInt(el.getAttribute('data-target'));
        const duration = 2000; // 2 seconds
        const start = Date.now();
        const step = () => {
            const now = Date.now();
            const elapsed = now - start;
            const progress = Math.min(elapsed / duration, 1);
            const currentValue = Math.floor(progress * target);
            el.textContent = currentValue.toLocaleString();
            if (progress < 1) {
                window.requestAnimationFrame(step);
            } else {
                el.textContent = target.toLocaleString();
            }
        };
        window.requestAnimationFrame(step);
    };
    
    // Start counter animation when element is in viewport
    const counters = document.querySelectorAll('.count-number');
    const observerOptions = {
        threshold: 0.1
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    counters.forEach(counter => {
        observer.observe(counter);
    });
}

/**
 * Inisialisasi tooltip dan popover Bootstrap
 */
function initTooltipsAndPopovers() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}

/**
 * Deteksi perangkat dan sesuaikan UI
 */
function checkDeviceAndAdjustUI() {
    const isMobile = window.innerWidth < 768;
    const isTablet = window.innerWidth >= 768 && window.innerWidth < 992;
    
    if (isMobile) {
        // Penyesuaian UI untuk mobile
        document.body.classList.add('mobile-view');
        adjustMobileLayout();
    } else if (isTablet) {
        // Penyesuaian UI untuk tablet
        document.body.classList.add('tablet-view');
    } else {
        // Penyesuaian UI untuk desktop
        document.body.classList.add('desktop-view');
    }
}

/**
 * Penyesuaian layout untuk perangkat mobile
 */
function adjustMobileLayout() {
    // Sederhanakan layout untuk tampilan mobile
    const tables = document.querySelectorAll('.table-responsive');
    tables.forEach(table => {
        table.classList.add('table-mobile-optimized');
    });
    
    // Sesuaikan padding dan margin untuk tampilan mobile
    const containers = document.querySelectorAll('.container, .card, .card-body');
    containers.forEach(container => {
        container.classList.add('mobile-padding');
    });
}

// Global utility functions
window.formatCurrency = function(amount) {
    return 'Rp ' + parseFloat(amount).toLocaleString('id-ID');
};

window.formatDateTime = function(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', { 
        day: 'numeric', 
        month: 'long', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
};

window.formatDate = function(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', { 
        day: 'numeric', 
        month: 'long', 
        year: 'numeric'
    });
};
