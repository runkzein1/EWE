<?php
// Set page title
$page_title = "Tambah/Edit Kendaraan";

// Include header
include 'includes/header.php';

$error = '';
$success = '';

// Check if editing existing vehicle
$isEditing = false;
$vehicle = null;

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $vehicle_id = intval($_GET['id']);
    
    // Get vehicle data
    $vehicle_sql = "SELECT * FROM vehicles WHERE vehicle_id = ?";
    $vehicle_stmt = $conn->prepare($vehicle_sql);
    $vehicle_stmt->bind_param("i", $vehicle_id);
    $vehicle_stmt->execute();
    $vehicle_result = $vehicle_stmt->get_result();
    
    if ($vehicle_result->num_rows > 0) {
        $vehicle = $vehicle_result->fetch_assoc();
        $isEditing = true;
        $page_title = "Edit Kendaraan: " . $vehicle['title'];
        
        // Get vehicle images
        $images_sql = "SELECT * FROM vehicle_images WHERE vehicle_id = ? ORDER BY is_main DESC";
        $images_stmt = $conn->prepare($images_sql);
        $images_stmt->bind_param("i", $vehicle_id);
        $images_stmt->execute();
        $images_result = $images_stmt->get_result();
        
        // Get vehicle specifications
        $specs_sql = "SELECT * FROM vehicle_specs WHERE vehicle_id = ? ORDER BY spec_id";
        $specs_stmt = $conn->prepare($specs_sql);
        $specs_stmt->bind_param("i", $vehicle_id);
        $specs_stmt->execute();
        $specs_result = $specs_stmt->get_result();
    } else {
        $error = "Kendaraan tidak ditemukan.";
    }
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Basic validation
    if (empty($_POST['title']) || empty($_POST['description']) || empty($_POST['make']) || 
        empty($_POST['model']) || empty($_POST['year']) || empty($_POST['starting_price'])) {
        $error = "Harap isi semua kolom yang diperlukan.";
    } else {
        // Get form data
        $title = clean_input($_POST['title']);
        $description = clean_input($_POST['description']);
        $make = clean_input($_POST['make']);
        $model = clean_input($_POST['model']);
        $year = intval($_POST['year']);
        $mileage = intval($_POST['mileage']);
        $condition_rating = intval($_POST['condition_rating']);
        $starting_price = floatval($_POST['starting_price']);
        $reserve_price = !empty($_POST['reserve_price']) ? floatval($_POST['reserve_price']) : null;
        $auction_start = clean_input($_POST['auction_start']);
        $auction_end = clean_input($_POST['auction_end']);
        $status = clean_input($_POST['status']);
        $seller_id = intval($_POST['seller_id']);
        
        // Prepare SQL statement
        if ($isEditing) {
            // Update existing vehicle
            $sql = "UPDATE vehicles SET 
                    title = ?, description = ?, make = ?, model = ?, year = ?, 
                    mileage = ?, condition_rating = ?, starting_price = ?, reserve_price = ?, 
                    auction_start = ?, auction_end = ?, status = ?, seller_id = ? 
                    WHERE vehicle_id = ?";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssiiiissssii", 
                $title, $description, $make, $model, $year, 
                $mileage, $condition_rating, $starting_price, $reserve_price, 
                $auction_start, $auction_end, $status, $seller_id, $vehicle_id);
        } else {
            // Insert new vehicle
            $sql = "INSERT INTO vehicles (
                    title, description, make, model, year, 
                    mileage, condition_rating, starting_price, reserve_price, 
                    auction_start, auction_end, status, seller_id) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssiiiissssi", 
                $title, $description, $make, $model, $year, 
                $mileage, $condition_rating, $starting_price, $reserve_price, 
                $auction_start, $auction_end, $status, $seller_id);
        }
        
        if ($stmt->execute()) {
            if (!$isEditing) {
                $vehicle_id = $conn->insert_id;
            }
            
            // Handle specifications
            if (isset($_POST['spec_names']) && isset($_POST['spec_values'])) {
                $spec_names = $_POST['spec_names'];
                $spec_values = $_POST['spec_values'];
                
                // Delete existing specs if editing
                if ($isEditing) {
                    $conn->query("DELETE FROM vehicle_specs WHERE vehicle_id = $vehicle_id");
                }
                
                // Insert new specs
                for ($i = 0; $i < count($spec_names); $i++) {
                    if (!empty($spec_names[$i]) && !empty($spec_values[$i])) {
                        $spec_name = clean_input($spec_names[$i]);
                        $spec_value = clean_input($spec_values[$i]);
                        
                        $spec_sql = "INSERT INTO vehicle_specs (vehicle_id, spec_name, spec_value) VALUES (?, ?, ?)";
                        $spec_stmt = $conn->prepare($spec_sql);
                        $spec_stmt->bind_param("iss", $vehicle_id, $spec_name, $spec_value);
                        $spec_stmt->execute();
                    }
                }
            }
            
            // Handle image uploads (would need to implement file upload functionality)
            // This is a placeholder for file upload handling
            
            $success = $isEditing ? "Kendaraan berhasil diperbarui." : "Kendaraan baru berhasil ditambahkan.";
            
            if (!$isEditing) {
                // Redirect to edit page for the new vehicle
                header("Location: vehicle-form.php?id=$vehicle_id&success=1");
                exit;
            } else {
                // Refresh vehicle data
                $vehicle_stmt->execute();
                $vehicle_result = $vehicle_stmt->get_result();
                $vehicle = $vehicle_result->fetch_assoc();
                
                // Refresh specs
                $specs_stmt->execute();
                $specs_result = $specs_stmt->get_result();
            }
        } else {
            $error = "Terjadi kesalahan: " . $conn->error;
        }
    }
}

// Get seller list for dropdown
$sellers_sql = "SELECT user_id, username FROM users ORDER BY username";
$sellers_result = $conn->query($sellers_sql);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><?php echo $isEditing ? "Edit Kendaraan" : "Tambah Kendaraan Baru"; ?></h1>
    <a href="vehicles.php" class="btn btn-secondary">
        <i class="fa fa-arrow-left"></i> Kembali ke Daftar
    </a>
</div>

<?php if(!empty($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if(!empty($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<?php if(isset($_GET['success']) && $_GET['success'] == 1): ?>
    <div class="alert alert-success">Kendaraan baru berhasil ditambahkan.</div>
<?php endif; ?>

<div class="de-box">
    <form method="post" action="" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-8">
                <h4 class="mb-3">Informasi Dasar</h4>
                
                <div class="mb-3">
                    <label for="title" class="form-label">Judul Kendaraan</label>
                    <input type="text" class="form-control" id="title" name="title" required 
                           value="<?php echo $isEditing ? $vehicle['title'] : ''; ?>">
                </div>
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="make" class="form-label">Merek</label>
                            <input type="text" class="form-control" id="make" name="make" required 
                                   value="<?php echo $isEditing ? $vehicle['make'] : ''; ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="model" class="form-label">Model</label>
                            <input type="text" class="form-control" id="model" name="model" required 
                                   value="<?php echo $isEditing ? $vehicle['model'] : ''; ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="year" class="form-label">Tahun</label>
                            <input type="number" class="form-control" id="year" name="year" required min="1900" max="<?php echo date('Y') + 1; ?>" 
                                   value="<?php echo $isEditing ? $vehicle['year'] : date('Y'); ?>">
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="mileage" class="form-label">Kilometer</label>
                            <input type="number" class="form-control" id="mileage" name="mileage" required min="0" 
                                   value="<?php echo $isEditing ? $vehicle['mileage'] : '0'; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="condition_rating" class="form-label">Kondisi (1-10)</label>
                            <input type="number" class="form-control" id="condition_rating" name="condition_rating" required min="1" max="10" 
                                   value="<?php echo $isEditing ? $vehicle['condition_rating'] : '8'; ?>">
                        </div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label">Deskripsi</label>
                    <textarea class="form-control" id="description" name="description" rows="5" required><?php echo $isEditing ? $vehicle['description'] : ''; ?></textarea>
                </div>
                
                <h4 class="mb-3 mt-4">Spesifikasi Tambahan</h4>
                <div id="specifications-container">
                    <?php if ($isEditing && $specs_result->num_rows > 0): ?>
                        <?php while ($spec = $specs_result->fetch_assoc()): ?>
                            <div class="row mb-2 spec-row">
                                <div class="col-md-5">
                                    <input type="text" class="form-control" name="spec_names[]" placeholder="Nama Spesifikasi" value="<?php echo $spec['spec_name']; ?>">
                                </div>
                                <div class="col-md-5">
                                    <input type="text" class="form-control" name="spec_values[]" placeholder="Nilai" value="<?php echo $spec['spec_value']; ?>">
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-danger btn-remove-spec"><i class="fa fa-times"></i></button>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="row mb-2 spec-row">
                            <div class="col-md-5">
                                <input type="text" class="form-control" name="spec_names[]" placeholder="Nama Spesifikasi">
                            </div>
                            <div class="col-md-5">
                                <input type="text" class="form-control" name="spec_values[]" placeholder="Nilai">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-danger btn-remove-spec"><i class="fa fa-times"></i></button>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <button type="button" class="btn btn-secondary btn-add-spec">
                        <i class="fa fa-plus"></i> Tambah Spesifikasi
                    </button>
                </div>
            </div>
            
            <div class="col-md-4">
                <h4 class="mb-3">Informasi Lelang</h4>
                
                <div class="mb-3">
                    <label for="starting_price" class="form-label">Harga Awal (Rp)</label>
                    <input type="number" class="form-control" id="starting_price" name="starting_price" required min="0" step="1000" 
                           value="<?php echo $isEditing ? $vehicle['starting_price'] : ''; ?>">
                </div>
                
                <div class="mb-3">
                    <label for="reserve_price" class="form-label">Harga Minimum (Rp, opsional)</label>
                    <input type="number" class="form-control" id="reserve_price" name="reserve_price" min="0" step="1000" 
                           value="<?php echo $isEditing && $vehicle['reserve_price'] ? $vehicle['reserve_price'] : ''; ?>">
                    <small class="text-muted">Harga minimum yang harus tercapai agar kendaraan terjual</small>
                </div>
                
                <div class="mb-3">
                    <label for="auction_start" class="form-label">Tanggal Mulai Lelang</label>
                    <input type="datetime-local" class="form-control" id="auction_start" name="auction_start" required 
                           value="<?php echo $isEditing ? date('Y-m-d\TH:i', strtotime($vehicle['auction_start'])) : ''; ?>">
                </div>
                
                <div class="mb-3">
                    <label for="auction_end" class="form-label">Tanggal Berakhir Lelang</label>
                    <input type="datetime-local" class="form-control" id="auction_end" name="auction_end" required 
                           value="<?php echo $isEditing ? date('Y-m-d\TH:i', strtotime($vehicle['auction_end'])) : ''; ?>">
                </div>
                
                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-control form-select" id="status" name="status" required>
                        <option value="upcoming" <?php echo $isEditing && $vehicle['status'] == 'upcoming' ? 'selected' : ''; ?>>Akan Datang</option>
                        <option value="active" <?php echo $isEditing && $vehicle['status'] == 'active' ? 'selected' : ''; ?>>Aktif</option>
                        <option value="ended" <?php echo $isEditing && $vehicle['status'] == 'ended' ? 'selected' : ''; ?>>Berakhir</option>
                        <option value="sold" <?php echo $isEditing && $vehicle['status'] == 'sold' ? 'selected' : ''; ?>>Terjual</option>
                        <option value="not_sold" <?php echo $isEditing && $vehicle['status'] == 'not_sold' ? 'selected' : ''; ?>>Tidak Terjual</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label for="seller_id" class="form-label">Penjual</label>
                    <select class="form-control form-select" id="seller_id" name="seller_id" required>
                        <option value="">Pilih Penjual</option>
                        <?php while ($seller = $sellers_result->fetch_assoc()): ?>
                            <option value="<?php echo $seller['user_id']; ?>" <?php echo $isEditing && $vehicle['seller_id'] == $seller['user_id'] ? 'selected' : ''; ?>>
                                <?php echo $seller['username']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <?php if ($isEditing): ?>
                    <div class="mb-3">
                        <label for="current_bid" class="form-label">Bid Saat Ini</label>
                        <input type="text" class="form-control" id="current_bid" value="<?php echo $vehicle['current_bid'] ? format_currency($vehicle['current_bid']) : 'Belum ada bid'; ?>" readonly>
                    </div>
                    
                    <?php if ($vehicle['current_bidder']): ?>
                        <?php
                        // Get current bidder username
                        $bidder_sql = "SELECT username FROM users WHERE user_id = ?";
                        $bidder_stmt = $conn->prepare($bidder_sql);
                        $bidder_stmt->bind_param("i", $vehicle['current_bidder']);
                        $bidder_stmt->execute();
                        $bidder_result = $bidder_stmt->get_result();
                        $bidder = $bidder_result->fetch_assoc();
                        ?>
                        <div class="mb-3">
                            <label for="current_bidder" class="form-label">Penawar Tertinggi</label>
                            <input type="text" class="form-control" id="current_bidder" value="<?php echo $bidder['username']; ?>" readonly>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                
                <h4 class="mb-3 mt-4">Gambar Kendaraan</h4>
                
                <?php if ($isEditing): ?>
                    <div class="mb-3">
                        <div class="row">
                            <?php if($images_result->num_rows > 0): ?>
                                <?php while ($image = $images_result->fetch_assoc()): ?>
                                    <div class="col-md-6 mb-2">
                                        <div class="card">
                                            <img src="../<?php echo $image['image_url']; ?>" class="card-img-top" alt="Vehicle Image">
                                            <div class="card-body p-2 text-center">
                                                <?php if ($image['is_main']): ?>
                                                    <span class="badge bg-primary">Gambar Utama</span>
                                                <?php else: ?>
                                                    <button type="button" class="btn btn-sm btn-primary set-main-btn" data-image-id="<?php echo $image['image_id']; ?>" data-vehicle-id="<?php echo $vehicle_id; ?>">Set Utama</button>
                                                <?php endif; ?>
                                                <button type="button" class="btn btn-sm btn-danger delete-image-btn" data-image-id="<?php echo $image['image_id']; ?>">Hapus</button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="col-12">
                                    <div class="alert alert-info">
                                        <i class="fa fa-info-circle"></i> Belum ada gambar untuk kendaraan ini. Silakan upload gambar.
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <h5>Upload Gambar Baru</h5>
                        <div class="custom-file">
                            <input type="file" class="form-control" id="vehicle_images" name="vehicle_images[]" multiple accept="image/*">
                            <small class="text-muted">Anda dapat memilih beberapa gambar sekaligus. Format yang didukung: JPG, JPEG, PNG, GIF.</small>
                        </div>
                        <div id="image-preview" class="mt-2 row"></div>
                        <button type="button" id="upload-images-btn" class="btn btn-primary mt-2">
                            <i class="fa fa-upload"></i> Upload Gambar
                        </button>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">
                        <i class="fa fa-exclamation-triangle"></i> Untuk mengupload gambar, Anda harus menyimpan data kendaraan terlebih dahulu.
                    </div>
                <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-4">
            <button type="submit" class="btn btn-primary btn-lg">
                <?php echo $isEditing ? 'Simpan Perubahan' : 'Tambah Kendaraan'; ?>
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add specification row
    document.querySelector('.btn-add-spec').addEventListener('click', function() {
        const container = document.getElementById('specifications-container');
        const newRow = document.createElement('div');
        newRow.className = 'row mb-2 spec-row';
        newRow.innerHTML = `
            <div class="col-md-5">
                <input type="text" class="form-control" name="spec_names[]" placeholder="Nama Spesifikasi">
            </div>
            <div class="col-md-5">
                <input type="text" class="form-control" name="spec_values[]" placeholder="Nilai">
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-danger btn-remove-spec"><i class="fa fa-times"></i></button>
            </div>
        `;
        container.appendChild(newRow);
        
        // Add event listener to the new remove button
        newRow.querySelector('.btn-remove-spec').addEventListener('click', function() {
            container.removeChild(newRow);
        });
    });
    
    // Remove specification row
    document.querySelectorAll('.btn-remove-spec').forEach(button => {
        button.addEventListener('click', function() {
            const row = this.closest('.spec-row');
            row.parentNode.removeChild(row);
        });
    });
    
    // Validate dates
    document.querySelector('form').addEventListener('submit', function(e) {
        const startDate = new Date(document.getElementById('auction_start').value);
        const endDate = new Date(document.getElementById('auction_end').value);
        
        if (endDate <= startDate) {
            e.preventDefault();
            alert('Tanggal berakhir lelang harus setelah tanggal mulai lelang.');
        }
    });
    
    // Image Upload Functionality
    const vehicleId = <?php echo $isEditing ? $vehicle_id : 0; ?>;
    
    if (vehicleId > 0) {
        // Handle file selection for preview
        const imageInput = document.getElementById('vehicle_images');
        const imagePreview = document.getElementById('image-preview');
        const uploadBtn = document.getElementById('upload-images-btn');
        let selectedFiles = [];
        
        imageInput.addEventListener('change', function() {
            imagePreview.innerHTML = '';
            selectedFiles = Array.from(this.files);
            
            selectedFiles.forEach((file, index) => {
                if (!file.type.match('image.*')) {
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    const col = document.createElement('div');
                    col.className = 'col-md-3 mb-2';
                    col.innerHTML = `
                        <div class="card">
                            <img src="${e.target.result}" class="card-img-top" alt="Preview">
                            <div class="card-body p-2 text-center">
                                <small>${file.name}</small>
                            </div>
                        </div>
                    `;
                    imagePreview.appendChild(col);
                };
                reader.readAsDataURL(file);
            });
        });
        
        // Upload Images
        uploadBtn.addEventListener('click', function() {
            if (selectedFiles.length === 0) {
                alert('Silakan pilih gambar terlebih dahulu.');
                return;
            }
            
            // Upload each file
            selectedFiles.forEach((file, index) => {
                const formData = new FormData();
                formData.append('action', 'vehicle_image_upload');
                formData.append('vehicle_id', vehicleId);
                formData.append('file', file);
                formData.append('is_main', index === 0 && document.querySelectorAll('.set-main-btn').length === 0 ? 1 : 0);
                
                fetch('upload-handler.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Add the uploaded image to the gallery
                        const imageGallery = document.querySelector('.row:has(.card)');
                        if (imageGallery) {
                            const newImage = document.createElement('div');
                            newImage.className = 'col-md-6 mb-2';
                            newImage.id = `image-container-${data.image_id}`;
                            
                            const isMainClass = data.is_main ? 'bg-primary' : 'btn-primary set-main-btn';
                            const isMainText = data.is_main ? 'Gambar Utama' : 'Set Utama';
                            const isMainTag = data.is_main ? 'span' : 'button';
                            
                            newImage.innerHTML = `
                                <div class="card">
                                    <img src="../${data.image_url}" class="card-img-top" alt="Vehicle Image">
                                    <div class="card-body p-2 text-center">
                                        ${data.is_main ? 
                                          '<span class="badge bg-primary">Gambar Utama</span>' : 
                                          `<button type="button" class="btn btn-sm btn-primary set-main-btn" data-image-id="${data.image_id}" data-vehicle-id="${vehicleId}">Set Utama</button>`
                                        }
                                        <button type="button" class="btn btn-sm btn-danger delete-image-btn" data-image-id="${data.image_id}">Hapus</button>
                                    </div>
                                </div>
                            `;
                            
                            imageGallery.appendChild(newImage);
                            
                            // Add event listeners to new buttons
                            const newSetMainBtn = newImage.querySelector('.set-main-btn');
                            if (newSetMainBtn) {
                                newSetMainBtn.addEventListener('click', handleSetMainClick);
                            }
                            
                            const newDeleteBtn = newImage.querySelector('.delete-image-btn');
                            if (newDeleteBtn) {
                                newDeleteBtn.addEventListener('click', handleDeleteClick);
                            }
                        }
                        
                        // Clear the file input and preview
                        imageInput.value = '';
                        imagePreview.innerHTML = '';
                        selectedFiles = [];
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Terjadi kesalahan saat mengunggah gambar.');
                });
            });
        });
        
        // Set Main Image
        function handleSetMainClick() {
            const imageId = this.dataset.imageId;
            const vehicleId = this.dataset.vehicleId;
            
            const formData = new FormData();
            formData.append('action', 'set_main_image');
            formData.append('image_id', imageId);
            formData.append('vehicle_id', vehicleId);
            
            fetch('upload-handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Refresh the page to show updated main image
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Terjadi kesalahan saat mengatur gambar utama.');
            });
        }
        
        // Add event listeners to existing Set Main buttons
        document.querySelectorAll('.set-main-btn').forEach(btn => {
            btn.addEventListener('click', handleSetMainClick);
        });
        
        // Delete Image
        function handleDeleteClick() {
            if (!confirm('Apakah Anda yakin ingin menghapus gambar ini?')) {
                return;
            }
            
            const imageId = this.dataset.imageId;
            const container = document.getElementById(`image-container-${imageId}`);
            
            const formData = new FormData();
            formData.append('action', 'delete_image');
            formData.append('image_id', imageId);
            
            fetch('upload-handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove the image from the DOM
                    if (container) {
                        container.remove();
                    }
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Terjadi kesalahan saat menghapus gambar.');
            });
        }
        
        // Add event listeners to existing Delete buttons
        document.querySelectorAll('.delete-image-btn').forEach(btn => {
            btn.addEventListener('click', handleDeleteClick);
        });
    }
});
</script>

<?php
// Include footer
include 'includes/footer.php';
?>
