<?php
/**
 * Two-Factor Authentication Setup Page for LelangMobil
 * Version: 1.0 (14 Mei 2025)
 *
 * This page allows users to set up 2FA for their accounts
 */

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Include necessary files
require_once 'config/database.php';
require_once 'config/security.php';
require_once 'config/two_factor_auth.php';

// Initialize variables
$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';
$secret = '';
$qrCodeUrl = '';
$backupCodes = [];
$is2faEnabled = is2FAEnabled($user_id);

// If 2FA is already enabled, get unused backup codes
if ($is2faEnabled) {
    $backupCodes = getUnusedBackupCodes($user_id);
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // CSRF token validation
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid security token. Please try again.';
    } else {
        
        // Enable 2FA
        if (isset($_POST['enable_2fa']) && !$is2faEnabled) {
            $secret = $_POST['secret'] ?? '';
            $code = $_POST['verification_code'] ?? '';
            
            if (empty($secret) || empty($code)) {
                $error_message = 'Verification code cannot be empty.';
            } else if (verify2FACode($secret, $code)) {
                $result = enable2FA($user_id, $secret);
                
                if ($result && isset($result['success'])) {
                    $backupCodes = $result['backup_codes'];
                    $is2faEnabled = true;
                    $success_message = 'Two-factor authentication has been enabled successfully. Please save your backup codes!';
                } else {
                    $error_message = 'Failed to enable two-factor authentication. Please try again.';
                }
            } else {
                $error_message = 'Invalid verification code. Please try again.';
            }
        }
        
        // Disable 2FA
        if (isset($_POST['disable_2fa']) && $is2faEnabled) {
            $code = $_POST['verification_code'] ?? '';
            $is2faSecret = get2FASecret($user_id);
            
            if (empty($code)) {
                $error_message = 'Verification code cannot be empty.';
            } else if (verify2FACode($is2faSecret, $code) || verifyBackupCode($user_id, $code)) {
                if (disable2FA($user_id)) {
                    $is2faEnabled = false;
                    $success_message = 'Two-factor authentication has been disabled successfully.';
                } else {
                    $error_message = 'Failed to disable two-factor authentication. Please try again.';
                }
            } else {
                $error_message = 'Invalid verification code. Please try again.';
            }
        }
        
        // Regenerate backup codes
        if (isset($_POST['regenerate_codes']) && $is2faEnabled) {
            $code = $_POST['verification_code'] ?? '';
            $is2faSecret = get2FASecret($user_id);
            
            if (empty($code)) {
                $error_message = 'Verification code cannot be empty.';
            } else if (verify2FACode($is2faSecret, $code) || verifyBackupCode($user_id, $code)) {
                $newCodes = regenerateBackupCodes($user_id);
                
                if ($newCodes) {
                    $backupCodes = $newCodes;
                    $success_message = 'Backup codes have been regenerated successfully. Please save your new backup codes!';
                } else {
                    $error_message = 'Failed to regenerate backup codes. Please try again.';
                }
            } else {
                $error_message = 'Invalid verification code. Please try again.';
            }
        }
    }
}

// Generate new secret and QR code URL if 2FA is not enabled
if (!$is2faEnabled) {
    $secret = generate2FASecret();
    $username = $_SESSION['username'];
    $qrCodeUrl = getQRCodeUrl($username, $secret);
}

// Set page title
$page_title = 'Two-Factor Authentication Setup';

// Include header
include_once 'includes/header.php';
?>

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-shield-alt"></i> <?php echo $page_title; ?></h4>
                </div>
                
                <div class="card-body">
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success_message)): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mb-4">
                        <h5 class="text-muted">Status:</h5>
                        <div class="d-flex align-items-center">
                            <?php if ($is2faEnabled): ?>
                                <span class="badge bg-success p-2">
                                    <i class="fas fa-check"></i> Enabled
                                </span>
                                <span class="ms-2 text-muted">Your account is protected with two-factor authentication.</span>
                            <?php else: ?>
                                <span class="badge bg-warning p-2">
                                    <i class="fas fa-times"></i> Disabled
                                </span>
                                <span class="ms-2 text-muted">Your account is not protected with two-factor authentication.</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php if (!$is2faEnabled): ?>
                        <!-- Enable 2FA Section -->
                        <form method="post" id="enable2faForm">
                            <?php echo generateCSRFToken(); ?>
                            <input type="hidden" name="secret" value="<?php echo $secret; ?>">
                            
                            <div class="mb-4">
                                <h5>Set up Two-Factor Authentication</h5>
                                <p>Two-factor authentication adds an extra layer of security to your account. In addition to your password, you'll need a code from your phone to log in.</p>
                            </div>
                            
                            <div class="mb-4">
                                <h6>1. Scan this QR code with your authenticator app</h6>
                                <div class="d-flex flex-column align-items-center my-3">
                                    <div class="qr-code-container bg-light p-3 rounded mb-3">
                                        <img src="<?php echo $qrCodeUrl; ?>" alt="QR Code" class="img-fluid">
                                    </div>
                                    <div class="mt-2">
                                        <strong>Secret Key:</strong> <span class="secret-key"><?php echo $secret; ?></span>
                                    </div>
                                    <div class="text-muted small mt-1">
                                        If you can't scan the QR code, enter this secret key manually in your app.
                                    </div>
                                </div>
                                
                                <div class="app-links mt-3">
                                    <small class="text-muted">Recommended authenticator apps: 
                                        <a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2" target="_blank">Google Authenticator</a>, 
                                        <a href="https://authy.com/download/" target="_blank">Authy</a>,
                                        <a href="https://play.google.com/store/apps/details?id=com.azure.authenticator" target="_blank">Microsoft Authenticator</a>
                                    </small>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <h6>2. Enter the verification code from your app</h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="verification_code" class="form-label">Verification Code</label>
                                            <input type="text" class="form-control" name="verification_code" id="verification_code" placeholder="Enter 6-digit code">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <button type="submit" name="enable_2fa" class="btn btn-primary">
                                    <i class="fas fa-lock"></i> Enable Two-Factor Authentication
                                </button>
                            </div>
                        </form>
                    <?php else: ?>
                        <!-- 2FA Enabled Options -->
                        <div class="mb-4">
                            <h5>Manage Two-Factor Authentication</h5>
                            
                            <?php if (!empty($backupCodes)): ?>
                                <!-- Backup Codes Section -->
                                <div class="backup-codes-section my-4 p-3 border rounded bg-light">
                                    <h6 class="text-danger"><i class="fas fa-exclamation-triangle"></i> Backup Codes</h6>
                                    <p class="small text-muted">Save these backup codes in a secure place. You can use them to log in if you lose access to your authenticator app.</p>
                                    
                                    <div class="backup-codes-list d-flex flex-wrap mb-3">
                                        <?php foreach ($backupCodes as $code): ?>
                                            <div class="backup-code bg-white p-2 m-1 border rounded"><?php echo $code; ?></div>
                                        <?php endforeach; ?>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between">
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="printBackupCodes()">
                                            <i class="fas fa-print"></i> Print
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="copyBackupCodes()">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="downloadBackupCodes()">
                                            <i class="fas fa-download"></i> Download
                                        </button>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <!-- Manage 2FA Forms -->
                            <div class="d-flex flex-column mt-4">
                                <form method="post" id="regenerateCodesForm" class="mb-3">
                                    <?php echo generateCSRFToken(); ?>
                                    <div class="row g-3 align-items-end">
                                        <div class="col-md-6">
                                            <label for="verification_code_regen" class="form-label">Enter verification code to regenerate backup codes</label>
                                            <input type="text" class="form-control" name="verification_code" id="verification_code_regen" placeholder="Enter 6-digit code">
                                        </div>
                                        <div class="col-md-6">
                                            <button type="submit" name="regenerate_codes" class="btn btn-warning">
                                                <i class="fas fa-sync-alt"></i> Regenerate Backup Codes
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                
                                <form method="post" id="disable2faForm">
                                    <?php echo generateCSRFToken(); ?>
                                    <div class="row g-3 align-items-end">
                                        <div class="col-md-6">
                                            <label for="verification_code_disable" class="form-label">Enter verification code to disable 2FA</label>
                                            <input type="text" class="form-control" name="verification_code" id="verification_code_disable" placeholder="Enter 6-digit code">
                                        </div>
                                        <div class="col-md-6">
                                            <button type="submit" name="disable_2fa" class="btn btn-danger" onclick="return confirm('Are you sure you want to disable two-factor authentication? This will make your account less secure.');">
                                                <i class="fas fa-unlock"></i> Disable Two-Factor Authentication
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="card-footer">
                    <a href="account.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Account
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyBackupCodes() {
    const codes = [];
    document.querySelectorAll('.backup-code').forEach(el => {
        codes.push(el.textContent.trim());
    });
    
    const textToCopy = codes.join('\n');
    navigator.clipboard.writeText(textToCopy).then(() => {
        alert('Backup codes copied to clipboard!');
    }).catch(err => {
        console.error('Failed to copy: ', err);
        alert('Failed to copy backup codes. Please try again.');
    });
}

function downloadBackupCodes() {
    const codes = [];
    document.querySelectorAll('.backup-code').forEach(el => {
        codes.push(el.textContent.trim());
    });
    
    const textToDownload = 'LelangMobil Backup Codes\n\n' + codes.join('\n') + '\n\nKeep these codes in a safe place.';
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(textToDownload));
    element.setAttribute('download', 'lelangmobil-backup-codes.txt');
    
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

function printBackupCodes() {
    const codes = [];
    document.querySelectorAll('.backup-code').forEach(el => {
        codes.push(el.textContent.trim());
    });
    
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
        <head>
            <title>LelangMobil Backup Codes</title>
            <style>
                body { font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 20px; }
                h1 { font-size: 24px; margin-bottom: 10px; }
                h2 { font-size: 18px; margin-top: 20px; margin-bottom: 10px; }
                .codes { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin: 20px 0; }
                .code { padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-family: monospace; font-size: 16px; }
                .footer { margin-top: 30px; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <h1>LelangMobil Backup Codes</h1>
            <p>These backup codes can be used to access your account if you lose your phone or cannot use your authenticator app.</p>
            <p>Each code can only be used once. Keep these codes in a safe place.</p>
            
            <h2>Your Backup Codes:</h2>
            <div class="codes">
                ${codes.map(code => `<div class="code">${code}</div>`).join('')}
            </div>
            
            <div class="footer">
                <p>Generated on: ${new Date().toLocaleDateString()}</p>
                <p>If you lose these codes and cannot access your authenticator app, you will need to contact support.</p>
            </div>
        </body>
        </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
}
</script>

<style>
.qr-code-container {
    display: flex;
    justify-content: center;
    width: 200px;
    height: 200px;
}

.secret-key {
    font-family: monospace;
    background-color: #f5f5f5;
    padding: 5px 10px;
    border-radius: 4px;
    border: 1px solid #ddd;
}

.backup-codes-list {
    max-width: 500px;
}

.backup-code {
    font-family: monospace;
    font-size: 1.1rem;
    letter-spacing: 1px;
}
</style>

<?php include_once 'includes/footer.php'; ?>
