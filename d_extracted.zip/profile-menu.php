<?php
// Aktifkan error reporting dan logging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data user
$user_query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "User tidak ditemukan.";
    header("Location: login.php");
    exit;
}

$user = $result->fetch_assoc();

// Proses update profil
$update_message = '';
$update_success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $postal_code = $_POST['postal_code'] ?? '';
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validasi
    if (empty($full_name) || empty($email) || empty($phone)) {
        $update_message = '<div class="alert alert-danger">Nama lengkap, email dan nomor telepon wajib diisi.</div>';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $update_message = '<div class="alert alert-danger">Format email tidak valid.</div>';
    } else {
        // Update data profil
        $update_sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, address = ?, city = ?, postal_code = ? WHERE user_id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("ssssssi", $full_name, $email, $phone, $address, $city, $postal_code, $user_id);
        
        if ($stmt->execute()) {
            $update_success = true;
            $update_message = '<div class="alert alert-success"><i class="fa fa-check-circle me-2"></i>Profil berhasil diperbarui.</div>';
            
            // Jika ada perubahan password
            if (!empty($current_password) && !empty($new_password) && !empty($confirm_password)) {
                // Verifikasi password lama
                if (password_verify($current_password, $user['password'])) {
                    // Validasi password baru
                    if ($new_password === $confirm_password) {
                        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                        $password_sql = "UPDATE users SET password = ? WHERE user_id = ?";
                        $stmt = $conn->prepare($password_sql);
                        $stmt->bind_param("si", $hashed_password, $user_id);
                        
                        if ($stmt->execute()) {
                            $update_message = '<div class="alert alert-success"><i class="fa fa-check-circle me-2"></i>Profil dan password berhasil diperbarui.</div>';
                        } else {
                            $update_message = '<div class="alert alert-warning"><i class="fa fa-check-circle me-2"></i>Profil berhasil diperbarui, tetapi gagal memperbarui password.</div>';
                        }
                    } else {
                        $update_message = '<div class="alert alert-warning"><i class="fa fa-check-circle me-2"></i>Profil berhasil diperbarui, tetapi password baru dan konfirmasi tidak cocok.</div>';
                    }
                } else {
                    $update_message = '<div class="alert alert-warning"><i class="fa fa-check-circle me-2"></i>Profil berhasil diperbarui, tetapi password lama tidak valid.</div>';
                }
            }
            
            // Refresh data user
            $stmt = $conn->prepare($user_query);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
        } else {
            $update_message = '<div class="alert alert-danger">Gagal memperbarui profil. Silakan coba lagi.</div>';
        }
    }
}

// Proses upload foto profil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_photo'])) {
    $upload_dir = 'uploads/profile_photos/';
    
    // Buat direktori jika belum ada
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    $file_name = $_FILES['profile_photo']['name'];
    $file_tmp = $_FILES['profile_photo']['tmp_name'];
    $file_type = $_FILES['profile_photo']['type'];
    $file_size = $_FILES['profile_photo']['size'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    $extensions = array("jpeg", "jpg", "png");
    
    if (in_array($file_ext, $extensions)) {
        if ($file_size < 5000000) { // Maksimal 5MB
            $new_file_name = "user_" . $user_id . "_" . time() . "." . $file_ext;
            $file_path = $upload_dir . $new_file_name;
            
            if (move_uploaded_file($file_tmp, $file_path)) {
                // Update path foto di database
                $photo_sql = "UPDATE users SET profile_photo = ? WHERE user_id = ?";
                $stmt = $conn->prepare($photo_sql);
                $stmt->bind_param("si", $file_path, $user_id);
                
                if ($stmt->execute()) {
                    $update_success = true;
                    $update_message = '<div class="alert alert-success"><i class="fa fa-check-circle me-2"></i>Foto profil berhasil diperbarui.</div>';
                    
                    // Refresh data user
                    $stmt = $conn->prepare($user_query);
                    $stmt->bind_param("i", $user_id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $user = $result->fetch_assoc();
                } else {
                    $update_message = '<div class="alert alert-danger">Gagal memperbarui database. Silakan coba lagi.</div>';
                }
            } else {
                $update_message = '<div class="alert alert-danger">Gagal mengupload foto. Silakan coba lagi.</div>';
            }
        } else {
            $update_message = '<div class="alert alert-danger">Ukuran file terlalu besar. Maksimal 5MB.</div>';
        }
    } else {
        $update_message = '<div class="alert alert-danger">Format file tidak didukung. Gunakan JPEG, JPG atau PNG.</div>';
    }
}

// Aktifkan flag untuk halaman dashboard dan tema ultra-modern
$page_title = "Profil Saya";
$is_dashboard_page = true;
$use_ultra_modern = true;
$use_premium_effects = true;
$modern_js_files = true;

// CSS tambahan untuk halaman ini
$page_specific_css = '<link href="css/profile-premium.css" rel="stylesheet" type="text/css">';

// JS tambahan untuk halaman ini
$page_specific_js = '<script src="js/profile-modern.js"></script>';

// Include header
include('includes/header.php');
?>

<div class="dashboard-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="page-title">Profil Saya</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                        <li class="breadcrumb-item"><a href="account.php">Akun Saya</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Profil Saya</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container py-5">
    <div class="row">
        <!-- Menu Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="account-menu-card">
                <div class="user-profile mb-4">
                    <div class="user-avatar">
                        <?php if (!empty($user['profile_photo']) && file_exists($user['profile_photo'])): ?>
                            <img src="<?php echo $user['profile_photo']; ?>" alt="Profile Photo" class="avatar-img">
                        <?php else: ?>
                            <div class="avatar-text">
                                <?php echo strtoupper(substr($user['username'] ?? 'U', 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="user-info mt-2">
                        <h5 class="mb-1"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h5>
                        <p class="text-muted mb-0">ID: <?php echo $user['user_id']; ?></p>
                    </div>
                </div>
                
                <div class="menu-items">
                    <a href="account.php" class="menu-item">
                        <i class="fa fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="topup-menu.php" class="menu-item">
                        <i class="fa fa-wallet"></i> Top-up Saldo
                    </a>
                    <a href="withdraw-menu.php" class="menu-item">
                        <i class="fa fa-money-bill-wave"></i> Tarik Saldo
                    </a>
                    <a href="transactions-menu.php" class="menu-item">
                        <i class="fa fa-history"></i> Riwayat Transaksi
                    </a>
                    <a href="bids-menu.php" class="menu-item">
                        <i class="fa fa-gavel"></i> Bid Saya
                    </a>
                    <a href="profile-menu.php" class="menu-item active">
                        <i class="fa fa-user"></i> Profil
                    </a>
                    <a href="?logout=true" class="menu-item">
                        <i class="fa fa-sign-out-alt"></i> Keluar
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-lg-9">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <!-- Profile Card -->
                    <div class="card profile-card">
                        <div class="card-body text-center">
                            <div class="profile-photo-container">
                                <?php if (!empty($user['profile_photo']) && file_exists($user['profile_photo'])): ?>
                                    <img src="<?php echo $user['profile_photo']; ?>" alt="Profile Photo" class="profile-photo">
                                <?php else: ?>
                                    <div class="profile-photo-placeholder">
                                        <span><?php echo strtoupper(substr($user['username'] ?? 'U', 0, 1)); ?></span>
                                    </div>
                                <?php endif; ?>
                                <button type="button" class="btn btn-sm btn-primary change-photo-btn" data-bs-toggle="modal" data-bs-target="#uploadPhotoModal">
                                    <i class="fa fa-camera"></i>
                                </button>
                            </div>
                            
                            <h4 class="mt-3 mb-1"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h4>
                            <p class="text-muted mb-2"><?php echo htmlspecialchars($user['email'] ?? ''); ?></p>
                            <p class="text-muted mb-3">
                                <i class="fa fa-phone-alt me-2"></i><?php echo htmlspecialchars($user['phone'] ?? 'Belum diatur'); ?>
                            </p>
                            
                            <div class="user-info-list">
                                <div class="user-info-item">
                                    <div class="info-label">Username</div>
                                    <div class="info-value"><?php echo htmlspecialchars($user['username']); ?></div>
                                </div>
                                <div class="user-info-item">
                                    <div class="info-label">Bergabung Sejak</div>
                                    <div class="info-value"><?php echo date('d M Y', strtotime($user['created_at'])); ?></div>
                                </div>
                                <div class="user-info-item">
                                    <div class="info-label">Status</div>
                                    <div class="info-value">
                                        <?php if ($user['is_active'] == 1): ?>
                                            <span class="badge bg-success">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Nonaktif</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Security Card -->
                    <div class="card mt-4 security-card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="fa fa-shield-alt me-2"></i>Keamanan Akun</h5>
                        </div>
                        <div class="card-body">
                            <div class="security-item">
                                <div class="security-icon bg-success">
                                    <i class="fa fa-lock"></i>
                                </div>
                                <div class="security-info">
                                    <h6>Password</h6>
                                    <p class="text-muted mb-0">Terakhir diperbarui: <?php echo date('d M Y', strtotime($user['updated_at'] ?? $user['created_at'])); ?></p>
                                </div>
                                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                                    Ubah
                                </button>
                            </div>
                            
                            <div class="security-item">
                                <div class="security-icon <?php echo !empty($user['email']) ? 'bg-success' : 'bg-warning'; ?>">
                                    <i class="fa fa-envelope"></i>
                                </div>
                                <div class="security-info">
                                    <h6>Email</h6>
                                    <p class="text-muted mb-0"><?php echo !empty($user['email']) ? htmlspecialchars($user['email']) : 'Belum diatur'; ?></p>
                                </div>
                                <a href="#email-section" class="btn btn-sm btn-outline-primary">
                                    Ubah
                                </a>
                            </div>
                            
                            <div class="security-item">
                                <div class="security-icon <?php echo !empty($user['phone']) ? 'bg-success' : 'bg-warning'; ?>">
                                    <i class="fa fa-phone-alt"></i>
                                </div>
                                <div class="security-info">
                                    <h6>Nomor Telepon</h6>
                                    <p class="text-muted mb-0"><?php echo !empty($user['phone']) ? htmlspecialchars($user['phone']) : 'Belum diatur'; ?></p>
                                </div>
                                <a href="#phone-section" class="btn btn-sm btn-outline-primary">
                                    Ubah
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><i class="fa fa-user-edit me-2"></i>Edit Profil</h5>
                        </div>
                        <div class="card-body">
                            <?php echo $update_message; ?>
                            
                            <?php if ($update_success): ?>
                                <div class="success-animation mb-4">
                                    <div class="checkmark-circle">
                                        <div class="checkmark draw"></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <form method="POST" action="" id="profileForm">
                                <input type="hidden" name="update_profile" value="1">
                                
                                <div class="mb-3">
                                    <label for="full_name" class="form-label">Nama Lengkap</label>
                                    <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
                                </div>
                                
                                <div class="mb-3" id="email-section">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                                </div>
                                
                                <div class="mb-3" id="phone-section">
                                    <label for="phone" class="form-label">Nomor Telepon</label>
                                    <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="address" class="form-label">Alamat</label>
                                    <textarea class="form-control" id="address" name="address" rows="2"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="city" class="form-label">Kota</label>
                                        <input type="text" class="form-control" id="city" name="city" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="postal_code" class="form-label">Kode Pos</label>
                                        <input type="text" class="form-control" id="postal_code" name="postal_code" value="<?php echo htmlspecialchars($user['postal_code'] ?? ''); ?>">
                                    </div>
                                </div>
                                
                                <button type="submit" class="btn btn-primary btn-lg w-100 mt-3">
                                    <i class="fa fa-save me-2"></i>Simpan Perubahan
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Upload Photo Modal -->
<div class="modal fade" id="uploadPhotoModal" tabindex="-1" aria-labelledby="uploadPhotoModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="uploadPhotoModalLabel">Upload Foto Profil</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="" enctype="multipart/form-data" id="photoUploadForm">
                    <div class="upload-area" id="uploadArea">
                        <div class="upload-icon">
                            <i class="fa fa-cloud-upload-alt"></i>
                        </div>
                        <p>Drag & drop foto di sini atau klik untuk memilih</p>
                        <input type="file" id="profile_photo" name="profile_photo" accept="image/jpeg, image/jpg, image/png" class="file-input">
                    </div>
                    
                    <div class="preview-container mt-3 d-none" id="previewContainer">
                        <img src="" alt="Preview" id="imagePreview" class="img-fluid rounded">
                        <button type="button" class="btn btn-sm btn-danger mt-2" id="removeImage">
                            <i class="fa fa-times me-1"></i>Hapus
                        </button>
                    </div>
                    
                    <div class="upload-info mt-3">
                        <h6>Petunjuk:</h6>
                        <ul>
                            <li>Format yang didukung: JPEG, JPG, PNG</li>
                            <li>Ukuran maksimal: 5MB</li>
                            <li>Disarankan resolusi: 300x300 piksel</li>
                        </ul>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" id="uploadButton" disabled>
                            <i class="fa fa-upload me-1"></i>Upload
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="changePasswordModalLabel">Ubah Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="passwordChangeForm" method="POST" action="">
                    <input type="hidden" name="update_profile" value="1">
                    <input type="hidden" name="full_name" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>">
                    <input type="hidden" name="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>">
                    <input type="hidden" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                    
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Password Saat Ini</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="current_password" name="current_password" required>
                            <button class="btn btn-outline-secondary toggle-password" type="button" data-target="current_password">
                                <i class="fa fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="new_password" class="form-label">Password Baru</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="new_password" name="new_password" required minlength="8">
                            <button class="btn btn-outline-secondary toggle-password" type="button" data-target="new_password">
                                <i class="fa fa-eye"></i>
                            </button>
                        </div>
                        <div class="password-strength mt-2">
                            <div class="progress">
                                <div id="password-strength-bar" class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <small id="password-strength-text" class="form-text text-muted">Kekuatan password: Belum diisi</small>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Konfirmasi Password Baru</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="8">
                            <button class="btn btn-outline-secondary toggle-password" type="button" data-target="confirm_password">
                                <i class="fa fa-eye"></i>
                            </button>
                        </div>
                        <div id="password-match" class="form-text"></div>
                    </div>
                    
                    <div class="password-guidelines alert alert-info">
                        <h6 class="mb-2"><i class="fa fa-info-circle me-2"></i>Petunjuk Password</h6>
                        <ul class="mb-0 ps-3">
                            <li>Minimal 8 karakter</li>
                            <li>Kombinasi huruf besar dan kecil</li>
                            <li>Minimal 1 angka</li>
                            <li>Minimal 1 karakter khusus (contoh: !@#$%^&*)</li>
                        </ul>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" id="changePasswordBtn">
                            <i class="fa fa-save me-1"></i>Simpan Password
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
