<?php
/**
 * Security Notification System for LelangMobil
 * Version: 1.0 (14 Mei 2025)
 *
 * This file manages the security notifications for the LelangMobil platform,
 * alerting users of suspicious activities and important security events.
 */

/**
 * Create security notification tables if they don't exist
 */
function createSecurityNotificationTables() {
    global $conn;
    
    $sql = "
    CREATE TABLE IF NOT EXISTS `security_notifications` (
      `notification_id` INT AUTO_INCREMENT PRIMARY KEY,
      `user_id` INT NOT NULL,
      `notification_type` VARCHAR(50) NOT NULL,
      `title` VARCHAR(255) NOT NULL,
      `message` TEXT NOT NULL,
      `is_read` TINYINT(1) DEFAULT 0,
      `is_important` TINYINT(1) DEFAULT 0,
      `requires_action` TINYINT(1) DEFAULT 0,
      `action_url` VARCHAR(255) NULL,
      `created_at` DATETIME NOT NULL,
      `read_at` DATETIME NULL,
      KEY `idx_notification_user` (`user_id`),
      KEY `idx_notification_read` (`is_read`),
      KEY `idx_notification_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    
    CREATE TABLE IF NOT EXISTS `notification_preferences` (
      `preference_id` INT AUTO_INCREMENT PRIMARY KEY,
      `user_id` INT NOT NULL,
      `notification_type` VARCHAR(50) NOT NULL,
      `email_enabled` TINYINT(1) DEFAULT 1,
      `sms_enabled` TINYINT(1) DEFAULT 0,
      `push_enabled` TINYINT(1) DEFAULT 1,
      `in_app_enabled` TINYINT(1) DEFAULT 1,
      `updated_at` DATETIME,
      UNIQUE KEY `idx_user_notification_type` (`user_id`, `notification_type`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";
    
    $queries = explode(';', $sql);
    
    foreach ($queries as $query) {
        if (trim($query) === '') continue;
        
        if (!$conn->query($query)) {
            error_log("Failed to create security notification tables: " . $conn->error);
            return false;
        }
    }
    
    return true;
}

/**
 * Create a new security notification for a user
 *
 * @param int $userId User ID to notify
 * @param string $type Notification type (e.g., 'login_attempt', 'password_changed')
 * @param string $title Short title of the notification
 * @param string $message Detailed message for the notification
 * @param bool $isImportant Whether this is a high-priority notification
 * @param bool $requiresAction Whether the user needs to take action
 * @param string|null $actionUrl URL to direct the user for action (if applicable)
 * @return bool True on success, false on failure
 */
function createSecurityNotification($userId, $type, $title, $message, $isImportant = false, $requiresAction = false, $actionUrl = null) {
    global $conn;
    
    $sql = "INSERT INTO security_notifications (
                user_id, notification_type, title, message, 
                is_important, requires_action, action_url, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
    
    $stmt = $conn->prepare($sql);
    $isImportantInt = $isImportant ? 1 : 0;
    $requiresActionInt = $requiresAction ? 1 : 0;
    
    $stmt->bind_param("isssiis", $userId, $type, $title, $message, $isImportantInt, $requiresActionInt, $actionUrl);
    
    $success = $stmt->execute();
    
    if ($success) {
        // Check notification preferences and send via other channels if enabled
        sendNotificationBasedOnPreferences($userId, $type, $title, $message, $actionUrl);
    }
    
    return $success;
}

/**
 * Send notification based on user preferences
 */
function sendNotificationBasedOnPreferences($userId, $type, $title, $message, $actionUrl = null) {
    global $conn;
    
    // Get user's notification preferences
    $sql = "SELECT * FROM notification_preferences WHERE user_id = ? AND notification_type = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $userId, $type);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // If no specific preferences, get default preferences
    if ($result->num_rows === 0) {
        $sql = "SELECT * FROM notification_preferences WHERE user_id = ? AND notification_type = 'default'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
    }
    
    if ($row = $result->fetch_assoc()) {
        // Send email notification if enabled
        if ($row['email_enabled']) {
            sendSecurityEmailNotification($userId, $title, $message, $actionUrl);
        }
        
        // Send SMS notification if enabled
        if ($row['sms_enabled']) {
            sendSecuritySMSNotification($userId, $title);
        }
        
        // Send push notification if enabled
        if ($row['push_enabled']) {
            sendSecurityPushNotification($userId, $title, $message, $actionUrl);
        }
    } else {
        // If no preferences found, send email by default
        sendSecurityEmailNotification($userId, $title, $message, $actionUrl);
    }
}

/**
 * Send security notification via email
 */
function sendSecurityEmailNotification($userId, $title, $message, $actionUrl = null) {
    global $conn;
    
    // Get user email
    $sql = "SELECT email, username FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $email = $row['email'];
        $username = $row['username'];
        
        // Include mailer configuration
        require_once __DIR__ . '/mailer.php';
        
        // HTML email template
        $template = getSecurityEmailTemplate($username, $title, $message, $actionUrl);
        
        // Send email
        $mail = setupPHPMailer();
        $mail->addAddress($email);
        $mail->Subject = "LelangMobil Security Alert: $title";
        $mail->Body = $template;
        
        try {
            $mail->send();
        } catch (Exception $e) {
            error_log("Failed to send security email notification: " . $mail->ErrorInfo);
        }
    }
}

/**
 * Get HTML email template for security notifications
 */
function getSecurityEmailTemplate($username, $title, $message, $actionUrl = null) {
    $siteName = "LelangMobil";
    $siteUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'];
    $year = date('Y');
    
    $actionButton = '';
    if ($actionUrl) {
        $actionButton = <<<HTML
        <tr>
            <td align="center" style="padding: 20px 0;">
                <a href="$actionUrl" style="background-color: #00a0e3; color: white; padding: 12px 30px; text-decoration: none; border-radius: 4px; font-weight: bold; display: inline-block;">Take Action</a>
            </td>
        </tr>
        HTML;
    }
    
    return <<<HTML
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>$title</title>
    </head>
    <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
        <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-collapse: collapse;">
            <tr>
                <td align="center" bgcolor="#00a0e3" style="padding: 20px 0; color: white;">
                    <h1 style="margin: 0;">Security Alert</h1>
                </td>
            </tr>
            <tr>
                <td style="padding: 20px 30px;">
                    <p>Dear $username,</p>
                    <p>We detected a security-related event on your LelangMobil account:</p>
                    <div style="background-color: #f8f8f8; padding: 15px; border-left: 4px solid #00a0e3; margin: 20px 0;">
                        <h2 style="margin-top: 0; color: #333;">$title</h2>
                        <p style="margin-bottom: 0;">$message</p>
                    </div>
                    <p>If you didn't perform this action, please secure your account immediately by changing your password and enabling two-factor authentication.</p>
                </td>
            </tr>
            $actionButton
            <tr>
                <td style="padding: 20px 30px;">
                    <p>For assistance, please contact our support team.</p>
                    <p>Best regards,<br>The $siteName Team</p>
                </td>
            </tr>
            <tr>
                <td bgcolor="#f8f8f8" style="padding: 15px 30px; font-size: 12px; color: #666; text-align: center;">
                    <p>&copy; $year $siteName. All rights reserved.</p>
                    <p>
                        <a href="$siteUrl/account.php" style="color: #00a0e3; text-decoration: none;">Account Settings</a> | 
                        <a href="$siteUrl/privacy-policy.php" style="color: #00a0e3; text-decoration: none;">Privacy Policy</a>
                    </p>
                </td>
            </tr>
        </table>
    </body>
    </html>
    HTML;
}

/**
 * Send security notification via SMS (placeholder - implement with SMS gateway)
 */
function sendSecuritySMSNotification($userId, $title) {
    global $conn;
    
    // Get user phone number
    $sql = "SELECT phone FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc() && !empty($row['phone'])) {
        $phone = $row['phone'];
        
        // Prepare SMS content
        $content = "LelangMobil Security Alert: $title. Please check your email or app for details.";
        
        // In a real implementation, integrate with an SMS gateway API here
        // This is a placeholder for the actual SMS sending logic
        // Example: sendSMS($phone, $content);
        
        error_log("SMS notification would be sent to $phone: $content");
    }
}

/**
 * Send security notification via push notification (placeholder - implement with FCM or other service)
 */
function sendSecurityPushNotification($userId, $title, $message, $actionUrl = null) {
    global $conn;
    
    // Get user's push token
    $sql = "SELECT push_token FROM user_devices WHERE user_id = ? AND push_enabled = 1 ORDER BY last_used DESC LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc() && !empty($row['push_token'])) {
        $token = $row['push_token'];
        
        // In a real implementation, integrate with Firebase Cloud Messaging or other push service
        // This is a placeholder for the actual push notification logic
        // Example: sendPushNotification($token, $title, $message, $actionUrl);
        
        error_log("Push notification would be sent to token: $token, Title: $title");
    }
}

/**
 * Get unread security notifications for a user
 *
 * @param int $userId User ID
 * @param int $limit Maximum number of notifications to return
 * @return array Array of notification objects
 */
function getUnreadSecurityNotifications($userId, $limit = 10) {
    global $conn;
    
    $notifications = [];
    
    $sql = "SELECT * FROM security_notifications 
            WHERE user_id = ? AND is_read = 0 
            ORDER BY is_important DESC, created_at DESC 
            LIMIT ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $userId, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    
    return $notifications;
}

/**
 * Get all security notifications for a user
 *
 * @param int $userId User ID
 * @param int $page Page number (1-based)
 * @param int $perPage Notifications per page
 * @return array Array of notification objects and pagination info
 */
function getAllSecurityNotifications($userId, $page = 1, $perPage = 20) {
    global $conn;
    
    $notifications = [];
    $offset = ($page - 1) * $perPage;
    
    // Get total count for pagination
    $countSql = "SELECT COUNT(*) as total FROM security_notifications WHERE user_id = ?";
    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param("i", $userId);
    $countStmt->execute();
    $countResult = $countStmt->get_result();
    $totalCount = $countResult->fetch_assoc()['total'];
    
    // Get notifications for current page
    $sql = "SELECT * FROM security_notifications 
            WHERE user_id = ? 
            ORDER BY is_read ASC, is_important DESC, created_at DESC 
            LIMIT ? OFFSET ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $userId, $perPage, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    
    return [
        'notifications' => $notifications,
        'pagination' => [
            'total' => $totalCount,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => ceil($totalCount / $perPage)
        ]
    ];
}

/**
 * Mark a security notification as read
 *
 * @param int $notificationId Notification ID
 * @param int $userId User ID (for verification)
 * @return bool True on success, false on failure
 */
function markSecurityNotificationAsRead($notificationId, $userId) {
    global $conn;
    
    $sql = "UPDATE security_notifications 
            SET is_read = 1, read_at = NOW() 
            WHERE notification_id = ? AND user_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $notificationId, $userId);
    
    return $stmt->execute();
}

/**
 * Mark all security notifications as read for a user
 *
 * @param int $userId User ID
 * @return bool True on success, false on failure
 */
function markAllSecurityNotificationsAsRead($userId) {
    global $conn;
    
    $sql = "UPDATE security_notifications 
            SET is_read = 1, read_at = NOW() 
            WHERE user_id = ? AND is_read = 0";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    
    return $stmt->execute();
}

/**
 * Delete a security notification
 *
 * @param int $notificationId Notification ID
 * @param int $userId User ID (for verification)
 * @return bool True on success, false on failure
 */
function deleteSecurityNotification($notificationId, $userId) {
    global $conn;
    
    $sql = "DELETE FROM security_notifications 
            WHERE notification_id = ? AND user_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $notificationId, $userId);
    
    return $stmt->execute();
}

/**
 * Get notification preferences for a user
 *
 * @param int $userId User ID
 * @return array Array of notification preferences
 */
function getNotificationPreferences($userId) {
    global $conn;
    
    $preferences = [];
    
    $sql = "SELECT * FROM notification_preferences WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $preferences[$row['notification_type']] = $row;
    }
    
    return $preferences;
}

/**
 * Update notification preferences for a user
 *
 * @param int $userId User ID
 * @param string $type Notification type
 * @param bool $emailEnabled Whether to send email notifications
 * @param bool $smsEnabled Whether to send SMS notifications
 * @param bool $pushEnabled Whether to send push notifications
 * @param bool $inAppEnabled Whether to show in-app notifications
 * @return bool True on success, false on failure
 */
function updateNotificationPreferences($userId, $type, $emailEnabled, $smsEnabled, $pushEnabled, $inAppEnabled) {
    global $conn;
    
    // Check if preference already exists
    $checkSql = "SELECT preference_id FROM notification_preferences WHERE user_id = ? AND notification_type = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("is", $userId, $type);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    
    if ($result->num_rows > 0) {
        // Update existing preference
        $sql = "UPDATE notification_preferences 
                SET email_enabled = ?, sms_enabled = ?, push_enabled = ?, in_app_enabled = ?, updated_at = NOW() 
                WHERE user_id = ? AND notification_type = ?";
        
        $stmt = $conn->prepare($sql);
        $emailInt = $emailEnabled ? 1 : 0;
        $smsInt = $smsEnabled ? 1 : 0;
        $pushInt = $pushEnabled ? 1 : 0;
        $inAppInt = $inAppEnabled ? 1 : 0;
        
        $stmt->bind_param("iiiis", $emailInt, $smsInt, $pushInt, $inAppInt, $userId, $type);
    } else {
        // Insert new preference
        $sql = "INSERT INTO notification_preferences 
                (user_id, notification_type, email_enabled, sms_enabled, push_enabled, in_app_enabled, updated_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW())";
        
        $stmt = $conn->prepare($sql);
        $emailInt = $emailEnabled ? 1 : 0;
        $smsInt = $smsEnabled ? 1 : 0;
        $pushInt = $pushEnabled ? 1 : 0;
        $inAppInt = $inAppEnabled ? 1 : 0;
        
        $stmt->bind_param("isiiii", $userId, $type, $emailInt, $smsInt, $pushInt, $inAppInt);
    }
    
    return $stmt->execute();
}

/**
 * Notify user of a new login to their account
 *
 * @param int $userId User ID
 * @param string $ipAddress IP address of the login
 * @param string $userAgent Browser/device information
 * @return bool Success status
 */
function notifyNewLogin($userId, $ipAddress, $userAgent) {
    // Get geo location info if available
    $location = getLocationFromIP($ipAddress);
    $locationInfo = $location ? " from " . $location : "";
    
    // Get device info
    $device = getDeviceInfo($userAgent);
    
    $title = "New account login detected";
    $message = "Your account was accessed successfully on " . date('Y-m-d H:i:s') . 
               $locationInfo . " using " . $device . ".\n\n" .
               "If this wasn't you, please secure your account immediately by changing your password " .
               "and enabling two-factor authentication.";
    
    // Determine if this login is suspicious
    $isSuspicious = isLoginSuspicious($userId, $ipAddress, $userAgent);
    
    if ($isSuspicious) {
        $title = "Suspicious login detected!";
        $message = "ALERT: A suspicious login to your account was detected on " . date('Y-m-d H:i:s') . 
                  $locationInfo . " using " . $device . ".\n\n" .
                  "If this wasn't you, please secure your account immediately by changing your password " .
                  "and enabling two-factor authentication.";
        
        // Create security notification with high importance and action required
        return createSecurityNotification(
            $userId, 
            'suspicious_login', 
            $title, 
            $message, 
            true, // Important
            true, // Requires action
            'two-factor-setup.php' // Action URL
        );
    } else {
        // Create regular login notification
        return createSecurityNotification(
            $userId, 
            'new_login', 
            $title, 
            $message,
            false, // Not flagged as important
            false, // No action required
            null
        );
    }
}

/**
 * Notify user of account lockout due to too many failed login attempts
 *
 * @param int $userId User ID
 * @param int $attemptCount Number of failed attempts
 * @param string $lockoutTime Time until account is unlocked
 * @return bool Success status
 */
function notifyAccountLockout($userId, $attemptCount, $lockoutTime) {
    $lockoutTimeFormatted = date('Y-m-d H:i:s', strtotime($lockoutTime));
    
    $title = "Account temporarily locked";
    $message = "Your account has been temporarily locked after " . $attemptCount . " failed login attempts. " .
               "This is a security measure to protect your account from unauthorized access.\n\n" .
               "Your account will be automatically unlocked at " . $lockoutTimeFormatted . ".\n\n" .
               "If you did not attempt to log in, someone else may be trying to access your account. " .
               "We recommend changing your password once your account is unlocked.";
    
    // Create security notification
    return createSecurityNotification(
        $userId, 
        'account_lockout', 
        $title, 
        $message, 
        true, // Important
        true, // Requires action
        'reset-password.php' // Action URL
    );
}

/**
 * Determine if a login attempt is suspicious based on previous login patterns
 *
 * @param int $userId User ID
 * @param string $ipAddress Current IP address
 * @param string $userAgent Current user agent
 * @return bool True if login looks suspicious
 */
function isLoginSuspicious($userId, $ipAddress, $userAgent) {
    global $conn;
    
    // Flag to indicate suspicious activity
    $suspicious = false;
    
    // Check if this IP has been used before by this user
    $sql = "SELECT COUNT(*) as ip_count FROM login_attempts 
            WHERE username = (SELECT username FROM users WHERE user_id = ?) 
            AND ip_address = ? 
            AND success = 1";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $userId, $ipAddress);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    // If this IP has never been used before for successful login
    if ($row['ip_count'] == 0) {
        // Get the user's last location
        $sql = "SELECT ip_address FROM login_attempts 
                WHERE username = (SELECT username FROM users WHERE user_id = ?) 
                AND success = 1 
                ORDER BY attempt_time DESC 
                LIMIT 1";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            $lastIP = $row['ip_address'];
            
            // Check if IPs are from different geographic locations
            $lastLocation = getLocationFromIP($lastIP);
            $currentLocation = getLocationFromIP($ipAddress);
            
            if ($lastLocation && $currentLocation && $lastLocation != $currentLocation) {
                $suspicious = true;
            }
        }
    }
    
    // Check if there were recent failed attempts before this successful login
    $sql = "SELECT COUNT(*) as failed_count FROM login_attempts 
            WHERE username = (SELECT username FROM users WHERE user_id = ?) 
            AND success = 0 
            AND attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    // If there were multiple failed attempts recently
    if ($row['failed_count'] >= 3) {
        $suspicious = true;
    }
    
    return $suspicious;
}

/**
 * Get location information from IP address
 *
 * @param string $ipAddress The IP address
 * @return string|null Location string or null if unavailable
 */
function getLocationFromIP($ipAddress) {
    // For local/internal IPs, return null
    if (filter_var($ipAddress, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return null;
    }
    
    // Simple implementation - in production, use a proper IP geolocation service
    // This is a placeholder implementation
    try {
        // Basic attempt to get geolocation data
        // In production, replace with an actual API call to a geolocation service
        $details = @json_decode(file_get_contents("http://ip-api.com/json/{$ipAddress}"), true);
        
        if ($details && isset($details['status']) && $details['status'] === 'success') {
            return $details['city'] . ', ' . $details['country'];
        }
    } catch (Exception $e) {
        error_log("Error getting location from IP: " . $e->getMessage());
    }
    
    return null;
}

/**
 * Extract device information from user agent
 *
 * @param string $userAgent Browser user agent string
 * @return string Simplified device information
 */
function getDeviceInfo($userAgent) {
    $browser = "Unknown Browser";
    $platform = "Unknown Platform";
    
    // Detect platform
    if (stripos($userAgent, 'windows') !== false) {
        $platform = 'Windows';
    } elseif (stripos($userAgent, 'macintosh') !== false || stripos($userAgent, 'mac os x') !== false) {
        $platform = 'macOS';
    } elseif (stripos($userAgent, 'linux') !== false) {
        $platform = 'Linux';
    } elseif (stripos($userAgent, 'iphone') !== false) {
        $platform = 'iPhone';
    } elseif (stripos($userAgent, 'ipad') !== false) {
        $platform = 'iPad';
    } elseif (stripos($userAgent, 'android') !== false) {
        $platform = 'Android';
    }
    
    // Detect browser
    if (stripos($userAgent, 'firefox') !== false) {
        $browser = 'Firefox';
    } elseif (stripos($userAgent, 'edge') !== false || stripos($userAgent, 'edg/') !== false) {
        $browser = 'Edge';
    } elseif (stripos($userAgent, 'chrome') !== false) {
        $browser = 'Chrome';
    } elseif (stripos($userAgent, 'safari') !== false) {
        $browser = 'Safari';
    } elseif (stripos($userAgent, 'opera') !== false || stripos($userAgent, 'opr/') !== false) {
        $browser = 'Opera';
    }
    
    return "$browser on $platform";
}

// Create notification tables when this file is included
createSecurityNotificationTables();
