/**
 * Dashboard Connection Script
 * Ensures all dashboard features are properly integrated and connected
 * Created: May 6, 2025
 */

document.addEventListener('DOMContentLoaded', function() {
    // Connect profile section with its actions
    connectProfileActions();
    
    // Connect transaction tabs and fix integration
    connectTransactionTabs();
    
    // Fix top-up form integration
    integrateTopUpForm();
    
    // Connect all dashboard tabs
    connectAllTabs();
    
    // Fix activity display
    fixActivityDisplay();
    
    // Connect admin panel integration if needed
    checkAdminIntegration();
    
    // Fix error messages
    fixErrorMessages();
});

/**
 * Connect profile actions to their respective handlers
 */
function connectProfileActions() {
    // Profile avatar click handler
    const profileAvatar = document.querySelector('.user-avatar-lg');
    if (profileAvatar) {
        profileAvatar.addEventListener('click', function() {
            const editProfileBtn = document.querySelector('[data-bs-target="#editProfileModal"]');
            if (editProfileBtn) editProfileBtn.click();
        });
    }
    
    // Fix profile menu items
    const profileMenuItems = document.querySelectorAll('.profile-menu-item');
    profileMenuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            const target = this.getAttribute('data-target');
            if (target) {
                e.preventDefault();
                const tabBtn = document.querySelector(`[data-bs-target="#${target}"]`);
                if (tabBtn) tabBtn.click();
            }
        });
    });
}

/**
 * Fix transaction tabs integration with the UI
 */
function connectTransactionTabs() {
    // Connect transaction tab buttons
    const transactionTabBtn = document.getElementById('transactions-tab');
    if (transactionTabBtn) {
        transactionTabBtn.addEventListener('click', function() {
            const tabContent = document.querySelector('[aria-labelledby="transactions-tab"]');
            if (tabContent) {
                // Show tab content
                const activeTab = document.querySelector('.tab-pane.active');
                if (activeTab) activeTab.classList.remove('active', 'show');
                
                tabContent.classList.add('active', 'show');
                
                // Update nav tabs
                const activeNavLink = document.querySelector('.nav-link.active');
                if (activeNavLink) activeNavLink.classList.remove('active');
                this.classList.add('active');
            }
        });
    }
    
    // Connect view all transactions button
    const viewAllTxBtn = document.querySelector('.view-all-link a');
    if (viewAllTxBtn) {
        viewAllTxBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const transactionTabBtn = document.getElementById('transactions-tab');
            if (transactionTabBtn) transactionTabBtn.click();
        });
    }
}

/**
 * Ensure top-up form is properly integrated
 */
function integrateTopUpForm() {
    // Connect top-up form elements
    const topupPresets = document.querySelectorAll('.ultra-preset-btn, .amount-preset');
    const amountInput = document.getElementById('amount');
    
    // Fix amount formatting
    if (amountInput) {
        amountInput.addEventListener('input', function() {
            this.value = this.value.replace(/\D/g, '');
            if (this.value) {
                this.value = new Intl.NumberFormat('id-ID').format(this.value);
            }
        });
    }
    
    // Fix preset buttons
    topupPresets.forEach(preset => {
        preset.addEventListener('click', function() {
            const amount = this.getAttribute('data-amount');
            
            // Remove active class from all presets
            topupPresets.forEach(p => p.classList.remove('active'));
            
            // Add active class to clicked preset
            this.classList.add('active');
            
            // Set input value
            if (amountInput) {
                amountInput.value = new Intl.NumberFormat('id-ID').format(amount);
            }
        });
    });
    
    // Fix file upload preview
    const fileInput = document.getElementById('proof_image');
    const previewContainer = document.querySelector('.preview-container');
    
    if (fileInput && previewContainer) {
        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    previewContainer.innerHTML = `
                        <div class="preview-image">
                            <img src="${e.target.result}" alt="Preview">
                            <button type="button" class="btn-remove-preview">
                                <i class="fa fa-times"></i>
                            </button>
                        </div>
                    `;
                    
                    // Add remove button functionality
                    const removeBtn = document.querySelector('.btn-remove-preview');
                    if (removeBtn) {
                        removeBtn.addEventListener('click', function() {
                            fileInput.value = '';
                            previewContainer.innerHTML = '';
                        });
                    }
                }
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
}

/**
 * Connect all dashboard tabs to ensure proper navigation
 */
function connectAllTabs() {
    // Fix tab navigation buttons
    document.querySelectorAll('[id$="-tab"]').forEach(tabBtn => {
        if (!tabBtn.hasAttribute('data-bs-toggle')) {
            tabBtn.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Get target tab
                const targetId = this.getAttribute('id').replace('-tab', '');
                const targetTab = document.getElementById(targetId);
                
                if (targetTab) {
                    // Hide all tabs
                    document.querySelectorAll('.tab-pane').forEach(tab => {
                        tab.classList.remove('active', 'show');
                    });
                    
                    // Show target tab
                    targetTab.classList.add('active', 'show');
                    
                    // Update nav tabs
                    document.querySelectorAll('.nav-link').forEach(navLink => {
                        navLink.classList.remove('active');
                    });
                    
                    this.classList.add('active');
                }
            });
        }
    });
    
    // Fix quick action buttons
    const quickActionBtns = document.querySelectorAll('.quick-action-btn');
    quickActionBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const action = this.getAttribute('data-action');
            
            switch(action) {
                case 'topup':
                    document.getElementById('wallet-tab').click();
                    break;
                case 'bid':
                    document.getElementById('bids-tab').click();
                    break;
                case 'profile':
                    document.getElementById('profile-tab').click();
                    break;
            }
        });
    });
}

/**
 * Fix activity display in the dashboard
 */
function fixActivityDisplay() {
    // Fix activity timeline animations
    const activityItems = document.querySelectorAll('.activity-item');
    
    activityItems.forEach((item, index) => {
        // Add delay to each item
        item.style.animationDelay = `${index * 0.1}s`;
        
        // Add hover effect
        item.addEventListener('mouseenter', function() {
            this.classList.add('activity-item-hover');
        });
        
        item.addEventListener('mouseleave', function() {
            this.classList.remove('activity-item-hover');
        });
    });
}

/**
 * Ensure admin panel integration if user is admin
 */
function checkAdminIntegration() {
    // Check if user is admin
    const adminMenuItems = document.querySelectorAll('.admin-menu-item');
    
    if (adminMenuItems.length > 0) {
        // User is admin, ensure admin panel links work
        adminMenuItems.forEach(item => {
            item.addEventListener('click', function(e) {
                const target = this.getAttribute('data-target');
                
                if (target && target.startsWith('admin-')) {
                    e.preventDefault();
                    window.location.href = `admin/${target.replace('admin-', '')}.php`;
                }
            });
        });
    }
}

/**
 * Fix error messages throughout the dashboard
 */
function fixErrorMessages() {
    // Clear any existing error message
    const errorAlert = document.querySelector('.alert-danger');
    if (errorAlert) {
        // Add close button if not exists
        if (!errorAlert.querySelector('.btn-close')) {
            const closeBtn = document.createElement('button');
            closeBtn.className = 'btn-close';
            closeBtn.setAttribute('data-bs-dismiss', 'alert');
            closeBtn.setAttribute('aria-label', 'Close');
            
            errorAlert.appendChild(closeBtn);
        }
        
        // Auto hide after 5 seconds
        setTimeout(() => {
            errorAlert.classList.add('fade');
            setTimeout(() => {
                errorAlert.remove();
            }, 500);
        }, 5000);
    }
}
