<?php
// Aktifkan error reporting dan logging untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Set ke 0 di production

// Atur timeout eksekusi agar tidak loading berulang
set_time_limit(15); // 15 detik maksimum karena upload file bisa lebih lama
ini_set('max_execution_time', 15);

// Auto redirect jika loading terlalu lama
header("Refresh: 20;url=error.php?reason=timeout&page=upload-payment");

// Set error handler untuk menangkap error fatal
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("Error in upload-payment.php: [$errno] $errstr in $errfile:$errline");
    if (in_array($errno, [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        header("Location: error.php?reason=" . urlencode($errstr));
        exit;
    }
    return true;
});

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Inisialisasi variabel
$error_messages = [];
$success_message = '';
$transaction = null;

// Set flags untuk tema dan layout
$page_title = "Upload Bukti Pembayaran";
$is_dashboard_page = true;
$use_ultra_modern = true;
$use_premium_effects = true;

// CSS tambahan untuk halaman ini
$page_specific_css = '<link href="css/payment-upload.css" rel="stylesheet" type="text/css">';

// JS tambahan untuk halaman ini
$page_specific_js = '<script src="js/payment-upload.js"></script>';

// Ambil ID transaksi dari parameter URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_messages'] = ['ID transaksi tidak valid.'];
    header("Location: account.php");
    exit;
}

$transaction_id = (int)$_GET['id'];

// Verifikasi bahwa transaksi ini milik user yang sedang login
$transaction_sql = "SELECT * FROM transactions WHERE transaction_id = ? AND user_id = ? AND type = 'deposit' AND status = 'pending'";
$transaction_stmt = $conn->prepare($transaction_sql);
$transaction_stmt->bind_param("ii", $transaction_id, $user_id);
$transaction_stmt->execute();
$transaction_result = $transaction_stmt->get_result();

if ($transaction_result->num_rows == 0) {
    $_SESSION['error_messages'] = ['Transaksi tidak ditemukan atau bukan milik Anda.'];
    header("Location: account.php");
    exit;
}

$transaction = $transaction_result->fetch_assoc();

// Proses upload gambar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validasi apakah ada file yang diupload
        if (!isset($_FILES['payment_proof'])) {
            throw new Exception('Terjadi kesalahan pada form upload. Silakan refresh halaman dan coba lagi.');
        }
        
        // Check untuk error pada upload
        $upload_error_codes = [
            UPLOAD_ERR_INI_SIZE => 'Ukuran file melebihi batas maksimum yang diizinkan oleh server.',
            UPLOAD_ERR_FORM_SIZE => 'Ukuran file melebihi batas maksimum yang diizinkan oleh form.',
            UPLOAD_ERR_PARTIAL => 'File hanya terupload sebagian. Silakan coba lagi.',
            UPLOAD_ERR_NO_FILE => 'Silakan pilih file bukti pembayaran.',
            UPLOAD_ERR_NO_TMP_DIR => 'Folder temporary tidak ditemukan. Harap hubungi administrator.',
            UPLOAD_ERR_CANT_WRITE => 'Gagal menyimpan file. Harap hubungi administrator.',
            UPLOAD_ERR_EXTENSION => 'Upload dihentikan oleh ekstensi PHP. Harap hubungi administrator.'
        ];
        
        if ($_FILES['payment_proof']['error'] !== UPLOAD_ERR_OK) {
            $error_code = $_FILES['payment_proof']['error'];
            throw new Exception($upload_error_codes[$error_code] ?? 'Terjadi kesalahan saat upload file.');
        }
        
        $file = $_FILES['payment_proof'];
        
        // Validasi jika file kosong
        if ($file['size'] <= 0) {
            throw new Exception('File yang diupload kosong atau tidak valid. Silakan coba lagi.');
        }
        
        // Validasi tipe file dengan pemeriksaan MIME type dan ekstensi
        $allowed_mimes = ['image/jpeg', 'image/png', 'application/pdf'];
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'pdf'];
        
        // Get file extension
        $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        // Validasi ekstensi file
        if (!in_array($file_extension, $allowed_extensions)) {
            throw new Exception('Format file tidak didukung. Gunakan JPG, JPEG, PNG, atau PDF.');
        }
        
        // Validasi MIME type menggunakan finfo
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $file_mime = $finfo->file($file['tmp_name']);
        
        if (!in_array($file_mime, $allowed_mimes)) {
            throw new Exception('Tipe file tidak valid. Gunakan gambar JPG/PNG atau dokumen PDF.');
        }
        
        // Validasi ukuran file (max 5MB)
        if ($file['size'] > 5 * 1024 * 1024) {
            throw new Exception('Ukuran file terlalu besar. Maksimum 5MB.');
        }
        
        // Set timeout untuk operasi database
        $timeout_start = microtime(true);
        
        // Buat direktori uploads/payment_proofs jika belum ada
        $upload_dir = 'uploads/payment_proofs/';
        if (!file_exists($upload_dir)) {
            if (!mkdir($upload_dir, 0777, true) && !is_dir($upload_dir)) {
                throw new Exception('Gagal membuat direktori upload. Harap hubungi administrator.');
            }
        }
        
        // Sanitasi nama file dan generate nama unik
        $base_filename = 'payment_' . (int)$transaction_id . '_' . time();
        $new_filename = $base_filename . '.' . $file_extension;
        $target_file = $upload_dir . $new_filename;
        
        // Mulai database transaction
        try {
            // Disable autocommit mode
            $conn->autocommit(FALSE);
            
            // Upload file
            if (!move_uploaded_file($file['tmp_name'], $target_file)) {
                throw new Exception('Terjadi kesalahan saat menyimpan file. Silakan coba lagi.');
            }
            
            // Validasi bahwa file berhasil disimpan
            if (!file_exists($target_file)) {
                throw new Exception('File gagal tersimpan. Silakan coba lagi.');
            }
            
            // Tambahkan catatan jika ada (dengan sanitasi untuk mencegah XSS)
            $notes = isset($_POST['notes']) ? htmlspecialchars(trim($_POST['notes']), ENT_QUOTES, 'UTF-8') : '';
            
            // Tambahkan informasi device untuk monitoring
            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Device';
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP';
            $device_info = "Uploaded from: " . substr($user_agent, 0, 255) . " | IP: " . $ip_address;
            
            // Tambahkan notes dari user jika ada
            if (!empty($notes)) {
                $detailed_notes = $notes . "\n" . $device_info;
            } else {
                $detailed_notes = $device_info;
            }
            
            // Update status transaksi dan simpan path bukti pembayaran
            $update_sql = "UPDATE transactions SET status = 'verification', payment_proof = ?, notes = CONCAT(IFNULL(notes, ''), ' | ', ?), updated_at = NOW() WHERE transaction_id = ? AND user_id = ? AND status = 'pending'";
            $update_stmt = $conn->prepare($update_sql);
            
            if (!$update_stmt) {
                throw new Exception("Prepare statement error: " . $conn->error);
            }
            
            $update_stmt->bind_param("ssii", $target_file, $detailed_notes, $transaction_id, $user_id);
            $update_result = $update_stmt->execute();
            
            if (!$update_result) {
                throw new Exception("Gagal memperbarui status transaksi: " . $update_stmt->error);
            }
            
            // Cek apakah ada baris yang diupdate
            if ($update_stmt->affected_rows == 0) {
                throw new Exception("Tidak ada transaksi yang diupdate. Transaksi mungkin sudah diproses atau tidak ditemukan.");
            }
            
            // Cek waktu eksekusi
            if ((microtime(true) - $timeout_start) > 10) { // Lebih dari 10 detik
                throw new Exception("Database operation timeout. Harap coba lagi.");
            }
            
            // Optional: Log aktivitas upload
            $log_sql = "INSERT INTO activity_logs (user_id, activity_type, reference_id, details, ip_address) VALUES (?, 'payment_upload', ?, ?, ?)";
            $log_stmt = $conn->prepare($log_sql);
            
            if ($log_stmt) {
                $detail = "Upload bukti pembayaran untuk transaksi #" . $transaction_id;
                $log_stmt->bind_param("iiss", $user_id, $transaction_id, $detail, $ip_address);
                $log_stmt->execute();
            }
            
            // Commit transaksi jika semua berhasil
            $conn->commit();
            
            // Log transaksi berhasil untuk audit
            error_log("Payment proof uploaded successfully: User ID {$user_id}, Transaction ID {$transaction_id}, File {$target_file}");
            
            // Set success message
            $success_message = 'Bukti pembayaran berhasil diupload. Tim kami akan memverifikasi pembayaran Anda dalam 1x24 jam kerja.';
            
            // Set session message untuk redirect
            $_SESSION['success_message'] = $success_message;
            
            // Redirect ke halaman account setelah 2 detik
            echo "<script>setTimeout(function(){ window.location.href = 'account.php'; }, 2000);</script>";
        } catch (Throwable $db_error) {
            // Rollback jika terjadi error
            $conn->rollback();
            
            // Hapus file yang sudah diupload jika ada error database
            if (file_exists($target_file)) {
                @unlink($target_file);
            }
            
            error_log("Database error in upload-payment.php: " . $db_error->getMessage());
            throw new Exception('Terjadi kesalahan saat memproses transaksi: ' . $db_error->getMessage());
        } finally {
            // Reset autocommit mode
            $conn->autocommit(TRUE);
        }
    } catch (Throwable $e) {
        // Tangkap semua exception dan error
        error_log("Error in upload-payment.php processing: " . $e->getMessage());
        $error_messages[] = $e->getMessage();
    }
}

// Include header dengan CSS dan JS yang sudah terintegrasi
include 'includes/header.php';
?>

<style>
    /* CSS tambahan untuk halaman ini */
    .upload-card {
        margin: 30px auto;
        background: white;
        border-radius: 15px;
        padding: 30px;
        box-shadow: 0 15px 35px rgba(0,0,0,0.1);
    }
    .upload-icon {
        font-size: 64px;
        color: var(--primary);
        margin-bottom: 20px;
        text-align: center;
    }
    .upload-area {
        border: 2px dashed var(--accent);
        border-radius: 10px;
        padding: 40px;
        text-align: center;
        margin: 20px 0;
        transition: all 0.3s;
        background: rgba(0,0,0,0.02);
    }
    .upload-area:hover, .upload-area.dragover {
        background: rgba(var(--accent-rgb), 0.1);
        border-color: var(--primary);
    }
    .upload-instructions {
        margin: 20px 0;
        color: var(--dark);
    }
    .transaction-detail {
        background: rgba(var(--accent-rgb), 0.1);
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
    }
    .file-preview {
        max-width: 100%;
        max-height: 300px;
        margin: 20px auto;
        display: none;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    .preview-container {
        text-align: center;
    }
    #file-name {
        font-size: 14px;
        color: var(--dark);
        margin-top: 10px;
    }
</style>

<div class="dashboard-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="page-title">Upload Bukti Pembayaran</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                        <li class="breadcrumb-item"><a href="account.php">Akun Saya</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Upload Bukti Pembayaran</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card upload-card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fa fa-receipt me-2"></i>Upload Bukti Pembayaran</h4>
                </div>
                <div class="card-body">
                    <div class="transaction-info-card mb-4">
                        <div class="row align-items-center">
                            <div class="col-auto">
                                <div class="transaction-icon">
                                    <i class="fa fa-money-bill-wave"></i>
                                </div>
                            </div>
                            <div class="col">
                                <h5 class="mb-1">Detail Transaksi #<?php echo htmlspecialchars($transaction['transaction_id']); ?></h5>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <div class="transaction-detail-item">
                                            <div class="detail-label">ID Transaksi</div>
                                            <div class="detail-value">#<?php echo htmlspecialchars($transaction['transaction_id']); ?></div>
                                        </div>
                                        <div class="transaction-detail-item">
                                            <div class="detail-label">Jumlah</div>
                                            <div class="detail-value fw-bold">Rp <?php echo number_format($transaction['amount'], 0, ',', '.'); ?></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="transaction-detail-item">
                                            <div class="detail-label">Tanggal</div>
                                            <div class="detail-value"><?php echo date('d M Y H:i', strtotime($transaction['created_at'])); ?> WIB</div>
                                        </div>
                                        <div class="transaction-detail-item">
                                            <div class="detail-label">Status</div>
                                            <div class="detail-value"><span class="badge bg-warning">Menunggu Pembayaran</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        
                    <?php if (!empty($error_messages)): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-exclamation-circle me-2"></i>
                            <div>
                                <?php if (count($error_messages) == 1): ?>
                                    <?php echo htmlspecialchars($error_messages[0]); ?>
                                <?php else: ?>
                                <ul class="mb-0 ps-3">
                                    <?php foreach ($error_messages as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success_message)): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-check-circle me-2"></i>
                            <div><?php echo htmlspecialchars($success_message); ?></div>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    
                    <form action="upload-payment.php?id=<?php echo (int)$transaction_id; ?>" method="post" enctype="multipart/form-data" id="uploadForm">
                        <div class="upload-area" id="drop-area">
                            <div class="upload-icon">
                                <i class="fa fa-cloud-upload-alt"></i>
                            </div>
                            <div class="upload-message">
                                <p>Drag & drop bukti pembayaran di sini atau</p>
                                <button type="button" class="btn btn-primary" id="browse-btn">Pilih File</button>
                                <input type="file" name="payment_proof" id="payment_proof" accept="image/*,application/pdf" class="file-input">
                            </div>
                            <div class="file-preview d-none" id="file-preview">
                                <div class="preview-container"></div>
                                <div class="file-info"></div>
                                <button type="button" class="btn btn-sm btn-danger remove-file" id="remove-file">
                                    <i class="fa fa-times me-1"></i>Hapus
                                </button>
                            </div>
                        </div>
                        
                        <div class="form-group mt-4">
                            <label for="notes" class="form-label">Catatan (opsional):</label>
                            <textarea class="form-control" name="notes" id="notes" rows="3" placeholder="Tambahkan catatan jika diperlukan"></textarea>
                        </div>
                        
                        <div class="upload-info alert alert-info mt-3">
                            <h6 class="mb-2"><i class="fa fa-info-circle me-2"></i>Petunjuk Upload:</h6>
                            <ul class="mb-0 ps-3">
                                <li>Format file yang didukung: JPG, JPEG, PNG, dan PDF</li>
                                <li>Ukuran file maksimal 5MB</li>
                                <li>Pastikan bukti pembayaran terlihat jelas</li>
                                <li>Pastikan semua informasi penting seperti nomor referensi dan jumlah terbaca</li>
                            </ul>
                        </div>
                        
                        <div class="d-flex justify-content-between mt-4">
                            <a href="transactions-menu.php" class="btn btn-outline-secondary">
                                <i class="fa fa-arrow-left me-2"></i>Kembali
                            </a>
                            <button type="submit" class="btn btn-primary" id="submitButton">
                                <i class="fa fa-upload me-2"></i>Upload Bukti Pembayaran
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
