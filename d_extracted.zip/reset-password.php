<?php
// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session
session_start();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';
$token_valid = false;
$user_id = 0;

// Check token validity
if (isset($_GET['token']) && isset($_GET['user_id'])) {
    $token = clean_input($_GET['token']);
    $user_id = clean_input($_GET['user_id']);
    
    // Verify token and check expiry
    $sql = "SELECT * FROM users WHERE user_id = ? AND reset_token = ? AND reset_token_expiry > NOW()";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $token_valid = true;
    } else {
        $error = "Token tidak valid atau sudah kadaluarsa. Silakan request reset password baru.";
    }
} else {
    $error = "Parameter tidak valid. Silakan gunakan tautan reset password yang dikirimkan ke email Anda.";
}

// Process password reset form
if ($_SERVER["REQUEST_METHOD"] == "POST" && $token_valid) {
    $password = clean_input($_POST['password']);
    $confirm_password = clean_input($_POST['confirm_password']);
    
    // Validate password
    if (strlen($password) < 8) {
        $error = "Password harus minimal 8 karakter.";
    } elseif ($password != $confirm_password) {
        $error = "Password dan konfirmasi password tidak cocok.";
    } else {
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Update password and clear reset token
        $update_sql = "UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE user_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("si", $hashed_password, $user_id);
        
        if ($update_stmt->execute()) {
            $success = "Password berhasil diubah. Anda sekarang dapat <a href='login.php'>masuk</a> dengan password baru Anda.";
            $token_valid = false; // Hide form after successful reset
        } else {
            $error = "Terjadi kesalahan saat mengubah password. Silakan coba lagi.";
        }
    }
}

// Page title for header
$page_title = "Reset Password - LelangMobil";
?>

<?php include 'includes/header.php'; ?>

<div id="top"></div>
<section id="subheader" class="jarallax text-light">
    <img src="images/background/2.jpg" class="jarallax-img" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="subtitle wow fadeInUp mb-3">LelangMobil</div>
            </div>
            <div class="col-lg-6">
                <h2 class="wow fadeInUp mb20" data-wow-delay=".2s">Reset Password</h2>
            </div>
        </div>
    </div>
</section>

<section aria-label="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="de-box">
                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if(!empty($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <?php if($token_valid): ?>
                        <form class="form-border" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . '?token=' . $token . '&user_id=' . $user_id); ?>">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="field-set">
                                        <label>Password Baru:</label>
                                        <input type="password" name="password" class="form-control" required>
                                        <small class="text-muted">Minimal 8 karakter.</small>
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="field-set">
                                        <label>Konfirmasi Password Baru:</label>
                                        <input type="password" name="confirm_password" class="form-control" required>
                                    </div>
                                </div>
                                
                                <div class="col-lg-12">
                                    <div class="spacer-20"></div>
                                    <button class="btn-main" type="submit">Ubah Password</button>
                                </div>
                            </div>
                        </form>
                    <?php elseif(empty($success)): ?>
                        <div class="text-center">
                            <p>Kembali ke <a href="login.php">halaman login</a> atau <a href="forgot-password.php">request reset password baru</a>.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
