<?php
// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    die("Akses ditolak. Anda harus login sebagai admin untuk menjalankan script ini.");
}

// Function to run SQL from file
function run_sql_from_file($conn, $filename) {
    $queries = file_get_contents($filename);
    $result = $conn->multi_query($queries);
    
    if (!$result) {
        return "Error executing SQL: " . $conn->error;
    }
    
    // Clear results
    while ($conn->more_results() && $conn->next_result()) {
        $discard = $conn->use_result();
        if ($discard) $discard->free();
    }
    
    return "SQL executed successfully";
}

// Generate placeholder image first
require_once 'generate_placeholder.php';

// Then generate car images
require_once 'generate_car_images.php';

// Run SQL import
$sql_result = run_sql_from_file($conn, 'import_vehicles.sql');

// Update image paths in database to ensure they use the get_vehicle_image_url function
$update_image_sql = "UPDATE vehicle_images SET image_url = CONCAT('uploads/vehicles/', 
                    (SELECT LOWER(REPLACE(make, ' ', '-')) FROM vehicles WHERE vehicle_id = vehicle_images.vehicle_id), 
                    '/', image_url) 
                    WHERE image_url NOT LIKE 'uploads/%' AND image_url NOT LIKE 'images/%'";

$conn->query($update_image_sql);

// Output results
echo "<h1>LelangMobil - Import Kendaraan</h1>";
echo "<p>Status import SQL: {$sql_result}</p>";
echo "<p>Import selesai! Kendaraan telah berhasil ditambahkan ke database.</p>";
echo "<p><a href='index.php' class='btn btn-primary'>Kembali ke Halaman Utama</a></p>";
?>
