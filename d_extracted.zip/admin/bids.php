<?php
// Set page title
$page_title = "Riwayat Bid";

// Include header
include 'includes/header.php';

// Process actions if any
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $bid_id = intval($_GET['id']);
    
    // Validate bid exists
    $check_sql = "SELECT b.*, v.title, u.username 
                 FROM bids b 
                 JOIN vehicles v ON b.vehicle_id = v.vehicle_id
                 JOIN users u ON b.bidder_id = u.user_id
                 WHERE b.bid_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $bid_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $bid = $check_result->fetch_assoc();
        
        if ($action == 'delete') {
            // Only delete if it's not the winning bid
            if ($bid['is_winning'] == 0) {
                $delete_sql = "DELETE FROM bids WHERE bid_id = ?";
                $delete_stmt = $conn->prepare($delete_sql);
                $delete_stmt->bind_param("i", $bid_id);
                
                if ($delete_stmt->execute()) {
                    $success = "Bid berhasil dihapus.";
                } else {
                    $error = "Gagal menghapus bid.";
                }
            } else {
                $error = "Tidak dapat menghapus bid yang sedang menjadi pemenang. Ubah pemenang bid terlebih dahulu.";
            }
        }
    } else {
        $error = "Bid tidak ditemukan.";
    }
}

// Pagination
$items_per_page = 15;
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($current_page - 1) * $items_per_page;

// Filtering
$where_clause = "1=1"; // Default to show all bids
$params = [];
$param_types = "";

// Search by vehicle title or bidder username
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = "%" . clean_input($_GET['search']) . "%";
    $where_clause .= " AND (v.title LIKE ? OR u.username LIKE ?)";
    $params[] = $search;
    $params[] = $search;
    $param_types .= "ss";
}

// Filter by vehicle ID
if (isset($_GET['vehicle_id']) && !empty($_GET['vehicle_id'])) {
    $vehicle_id = intval($_GET['vehicle_id']);
    $where_clause .= " AND b.vehicle_id = ?";
    $params[] = $vehicle_id;
    $param_types .= "i";
}

// Filter by user ID
if (isset($_GET['user_id']) && !empty($_GET['user_id'])) {
    $user_id = intval($_GET['user_id']);
    $where_clause .= " AND b.bidder_id = ?";
    $params[] = $user_id;
    $param_types .= "i";
}

// Filter by winning bids
if (isset($_GET['winning']) && $_GET['winning'] !== '') {
    $winning = intval($_GET['winning']);
    $where_clause .= " AND b.is_winning = ?";
    $params[] = $winning;
    $param_types .= "i";
}

// Count total bids matching criteria
$count_sql = "SELECT COUNT(*) as total 
             FROM bids b 
             JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
             JOIN users u ON b.bidder_id = u.user_id 
             WHERE $where_clause";
$count_stmt = $conn->prepare($count_sql);
if (!empty($params)) {
    $count_stmt->bind_param($param_types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$count_row = $count_result->fetch_assoc();
$total_items = $count_row['total'];
$total_pages = ceil($total_items / $items_per_page);

// Get bids with pagination
$bids_sql = "SELECT b.*, v.title as vehicle_title, v.status as vehicle_status, 
             u.username as bidder_username
             FROM bids b 
             JOIN vehicles v ON b.vehicle_id = v.vehicle_id 
             JOIN users u ON b.bidder_id = u.user_id 
             WHERE $where_clause 
             ORDER BY b.bid_time DESC 
             LIMIT ?, ?";
$params[] = $offset;
$params[] = $items_per_page;
$param_types .= "ii";

$bids_stmt = $conn->prepare($bids_sql);
$bids_stmt->bind_param($param_types, ...$params);
$bids_stmt->execute();
$bids_result = $bids_stmt->get_result();

// Get vehicles for filter dropdown
$vehicles_sql = "SELECT vehicle_id, title FROM vehicles ORDER BY title";
$vehicles_result = $conn->query($vehicles_sql);

// Get users for filter dropdown
$users_sql = "SELECT user_id, username FROM users ORDER BY username";
$users_result = $conn->query($users_sql);
?>

<h1 class="mb-4">Riwayat Bid</h1>

<?php if(isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<?php if(isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<!-- Filter Form -->
<div class="de-box mb-4">
    <form action="" method="get" class="row g-3">
        <div class="col-md-3">
            <input type="text" name="search" class="form-control" placeholder="Cari judul kendaraan atau username..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        </div>
        <div class="col-md-2">
            <select name="vehicle_id" class="form-control form-select">
                <option value="">Semua Kendaraan</option>
                <?php while ($vehicle = $vehicles_result->fetch_assoc()): ?>
                    <option value="<?php echo $vehicle['vehicle_id']; ?>" <?php echo (isset($_GET['vehicle_id']) && $_GET['vehicle_id'] == $vehicle['vehicle_id']) ? 'selected' : ''; ?>>
                        <?php echo $vehicle['title']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-2">
            <select name="user_id" class="form-control form-select">
                <option value="">Semua Pengguna</option>
                <?php while ($user = $users_result->fetch_assoc()): ?>
                    <option value="<?php echo $user['user_id']; ?>" <?php echo (isset($_GET['user_id']) && $_GET['user_id'] == $user['user_id']) ? 'selected' : ''; ?>>
                        <?php echo $user['username']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-1">
            <select name="winning" class="form-control form-select">
                <option value="">Semua</option>
                <option value="1" <?php echo (isset($_GET['winning']) && $_GET['winning'] == '1') ? 'selected' : ''; ?>>Pemenang</option>
                <option value="0" <?php echo (isset($_GET['winning']) && $_GET['winning'] == '0') ? 'selected' : ''; ?>>Bukan Pemenang</option>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">Filter</button>
        </div>
        <div class="col-md-2">
            <a href="bids.php" class="btn btn-secondary w-100">Reset</a>
        </div>
    </form>
</div>

<!-- Bids Table -->
<div class="de-box">
    <div class="table-responsive">
        <table class="table table-hover admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Kendaraan</th>
                    <th>Penawar</th>
                    <th>Jumlah Bid</th>
                    <th>Waktu Bid</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($bids_result->num_rows > 0): ?>
                    <?php while ($bid = $bids_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $bid['bid_id']; ?></td>
                            <td>
                                <a href="../vehicle.php?id=<?php echo $bid['vehicle_id']; ?>" target="_blank" class="text-decoration-none">
                                    <?php echo $bid['vehicle_title']; ?>
                                </a>
                            </td>
                            <td>
                                <a href="user-detail.php?id=<?php echo $bid['bidder_id']; ?>" class="text-decoration-none">
                                    <?php echo $bid['bidder_username']; ?>
                                </a>
                            </td>
                            <td><?php echo format_currency($bid['bid_amount']); ?></td>
                            <td><?php echo date('d M Y H:i:s', strtotime($bid['bid_time'])); ?></td>
                            <td>
                                <?php if ($bid['is_winning']): ?>
                                    <span class="badge bg-success">Tertinggi</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Outbid</span>
                                <?php endif; ?>
                                
                                <?php
                                switch ($bid['vehicle_status']) {
                                    case 'upcoming':
                                        echo '<span class="badge bg-info ms-1">Akan Datang</span>';
                                        break;
                                    case 'active':
                                        echo '<span class="badge bg-primary ms-1">Aktif</span>';
                                        break;
                                    case 'ended':
                                        echo '<span class="badge bg-warning ms-1">Berakhir</span>';
                                        break;
                                    case 'sold':
                                        echo '<span class="badge bg-success ms-1">Terjual</span>';
                                        break;
                                    case 'not_sold':
                                        echo '<span class="badge bg-danger ms-1">Tidak Terjual</span>';
                                        break;
                                }
                                ?>
                            </td>
                            <td>
                                <div class="btn-group" role="group" aria-label="Bid Actions">
                                    <a href="bid-detail.php?id=<?php echo $bid['bid_id']; ?>" class="btn btn-sm btn-primary">
                                        <i class="fa fa-eye"></i> Detail
                                    </a>
                                    <?php if (!$bid['is_winning']): ?>
                                        <a href="bids.php?action=delete&id=<?php echo $bid['bid_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus bid ini?')">
                                            <i class="fa fa-trash"></i> Hapus
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">Tidak ada bid yang ditemukan</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center mt-4">
                <?php if ($current_page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo "bids.php?" . http_build_query(array_merge($_GET, ['page' => $current_page - 1])); ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                        <a class="page-link" href="<?php echo "bids.php?" . http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($current_page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo "bids.php?" . http_build_query(array_merge($_GET, ['page' => $current_page + 1])); ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
