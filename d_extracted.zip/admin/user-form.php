<?php
// Set page title (dynamic based on whether adding or editing)
$page_title = "Tambah Pengguna Baru";

// Include header
include 'includes/header.php';

// Initialize variables
$user = [
    'user_id' => 0,
    'username' => '',
    'email' => '',
    'full_name' => '',
    'phone' => '',
    'address' => '',
    'balance' => 0.00,
    'is_verified' => 0,
    'is_admin' => 0
];

// Check if editing existing user
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $user_id = intval($_GET['id']);
    
    // Get user data
    $user_sql = "SELECT * FROM users WHERE user_id = ?";
    $user_stmt = $conn->prepare($user_sql);
    $user_stmt->bind_param("i", $user_id);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    
    if ($user_result->num_rows > 0) {
        $user = $user_result->fetch_assoc();
        $page_title = "Edit Pengguna: " . $user['username'];
    } else {
        // If user not found, redirect to users list
        header("Location: users.php?error=user_not_found");
        exit;
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Clean and validate inputs
    $username = clean_input($_POST['username']);
    $email = clean_input($_POST['email']);
    $full_name = clean_input($_POST['full_name']);
    $phone = clean_input($_POST['phone']);
    $address = clean_input($_POST['address']);
    $is_verified = isset($_POST['is_verified']) ? 1 : 0;
    $is_admin = isset($_POST['is_admin']) ? 1 : 0;
    $balance = isset($_POST['balance']) ? floatval($_POST['balance']) : 0.00;
    
    // Only validate password for new users or if password field is not empty
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validate inputs
    $errors = [];
    
    if (empty($username)) {
        $errors[] = "Username harus diisi.";
    }
    
    if (empty($email)) {
        $errors[] = "Email harus diisi.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Format email tidak valid.";
    }
    
    // Check if username or email already exists (and not the same user)
    if ($user['user_id'] > 0) {
        $check_sql = "SELECT * FROM users WHERE (username = ? OR email = ?) AND user_id != ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("ssi", $username, $email, $user['user_id']);
    } else {
        $check_sql = "SELECT * FROM users WHERE username = ? OR email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("ss", $username, $email);
    }
    
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $user_exists = $check_result->fetch_assoc();
        if ($user_exists['username'] == $username) {
            $errors[] = "Username sudah digunakan oleh pengguna lain.";
        }
        if ($user_exists['email'] == $email) {
            $errors[] = "Email sudah digunakan oleh pengguna lain.";
        }
    }
    
    // Check password for new users or password change
    if ($user['user_id'] == 0 || !empty($password)) {
        if (empty($password)) {
            $errors[] = "Password harus diisi untuk pengguna baru.";
        } elseif (strlen($password) < 6) {
            $errors[] = "Password minimal 6 karakter.";
        } elseif ($password != $confirm_password) {
            $errors[] = "Konfirmasi password tidak cocok.";
        }
    }
    
    // If no errors, proceed with update or insert
    if (empty($errors)) {
        if ($user['user_id'] > 0) {
            // Prepare UPDATE statement
            if (!empty($password)) {
                // With password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $update_sql = "UPDATE users SET 
                              username = ?, 
                              email = ?, 
                              password = ?,
                              full_name = ?, 
                              phone = ?, 
                              address = ?,
                              balance = ?,
                              is_verified = ?,
                              is_admin = ?,
                              updated_at = NOW()
                              WHERE user_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param(
                    "ssssssdiii",
                    $username,
                    $email,
                    $hashed_password,
                    $full_name,
                    $phone,
                    $address,
                    $balance,
                    $is_verified,
                    $is_admin,
                    $user['user_id']
                );
            } else {
                // Without changing password
                $update_sql = "UPDATE users SET 
                              username = ?, 
                              email = ?, 
                              full_name = ?, 
                              phone = ?, 
                              address = ?,
                              balance = ?,
                              is_verified = ?,
                              is_admin = ?,
                              updated_at = NOW()
                              WHERE user_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param(
                    "ssssdiii",
                    $username,
                    $email,
                    $full_name,
                    $phone,
                    $address,
                    $balance,
                    $is_verified,
                    $is_admin,
                    $user['user_id']
                );
            }
            
            // Execute update
            if ($update_stmt->execute()) {
                // If balance changed, create a transaction record
                if ($balance != $user['balance']) {
                    $transaction_type = $balance > $user['balance'] ? 'deposit' : 'withdrawal';
                    $transaction_amount = abs($balance - $user['balance']);
                    $transaction_notes = "Penyesuaian saldo oleh admin";
                    
                    $transaction_sql = "INSERT INTO transactions (user_id, amount, type, status, notes, admin_id) 
                                       VALUES (?, ?, ?, 'completed', ?, ?)";
                    $transaction_stmt = $conn->prepare($transaction_sql);
                    $transaction_stmt->bind_param("idssi", $user['user_id'], $transaction_amount, $transaction_type, $transaction_notes, $admin_id);
                    $transaction_stmt->execute();
                }
                
                $success = "Pengguna berhasil diperbarui.";
                
                // Refresh user data
                $user_stmt->execute();
                $user_result = $user_stmt->get_result();
                $user = $user_result->fetch_assoc();
            } else {
                $error = "Gagal memperbarui pengguna: " . $conn->error;
            }
        } else {
            // Create new user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $verification_token = NULL;
            
            // If not verified, generate token
            if (!$is_verified) {
                $verification_token = md5(time() . $email);
            }
            
            $insert_sql = "INSERT INTO users (
                          username, email, password, full_name, phone, address,
                          balance, is_verified, verification_token, is_admin, created_at, updated_at
                          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param(
                "ssssssdisi",
                $username,
                $email,
                $hashed_password,
                $full_name,
                $phone,
                $address,
                $balance,
                $is_verified,
                $verification_token,
                $is_admin
            );
            
            if ($insert_stmt->execute()) {
                $new_user_id = $conn->insert_id;
                
                // If balance is not zero, create a deposit transaction
                if ($balance > 0) {
                    $transaction_sql = "INSERT INTO transactions (user_id, amount, type, status, notes, admin_id) 
                                       VALUES (?, ?, 'deposit', 'completed', ?, ?)";
                    $transaction_notes = "Saldo awal oleh admin";
                    $transaction_stmt = $conn->prepare($transaction_sql);
                    $transaction_stmt->bind_param("idsi", $new_user_id, $balance, $transaction_notes, $admin_id);
                    $transaction_stmt->execute();
                }
                
                $success = "Pengguna baru berhasil dibuat.";
                
                // Redirect to user detail page
                header("Location: user-detail.php?id=" . $new_user_id . "&success=created");
                exit;
            } else {
                $error = "Gagal membuat pengguna baru: " . $conn->error;
            }
        }
    }
}
?>

<div class="container-fluid content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><?php echo $page_title; ?></h1>
        <a href="users.php" class="btn btn-secondary">
            <i class="fa fa-arrow-left"></i> Kembali
        </a>
    </div>
    
    <?php if(isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <?php if(isset($errors) && !empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach($errors as $err): ?>
                    <li><?php echo $err; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <div class="de-box">
        <form method="post" action="">
            <div class="row mb-3">
                <div class="col-md-6">
                    <h5 class="mb-3">Informasi Akun</h5>
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">
                            <?php echo $user['user_id'] > 0 ? 'Password (Kosongkan jika tidak diubah)' : 'Password <span class="text-danger">*</span>'; ?>
                        </label>
                        <input type="password" class="form-control" id="password" name="password" <?php echo $user['user_id'] == 0 ? 'required' : ''; ?>>
                        <?php if($user['user_id'] == 0): ?>
                            <small class="text-muted">Minimal 6 karakter</small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">
                            <?php echo $user['user_id'] > 0 ? 'Konfirmasi Password (Jika diubah)' : 'Konfirmasi Password <span class="text-danger">*</span>'; ?>
                        </label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" <?php echo $user['user_id'] == 0 ? 'required' : ''; ?>>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="is_verified" name="is_verified" <?php echo $user['is_verified'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="is_verified">
                                Akun Terverifikasi
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="is_admin" name="is_admin" <?php echo $user['is_admin'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="is_admin">
                                Admin
                            </label>
                        </div>
                        <small class="text-warning">Perhatian: Memberikan akses admin berarti memberikan akses penuh ke sistem.</small>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <h5 class="mb-3">Informasi Personal</h5>
                    
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="phone" class="form-label">Nomor Telepon</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="address" class="form-label">Alamat</label>
                        <textarea class="form-control" id="address" name="address" rows="3"><?php echo htmlspecialchars($user['address']); ?></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="balance" class="form-label">Saldo (Rp)</label>
                        <input type="number" class="form-control" id="balance" name="balance" value="<?php echo $user['balance']; ?>" min="0" step="1000">
                        <?php if($user['user_id'] > 0): ?>
                            <small class="text-info">Saldo saat ini: <?php echo format_currency($user['balance']); ?></small>
                            <br>
                            <small class="text-warning">Perubahan saldo akan tercatat sebagai transaksi.</small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="border-top pt-3">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> <?php echo $user['user_id'] > 0 ? 'Simpan Perubahan' : 'Buat Pengguna'; ?>
                </button>
                
                <a href="users.php" class="btn btn-secondary ms-2">
                    <i class="fa fa-times"></i> Batal
                </a>
                
                <?php if($user['user_id'] > 0): ?>
                    <a href="user-detail.php?id=<?php echo $user['user_id']; ?>" class="btn btn-info ms-2">
                        <i class="fa fa-eye"></i> Lihat Detail
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<?php
// Include footer
include 'includes/footer.php';
?>
