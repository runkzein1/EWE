<?php
/**
 * Security Headers Implementation
 * LelangMobil Web App - Versi 2025
 * 
 * This file sets up crucial security headers to enhance the security posture
 * of the web application against common web vulnerabilities.
 */

// Protect against XSS attacks
header("X-XSS-Protection: 1; mode=block");

// Prevent MIME type sniffing
header("X-Content-Type-Options: nosniff");

// Control framing of the site (prevent clickjacking)
header("X-Frame-Options: SAMEORIGIN");

// Enable HTTP Strict Transport Security (HSTS)
header("Strict-Transport-Security: max-age=31536000; includeSubDomains");

// Content Security Policy
$csp = "default-src 'self'; " .
       "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://code.jquery.com; " .
       "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; " .
       "img-src 'self' data: https:; " .
       "font-src 'self' https://fonts.gstatic.com https://cdn.jsdelivr.net; " .
       "connect-src 'self'; " .
       "media-src 'self'; " .
       "object-src 'none'; " .
       "frame-ancestors 'self'; " .
       "form-action 'self'; " .
       "upgrade-insecure-requests;";

// Only apply CSP in production environments - can be adjusted based on environment detection
if (!isset($_GET['debug']) && !isset($_GET['dev'])) {
    header("Content-Security-Policy: " . $csp);
}

// Referrer Policy
header("Referrer-Policy: strict-origin-when-cross-origin");

// Feature Policy / Permissions Policy
$permissions_policy = "camera=(), microphone=(), geolocation=(), payment=()";
header("Permissions-Policy: " . $permissions_policy);

// Cache control for sensitive pages
function set_no_cache_headers() {
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Pragma: no-cache");
    header("Expires: 0");
}

// For sensitive pages like account pages, payments, etc.
$sensitive_pages = ['account.php', 'profile.php', 'payment.php', 'topup.php', 'withdraw.php'];
$current_page = basename($_SERVER['PHP_SELF']);

if (in_array($current_page, $sensitive_pages)) {
    set_no_cache_headers();
}
?>