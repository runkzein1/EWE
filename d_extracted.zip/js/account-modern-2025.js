/**
 * Account Modern 2025 JavaScript
 * File untuk mengatur integrasi dan interaksi berbagai komponen pada halaman account
 */

document.addEventListener('DOMContentLoaded', function() {
    // Mengaktifkan transisi antar tab
    initTabNavigation();
    
    // Mengaktifkan animasi pada dashboard
    animateDashboardElements();
    
    // Integrasi dengan transaction table
    connectTransactionComponents();
});

/**
 * Inisialisasi navigasi tab untuk halaman account
 */
function initTabNavigation() {
    const tabLinks = document.querySelectorAll('.nav-tab-item-2025');
    const tabContents = document.querySelectorAll('.tab-pane-2025');
    
    // Cek apakah ada tabs pada halaman ini
    if (tabLinks.length === 0) return;
    
    // Tambahkan event listener untuk setiap tab
    tabLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Hanya mencegah default jika ini adalah tab pada halaman yang sama
            if (link.getAttribute('data-target')) {
                e.preventDefault();
                
                // Remove active class dari semua tab links
                tabLinks.forEach(l => l.classList.remove('active'));
                
                // Add active class ke tab yang di-klik
                link.classList.add('active');
                
                // Sembunyikan semua tab content
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Tampilkan tab content yang relevan
                const target = link.getAttribute('data-target');
                document.querySelector(target).classList.add('active');
            }
        });
    });
}

/**
 * Animasi elemen dashboard pada saat load
 */
function animateDashboardElements() {
    // Animate profile header
    const profileHeader = document.querySelector('.profile-header-2025');
    if (profileHeader) {
        setTimeout(() => {
            profileHeader.classList.add('fade-in-up');
        }, 100);
    }
    
    // Animate stats dengan delay bertahap
    const stats = document.querySelectorAll('.profile-stat-item-2025');
    stats.forEach((stat, index) => {
        setTimeout(() => {
            stat.classList.add('fade-in-up');
        }, 200 + (index * 100));
    });
    
    // Animate tabs
    const tabs = document.querySelector('.tabs-container-2025');
    if (tabs) {
        setTimeout(() => {
            tabs.classList.add('fade-in-up');
        }, 300);
    }
    
    // Animate content panels
    const contentPanels = document.querySelectorAll('.tab-content-2025');
    contentPanels.forEach((panel, index) => {
        setTimeout(() => {
            panel.classList.add('fade-in-up');
        }, 400 + (index * 100));
    });
}

/**
 * Menghubungkan komponen-komponen transaction table
 */
function connectTransactionComponents() {
    // Export transactions button
    const exportBtn = document.querySelector('.tab-actions-2025 button');
    if (exportBtn) {
        exportBtn.addEventListener('click', function() {
            if (typeof exportTransactions === 'function') {
                exportTransactions();
            } else {
                console.warn('Export function not found. Make sure transaction-modern-2025.js is loaded.');
            }
        });
    }
    
    // Transaction type dan status highlight
    highlightTransactionElements();
}

/**
 * Highlight elemen-elemen penting pada tabel transaksi
 */
function highlightTransactionElements() {
    // Highlight amount lebih dari 1 juta
    const amounts = document.querySelectorAll('.transaction-amount-2025');
    
    amounts.forEach(amount => {
        const valueText = amount.querySelector('.amount-value').textContent;
        const numericValue = parseFloat(valueText.replace(/[^0-9]/g, ''));
        
        // Jika nilainya lebih dari 1 juta, tambahkan class high-value
        if (numericValue >= 1000000) {
            amount.classList.add('high-value');
        }
    });
    
    // Hover effect untuk rows
    const rows = document.querySelectorAll('.transaction-table-2025 tbody tr');
    rows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.classList.add('row-highlight');
        });
        
        row.addEventListener('mouseleave', function() {
            this.classList.remove('row-highlight');
        });
    });
}

// Fungsi utilitas untuk testing koneksi
function testConnection() {
    console.log('Account Modern 2025 JS loaded and connected successfully');
    return true;
}
