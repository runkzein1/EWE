<?php
// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';
require_once 'config/mailer.php';

$error = '';
$success = '';

// Check if user_id and token are provided
if (isset($_GET['user_id']) && isset($_GET['token'])) {
    $user_id = clean_input($_GET['user_id']);
    $token = clean_input($_GET['token']);
    
    // Check if token is valid
    $sql = "SELECT * FROM users WHERE user_id = ? AND verification_token = ? AND token_expiry > NOW() AND is_verified = 0";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Get user data
        $user = $result->fetch_assoc();
        $email = $user['email'];
        $username = $user['username'];
        
        // Valid token, verify the user
        $update_sql = "UPDATE users SET is_verified = 1, verification_token = NULL, token_expiry = NULL WHERE user_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("i", $user_id);
        
        if ($update_stmt->execute()) {
            $success = "Email berhasil diverifikasi! Sekarang Anda dapat masuk ke akun Anda.";
            
            // Send welcome email to user
            send_welcome_email($conn, $email, $username);
        } else {
            $error = "Terjadi kesalahan saat verifikasi. Silakan coba lagi nanti.";
        }
    } else {
        // Check if user is already verified
        $check_verified = "SELECT * FROM users WHERE user_id = ? AND is_verified = 1";
        $check_stmt = $conn->prepare($check_verified);
        $check_stmt->bind_param("i", $user_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $success = "Akun Anda sudah diverifikasi sebelumnya. Silakan masuk.";
        } else {
            $error = "Tautan verifikasi tidak valid atau sudah kedaluwarsa.";
        }
    }
} else {
    $error = "Parameter tidak lengkap.";
}

// Page title for header
$page_title = "Verifikasi Email - LelangMobil";
?>

<?php include 'includes/header.php'; ?>

<div id="top"></div>
<section id="subheader" class="jarallax text-light">
    <img src="images/background/2.jpg" class="jarallax-img" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="subtitle wow fadeInUp mb-3">LelangMobil</div>
            </div>
            <div class="col-lg-6">
                <h2 class="wow fadeInUp mb20" data-wow-delay=".2s">Verifikasi Email</h2>
            </div>
        </div>
    </div>
</section>

<section aria-label="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="de-box text-center" data-wow-delay=".2s">
                    <?php if(!empty($error)): ?>
                        <?php echo show_message('danger', $error); ?>
                        <p class="mt-3">Kembali ke <a href="login.php" class="text-primary">halaman login</a> atau <a href="index.php" class="text-primary">halaman utama</a>.</p>
                    <?php endif; ?>
                    
                    <?php if(!empty($success)): ?>
                        <?php echo show_message('success', $success); ?>
                        <div class="spacer-20"></div>
                        <a href="login.php" class="btn-main">Masuk Sekarang</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
