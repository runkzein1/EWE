<?php
// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Page title
$page_title = "Cara Kerja Lelang - LelangMobil";
?>

<?php include 'includes/header.php'; ?>

<div id="top"></div>
<section id="subheader" class="jarallax text-light">
    <img src="images/background/2.jpg" class="jarallax-img" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="subtitle wow fadeInUp mb-3">LelangMobil</div>
            </div>
            <div class="col-lg-6">
                <h2 class="wow fadeInUp mb20" data-wow-delay=".2s">Cara Kerja</h2>
            </div>
        </div>
    </div>
</section>

<section aria-label="section" class="pt60">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <h2 class="text-center mb-5">Bagaimana Proses Lelang Bekerja?</h2>
                
                <div class="de-box p-4 mb-5">
                    <div class="row align-items-center">
                        <div class="col-lg-3 text-center">
                            <div class="de-process">
                                <span class="p-number bg-color text-light">1</span>
                                <h4>Pendaftaran</h4>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <h3>Daftar Akun</h3>
                            <p>Langkah pertama untuk mulai mengikuti lelang di platform kami adalah mendaftar akun. Daftar dengan mengisi formulir pendaftaran dan verifikasi email Anda. Proses verifikasi email memastikan bahwa hanya pengguna yang serius yang dapat berpartisipasi dalam lelang kendaraan.</p>
                            <ul class="list-style-2">
                                <li>Isi formulir pendaftaran dengan data diri yang valid</li>
                                <li>Periksa email Anda untuk link verifikasi</li>
                                <li>Klik link untuk mengaktifkan akun</li>
                                <li>Lengkapi profil Anda dengan data yang lengkap</li>
                            </ul>
                            <a href="register.php" class="btn-main">Daftar Sekarang</a>
                        </div>
                    </div>
                </div>
                
                <div class="de-box p-4 mb-5">
                    <div class="row align-items-center">
                        <div class="col-lg-3 text-center">
                            <div class="de-process">
                                <span class="p-number bg-color text-light">2</span>
                                <h4>Top-up Saldo</h4>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <h3>Isi Saldo Akun</h3>
                            <p>Sebelum Anda dapat melakukan penawaran dalam lelang, Anda perlu mengisi saldo ke akun Anda. Saldo ini akan digunakan untuk menjamin penawaran Anda dan memastikan bahwa hanya penawaran yang serius yang diterima.</p>
                            <ul class="list-style-2">
                                <li>Login ke akun Anda</li>
                                <li>Kunjungi halaman "Akun Saya" dan pilih menu "Top-up Saldo"</li>
                                <li>Transfer dana ke salah satu rekening bank resmi LelangMobil</li>
                                <li>Isi formulir konfirmasi dengan detail pembayaran</li>
                                <li>Admin akan memverifikasi pembayaran Anda dan menambahkan saldo ke akun</li>
                            </ul>
                            <?php if (is_logged_in()): ?>
                                <a href="account.php#topup" class="btn-main">Top-up Saldo</a>
                            <?php else: ?>
                                <a href="login.php" class="btn-main">Login untuk Top-up</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="de-box p-4 mb-5">
                    <div class="row align-items-center">
                        <div class="col-lg-3 text-center">
                            <div class="de-process">
                                <span class="p-number bg-color text-light">3</span>
                                <h4>Telusuri Lelang</h4>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <h3>Cari Mobil Impian</h3>
                            <p>Jelajahi berbagai kendaraan yang tersedia di platform kami. Anda dapat melihat detail lengkap, foto, spesifikasi, dan riwayat setiap kendaraan. Gunakan filter untuk menemukan kendaraan yang sesuai dengan preferensi Anda.</p>
                            <ul class="list-style-2">
                                <li>Kunjungi halaman "Lelang Aktif"</li>
                                <li>Gunakan filter untuk mempersempit pencarian</li>
                                <li>Periksa detail kendaraan secara seksama</li>
                                <li>Baca spesifikasi dan riwayat kendaraan</li>
                                <li>Lihat semua foto yang tersedia</li>
                            </ul>
                            <a href="auctions.php" class="btn-main">Lihat Lelang</a>
                        </div>
                    </div>
                </div>
                
                <div class="de-box p-4 mb-5">
                    <div class="row align-items-center">
                        <div class="col-lg-3 text-center">
                            <div class="de-process">
                                <span class="p-number bg-color text-light">4</span>
                                <h4>Ajukan Bid</h4>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <h3>Ajukan Penawaran</h3>
                            <p>Setelah menemukan kendaraan yang Anda minati, Anda dapat mengajukan penawaran (bid). Setiap penawaran harus melebihi penawaran tertinggi saat ini dengan minimal 5%. Dana akan ditahan dari saldo Anda selama penawaran aktif.</p>
                            <ul class="list-style-2">
                                <li>Masuk ke halaman detail kendaraan</li>
                                <li>Periksa harga penawaran tertinggi saat ini</li>
                                <li>Masukkan jumlah penawaran Anda (minimal 5% lebih tinggi dari penawaran sebelumnya)</li>
                                <li>Konfirmasi penawaran Anda</li>
                                <li>Dana akan ditahan dari saldo akun Anda</li>
                            </ul>
                            <p>Catatan: Jika penawaran Anda dikalahkan, dana yang ditahan akan otomatis dikembalikan ke saldo akun Anda.</p>
                        </div>
                    </div>
                </div>
                
                <div class="de-box p-4 mb-5">
                    <div class="row align-items-center">
                        <div class="col-lg-3 text-center">
                            <div class="de-process">
                                <span class="p-number bg-color text-light">5</span>
                                <h4>Menangkan Lelang</h4>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <h3>Menjadi Pemenang</h3>
                            <p>Jika penawaran Anda adalah yang tertinggi saat lelang berakhir, selamat! Anda menjadi pemenang lelang. Tim LelangMobil akan menghubungi Anda untuk proses selanjutnya.</p>
                            <ul class="list-style-2">
                                <li>Penawaran tertinggi saat lelang berakhir adalah pemenang</li>
                                <li>Anda akan menerima notifikasi jika memenangkan lelang</li>
                                <li>Tim LelangMobil akan menghubungi Anda untuk proses selanjutnya</li>
                                <li>Dana yang ditahan akan digunakan sebagai pembayaran</li>
                                <li>Anda perlu melunasi sisa pembayaran (jika ada)</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="de-box p-4 mb-5">
                    <div class="row align-items-center">
                        <div class="col-lg-3 text-center">
                            <div class="de-process">
                                <span class="p-number bg-color text-light">6</span>
                                <h4>Penyelesaian</h4>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <h3>Selesaikan Transaksi</h3>
                            <p>Setelah memenangkan lelang, Anda perlu menyelesaikan transaksi dalam waktu yang ditentukan. Tim LelangMobil akan membantu Anda dalam proses pengambilan kendaraan dan penyelesaian dokumen.</p>
                            <ul class="list-style-2">
                                <li>Lunasi sisa pembayaran (jika ada)</li>
                                <li>Jadwalkan waktu pengambilan kendaraan</li>
                                <li>Periksa kendaraan sesuai dengan deskripsi</li>
                                <li>Selesaikan dokumen kepemilikan</li>
                                <li>Nikmati kendaraan baru Anda!</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="spacer-single"></div>
                
                <div class="text-center">
                    <h3>Punya Pertanyaan Lainnya?</h3>
                    <p>Jangan ragu untuk menghubungi tim layanan pelanggan kami jika Anda memiliki pertanyaan lebih lanjut.</p>
                    <a href="contact.php" class="btn-main">Hubungi Kami</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
