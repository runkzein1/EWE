<?php
/**
 * Bid Processor API
 * Endpoint untuk memproses bid kendaraan
 * Digunakan oleh vehicle-auction-2025.js
 */

// Start session
session_start();

// Headers
header('Content-Type: application/json');

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Anda harus login untuk melakukan bid',
        'redirect' => 'login.php'
    ]);
    exit;
}

// Pastikan request menggunakan metode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method'
    ]);
    exit;
}

// Pastikan data yang dibutuhkan tersedia
$requiredFields = ['vehicle_id', 'bid_amount'];
$missingFields = [];

foreach ($requiredFields as $field) {
    if (!isset($_POST[$field]) || empty($_POST[$field])) {
        $missingFields[] = $field;
    }
}

if (!empty($missingFields)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Missing required fields: ' . implode(', ', $missingFields)
    ]);
    exit;
}

// Load koneksi database
require_once '../config/database.php';

// Sanitasi input
$vehicle_id = filter_var($_POST['vehicle_id'], FILTER_SANITIZE_NUMBER_INT);
$bid_amount = filter_var(
    preg_replace('/[^0-9]/', '', $_POST['bid_amount']), 
    FILTER_SANITIZE_NUMBER_INT
);
$user_id = $_SESSION['user_id'];

try {
    // Periksa apakah lelang masih aktif
    $auction_check_sql = "SELECT vehicle_id, current_bid, auction_end, status FROM vehicles WHERE vehicle_id = ?";
    $auction_check_stmt = $conn->prepare($auction_check_sql);
    $auction_check_stmt->bind_param('i', $vehicle_id);
    $auction_check_stmt->execute();
    $auction_result = $auction_check_stmt->get_result();
    
    if (!$auction_result || $auction_result->num_rows == 0) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Kendaraan tidak ditemukan'
        ]);
        exit;
    }
    
    $vehicle = $auction_result->fetch_assoc();
    
    // Periksa status lelang
    if ($vehicle['status'] != 'active') {
        echo json_encode([
            'status' => 'error',
            'message' => 'Lelang tidak aktif'
        ]);
        exit;
    }
    
    // Periksa waktu lelang
    $now = new DateTime();
    $auction_end = new DateTime($vehicle['auction_end']);
    
    if ($now > $auction_end) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Lelang telah berakhir'
        ]);
        exit;
    }
    
    // Periksa apakah bid lebih tinggi dari current_bid
    if ($bid_amount <= $vehicle['current_bid']) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Jumlah bid harus lebih tinggi dari harga saat ini'
        ]);
        exit;
    }
    
    // Periksa saldo wallet
    $wallet_sql = "SELECT balance FROM wallets WHERE user_id = ?";
    $wallet_stmt = $conn->prepare($wallet_sql);
    $wallet_stmt->bind_param('i', $user_id);
    $wallet_stmt->execute();
    $wallet_result = $wallet_stmt->get_result();
    
    if (!$wallet_result || $wallet_result->num_rows == 0) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Wallet tidak ditemukan'
        ]);
        exit;
    }
    
    $wallet = $wallet_result->fetch_assoc();
    
    if ($wallet['balance'] < $bid_amount) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Saldo wallet tidak mencukupi'
        ]);
        exit;
    }
    
    // Mulai transaction
    $conn->begin_transaction();
    
    try {
        // Periksa struktur tabel untuk menentukan nama kolom
        $column_check_sql = "SHOW COLUMNS FROM bids LIKE 'bidder_id'";
        $column_check_stmt = $conn->prepare($column_check_sql);
        $column_check_stmt->execute();
        
        if ($column_check_stmt->get_result()->num_rows > 0) {
            // Gunakan bidder_id jika kolom ada
            $insert_bid_sql = "INSERT INTO bids (vehicle_id, bidder_id, bid_amount, created_at) VALUES (?, ?, ?, NOW())";
        } else {
            // Gunakan user_id sebagai fallback
            $insert_bid_sql = "INSERT INTO bids (vehicle_id, user_id, bid_amount, created_at) VALUES (?, ?, ?, NOW())";
        }
        
        $insert_bid_stmt = $conn->prepare($insert_bid_sql);
        $insert_bid_stmt->bind_param('iid', $vehicle_id, $user_id, $bid_amount);
        $insert_bid_stmt->execute();
        
        // Update current_bid di vehicles
        $update_vehicle_sql = "UPDATE vehicles SET current_bid = ? WHERE vehicle_id = ?";
        $update_vehicle_stmt = $conn->prepare($update_vehicle_sql);
        $update_vehicle_stmt->bind_param('di', $bid_amount, $vehicle_id);
        $update_vehicle_stmt->execute();
        
        // Insert ke transactions untuk hold amount
        $insert_transaction_sql = "INSERT INTO transactions (user_id, type, amount, status, reference, notes, created_at) 
                                  VALUES (?, 'bid', ?, 'pending', ?, 'Bid amount hold for auction', NOW())";
        $reference = "BID-" . $vehicle_id . "-" . time();
        $insert_transaction_stmt = $conn->prepare($insert_transaction_sql);
        $insert_transaction_stmt->bind_param('ids', $user_id, $bid_amount, $reference);
        $insert_transaction_stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        // Sukses
        echo json_encode([
            'status' => 'success',
            'message' => 'Bid berhasil',
            'data' => [
                'vehicle_id' => $vehicle_id,
                'bid_amount' => $bid_amount,
                'timestamp' => date('Y-m-d H:i:s')
            ]
        ]);
        
    } catch (Exception $e) {
        // Rollback jika ada error
        $conn->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    // Error handling
    error_log("Error in bid-processor.php: " . $e->getMessage());
    
    echo json_encode([
        'status' => 'error',
        'message' => 'Terjadi kesalahan saat memproses bid'
    ]);
}
