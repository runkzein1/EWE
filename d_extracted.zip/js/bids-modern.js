/**
 * Bids Modern JS - LelangMobil
 * Modul JavaScript untuk halaman bid (bids-menu.php)
 * Versi: 1.0 (6 Mei 2025)
 */

document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi variabel dan elemen
    const bidStatusFilter = document.getElementById('bidStatusFilter');
    const bidHistoryTable = document.getElementById('bidHistoryTable');
    const bidHistoryRows = document.querySelectorAll('.bid-history-row');
    const refreshActiveBidsBtn = document.getElementById('refreshActiveBidsBtn');
    const countdownTimers = document.querySelectorAll('.countdown-timer');
    
    // Filter bid history berdasarkan status
    if (bidStatusFilter && bidHistoryRows.length > 0) {
        bidStatusFilter.addEventListener('change', function() {
            const selectedStatus = this.value;
            
            bidHistoryRows.forEach(row => {
                if (!selectedStatus || row.dataset.status === selectedStatus) {
                    row.style.display = 'table-row';
                } else {
                    row.style.display = 'none';
                }
            });
            
            // Tampilkan pesan jika tidak ada data yang sesuai dengan filter
            const visibleRows = document.querySelectorAll('.bid-history-row[style="display: table-row"]');
            const noDataRow = document.querySelector('.no-data-row');
            
            if (visibleRows.length === 0) {
                if (!noDataRow) {
                    const tbody = bidHistoryTable.querySelector('tbody');
                    const tr = document.createElement('tr');
                    tr.className = 'no-data-row';
                    tr.innerHTML = '<td colspan="6" class="text-center py-3">Tidak ada data bid dengan status ini.</td>';
                    tbody.appendChild(tr);
                } else {
                    noDataRow.style.display = 'table-row';
                }
            } else if (noDataRow) {
                noDataRow.style.display = 'none';
            }
        });
    }
    
    // Refresh active bids
    if (refreshActiveBidsBtn) {
        refreshActiveBidsBtn.addEventListener('click', function() {
            // Tambahkan animasi spin pada ikon
            const icon = this.querySelector('i');
            icon.classList.add('fa-spin');
            
            // Simulasi refresh (dalam implementasi sebenarnya akan menggunakan AJAX)
            setTimeout(() => {
                // Setelah refresh selesai, hentikan animasi
                icon.classList.remove('fa-spin');
                
                // Tampilkan notifikasi refresh berhasil
                const notification = document.createElement('div');
                notification.className = 'alert alert-success alert-dismissible fade show';
                notification.innerHTML = '<i class="fa fa-check-circle me-2"></i>Data bid berhasil diperbarui.<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                
                // Tambahkan notifikasi ke halaman
                const container = document.querySelector('.card-body');
                if (container) {
                    container.prepend(notification);
                    
                    // Hapus notifikasi setelah 3 detik
                    setTimeout(() => {
                        notification.remove();
                    }, 3000);
                }
            }, 1000);
        });
    }
    
    // Update countdown timers
    function updateCountdowns() {
        countdownTimers.forEach(timer => {
            const endTime = new Date(timer.dataset.end);
            const now = new Date();
            
            // Hitung selisih waktu
            let diff = endTime - now;
            
            // Jika sudah berakhir
            if (diff <= 0) {
                timer.innerHTML = '<span class="text-danger">Berakhir</span>';
                timer.classList.remove('urgent');
                return;
            }
            
            // Konversi ke format hari, jam, menit, detik
            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            diff -= days * (1000 * 60 * 60 * 24);
            
            const hours = Math.floor(diff / (1000 * 60 * 60));
            diff -= hours * (1000 * 60 * 60);
            
            const minutes = Math.floor(diff / (1000 * 60));
            diff -= minutes * (1000 * 60);
            
            const seconds = Math.floor(diff / 1000);
            
            // Format waktu yang tersisa
            let timeString = '';
            
            if (days > 0) {
                timeString = days + ' hari ' + hours + ' jam';
            } else if (hours > 0) {
                timeString = hours + ' jam ' + minutes + ' menit';
            } else if (minutes > 0) {
                timeString = minutes + ' menit ' + seconds + ' detik';
            } else {
                timeString = seconds + ' detik';
            }
            
            // Update tampilan dan tambahkan class urgent jika waktu tersisa kurang dari 5 menit
            timer.innerHTML = timeString;
            
            if (days === 0 && hours === 0 && minutes < 5) {
                timer.classList.add('urgent');
            } else {
                timer.classList.remove('urgent');
            }
        });
    }
    
    // Inisialisasi update countdown
    if (countdownTimers.length > 0) {
        updateCountdowns();
        
        // Update setiap detik
        setInterval(updateCountdowns, 1000);
    }
    
    // Refresh Status Bid
    function refreshBidStatus() {
        // Dalam implementasi sebenarnya, ini akan menggunakan AJAX untuk memperbarui status bid dari server
        console.log('Refreshing bid status...');
        
        // Simulasi pembaruan status
        document.querySelectorAll('.active-bid-card').forEach(card => {
            // Jika ini adalah implementasi nyata, bagian ini akan menggunakan data dari server
            // Untuk simulasi, kita hanya memperbarui waktu
            const timer = card.querySelector('.countdown-timer');
            if (timer) {
                updateCountdowns();
            }
        });
    }
    
    // Refresh bid status setiap 30 detik
    setInterval(refreshBidStatus, 30000);
    
    // Inisialisasi tooltip
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    if (typeof bootstrap !== 'undefined' && tooltipTriggerList.length > 0) {
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
});
