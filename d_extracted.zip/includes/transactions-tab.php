<?php
/**
 * File untuk Tab Transactions yang sudah diperbaiki menggunakan helper functions
 * Untuk menghindari PHP errors dan warnings
 */

// Pastikan user_id sudah didefinisikan
if (!isset($user_id) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
}

// Inisialisasi variabel transaksi
$total_deposit = 0;
$total_withdrawal = 0;
$hold_amount = 0;

// Query untuk mengambil transaksi user dengan error handling yang lebih baik
try {
    $transactions_sql = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($transactions_sql);
    $stmt->bind_param("i", $user_id);
    
    // Set timeout untuk mencegah query terlalu lama
    $timeout_start = microtime(true);
    $execute_result = $stmt->execute();
    
    // Cek jika query terlalu lama atau gagal
    if (!$execute_result || (microtime(true) - $timeout_start) > 3) {
        throw new Exception("Query timeout or failed");
    }
    
    $transactions_result = $stmt->get_result();
} catch (Throwable $e) {
    error_log("Error fetching transactions: " . $e->getMessage());
    echo '<div class="modern-alert modern-alert-danger mb-4">
            <i class="fa fa-exclamation-circle"></i>
            <div>Error mengambil data transaksi. Silakan coba lagi nanti.</div>
          </div>';
    // Tetapkan null agar kode berikutnya tidak mencoba mengakses hasil
    $transactions_result = null;
}

// Fungsi helper sederhana jika yang asli tidak tersedia
if (!function_exists('is_valid_result')) {
    function is_valid_result($result) {
        return ($result && $result instanceof mysqli_result && $result->num_rows > 0);
    }
}

if (!function_exists('get_value')) {
    function get_value($array, $key, $default = '') {
        return isset($array[$key]) ? $array[$key] : $default;
    }
}

// Hitung total deposit, withdrawal, dan hold amount
if ($transactions_result && $transactions_result instanceof mysqli_result && $transactions_result->num_rows > 0) {
    while ($tx = $transactions_result->fetch_assoc()) {
        $type = isset($tx['type']) ? $tx['type'] : '';
        $status = isset($tx['status']) ? $tx['status'] : '';
        $amount = isset($tx['amount']) ? (float)$tx['amount'] : 0;
        
        if ($type == 'deposit' && $status == 'completed') {
            $total_deposit += $amount;
        } elseif ($type == 'withdrawal' && $status == 'completed') {
            $total_withdrawal += $amount;
        } elseif ($type == 'bid_hold') {
            $hold_amount += (float)get_value($tx, 'amount', 0);
        }
    }
}
?>

<!-- Tab Transactions -->
<div class="tab-pane fade" id="transactions" role="tabpanel" aria-labelledby="transactions-tab">
    <h3 class="mb-4 animated-heading"><i class="fa fa-history me-2"></i>Riwayat Transaksi</h3>
    
    <!-- Filter & Search Panel -->
    <div class="premium-card mb-4">
        <div class="card-body">
            <div class="row align-items-end">
                <div class="col-md-3 mb-3 mb-md-0">
                    <label for="transaction-type" class="form-label">Jenis Transaksi</label>
                    <select class="form-select" id="transaction-type">
                        <option value="">Semua Transaksi</option>
                        <option value="deposit">Top Up / Deposit</option>
                        <option value="withdrawal">Penarikan Dana</option>
                        <option value="bid_hold">Hold Bid</option>
                        <option value="bid_release">Release Bid</option>
                    </select>
                </div>
                <div class="col-md-3 mb-3 mb-md-0">
                    <label for="transaction-status" class="form-label">Status</label>
                    <select class="form-select" id="transaction-status">
                        <option value="">Semua Status</option>
                        <option value="completed">Selesai</option>
                        <option value="pending">Menunggu</option>
                        <option value="rejected">Ditolak</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3 mb-md-0">
                    <label for="transaction-date" class="form-label">Periode</label>
                    <div class="d-flex">
                        <input type="date" class="form-control me-2" id="date-from" placeholder="Dari">
                        <input type="date" class="form-control" id="date-to" placeholder="Sampai">
                    </div>
                </div>
                <div class="col-md-2">
                    <button class="btn premium-btn premium-btn-primary w-100">
                        <i class="fa fa-filter me-2"></i>Filter
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Summary Stats Cards with Premium Auto Theme -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card ultra-glass stat-card js-tilt-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center tilt-child">
                        <div class="ultra-stat-icon blue">
                            <i class="fa fa-exchange-alt"></i>
                        </div>
                        <div class="ultra-stat-content ms-3">
                            <div class="ultra-stat-value count-number" data-target="<?php echo $transactions_result->num_rows; ?>">
                                <?php echo $transactions_result->num_rows; ?>
                            </div>
                            <div class="ultra-stat-label">Total Transaksi</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card ultra-glass stat-card js-tilt-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center tilt-child">
                        <div class="ultra-stat-icon teal">
                            <i class="fa fa-arrow-down"></i>
                        </div>
                        <div class="ultra-stat-content ms-3">
                            <div class="ultra-stat-value text-gradient">Rp <?php echo safe_format_currency($total_deposit); ?></div>
                            <div class="ultra-stat-label">Total Deposit</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card ultra-glass stat-card js-tilt-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center tilt-child">
                        <div class="ultra-stat-icon purple">
                            <i class="fa fa-arrow-up"></i>
                        </div>
                        <div class="ultra-stat-content ms-3">
                            <div class="ultra-stat-value">Rp <?php echo safe_format_currency($total_withdrawal); ?></div>
                            <div class="ultra-stat-label">Total Penarikan</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card ultra-glass stat-card js-tilt-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center tilt-child">
                        <div class="ultra-stat-icon gold">
                            <i class="fa fa-lock"></i>
                        </div>
                        <div class="ultra-stat-content ms-3">
                            <div class="ultra-stat-value">Rp <?php echo safe_format_currency($hold_amount); ?></div>
                            <div class="ultra-stat-label">Dana Tertahan</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Transactions Table -->
    <div class="premium-card">
        <div class="card-body p-0">
            <?php if (!is_valid_result($transactions_result) || $transactions_result->num_rows == 0): ?>
            <div class="p-4 text-center">
                <div class="empty-state">
                    <i class="fa fa-receipt fa-3x text-muted mb-3"></i>
                    <h5>Belum Ada Transaksi</h5>
                    <p class="text-muted">Belum ada riwayat transaksi yang tercatat.</p>
                    <a href="topup.php" class="btn premium-btn premium-btn-primary mt-3">
                        <i class="fa fa-plus-circle me-2"></i>Top Up Sekarang
                    </a>
                </div>
            </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-premium table-hover">
                    <thead>
                        <tr>
                            <th>ID Transaksi</th>
                            <th>Tanggal</th>
                            <th>Jenis</th>
                            <th>Jumlah</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Reset pointer dengan validasi
                        if (is_valid_result($transactions_result)) {
                            $transactions_result->data_seek(0);
                            while ($transaction = $transactions_result->fetch_assoc()): 
                                // Get type info
                                list($type_icon, $type_label) = get_transaction_type_info($transaction);
                        ?>
                        <tr>
                            <td><span class="badge premium-badge premium-badge-dark">#<?php echo get_value($transaction, 'transaction_id', 'N/A'); ?></span></td>
                            <td><?php echo get_formatted_date($transaction, 'created_at', 'd M Y H:i'); ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <span class="icon-circle me-2 <?php echo get_value($transaction, 'type', ''); ?>">
                                        <i class="fa <?php echo $type_icon; ?>"></i>
                                    </span>
                                    <?php echo $type_label; ?>
                                </div>
                            </td>
                            <td class="fw-bold <?php echo (get_value($transaction, 'type') == 'deposit' || get_value($transaction, 'type') == 'bid_release') ? 'text-success' : 'text-danger'; ?>">
                                <?php echo (get_value($transaction, 'type') == 'deposit' || get_value($transaction, 'type') == 'bid_release') ? '+' : '-'; ?>
                                Rp <?php echo safe_format_currency(get_value($transaction, 'amount', 0)); ?>
                            </td>
                            <td>
                                <?php echo get_transaction_status_badge($transaction); ?>
                            </td>
                            <td>
                                <div class="notes-truncate">
                                    <?php echo get_value($transaction, 'notes', '-'); ?>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex">
                                    <button type="button" class="btn premium-btn premium-btn-primary btn-sm me-2" data-bs-toggle="modal" data-bs-target="#transactionModal<?php echo get_value($transaction, 'transaction_id'); ?>">
                                        <i class="fa fa-eye"></i>
                                    </button>
                                    
                                    <?php if (get_value($transaction, 'status') == 'pending' && get_value($transaction, 'type') == 'deposit'): ?>
                                    <a href="upload-payment.php?id=<?php echo get_value($transaction, 'transaction_id'); ?>" class="btn premium-btn premium-btn-success btn-sm">
                                        <i class="fa fa-upload"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php 
                            endwhile; 
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div><!-- Akhir tab transactions -->
