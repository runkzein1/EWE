<?php
/**
 * Modern Profile Page
 * LelangMobil Web App - Versi 2025
 */

// Aktifkan error reporting dan logging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 90);

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';
$user_id = $_SESSION['user_id'];

// Get user information
try {
    $user_sql = "SELECT * FROM users WHERE user_id = ?";
    $user_stmt = $conn->prepare($user_sql);
    $user_stmt->bind_param("i", $user_id);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    $user = $user_result->fetch_assoc();
} catch (Throwable $e) {
    die("Error fetching user data: " . $e->getMessage());
}

// Process Profile Update request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update_profile') {
    // Validasi input
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if (empty($full_name) || empty($email)) {
        $error = "Nama dan email tidak boleh kosong.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid.";
    } else {
        // Check if email already exists for different user
        $check_sql = "SELECT * FROM users WHERE email = ? AND user_id != ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("si", $email, $user_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $error = "Email sudah digunakan oleh akun lain.";
        } else {
            // Update profile
            $update_sql = "UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("sssi", $full_name, $email, $phone, $user_id);

            if ($update_stmt->execute()) {
                $success = "Profil berhasil diperbarui.";

                // Update local user data
                $user['full_name'] = $full_name;
                $user['email'] = $email;
                $user['phone'] = $phone;
            } else {
                $error = "Gagal memperbarui profil: " . $conn->error;
            }
        }
    }
}

// Process Change Password request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'change_password') {
    // Validasi input
    $current_password = trim($_POST['current_password'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = "Semua field password harus diisi.";
    } elseif ($new_password !== $confirm_password) {
        $error = "Password baru dan konfirmasi password harus sama.";
    } elseif (strlen($new_password) < 8) {
        $error = "Password baru minimal harus 8 karakter.";
    } else {
        // Check current password
        $password_sql = "SELECT password FROM users WHERE user_id = ?";
        $password_stmt = $conn->prepare($password_sql);
        $password_stmt->bind_param("i", $user_id);
        $password_stmt->execute();
        $password_result = $password_stmt->get_result();
        $password_data = $password_result->fetch_assoc();

        if (password_verify($current_password, $password_data['password'])) {
            // Hash new password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Update password
            $update_sql = "UPDATE users SET password = ? WHERE user_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("si", $hashed_password, $user_id);

            if ($update_stmt->execute()) {
                $success = "Password berhasil diubah.";
            } else {
                $error = "Gagal mengubah password: " . $conn->error;
            }
        } else {
            $error = "Password saat ini tidak valid.";
        }
    }
}

// Process Profile Image Upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'upload_profile_image') {
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/jpg', 'image/png'];
        $max_size = 5 * 1024 * 1024; // 5MB

        if (!in_array($_FILES['profile_image']['type'], $allowed_types)) {
            $error = "Jenis file tidak didukung. Gunakan format JPG, JPEG, atau PNG.";
        } elseif ($_FILES['profile_image']['size'] > $max_size) {
            $error = "Ukuran file terlalu besar. Maksimal 5MB.";
        } else {
            // Create upload directory if it doesn't exist
            $upload_dir = 'uploads/profile/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            // Generate unique filename
            $file_extension = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
            $filename = 'profile_' . $user_id . '_' . time() . '.' . $file_extension;
            $target_file = $upload_dir . $filename;

            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_file)) {
                // Update user profile image in database
                $update_sql = "UPDATE users SET profile_photo = ? WHERE user_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("si", $filename, $user_id);

                if ($update_stmt->execute()) {
                    $success = "Foto profil berhasil diperbarui.";
                    $user['profile_photo'] = $filename;
                } else {
                    $error = "Gagal memperbarui foto profil: " . $conn->error;
                }
            } else {
                $error = "Gagal mengunggah file. Silakan coba lagi.";
            }
        }
    } else {
        $error = "Gagal mengunggah file. Silakan coba lagi.";
    }
}

// Get user statistics
$total_bids = 0;
$total_wins = 0;

// Get total bids
$bids_count_sql = "SELECT COUNT(*) as total FROM bids WHERE bidder_id = ?";
$bids_count_stmt = $conn->prepare($bids_count_sql);
$bids_count_stmt->bind_param("i", $user_id);
$bids_count_stmt->execute();
$bids_count_result = $bids_count_stmt->get_result();
$total_bids = $bids_count_result->fetch_assoc()['total'] ?? 0;

// Get total wins menggunakan query langsung tanpa fungsi helper dan dengan struktur database yang benar
try {
    // Set timeout untuk mencegah query terlalu lama
    $timeout_start = microtime(true);

    $wins_sql = "SELECT COUNT(*) as total
               FROM bids
               JOIN vehicles ON bids.vehicle_id = vehicles.vehicle_id
               WHERE bids.bidder_id = ?
               AND vehicles.status = 'ended'
               AND bids.bid_amount = vehicles.current_bid";
    $wins_stmt = $conn->prepare($wins_sql);
    $wins_stmt->bind_param("i", $user_id);
    $execute_result = $wins_stmt->execute();

    // Cek jika query timeout atau gagal
    if (!$execute_result || (microtime(true) - $timeout_start) > 3) {
        throw new Exception("Query timeout or failed");
    }

    $wins_result = $wins_stmt->get_result();
    $total_wins = $wins_result->fetch_assoc()['total'] ?? 0;
} catch (Throwable $e) {
    error_log("Error getting wins count in profile-modern.php: " . $e->getMessage());
    $total_wins = 0;
}

// Aktifkan flag untuk halaman dashboard dan tema modern
$page_title = "Profil Saya";
$is_dashboard_page = true;
$use_modern_dashboard = true;

// Include header
if (file_exists('/home/lelang/public_html/includes/header.php')) {
    include('/home/lelang/public_html/includes/header.php');
} else {
    include("includes/header.php");
}
?>

<!-- Main Content Container -->
<div class="container-fluid py-5">
    <?php if (!empty($success)): ?>
    <div class="modern-alert modern-alert-success mb-4 fade-in">
        <i class="fa fa-check-circle"></i>
        <div><?php echo $success; ?></div>
    </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
    <div class="modern-alert modern-alert-danger mb-4 fade-in">
        <i class="fa fa-exclamation-circle"></i>
        <div><?php echo $error; ?></div>
    </div>
    <?php endif; ?>

    <div class="row">
        <!-- Sidebar Navigation -->
        <div class="col-lg-3">
            <?php
            try {
                if (file_exists('/home/lelang/public_html/includes/account-navbar.php')) {
                    include('/home/lelang/public_html/includes/account-navbar.php');
                } else {
                    include("includes/account-navbar.php");
                }
            } catch (Throwable $e) {
                echo '<div class="modern-alert modern-alert-danger mb-4">
                    <i class="fa fa-exclamation-circle"></i>
                    <div>Error memuat navigasi: ' . htmlspecialchars($e->getMessage()) . '</div>
                </div>';

                // Tampilkan navbar alternatif simple
                echo '<div class="list-group mb-4">
                    <a href="account.php" class="list-group-item list-group-item-action">Dashboard</a>
                    <a href="profile-modern.php" class="list-group-item list-group-item-action active">Profil</a>
                    <a href="bids-modern.php" class="list-group-item list-group-item-action">Riwayat Bid</a>
                    <a href="transactions-modern.php" class="list-group-item list-group-item-action">Transaksi</a>
                </div>';

                error_log("Error including account-navbar.php in profile-modern.php: " . $e->getMessage());
            }
            ?>
        </div>

        <!-- Main Content -->
        <div class="col-lg-9">
            <h2 class="mb-4 fade-in"><?php echo $page_title; ?></h2>

            <div class="row">
                <!-- Profile Card -->
                <div class="col-lg-4">
                    <div class="modern-card fade-in">
                        <div class="modern-card-body p-0">
                            <div class="modern-profile-card">
                                <form method="post" action="" enctype="multipart/form-data" id="profileImageForm">
                                    <input type="hidden" name="action" value="upload_profile_image">
                                    <div class="profile-image-container">
                                        <img src="<?php echo !empty($user['profile_photo']) ? 'uploads/profile/'.$user['profile_photo'] : 'images/avatar-placeholder.jpg'; ?>"
                                             alt="<?php echo htmlspecialchars($user['username']); ?>"
                                             class="modern-profile-avatar"
                                             onerror="this.src='images/avatar-placeholder.jpg';">
                                        <div class="profile-image-overlay">
                                            <label for="profile_image" class="mb-0">
                                                <i class="fa fa-camera"></i>
                                            </label>
                                            <input type="file" id="profile_image" name="profile_image" class="d-none" onchange="document.getElementById('profileImageForm').submit()">
                                        </div>
                                    </div>
                                </form>

                                <h3 class="modern-profile-name"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h3>
                                <p class="modern-profile-info">
                                    <i class="fa fa-envelope me-2"></i><?php echo htmlspecialchars($user['email']); ?>
                                    <?php if (!empty($user['phone'])): ?>
                                    <br><i class="fa fa-phone me-2"></i><?php echo htmlspecialchars($user['phone']); ?>
                                    <?php endif; ?>
                                </p>

                                <div class="modern-profile-stats">
                                    <div class="modern-profile-stat">
                                        <div class="modern-profile-stat-value"><?php echo number_format($total_bids, 0, ',', '.'); ?></div>
                                        <div class="modern-profile-stat-label">Total Bid</div>
                                    </div>
                                    <div class="modern-profile-stat">
                                        <div class="modern-profile-stat-value"><?php echo number_format($total_wins, 0, ',', '.'); ?></div>
                                        <div class="modern-profile-stat-label">Menang</div>
                                    </div>
                                    <div class="modern-profile-stat">
                                        <div class="modern-profile-stat-value"><?php echo isset($user['join_date']) ? date('Y', strtotime($user['join_date'])) : date('Y'); ?></div>
                                        <div class="modern-profile-stat-label">Bergabung</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modern-card mt-4 fade-in">
                        <div class="modern-card-header">
                            <h3 class="modern-card-title"><i class="fa fa-shield-alt"></i> Keamanan</h3>
                        </div>
                        <div class="modern-card-body">
                            <div class="d-grid gap-2">
                                <button type="button" class="modern-button modern-button-primary" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                                    <i class="fa fa-key me-2"></i>Ubah Password
                                </button>

                                <?php if (!isset($user['email_verified']) || !$user['email_verified']): ?>
                                <a href="resend_verification.php" class="modern-button modern-button-warning">
                                    <i class="fa fa-envelope me-2"></i>Verifikasi Email
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Profile Form -->
                <div class="col-lg-8">
                    <div class="modern-card fade-in">
                        <div class="modern-card-header">
                            <h3 class="modern-card-title"><i class="fa fa-user-edit"></i> Edit Profil</h3>
                        </div>
                        <div class="modern-card-body">
                            <form method="post" action="" id="editProfileForm">
                                <input type="hidden" name="action" value="update_profile">

                                <div class="modern-form-group">
                                    <label class="modern-form-label" for="username">Username</label>
                                    <input type="text" class="modern-form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" disabled>
                                    <small class="text-muted">Username tidak dapat diubah.</small>
                                </div>

                                <div class="modern-form-group">
                                    <label class="modern-form-label" for="full_name">Nama Lengkap</label>
                                    <input type="text" class="modern-form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
                                </div>

                                <div class="modern-form-group">
                                    <label class="modern-form-label" for="email">Email</label>
                                    <input type="email" class="modern-form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                                </div>

                                <div class="modern-form-group">
                                    <label class="modern-form-label" for="phone">Nomor Telepon</label>
                                    <input type="tel" class="modern-form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                </div>

                                <div class="mt-4 text-end">
                                    <button type="submit" class="modern-button modern-button-primary">
                                        <i class="fa fa-save me-2"></i>Simpan Perubahan
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="modern-card mt-4 fade-in">
                        <div class="modern-card-header">
                            <h3 class="modern-card-title"><i class="fa fa-info-circle"></i> Informasi Akun</h3>
                        </div>
                        <div class="modern-card-body">
                            <table class="modern-table">
                                <tbody>
                                    <tr>
                                        <td width="40%"><strong>Status Akun</strong></td>
                                        <td>
                                            <?php if (isset($user['status']) && $user['status'] == 'active'): ?>
                                                <span class="modern-badge modern-badge-success"><i class="fa fa-check-circle"></i> Aktif</span>
                                            <?php else: ?>
                                                <span class="modern-badge modern-badge-danger"><i class="fa fa-times-circle"></i> Tidak Aktif</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Status Email</strong></td>
                                        <td>
                                            <?php if (isset($user['email_verified']) && $user['email_verified']): ?>
                                                <span class="modern-badge modern-badge-success"><i class="fa fa-check"></i> Terverifikasi</span>
                                            <?php else: ?>
                                                <span class="modern-badge modern-badge-warning"><i class="fa fa-clock"></i> Belum Terverifikasi</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Tanggal Bergabung</strong></td>
                                        <td><?php echo isset($user['join_date']) ? date('d F Y', strtotime($user['join_date'])) : '-'; ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Login Terakhir</strong></td>
                                        <td><?php echo isset($user['last_login']) ? date('d F Y H:i', strtotime($user['last_login'])) : '-'; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="changePasswordModalLabel"><i class="fa fa-lock me-2"></i>Ubah Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="changePasswordForm" action="" method="post">
                    <input type="hidden" name="action" value="change_password">

                    <div class="modern-form-group">
                        <label class="modern-form-label" for="current_password">Password Saat Ini</label>
                        <input type="password" class="modern-form-control" id="current_password" name="current_password" required>
                    </div>

                    <div class="modern-form-group">
                        <label class="modern-form-label" for="new_password">Password Baru</label>
                        <input type="password" class="modern-form-control" id="new_password" name="new_password" required>
                        <small class="text-muted">Password minimal 8 karakter</small>
                    </div>

                    <div class="modern-form-group">
                        <label class="modern-form-label" for="confirm_password">Konfirmasi Password Baru</label>
                        <input type="password" class="modern-form-control" id="confirm_password" name="confirm_password" required>
                    </div>

                    <div class="mt-4 text-end">
                        <button type="button" class="modern-button modern-button-outline" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="modern-button modern-button-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
.profile-image-container {
    position: relative;
    width: 120px;
    height: 120px;
    margin: 0 auto 1rem;
}

.profile-image-overlay {
    position: absolute;
    bottom: 0;
    right: 0;
    background: var(--primary-color);
    color: white;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.profile-image-overlay:hover {
    background: var(--secondary-color);
    transform: scale(1.1);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Password confirmation validation
    const newPasswordInput = document.getElementById('new_password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    const changePasswordForm = document.getElementById('changePasswordForm');

    if (changePasswordForm && newPasswordInput && confirmPasswordInput) {
        changePasswordForm.addEventListener('submit', function(e) {
            if (newPasswordInput.value !== confirmPasswordInput.value) {
                e.preventDefault();
                alert('Password baru dan konfirmasi password tidak cocok.');
            }
        });
    }
});
</script>

<?php
if (file_exists('/home/lelang/public_html/includes/footer.php')) {
    include('/home/lelang/public_html/includes/footer.php');
} else {
    include("includes/footer.php");
}
?>
