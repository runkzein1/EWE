<?php
/**
 * User Verification Functions
 * LelangMobil Web App - Versi 2025
 * 
 * This file contains functions for verifying and repairing user data integrity
 * Version: 1.0
 */

/**
 * Verifies if a user exists and creates a basic record if not
 * @param object $conn Database connection
 * @param int $user_id User ID to verify
 * @return array User data or fallback data
 */
function verify_and_repair_user($conn, $user_id) {
    if (!is_numeric($user_id) || $user_id <= 0) {
        error_log("Invalid user ID: {$user_id}");
        return null;
    }
    
    // Check if user exists
    $check_query = "SELECT COUNT(*) as count FROM users WHERE user_id = ?";
    $check_stmt = $conn->prepare($check_query);
    
    if (!$check_stmt) {
        error_log("Failed to prepare user verification query: " . $conn->error);
        return null;
    }
    
    $check_stmt->bind_param("i", $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $count = $check_result->fetch_assoc()['count'];
    
    if ($count > 0) {
        // User exists, no repair needed
        return true;
    }
    
    // User doesn't exist, create placeholder
    error_log("User ID {$user_id} not found in database. Attempting to create placeholder.");
    
    // Generate username based on user ID
    $username = "user_" . $user_id . "_repaired_" . substr(md5(time()), 0, 6);
    $hashed_password = password_hash("reset" . time() . rand(1000, 9999), PASSWORD_DEFAULT);
    $email = "user{$user_id}@lelangmobil-recovery.com";
    
    // Create placeholder user
    $insert_query = "INSERT INTO users (user_id, username, email, password, full_name, is_verified) 
                    VALUES (?, ?, ?, ?, ?, 0) 
                    ON DUPLICATE KEY UPDATE username = VALUES(username)";
    
    $insert_stmt = $conn->prepare($insert_query);
    
    if (!$insert_stmt) {
        error_log("Failed to prepare user repair query: " . $conn->error);
        return null;
    }
    
    $full_name = "User {$user_id} (Auto-Generated)";
    
    $insert_stmt->bind_param("issss", $user_id, $username, $email, $hashed_password, $full_name);
    $success = $insert_stmt->execute();
    
    if (!$success) {
        error_log("Failed to create user placeholder: " . $insert_stmt->error);
        return null;
    }
    
    error_log("Created placeholder for user {$user_id}");
    return true;
}

/**
 * Gets minimal user data or creates a fallback
 * @param object $conn Database connection
 * @param int $user_id User ID
 * @return array User data (even if fallback)
 */
function get_minimal_user_data($conn, $user_id) {
    // Verifies and potentially repairs
    $verified = verify_and_repair_user($conn, $user_id);
    
    if (!$verified) {
        // Create fallback data structure
        return [
            'user_id' => $user_id,
            'username' => 'user_' . $user_id . '_recovery',
            'email' => 'recovery_' . $user_id . '@lelangmobil.com',
            'full_name' => 'Recovered User ' . $user_id,
            'balance' => 0.00,
            'is_verified' => 0,
            'is_admin' => 0,
            '_is_fallback' => true
        ];
    }
    
    // Try to get the actual data
    $query = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    
    if (!$stmt) {
        error_log("Failed to prepare minimal user query: " . $conn->error);
        return null;
    }
    
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $user_data = $result->fetch_assoc();
        return $user_data;
    }
    
    // This shouldn't happen if verify_and_repair worked properly
    error_log("Unexpected error: User verified but not found in database");
    return null;
}
