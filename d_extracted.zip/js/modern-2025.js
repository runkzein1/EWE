/**
 * LelangMobil Modern 2025 JavaScript
 * Adds interactivity and modern effects to the website
 */
document.addEventListener('DOMContentLoaded', function() {
    // Add ripple effect to buttons
    const buttons = document.querySelectorAll('.btn-2025');
    buttons.forEach(btn => {
        btn.addEventListener('mousedown', function(e) {
            const x = e.clientX - e.target.getBoundingClientRect().left;
            const y = e.clientY - e.target.getBoundingClientRect().top;
            
            const ripple = document.createElement('span');
            ripple.classList.add('ripple-effect');
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
    
    // Handle preset amount buttons in topup.php
    const presetButtons = document.querySelectorAll('.preset-amount');
    const amountInput = document.getElementById('amount');
    
    if (presetButtons.length > 0 && amountInput) {
        presetButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                presetButtons.forEach(b => b.classList.remove('active'));
                
                // Add active class to clicked button
                this.classList.add('active');
                
                // Get amount and format for display
                const amount = this.getAttribute('data-amount');
                
                // Format number with thousand separator
                const formattedAmount = parseInt(amount).toLocaleString('id-ID');
                
                // Set value in input
                amountInput.value = formattedAmount;
            });
        });
    }
    
    // Animate cards on scroll
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.fade-in-up-2025:not(.visible)');
        
        elements.forEach(el => {
            const rect = el.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            if (rect.top < windowHeight - 100) {
                el.classList.add('visible');
            }
        });
    };
    
    // Run once on load
    animateOnScroll();
    
    // Add scroll event listener
    window.addEventListener('scroll', animateOnScroll);
    
    // Format currency inputs
    const currencyInputs = document.querySelectorAll('input[data-type="currency"]');
    currencyInputs.forEach(input => {
        input.addEventListener('input', function() {
            // Remove non-digit characters
            let value = this.value.replace(/[^0-9]/g, '');
            
            // Format with thousand separator
            if (value) {
                value = parseInt(value).toLocaleString('id-ID');
            }
            
            this.value = value;
        });
    });
    
    // Add smooth hover effect to modern cards
    const modernCards = document.querySelectorAll('.card-2025');
    modernCards.forEach(card => {
        card.addEventListener('mousemove', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            // Calculate rotation and perspective based on mouse position
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 20;
            const rotateY = (centerX - x) / 20;
            
            this.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
        });
    });
});
