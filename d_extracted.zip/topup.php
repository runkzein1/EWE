<?php
// Aktifkan error reporting dan logging untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Set ke 0 di production

// Atur timeout eksekusi agar tidak loading berulang
set_time_limit(10); // 10 detik maksimum
ini_set('max_execution_time', 10);

// Auto redirect jika loading terlalu lama
header("Refresh: 15;url=error.php?reason=timeout&page=topup");

// Set error handler untuk menangkap error fatal
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("Error in topup.php: [$errno] $errstr in $errfile:$errline");
    if (in_array($errno, [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        header("Location: error.php?reason=" . urlencode($errstr));
        exit;
    }
    return true;
});

// Include database connection and functions
require_once 'config/database.php';
require_once 'config/functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$error_messages = [];
$success_message = '';

// Get user information
$user_sql = "SELECT * FROM users WHERE user_id = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Data bank yang tersedia
$banks = [
    ["code" => "bca", "name" => "Bank Central Asia (BCA)", "icon" => "fa-university", "account" => "8800 123 456", "holder" => "PT Lelang Mobil Indonesia"],
    ["code" => "bni", "name" => "Bank Negara Indonesia (BNI)", "icon" => "fa-university", "account" => "0123 456 789", "holder" => "PT Lelang Mobil Indonesia"],
    ["code" => "bri", "name" => "Bank Rakyat Indonesia (BRI)", "icon" => "fa-university", "account" => "0123 4567 8901 2345", "holder" => "PT Lelang Mobil Indonesia"],
    ["code" => "mandiri", "name" => "Bank Mandiri", "icon" => "fa-university", "account" => "123 00 1234567 8", "holder" => "PT Lelang Mobil Indonesia"],
    ["code" => "cimb", "name" => "CIMB Niaga", "icon" => "fa-university", "account" => "800 123 456 700", "holder" => "PT Lelang Mobil Indonesia"],
    ["code" => "permata", "name" => "Bank Permata", "icon" => "fa-university", "account" => "123 456 7890", "holder" => "PT Lelang Mobil Indonesia"],
    ["code" => "gopay", "name" => "GoPay", "icon" => "fa-wallet", "account" => "0812 3456 7890", "holder" => "PT Lelang Mobil Indonesia"],
    ["code" => "ovo", "name" => "OVO", "icon" => "fa-wallet", "account" => "0812 3456 7890", "holder" => "PT Lelang Mobil Indonesia"],
    ["code" => "dana", "name" => "DANA", "icon" => "fa-wallet", "account" => "0812 3456 7890", "holder" => "PT Lelang Mobil Indonesia"]
];

// Proses permintaan top-up
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_topup'])) {
    try {
        // Get post data dengan validasi
        if (!isset($_POST['amount']) || empty($_POST['amount'])) {
            throw new Exception('Jumlah top-up harus diisi');
        }
        
        $amount = preg_replace('/[^0-9]/', '', $_POST['amount']); // Remove non-numeric characters
        $bank_code = isset($_POST['bank_code']) ? clean_input($_POST['bank_code']) : '';
        $notes = isset($_POST['notes']) ? clean_input($_POST['notes']) : '';
        
        // Validasi jumlah dengan pengecekan lebih ketat
        if (empty($amount) || !is_numeric($amount)) {
            throw new Exception('Jumlah top-up tidak valid');
        }
        
        if ((int)$amount < 50000) {
            throw new Exception('Jumlah top-up minimal Rp 50.000');
        }
        
        if ((int)$amount > 100000000) { // Batas maksimum 100 juta
            throw new Exception('Jumlah top-up maksimal Rp 100.000.000');
        }
        
        // Validasi bank dengan pencarian yang lebih efisien
        $valid_bank = false;
        $bank_names = array_column($banks, 'name', 'code');
        
        if (!array_key_exists($bank_code, $bank_names)) {
            throw new Exception('Metode pembayaran yang dipilih tidak valid');
        }
        
        // Set timeout untuk operasi insert database
        $timeout_start = microtime(true);
        
        // Generate unique reference number
        $reference = 'TOP' . date('YmdHis') . substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 6);
        
        // Buat transaksi dalam blok try-catch terpisah untuk handling error database
        try {
            // Disable AUTOCOMMIT untuk memastikan transaksi atomic
            $conn->autocommit(FALSE);
            
            // Create transaction record
            $sql = "INSERT INTO transactions (user_id, amount, type, status, payment_method, reference_number, notes) VALUES (?, ?, 'deposit', 'pending', ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            
            if (!$stmt) {
                throw new Exception("Prepare statement error: " . $conn->error);
            }
            
            $stmt->bind_param("idsss", $user_id, $amount, $bank_code, $reference, $notes);
            
            // Execute dengan timeout check
            $execute_success = $stmt->execute();
            
            if (!$execute_success) {
                throw new Exception("Execute statement error: " . $stmt->error);
            }
            
            // Cek waktu eksekusi
            if ((microtime(true) - $timeout_start) > 5) { // Lebih dari 5 detik
                throw new Exception("Database operation timeout");
            }
            
            $transaction_id = $stmt->insert_id;
            
            // Commit jika semua berhasil
            $conn->commit();
            
            // Log transaksi berhasil
            error_log("Topup request created successfully: User ID {$user_id}, Amount {$amount}, Transaction ID {$transaction_id}");
            
            // Set session message dan redirect
            $_SESSION['success_message'] = 'Permintaan top-up berhasil dibuat. Silakan lakukan pembayaran dan upload bukti pembayaran.';
            header("Location: upload-payment.php?id=" . $transaction_id);
            exit;
            
        } catch (Throwable $db_error) {
            // Rollback jika terjadi error
            $conn->rollback();
            error_log("Database error in topup.php: " . $db_error->getMessage());
            throw new Exception('Terjadi kesalahan database saat memproses transaksi');
        } finally {
            // Reset autocommit mode
            $conn->autocommit(TRUE);
        }
    } catch (Throwable $e) {
        // Tangkap semua exception dan error
        error_log("Error in topup.php processing: " . $e->getMessage());
        $error_messages[] = $e->getMessage();
    }
}

// Set page title and include header
$page_title = "Top Up Saldo";
$use_modern_2025 = true; // Flag untuk menggunakan style modern 2025
include 'includes/header.php';
?>

<!-- Custom CSS for Top Up page with Modern 2025 style -->
<link rel="stylesheet" href="css/modern-account.css">
<link rel="stylesheet" href="css/transaction-style.css">
<link rel="stylesheet" href="css/topup-withdraw.css">
<link rel="stylesheet" href="css/modern-2025.css">

<div class="container mt-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <!-- Main Card -->
            <div class="card premium-card topup-card">
                <div class="card-header">
                    <h3 class="mb-0"><i class="fas fa-plus-circle float me-2"></i>Top Up Saldo</h3>
                    <div class="lightning-effect"></div>
                </div>
                
                <div class="card-body">
                    <?php if (!empty($error_messages)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul class="mb-0">
                                <?php foreach ($error_messages as $error): ?>
                                    <li><?php echo $error; ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success_message)): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo $success_message; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <div class="topup-balance-card">
                        <div class="balance-info">
                            <div class="balance-label">Saldo Anda</div>
                            <div class="balance-amount">Rp <?php echo number_format($user['balance'], 0, ',', '.'); ?></div>
                        </div>
                        <div class="balance-decoration">
                            <div class="circle-1"></div>
                            <div class="circle-2"></div>
                            <div class="circle-3"></div>
                            <div class="circle-4"></div>
                        </div>
                    </div>
                    
                    <form action="topup.php" method="post" id="topupForm">
                        <div class="section-title">
                            <span class="section-number">1</span>
                            <h4>Pilih Metode Pembayaran</h4>
                        </div>
                        
                        <div class="payment-methods-container">
                            <div class="row">
                                <?php foreach ($banks as $bank): ?>
                                <div class="col-md-4 col-6">
                                    <div class="payment-method" data-bank="<?php echo $bank['code']; ?>">
                                        <input type="radio" name="bank_code" value="<?php echo $bank['code']; ?>" class="d-none" <?php echo $bank['code'] === 'bca' ? 'checked' : ''; ?>>
                                        <div class="payment-method-inner">
                                            <div class="payment-icon">
                                                <i class="fas <?php echo $bank['icon']; ?>"></i>
                                            </div>
                                            <div class="payment-name"><?php echo $bank['name']; ?></div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="section-title">
                            <span class="section-number">2</span>
                            <h4>Pilih Jumlah Top Up</h4>
                        </div>
                        
                        <div class="amount-presets-container">
                            <div class="row">
                                <div class="col-md-4 col-6">
                                    <div class="amount-preset" data-amount="100000">
                                        <div class="amount-preset-inner">
                                            Rp 100.000
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-6">
                                    <div class="amount-preset" data-amount="500000">
                                        <div class="amount-preset-inner">
                                            Rp 500.000
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-6">
                                    <div class="amount-preset" data-amount="1000000">
                                        <div class="amount-preset-inner">
                                            Rp 1.000.000
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-6">
                                    <div class="amount-preset" data-amount="2500000">
                                        <div class="amount-preset-inner">
                                            Rp 2.500.000
                            </div>
                        </div>
                    </div>
                    
                    <form method="post" action="topup.php">
                        <div class="mb-4">
                            <label for="amount" class="form-label">Jumlah Top Up</label>
                            <div class="input-group input-group-2025">
                                <span class="input-group-text">Rp</span>
                                <input type="text" class="form-control form-control-2025" id="amount" name="amount" placeholder="100.000" required>
                            </div>
                            <div class="form-text">Minimal Rp 50.000</div>
                        </div>
                        
                        <!-- Preset amounts untuk mempermudah pemilihan -->
                        <div class="preset-amounts mb-4">
                            <div class="d-flex flex-wrap gap-2">
                                <button type="button" class="btn btn-outline-primary btn-2025 preset-amount" data-amount="100000">Rp 100.000</button>
                                <button type="button" class="btn btn-outline-primary btn-2025 preset-amount" data-amount="500000">Rp 500.000</button>
                                <button type="button" class="btn btn-outline-primary btn-2025 preset-amount" data-amount="1000000">Rp 1.000.000</button>
                                <button type="button" class="btn btn-outline-primary btn-2025 preset-amount" data-amount="5000000">Rp 5.000.000</button>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label for="bank_code" class="form-label">Metode Pembayaran</label>
                            <select class="form-select form-control-2025" id="bank_code" name="bank_code" required>
                                <option value="" selected disabled>Pilih Metode Pembayaran</option>
                                <?php foreach($banks as $bank): ?>
                                <option value="<?php echo htmlspecialchars($bank['code']); ?>"><?php echo htmlspecialchars($bank['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-4">
                            <label for="notes" class="form-label">Catatan (Opsional)</label>
                            <textarea class="form-control form-control-2025" id="notes" name="notes" rows="2" placeholder="Catatan tambahan untuk transaksi ini"></textarea>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" name="request_topup" class="btn btn-primary btn-2025">
                                <i class="fas fa-plus-circle me-2"></i>Buat Permintaan Top Up
                            </button>
                            <a href="account.php" class="btn btn-outline-secondary btn-2025">
                                <i class="fas fa-arrow-left me-2"></i>Kembali
                            </a>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="topup-info-card mt-4">
                <div class="info-header">
                    <i class="fas fa-info-circle"></i>
                    <h5>Informasi Top Up</h5>
                </div>
                <div class="info-content">
                    <ol>
                        <li>Pilih metode pembayaran yang diinginkan.</li>
                        <li>Masukkan jumlah yang ingin di-top up.</li>
                        <li>Setelah mengklik "Lanjutkan Top Up", Anda akan diarahkan ke halaman upload bukti pembayaran.</li>
                        <li>Lakukan pembayaran sesuai dengan instruksi yang diberikan.</li>
                        <li>Upload bukti pembayaran yang valid.</li>
                        <li>Tunggu verifikasi dari admin (1x24 jam kerja).</li>
                        <li>Setelah terverifikasi, saldo Anda akan bertambah secara otomatis.</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Format currency input
    const amountInput = document.querySelector('.amount-input');
    const formatCurrency = (value) => {
        value = value.replace(/\D/g, '');
        if (value === '') return '';
        return new Intl.NumberFormat('id-ID').format(value);
    };
    
    amountInput.addEventListener('input', function(e) {
        this.value = formatCurrency(this.value);
    });
    
    // Payment Method Selection
    const paymentMethods = document.querySelectorAll('.payment-method');
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            // Update visual selection
            paymentMethods.forEach(m => m.classList.remove('active'));
            this.classList.add('active');
            
            // Check the radio button
            const radio = this.querySelector('input[type="radio"]');
            radio.checked = true;
            
            // Update payment info card
            updatePaymentInfo(this.dataset.bank);
        });
    });
    
    // Amount Preset Selection
    const amountPresets = document.querySelectorAll('.amount-preset');
    amountPresets.forEach(preset => {
        preset.addEventListener('click', function() {
            // Update visual selection
            amountPresets.forEach(p => p.classList.remove('active'));
            this.classList.add('active');
            
            // Update amount input
            const amount = parseInt(this.dataset.amount);
            amountInput.value = formatCurrency(amount.toString());
        });
    });
    
    // Initialize default payment info
    const defaultBank = document.querySelector('.payment-method[data-bank="bca"]');
    defaultBank.classList.add('active');
    updatePaymentInfo('bca');
    
    // Initialize default amount preset
    const defaultAmountPreset = document.querySelector('.amount-preset[data-amount="100000"]');
    defaultAmountPreset.classList.add('active');
    
    // Function to update payment info card
    function updatePaymentInfo(bankCode) {
        const bankInfo = <?php echo json_encode($banks); ?>.find(bank => bank.code === bankCode);
        if (!bankInfo) return;
        
        const paymentInfoCard = document.getElementById('paymentInfoCard');
        
        let html = `
            <div class="bank-info">
                <div class="bank-logo">
                    <i class="fas ${bankInfo.icon} fa-2x"></i>
                </div>
                <div class="bank-details">
                    <h5>${bankInfo.name}</h5>
                    <div class="account-details">
                        <div class="account-number">${bankInfo.account}</div>
                        <div class="account-holder">${bankInfo.holder}</div>
                    </div>
                </div>
            </div>
            <div class="payment-instructions">
                <h6><i class="fas fa-info-circle me-2"></i>Instruksi Pembayaran:</h6>
                <ol>
                    <li>Lakukan pembayaran ke rekening di atas.</li>
                    <li>Pastikan jumlah transfer sesuai dengan jumlah top up yang diinginkan.</li>
                    <li>Simpan bukti pembayaran untuk diupload pada halaman berikutnya.</li>
                </ol>
            </div>
        `;
        
        paymentInfoCard.innerHTML = html;
    }
    
    // Ripple effect for buttons
    const buttons = document.querySelectorAll('.topup-submit-btn');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            const x = e.clientX - e.target.getBoundingClientRect().left;
            const y = e.clientY - e.target.getBoundingClientRect().top;
            
            const ripple = document.createElement('span');
            ripple.classList.add('ripple');
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>
